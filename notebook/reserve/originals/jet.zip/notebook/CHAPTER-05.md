# Capítulo 5 — Number theory

> Registo histórico desta entrega. Para os contratos e alterações posteriores,
> ver [REVISION-ALGORITHMS.md](REVISION-ALGORITHMS.md).

Estado desta entrega: capítulos 1–5 implementados. As entregas anteriores
em CHAPTERS-01-02.md, CHAPTER-03.md e CHAPTER-04.md são registos históricos.
Continuam em vigor as regras de `NOTEBOOK-RULES.md`.

## Conteúdo impresso

- GCD/LCM: funções da biblioteca padrão, zero e teste de overflow antes
  da multiplicação; sem reimplementar o que já existe em C++.
- `ExtGCD.h`: Euclides estendido para int/ll signed; coeficientes de Bézout
  e gcd não negativo. Exclui o mínimo signed nos dois argumentos.
  As notas incluem existência, parametrização e limites diofantinos.
- `ModPower.h`, partilhado com Numerical: modMul e modPow templated;
  multiplicação em unsigned 128 bits, módulo positivo até todo uint64.
  A potência normaliza bases signed negativas. Usar base e módulo do
  mesmo tipo, ou indicar o tipo explicitamente na instanciação.
- `ModInv.h`: inverso para módulo signed >1, incluindo composto;
  optional vazio se não existir. Fermat fica numa nota com as condições.
- `GeneralCRT.h`: merge de duas congruências com módulos positivos;
  retorna (resíduo normalizado, LCM), (-1,0) se incompatível e (0,-1)
  se o LCM exceder LLONG_MAX. Incompatibilidade é verificada primeiro.
- `SPF.h`: menor fator primo em [0,lim); fatorização para 1<=x<lim.
- `TrialDivision.h`: fatorização simples, com p<=n/p para evitar overflow.
- `Prime64.h`: Miller–Rabin determinístico para todo unsigned de 64 bits.
- `Factor64.h`: Pollard Rho com reinícios e fatorização completa de n>=1.
- `Divisors.h`: enumeração de divisores a partir de fatores primos.
  Quantidade, soma e totiente ficam como fórmulas/notas curtas.

SPF, trial division e Pollard devolvem fatores ordenados com multiplicidade,
aceites diretamente por divisors. A lista de divisores não é ordenada.
Para n=1, fatores vazios, divisores {1}, tau=sigma=phi=1.

## Integração e limites

`content/numerical/ModPower.h` é a única implementação partilhada de
multiplicação/exponenciação modular entre os novos capítulos. O capítulo5
remete para o header impresso no 4, evitando duplicação. Foram repetidos
os testes de Numerical após esta generalização.

Não foram alterados os headers legados de Number theory, pois outros
capítulos ainda os podem usar. Já não são impressos neste capítulo:
log/raiz modular, modular sum, frações contínuas, raízes primitivas,
triplos pitagóricos, Möbius e peneiras adicionais não pertencem à seleção.
Os capítulos 1–3 e 6 em diante, e os estilos globais, são preservados.

A complexidade de Pollard é esperada, não uma garantia de tempo máximo.
Aritmética modular cobre uint64; CRT/inverso usam long long. Não confundir
estes domínios. Sigma pode exceder 64 bits mesmo quando n cabe.

## Reproduzir

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-05.sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-04.sh
```

Requer GNU++20 e Boost (apenas nos testes); BOOST_INCLUDEDIR pode indicar
um diretório alternativo dos headers. ASan/UBSan e STL debug ficam ativos;
LeakSanitizer é desligado neste ambiente por incompatibilidade com ptrace.

Resultados e contagens: `validation/chapter-05-tests.log`.
A regressão do helper partilhado está em
`validation/chapter-04-regression-ch05.log`.
PDF, hashes e preservação do formato: `validation/chapter-05.json`.
