# Capítulo 6 — Combinatorial

Estado desta entrega: capítulos 1–6 implementados/revistos.
Regras em NOTEBOOK-RULES.md; capítulos 7 em diante continuam por rever.

## Seleção e implementação

- Fatoriais, binomiais e multinomiais: definições e limites exatos curtos;
  `Binomial.h` calcula coeficientes exatos, `ModComb.h` prepara f/iv e C
  módulo primo. Multinomial reutiliza produto de binomiais ou f/iv.
  Pascal fica como recorrência curta, incluindo módulo composto.
- Inclusão–exclusão: fórmula, termo vazio, sinais e custo dos termos.
- Stars and bars: soluções não negativas/positivas, caixas vazias e
  transformação conjunta dos limites inferiores e superiores.
- Catalan: fórmula, diferença de binomiais, recorrência, reconhecimento
  e condições de divisão modular; sem biblioteca adicional.
- `PermCycles.h`: apenas comprimentos dos ciclos. Paridade, mínimo de
  trocas arbitrárias e ordem por LCM ficam como fórmulas.

Não se imprimem IntPerm, a tabela extensa de fatoriais, derangements,
Burnside, Lucas, partições, Bernoulli, Stirling, Eulerian, Bell ou árvores
rotuladas. Os ficheiros legados permanecem intactos no ZIP.

## Contratos

- `binom<T=ll>(ll n,ll k)`: n>=0; k<0 ou k>n devolve zero. O resultado
  deve caber em T. GCD cancela o denominador antes da multiplicação,
  evitando overflow intermédio quando a resposta cabe. Suporta cpp_int
  sem incluir Boost no header. O custo de inteiros grandes depende dos bits.
- `ModComb<T=ll>(int lim,T prime)`: p primo, 1<=lim<=p. Índices [0,lim);
  `C(n,k)` exige 0<=n<lim e devolve zero para k inválido. f/iv são públicos.
  Reutiliza exatamente ModPower.h do capítulo 4, sem modificar dependências.
  Tipos integrais até 64 bits, com aritmética modular larga partilhada.
- `cycleLengths(const vi& p)`: p é uma permutação válida de [0,n),
  incluindo vazia; resultado em qualquer ordem. Sem operações extra.
- Nas fórmulas, saltar resíduos negativos antes de chamar binom.
  Para Catalan via ModComb, 2n<lim<=p; usar a forma por diferença não
  elimina este limite. Binomiais exatos podem exceder o valor de Catalan.

## Testes

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-06.sh
```

Requer GNU++20 e Boost apenas para os oráculos dos testes.
BOOST_INCLUDEDIR pode indicar o diretório dos headers Boost.
LeakSanitizer está desligado neste ambiente por ptrace; ASan/UBSan e
STL debug permanecem ativos. Compilação com warnings tratados como erros.

Por configuração (release e debug com sanitizers):

- Integração de todos os headers selecionados dos capítulos 2–6 com o
  preâmbulo real de Contest.
- Coeficientes: 51296 casos exatos, 210770 modulares, 29524 permutações
  distintas e 281734 verificações independentes. Oráculos Pascal aditivo,
  produto descendente cpp_int e enumeração de palavras com repetições.
  Inclui limites int/ll/ull, argumentos junto LLONG_MAX, cpp_int e primos
  de 64 bits certificados nos testes do capítulo 5.
- Permutações: 46847 casos, incluindo todas até 8 elementos; 512159
  períodos de órbitas independentes, 46835 paridades por inversões,
  46835 contagens de trocas para ordenar, 46237 ordens por composição
  repetida e 12 padrões conhecidos, incluindo 100000 elementos.
- Fórmulas: 38883 famílias de conjuntos, 3182 distribuições por caixas,
  1001 verificações de Catalan. Enumeração independente de interseções,
  distribuições limitadas e palavras de parênteses; recorrência exata
  e redução em módulos compostos.

Estas contagens têm granularidades diferentes; não são somadas como
casos independentes. Resultados: validation/chapter-06-tests.log.
O estilo global e o conteúdo dos outros capítulos foram preservados.
