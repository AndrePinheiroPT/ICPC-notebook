# Substituição ModPower -> ModPow

Base desta revisão: o notebook.zip enviado em 28/09/2026. As alterações do utilizador já presentes nesse ZIP, incluindo Dijkstra e a seleção dos capítulos, foram preservadas.

## Código e dependências

- `content/numerical/ModPower.h` foi substituído por `content/numerical/ModPow.h`. O corpo de `modpow(ll b,ll e)` e a constante global são os originais do KACTL: módulo fixo 1000000007, sem templates nem multiplicação de 128 bits nesta função.
- A variante com módulo variável e a multiplicação segura ficam em `content/number-theory/ModMulLL.h`: `modpow(b,e,m)` e `modmul(a,b,m)`. São genéricas e preservam os contratos anteriores de tipos até 64 bits e normalização de bases negativas. Usam produto unsigned de 128 bits, sem conditional_t nem aproximações por long double.
- `ModPow.h` inclui esse helper, permitindo que todos os consumidores antigos de ModPower incluam agora ModPow. GaussMod, NTT, Prime64, Factor64 e ModComb foram atualizados para os nomes modpow/modmul. Cada algoritmo continua a usar o seu próprio módulo.
- `content/number-theory/ModPow.h`, o caminho legado, passa a incluir o ficheiro ativo de Numerical, evitando duas definições da mesma função.
- Atualizados imports e notas dos capítulos 4, 5 e 6, chamadas dos testes e fixtures de compilação. ModMulLL passa a ser impresso no capítulo 5, para que o código de suporte aos módulos variáveis também esteja disponível em papel.
- As notas dos ficheiros CHAPTER e REVISION anteriores são registos históricos; o contrato atual está nos headers e neste relatório.

## Testes executados

GNU C++17, release e debug com AddressSanitizer/UndefinedBehaviorSanitizer e verificações STL:

- Runner completo do capítulo 4: integração, Search, SearchFinite, Gauss, MatrixBinary, NTT e Adversarial.
- Runner completo do capítulo 5: integração, Modular, EuclidCRT, SieveDivisors, PrimeFactor e Adversarial.
- Runner completo do capítulo 6: integração, Combinations, Permutations, Identities e Adversarial.
- Modular: 237878 verificações exatas por modo, incluindo novos casos da função original de dois argumentos contra cpp_int e contra a variante de três argumentos. Inclui expoentes LLONG_MAX/ULLONG_MAX, módulo 1 na variante variável, bases negativas e valores próximos dos limites signed/unsigned.
- NTT: 1794 convoluções, 216 transformadas e 1105043 coeficientes por modo. Gauss: 19816 casos modulares e 2360 reais. Primalidade/fatorização: 251745 casos de primalidade e 21970 fatorizações por modo. Combinatória: 210770 casos modulares por modo.
- Teste ModMulLL atualizado: 100900 comparações de produtos por modo com um oráculo cpp_int independente. O teste antigo esperava encontrar erros da aproximação por long double fora do seu domínio e ficaria num ciclo sem fim com a nova multiplicação exata; essa expectativa foi removida.
- Sete headers afetados instanciados isoladamente com o template real, incluindo compilação LOCAL. Testada a inclusão dos caminhos novo e legado em conjunto, sem redefinições. Compilação conjunta dos 85 headers efetivamente incluídos no PDF, ignorando imports comentados.
- PDF regenerado com o layout existente: 26 páginas, 3 colunas, 9pt. Verificação visual documentada em validation/modpow.

Todos os testes acima passaram. Logs: `validation/modpow/`. LeakSanitizer foi desativado neste ambiente por incompatibilidade com ptrace; ASan e UBSan foram executados. Não foram repetidos testes de algoritmos não afetados por esta substituição.

## Reproduzir

Com g++, Python 3 e headers Boost disponíveis, na raiz do notebook:

```sh
bash doc/scripts/test-modpow.sh
```

Se Boost estiver fora do include path padrão:

```sh
BOOST_INCLUDEDIR=/pasta/que/contem/boost bash doc/scripts/test-modpow.sh
```

Para regenerar o PDF: `make kactl`.
