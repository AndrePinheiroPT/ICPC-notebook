# Capítulo 3 — versão compacta revista

Estado atual: capítulos 1–3 implementados; capítulos 4 em diante por rever.
Regras para as próximas etapas: `NOTEBOOK-RULES.md`.
A revisão de Mathematics e Data structures está resumida em
`REVISION-02-03.md`.

## Conteúdo impresso

- `UnionFind.h`: UF original KACTL.
- `UnionFindRollback.h`: RollbackUF original KACTL.
- `DynamicConnectivity.h`: intervalos de atividade e callback por instante.
- `Fenwick.h`: adição pontual e somas de prefixo/intervalo.
- `Fenwick2D.h`: coordenadas de updates conhecidas antecipadamente.
- `SegmentTree.h`: SegTree original KACTL; point assignment/range max.
- `LazySegTree.h`: template de tipo, range add/range sum.
- `SparseTable.h`: RMQ estática; operação associativa e idempotente.
- `OrderedSet.h`: GNU PBDS, rank/kth.
- `SqrtDecomposition.h`: point assignment e countLess em blocos ordenados.
- `PrefixSum2D.h`: somas estáticas de retângulos.
- `Difference2D.h`: adições a retângulos e materialização da grelha.

Todos os imports ficam em `content/data-structures/chapter.tex`.
Foram apagados `SegTree.h` (versão estendida), `PrefixSum.h` e `Difference.h`.
Não há maxRight, pesquisa por prefixo da nova Fenwick, countLE nos blocos
ou set/min/max na nova lazy tree.

Apenas os corpos de UF, RollbackUF e SegTree são exatamente os do ZIP
KACTL fornecido; a metadata foi encurtada. O SegTree original usa
`typedef int T`, função `f` e identidade `unit`, que se adaptam diretamente.
As restantes estruturas generalizam o tipo quando isso é natural.

Os headers antigos não impressos continuam no ZIP quando necessários aos
capítulos ainda por rever. O HLD legado, por exemplo, usa a antiga
`LazySegmentTree.h`; a implementação selecionada no capítulo 3 é
`LazySegTree.h`. Os capítulos restantes não foram modificados nesta etapa.

## Verificação

Executar na raiz do notebook:

```sh
bash doc/scripts/test-chapter-03.sh
```

- Integração dos 12 headers com o preâmbulo real de Contest.
- Release e ASan/UBSan; STL debug também, exceto no stress longo de PBDS
  (o respetivo custo interno é quadrático por mutação; a integração cobre
  PBDS com STL debug).
- DSU/rollback/offline: 585 078 comparações de estados com BFS.
- Fenwick e estruturas 2D: 1 244 888 verificações em 1 580 casos.
- Segment tree/lazy: 1 914 451 verificações.
- Sparse table: 1 030 291 queries.
- OST: 286 127 verificações.
- Blocos: 170 421 queries.
- Regressão DirectedMST: 50 000 grafos em release.

As contagens de cada grupo repetem-se em release e com sanitizers.
Usam granularidades diferentes; não são somadas como casos independentes.
Logs: `validation/chapter-03-tests.log`.

Neste ambiente, LeakSanitizer é incompatível com ptrace: executou-se com
`ASAN_OPTIONS=detect_leaks=0`. ASan/UBSan continuaram ativos; a configuração
de Contest não foi alterada.

## Documento

- Três colunas, 9 pt e estilos globais preservados byte a byte.
- PDF completo: 35 páginas, incluindo capa; antes desta revisão eram 37.
- Páginas afetadas inspecionadas visualmente; sem novos avisos Overfull.
- Permanecem os três avisos anteriores de Tridiagonal, Bit hacks e SIMD.
- `CHAPTERS-01-02.md` e `validation/chapters-01-02.*` são registos históricos
  da primeira entrega; o texto do capítulo 2 foi agora compactado, mantendo
  os corpos das implementações matemáticas exatamente iguais.
