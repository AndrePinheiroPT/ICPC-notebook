# Capítulo 8 — Geometry

> Registo histórico desta entrega. Para os contratos e alterações posteriores,
> ver [REVISION-ALGORITHMS.md](REVISION-ALGORITHMS.md).

Estado desta entrega: capítulos 1–8 implementados/revistos.
Regras em NOTEBOOK-RULES.md; capítulos 9 e 10 continuam por rever.

## Seleção e implementação

- Formulário curto: leis dos senos/cossenos, Heron, área por dois lados
  e ângulo, arco e setor; convenções de ângulos, tipos e tolerâncias.
- Point2: vetores/pontos genéricos, dot/cross, orientação, pertença a
  segmento, distâncias e perpendicular. Aritmética inteira larga nas
  operações multiplicativas; construções reais usam long double.
- Interseção de retas e segmentos, incluindo paralelas, coincidência,
  extremos, sobreposição e segmentos reduzidos a pontos.
- Projeção, reflexão e distância de ponto a reta/segmento.
- Shoelace, point in polygon, convex hull, point in convex polygon,
  diâmetro por rotating calipers e corte por semiplano.
- Interseções círculo–reta/círculo–círculo, circuncírculo e círculo
  mínimo envolvente randomizado.
- Closest pair com IDs originais e distância ao quadrado; união de
  retângulos por sweep e segment tree de comprimento coberto.
- Grelha espacial/vizinhos num raio fica como nota: floor para negativos,
  raio zero, filtro por distância e custo dependente da concentração.

São 13 headers selecionados. Point2.h é a base partilhada; o círculo
mínimo reutiliza Circle2.h. A união de retângulos precisa de contagens de
cobertura e comprimentos geométricos, pelo que não reutiliza a lazy tree
de add/sum. A grelha referencia floorDiv do capítulo 2.

Headers legados de Geometry permanecem intactos no ZIP, mas não são
impressos. Não foram adicionados Delaunay, KD-tree, geometria 3D, união
exata de círculos, tangentes ou operações booleanas gerais de polígonos.

## Contratos principais

- Point2<T>: T inteiro com sinal ou real. W é __int128 para inteiros,
  caso contrário T. Soma/subtração/operações do ponto devem caber em T;
  produtos e acumulações devem caber em W. Não se promete suporte a
  quaisquer pares de extremos de ll. Coordenadas ll até ±1e18 permitem
  diferenças, orientações e distâncias quadradas; somas de muitas áreas
  ainda requerem verificar o limite de 128 bits.
- Predicados inteiros são exatos dentro desses limites. Reais exigem
  entradas/intermédios finitos e escala/condicionamento adequados; não há
  epsilon universal. side/onSeg aceitam eps>=0 em unidades de comprimento
  ao quadrado. Ordenação, hull e pesquisas de polígonos usam comparações
  exatas, sem epsilon no comparador.
- lineInter devolve {count,point}: 0 paralelas distintas, -1 coincidentes,
  1 interseção única. Retas exigem extremos diferentes. O ponto só é
  válido no último caso e usa P2, mesmo para entradas inteiras.
- segInter devolve 0/1 pontos ou os 2 extremos da sobreposição, ordenados
  lexicograficamente. Segmentos degenerados são válidos. A classificação
  pode ser inteira exata, mas as coordenadas devolvidas são aproximadas.
- project/reflect/lineDist exigem reta não degenerada; segDist aceita
  segmento degenerado. Distâncias devolvidas são não negativas.
- polyArea2 devolve área dupla com sinal; CCW é positivo. Para área da
  região, usar polígono simples e valor absoluto dividido por 2.
- pointInPoly aceita qualquer orientação de polígono simples;
  pointInConvex exige hull estritamente convexo CCW. Ambos devolvem
  -1 fora, 0 fronteira, 1 interior e suportam n=0/1/2.
- hull elimina repetidos e colineares interiores; não repete o primeiro
  vértice no fim. hullDiameter2 recebe esse formato e devolve distância
  máxima ao quadrado, zero para n<2.
- convexCut conserva a esquerda inclusiva de a->b, com a!=b. Aceita
  entradas/saídas vazias, pontos e segmentos, preservando a ordem.
  Pode conservar vértices colineares: fazer hull antes de rotinas que
  exijam convexidade estrita. Comparações de sinal usam eps=0.
- Circle{c,r}: centro P2, raio ld>=0. circleLine exige reta não degenerada.
  circleCircle usa optional<vector<P2>>: nullopt significa coincidência
  dentro da tolerância, com infinitos pontos; vetor vazio significa
  ausência de interseção. Raios zero são tratados separadamente.
- Nos círculos, eps>=0 é tolerância absoluta de distância. Interseções
  próximas de tangência/coincidência são classificadas dentro de eps.
  circumcircle devolve nullopt para colinearidade calculada; quase
  colinearidade pode tornar o centro mal condicionado.
- enclosingCircle aceita vazio (raio -1), repetidos e colinearidade.
  Usa eps mais proteção de arredondamento relativa à escala das
  coordenadas/centro/raio; a minimalidade é aproximada nessa escala.
  Recalcula o raio final para cobrir todos os pontos na aritmética usada.
  Shuffle interno aleatório; tempo esperado O(n), pior caso O(n^3).
- nearestPair devolve {distância quadrada,{id1,id2}}, sem alterar entrada;
  n<2 devolve {0,{-1,-1}}, empates arbitrários e repetidos válidos.
- rectUnion recebe {x1,y1,x2,y2}, extremos ordenados, retângulos
  [x1,x2)×[y1,y2); vazios ignorados. Retorna __int128, com comprimentos,
  produtos e área dentro desse tipo. Diferenças são promovidas antes de
  subtrair, permitindo coordenadas ll extremas quando a área cabe.

## Testes

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-08.sh
```

GNU++20; Boost apenas nos oráculos dos testes. BOOST_INCLUDEDIR pode
indicar os headers Boost (tratados como headers de sistema). O código
do notebook não depende de Boost. Warnings próprios tratados como erros.
O runner usa release e ASan/UBSan/STL debug; LeakSanitizer desativado neste
ambiente por ptrace. Integra todos os headers selecionados dos capítulos
2–8 com o template real de Contest.

Por configuração:

- Primitivas: 322287 checks, 11563 casos de segmentos e 10185 de retas.
  Oráculos cpp_int por determinantes, Cramer racional e caixas; todos os
  segmentos numa grelha pequena, inteiros até ±1e18 e casos degenerados.
  Projeções/reflexões verificadas por equações de retas e transformações,
  com erros medidos relativamente à escala dos dados.
- Polígonos: 1730 hulls, 1982 polígonos, 240243 consultas, 681034 pares
  de distâncias e 1285 cortes; 298154 checks. Oráculos independentes por
  gift wrapping, winding number, todos os pares e interseções racionais;
  fronteiras, orientação invertida, colinearidade e cortes repetidos.
- Círculos: 2400 círculo–reta, 2600 círculo–círculo, 2603 circuncírculos
  e 16165 círculos envolventes; 241831 checks. Oráculo racional por todos
  os círculos candidatos de 1/2/3 pontos; escalas, translações e nuvens
  quase colineares, incluindo pontos menores que eps.
- Espacial: 16026 closest pairs contra 5339190 pares enumerados;
  17142 uniões contra 455632 células. Casos estruturais de 100000 pontos
  e retângulos em release. A grelha de 100000 pontos mantém-se em debug;
  os outros casos estruturais usam 2000 em STL debug, porque a validação
  interna linear de lower_bound tornaria o sweep artificialmente quadrático.

As contagens têm granularidades diferentes e não são somadas como casos
independentes. Inputs usam sementes fixas; a permutação interna de MEC
permanece aleatória. Resultados em validation/chapter-08-tests.log.

## Revisão numérica e layout

A revisão independente detetou uma instabilidade de MEC com eps=0:
arredondamento perto da fronteira podia forçar um circuncírculo enorme.
Foi corrigida com a margem relativa de roundoff. O testemunho está nos
testes, repetido 300 vezes, além de 10000 nuvens nos extremos e 1000
translações. O revisor validou ainda 50000 nuvens quase degeneradas e
40000 casos transladados até 1e18, usando cobertura e um limite superior
construtivo para o raio. Não se afirma exatidão arbitrária em ponto flutuante.

Estilo global preservado: 3 colunas, 9 pt; fontes de outros capítulos e
headers legados byte-identical à entrega do capítulo 7. Sem novos avisos
de largura; mantêm-se os dois avisos herdados de Various e os destinos
duplicados do apêndice. Logs das entregas anteriores são históricos.
