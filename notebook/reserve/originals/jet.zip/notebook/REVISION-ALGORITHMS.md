# Revisão das implementações e apresentação

Atualização posterior: `REVISION-RELIABILITY.md` descreve a auditoria geral
e as substituições seguintes de RMQ, KMP e BinarySearch.

Este documento atualiza os contratos alterados após a entrega dos
capítulos 1–10. Os relatórios `CHAPTER-*.md` e `CHAPTERS-09-10.md` conservam
o histórico; quando houver diferenças, prevalece esta revisão.

## Alterações pedidas

| Área | Resultado |
| --- | --- |
| Point | `Point.h` usa o corpo original do KACTL fornecido. Os algoritmos geométricos usam `Point<T>`; `Predicates.h` reúne `side`, `onSeg`, `P2` e `toReal`, sem alterar o Point original. |
| Interseção de retas | `lineIntersection.h` recupera o corpo original de `lineInter`. Usar pontos reais para interseções fracionárias: com inteiros, a divisão trunca. O código de segmentos reutiliza esta rotina em coordenadas locais, com origem no segmento mais curto, reduzindo o cancelamento com coordenadas grandes. |
| Bellman–Ford e Floyd–Warshall | Corpos originais preservados, com metadados e quebras de linha ajustados. Os namespaces `BF` e `FW` isolam os dois símbolos `inf`, permitindo incluir ambos no notebook. |
| Dijkstra | A API principal é `dijkstra(g,s)`, de origem única. O heap recebe melhorias estritas e entradas desatualizadas são descartadas antes de expandir. A soma é protegida pelo limite `inf`; as notas explicam destino único, agrupamento de consultas, grafo inverso, múltiplas origens, BFS e 0–1 BFS. |
| Trie | `AlphabetTrie.h` contém `struct TRIE` igual ao `/home/angelo/Desktop/cp/trie.cpp`, exceto whitespace. Mantém nomes, constantes, `add`, `get_node`, `find` e `prefix`; não há templates de alfabeto nem contadores de multiplicidade. |
| Description | Foi retirado globalmente o rótulo impresso “Description”. Mantêm-se os bullets e os campos de metadados usados pelo parser. Fontes, margens, três colunas e 9 pt permanecem. |
| Operações de bits | `BitOperations.txt` apresenta os blocos pedidos com `unsigned` de 32 bits e `1U`. As notas separam as adaptações para 64 bits, o caso zero dos builtins e máscaras completas sem shifts inválidos. |
| Guia de complexidade | A tabela relaciona dimensão de entrada e complexidade típica. Os limites são aproximados: `500^3` já representa 125 milhões de operações e pode exceder o tempo. Contam também transições, múltiplos casos e memória. |
| Tipos e 128 bits | Geometria, histograma, CHT e Euclides estendido usam os tipos habituais sem alargamento automático. Os 128 bits permanecem apenas nos produtos modulares largos, produtos necessários do CRT e rotinas explícitas de leitura/escrita de inteiros de 128 bits. |

## Contratos que mudaram

- **Geometria:** diferenças, produtos e somas devem caber em `T`;
  preferir `ll` a `int` para predicados inteiros. Já não existe a garantia
  anterior de produtos automáticos em 128 bits. `Point::dist` e `angle`
  devolvem `double`, como no original. `P2` é `Point<long double>` para
  construções reais; arredondamento e condicionamento continuam relevantes.
  `lineInter` pode calcular produtos de três coordenadas, que também têm
  de caber no tipo. `rectUnion` recebe coordenadas `ll` e devolve área `ll`;
  comprimentos, diferenças, produtos e área total devem ser representáveis.
- **Grafos originais:** `BF::bellmanFord(nodes,eds,s)` recebe pesos `int`,
  modifica os nós e ordena as arestas; iniciar os nós com os valores
  predefinidos. `BF::inf=LLONG_MAX`; `-inf` assinala os vértices afetados
  por ciclos negativos alcançáveis. As somas de relaxação finitas devem
  ficar estritamente entre os sentinelas. `FW::floydWarshall(m)` modifica
  uma matriz `ll`, usa `FW::inf=2^62`, mínimo nas arestas paralelas e
  `-inf` para distâncias sem limite inferior. Respeitar os limites dos
  pesos indicados nos headers. Dijkstra exige pesos não negativos, origem
  válida e distâncias finitas menores que `inf`.
- **TRIE:** alfabeto fixo `a`–`z`, 200 005 nós pré-alocados, incluindo a
  raiz zero. `find` e `prefix` devolvem `bool`; `get_node` devolve ID ou
  `-1`. Duplicados são idempotentes. `prefix("")` é sempre verdadeiro,
  mesmo antes de inserir; `find("")` só fica verdadeiro depois de inserir
  a palavra vazia. Inicialização/espaço `O(200005·26)`; operações
  `O(|s|+1)`. O corpo foi comparado com o ficheiro fornecido ignorando
  apenas whitespace, sem alterar constantes ou semântica.
- **Histograma:** resultado `(ll área,int l,int r)` e prefixos de larguras
  em `ll`; valores, somas de larguras e áreas devem caber em `ll`.
  Continuam válidos larguras variáveis positivas, alturas não negativas
  e resultado `(0,0,0)` para vazio/tudo zero.
- **CHT:** `LineHull` usa `ll` para coeficientes, breakpoints, consultas e
  resultado; reutiliza `floorDiv`. Diferenças, quocientes, produtos e
  somas calculados devem caber em `ll`. O sentinela negativo exige
  `x > -LLONG_MAX`. Declives iguais são permitidos e consultar vazio é
  inválido. Para mínimos, as negações dos coeficientes e resposta também
  têm de ser representáveis.
- **Euclides/CRT:** `extGcd<int/ll>` usa a atualização convencional dos
  coeficientes, incluindo entradas com sinais; ambos os argumentos
  excluem o mínimo do tipo. No CRT, incompatibilidade continua a ter
  prioridade sobre overflow; a LCM só é multiplicada depois do teste
  `m/g > LLONG_MAX/n`. Os produtos de congruências que precisam de maior
  largura continuam em 128 bits. Resíduos negativos, incluindo
  `LLONG_MIN`, são normalizados antes de chamar Euclides.
- **Modular/matrizes:** `modMul` usa `unsigned long long` para tipos de
  até 32 bits e `__uint128_t` para tipos de 64 bits. `Mat` usa `ll` quando
  `MOD<=INT_MAX`, e `__int128_t` para módulos maiores; entradas modulares
  continuam normalizadas e o módulo deve caber em `T`. Com `MOD=0`,
  mantém-se aritmética normal de `T`. O I/O explícito de 128 bits fica
  disponível no capítulo Mathematics.

O calendário gregoriano e a deteção de ciclos não mudaram nesta revisão.
As datas mantêm ano astronómico zero, anos entre ±10^12 e a época
`1970-01-01=0`. Hash duplo continua probabilístico, com símbolos de
64 bits codificados em quatro dígitos de 16 bits; essa largura do símbolo
não implica usar 128 bits no cálculo do hash.

## Validação e reprodução

Runners na raiz do notebook:

```sh
bash doc/scripts/test-chapter-04.sh
bash doc/scripts/test-chapter-05.sh
bash doc/scripts/test-chapter-07.sh
bash doc/scripts/test-chapter-08.sh
bash doc/scripts/test-chapters-09-10.sh
```

GNU++20; release e ASan/UBSan/STL debug. Boost é usado apenas pelos
oráculos; definir `BOOST_INCLUDEDIR` se necessário. Neste ambiente,
`ASAN_OPTIONS=detect_leaks=0` contorna a restrição de LeakSanitizer sob
ptrace, mantendo ASan/UBSan ativos. Os runners incluem integração com
o template real de Contest; não dependem de macros `all`/`rep` que esse
template não fornece.

As suites 04, 05, 07, 08 e 09–10 passaram nas duas configurações.
Os logs estão em `validation/revision-10/`; o ficheiro `ch08.log` é um
resumo identificado da execução completa, não um log bruto. Depois da
revisão final da interseção de segmentos, a suite Primitives passou
novamente em ambas as configurações: 354 744 verificações, incluindo
8 112 novos casos de regressão de coordenadas grandes, translações
e ordens dos extremos. Os corpos originais de Point e lineInter foram
comparados byte a byte; Bellman–Ford e Floyd–Warshall conservam os tokens
do código original, além dos namespaces de isolamento.

O script de hash usa explicitamente C++20 para aceitar os separadores
de dígitos presentes no TRIE fornecido.

Nos capítulos 09–10, os testes confirmam o TRIE booleano contra um set,
incluindo a capacidade exata, e usam oráculos largos para validar o novo
domínio `ll` de histograma/CHT. As notas de bits cobrem agora 32 e 64 bits.
As contagens atuais estão nos READMEs de
[Strings](stress-tests/chapter-09/README.md) e
[Various](stress-tests/chapter-10/README.md). Os testes não recuperam
automaticamente o domínio numérico maior que foi retirado dos headers.
