# Revisão compacta dos capítulos 2 e 3

- Mathematics: bullets, fórmulas e condições essenciais; removida a prosa
  explicativa. Todos os tópicos acordados foram mantidos.
- Descrições: apenas o que faz, complexidade e contratos; Usage só nos
  algoritmos de utilização menos óbvia.
- UF, RollbackUF e SegTree: corpos originais do KACTL recebido, verificados
  byte a byte desde `#pragma once`.
- Removidas extensões: maxRight, pesquisa por prefixo da Fenwick, countLE
  nos blocos e query de prefixo isolado em PrefixSum2D.
- Lazy: implementação própria seguindo o esquema recursivo de propagação
  descrito no [CPH, capítulo 28](https://cses.fi/book/book.pdf), apenas range
  add/range sum, com template de tipo e vetores.
- PrefixSum1D/Difference1D: ficheiros, imports e testes eliminados.
- `NOTEBOOK-RULES.md` regista estas escolhas para os próximos capítulos.

O estilo global, três colunas, 9 pt e margens permanecem iguais.
O capítulo 1 e os capítulos 4 em diante não foram alterados.
Os corpos de IntDivision, ModAlign e Int128 também ficaram inalterados.

Testes reproduzíveis e resultados atuais: `CHAPTER-03.md` e
`validation/chapter-03-tests.log`. A validação abrange as alterações desta
revisão; não se voltou a executar a suite completa dos capítulos legados.
