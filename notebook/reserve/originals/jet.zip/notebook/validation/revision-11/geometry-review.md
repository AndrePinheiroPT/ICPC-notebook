# Geometry — revisão de fiabilidade, pedido 10–15

## Âmbito e contratos

Revistos todos os 15 headers selecionados por `content/geometry/chapter.tex`:
`Point.h`, `Predicates.h`, `lineIntersection.h`, `LineSegInter.h`,
`Projection2.h`, `PolyArea.h`, `PointInPoly.h`, `Hull.h`,
`PointInConvex.h`, `HullDiameter2.h`, `ConvexCut.h`, `Circle2.h`,
`EnclosingCircle.h`, `NearestPair.h` e `RectUnion.h`, mais as notas da
grelha espacial e fórmulas geométricas.

- Inteiros: diferenças, produtos, somas e resultados usados têm de caber no
  tipo. As novas fronteiras de testes respeitam esse contrato; coordenadas
  extremas não significam diferenças ou áreas extremas fora de `ll`.
- Ponto em polígono convexo e diâmetro: hull estritamente convexo, CCW;
  entrada com 0/1/2 vértices tem tratamento próprio. O hull elimina
  duplicados e colineares interiores. O corte aceita orientação inversa,
  degenerações e colineares; executar hull antes das consultas estritas.
- `lineInter` original mantém divisão inteira truncada quando T é inteiro.
  As construções fracionárias usam `P2`. O corpo original pode perder
  precisão por cancelamento; o wrapper de segmentos traduz a origem e
  escolhe o segmento mais curto. A regressão anterior foi preservada.
- Reais: sem NaN/Inf; escala e condicionamento compatíveis com long double.
  Epsilon absoluto nas interseções de círculos; MEC combina epsilon com
  roundoff por escala. Testes não permitem prometer exatidão universal
  para dados reais arbitrariamente mal condicionados.
- Área de retângulos: limites ordenados, vazios ignorados, comprimentos,
  produtos e área total em ll. Ordem de eventos no mesmo x é inócua porque
  a largura desse passo é zero e as remoções correspondem a adições ativas.
- Closest pair: IDs originais, desempate arbitrário; zero para duplicados.
  A mistura de ordenação por x/y e a utilização do buffer foram revistas.

## Alterações

Não foi encontrada uma falha nova dos algoritmos dentro dos contratos.
Os corpos de Point e lineIntersection originais não foram alterados.

Clarificação curta nas notas da grelha: os índices das células **e os
offsets para células vizinhas** têm de caber no tipo. O resto da receita
(9 células para lado r, floor para negativos, filtro por distância, raio
zero por igualdade e consulta antes de inserir) foi exercitado contra
um oráculo por todos os pares.

Adicionada `stress-tests/chapter-08/Adversarial.cpp`, incluída no runner.
Não foram adicionadas funções de conveniência ao notebook.

## Verificações novas

- 600 polígonos com shears inteiros, rotações de 90 graus e translações;
  classificação por coordenadas originais, área conhecida, diâmetro por
  enumeração de pares, hull com pontos interiores/duplicados e corte com
  área conhecida. Deste modo o oráculo não replica ray casting nem
  clipping.
- 24 famílias de transformações analíticas para projeção/reflexão,
  distâncias, círculo–reta, círculo–círculo, circuncírculo e MEC, em escalas
  1e-9, 1 e 1e9. Erro permitido deriva de machine epsilon e escala.
- Tangências imediatamente dentro/fora do epsilon declarado.
- 1 600 casos de grelha com raio zero ou positivo, negativos, duplicados,
  translações perto de LLONG_MIN/MAX e comparação com todos os pares.
- Predicados/hull/query/closest pair com coordenadas junto aos extremos de
  ll, mas diferenças e produtos válidos; distância quadrada de dois pontos
  próxima de LLONG_MAX; área de união exatamente LLONG_MAX, repetição de
  retângulos e retângulos vazios.
- 19 566 verificações na suite nova por modo de compilação.

## Auditoria de aliases e macros

Dependências externas de produção: `ll`, `vi` e `sz`, todos definidos no
`content/contest/template.cpp` real. `ld` e `P2` são definidos em
`Predicates.h`; `Point` e `sgn` são definidos em `Point.h`. Os headers que
usam essas entidades incluem as dependências, direta ou transitivamente.
Não são necessários `rep`, `all`, `pb`, `FOR` ou aliases ausentes.
`bits/stdc++.h` e `using namespace std` vêm do template. Boost e tipos
inteiros de 128 bits usados como oráculos pertencem apenas aos testes.

O runner integra primeiro todos os headers selecionados dos capítulos 2–8
com o preâmbulo extraído do template real. Só os includes do Point original
suprimem os avisos de shadowing/conversão próprios desse original; o resto
compila com `-Wall -Wextra -Wshadow -Wconversion -Werror`.

## Execução

Comando (log integral em `ch08.log`):

```sh
BOOST_INCLUDEDIR=/tmp/jet_cp_boost/extracted/usr/include \
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-08.sh
```

Release: `-O2`; debug: `-O1 -g -DLOCAL -D_GLIBCXX_DEBUG`, ASan e UBSan.
As suites têm oráculos independentes: cpp_int/Cramer e caixas,
gift wrapping/winding, clipping racional, círculos candidatos exatos,
pares enumerados, raster/células e novas construções analíticas.
Sementes dos inputs fixas; embaralhamento interno de MEC aleatório.

**Concluído: exit code 0, release e debug passaram.**

Contagens em cada modo:

| Suite | Casos / verificações |
|---|---|
| Primitives | 354 744 checks; 19 675 segmentos, 10 185 retas |
| Polygons | 298 602 checks; 1 730 hulls, 1 982 polígonos, 240 315 consultas, 1 285 cortes |
| Circles | 241 831 checks; 2 400 círculo–reta, 2 600 círculo–círculo, 2 603 circuncírculos, 16 165 MEC |
| Spatial | 16 026 closest pairs, 5 339 190 pares do oráculo; 17 142 uniões, 455 632 células do oráculo |
| Adversarial | 19 566 checks; 600 polígonos transformados, 24 famílias analíticas, 1 600 grelhas |

Os casos estruturais usam 100 000 pontos/retângulos em release e 2 000 em
STL debug, cuja validação de lower_bound é linear. A grelha grande de
100 000 pontos é exercitada nos dois modos. Sem falhas de sanitizers e
sem avisos de compilação.
