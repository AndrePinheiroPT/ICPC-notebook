# Revisão independente — Strings e Various

Revisão read-only dos headers selecionados dos capítulos 9–10, das notas
DP/bit operations e das duas novas suites `Adversarial.cpp`. Não substitui
nem reexecuta o runner completo do responsável principal.

## Resultado

Não foi encontrada uma falha nova dos algoritmos em entradas dentro dos
contratos e dos tamanhos utilizáveis em competição. Foram identificados
um caso de teste inválido e dois limites formais de tamanho, todos
resolvidos e confirmados nos ficheiros finais:

1. **Oracle/teste de datas:** o loop `d=1..28` na nova suite Various
   chamava `gregorianDays(1900,2,29)` ao verificar o dia seguinte de 28 de
   fevereiro. Essa data é inválida e viola o contrato do header. A fórmula
   normaliza-a implicitamente para 1 de março, portanto a asserção passava
   sem testar uma transição entre datas válidas. Comunicado ao responsável:
   limitar a verificação a `d<28` ou construir o próximo dia válido.
   **Resolvido:** a suite agora avança de 28/02 para 01/03 nos anos não
   bissextos, antes da execução final dos testes.
2. **RMQ original, limite teórico:** com `n>=2^30`, o ciclo de construção
   chega a `k=31`, e `1<<k` deixa de representar uma largura int positiva.
   A memória O(n log n) já torna esses inputs impraticáveis em competição.
   **Resolvido:** o contrato de RMQ agora explicita `n<2^30`, preservando
   o corpo original da construção.
3. **KMP, limite teórico:** o caso padrão vazio usa `n+1`, pelo que o
   comprimento da string de texto deve ser estritamente menor que INT_MAX.
   **Resolvido:** a convenção geral de Strings agora exige comprimentos,
   contagens de nós e de padrões estritamente menores que INT_MAX.
   DoubleHash já documentava esse limite.

Não foram editados os headers nem as novas suites nesta revisão.
Os pontos acima foram enviados ao responsável principal e as resoluções
foram confirmadas por leitura do código/metadados atualizados. Não ficaram
findings pendentes desta revisão independente.

## Oráculos novos revistos

- KMP: comparação direta de todas as posições; o espelho `n-m-i` também
  está correto para padrão vazio (n+1 fronteiras).
- Prefix/Z/Manacher: mapeamento injetivo de bytes para ll preserva igualdade;
  para minimum rotation também preserva a ordem de bytes unsigned.
  A relação entre raios pares e o reverso usa índice `n-i` e exclui i=0.
- `leastRotation(s+s)==leastRotation(s)` é válida por periodicidade e pelo
  desempate no primeiro índice; também é válida para string vazia.
- Suffix LCP: enumeração direta das igualdades de símbolos, além do RMQ
  entre ranks. Strings vazias não provocam consultas em intervalos vazios;
  sufixos iguais devolvem n-i diretamente.
- Hash: concatenação, extração e associatividade testam consistência; não
  são uma prova de ausência de colisões. O header já documenta a natureza
  probabilística. Os vetores mapeados não excedem ll.
- Aho: enumeração independente dos padrões terminados em cada fronteira,
  incluindo padrões vazios e duplicados. O alfabeto de 256 símbolos usa
  unsigned char. Os comprimentos escolhidos por rnd são sempre positivos
  como argumento do gerador e produzem substrings válidas.
- Trie: conjunto de strings para membership e enumeração de prefixos;
  prefixo vazio existe mesmo antes de inserir palavras. Capacidade
  máxima não é excedida nesta nova suite; a suite antiga testa capacidade.
- LIS/LNDS: DP quadrática compara apenas a chave de ordenação, testando
  equivalência sob strict weak ordering sem depender do payload.
- Subset bits: DP com camada anterior evita reusar o item; LLONG_MAX é
  ignorado corretamente e não causa overflow em `s-x` devido à guarda.
- SOS: gcd de todos os sub/supermasks é um oráculo enumerativo independente.
- Histogram: expansão das larguras em barras unitárias seguida da busca
  de todos os intervalos; escalas/reflexões adicionais preservam o ótimo.
- Interval cover: a transformação crescente preserva possibilidade e
  cardinalidade mínima, mas esse teste sozinho é apenas metamórfico.
  A suite antiga `IntervalsHistogram.cpp` fornece o oráculo por subconjuntos.
- CHT: máximo por todas as retas, duas ordens de inserção; operações dentro
  de ll e fora das sentinelas excluídas. Limites adicionais do header estão
  explícitos: diferenças, produtos, somas e floor quotient cabem no tipo.
- Floyd cycle: caminho e ciclo conhecidos sob permutação dos IDs, incluindo
  mu=0 e ciclo de tamanho 1. Resultado esperado independente da simulação.
- Grundy/minimax: tabulação dos pares em ordem crescente é válida porque
  cada jogada reduz pelo menos uma coordenada. O oracle não depende do xor.
- Knapsack limitado: enumeração de todas as multiplicidades independentes
  dos grupos binários; pesos zero e valores negativos tratados corretamente.
  O tamanho reduzido dos casos evita overflow do doubling do grupo.

## API e dependências

Os headers revistos usam apenas aliases/macros do template (`ll`, `vi`,
`sz`) e definições locais, além dos includes declarados. LineHull e datas
incluem IntDivision. Suffixes documenta o RMQ externo; não o usa no corpo.
A renomeação para KMP preserva prefixFunction e kmpMatches, sem necessidade
de alterar a API. Não se encontraram imports ativos do antigo nome nas
suites revistas.

As notas sobre Knuth/D&C incluem as condições necessárias; os jogos
explicitam normal play/terminação/independência. A documentação de bits
já distingue unsigned, tamanhos de shift e builtins indefinidos para zero.

## Auxiliar fornecido

`geometry-instantiations.json`: mapa dos 15 basenames selecionados de
Geometry para um `int main()` mínimo, com instanciações e asserções, para
a auditoria isolada contra o template real. Não modifica o notebook.
