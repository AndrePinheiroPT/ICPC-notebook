# Graph — auditoria e stress tests da revisão 11

Todos os 19 headers selecionados em `content/graph/chapter.tex` foram
lidos e revistos contra o preâmbulo real de `content/contest/template.cpp`.
Não foi encontrado um defeito de implementação dentro dos contratos
indicados. Não se infere uma garantia absoluta a partir de stress tests.

## Alteração de produção

Apenas metadados de `MinCostFlow.h`: os valores limitados pela sentinela
INF são os custos das arestas, distâncias reduzidas e potenciais. O custo
total devolvido pode ultrapassar INF, desde que caiba em C. Um novo caso
verifica fluxo e custo iguais a INT_MAX. Nenhum corpo de algoritmo mudou.
`BellmanFord.h` e `FloydWarshall.h` continuam byte a byte iguais ao ZIP
entregue antes desta revisão, incluindo os corpos originais do KACTL.

## Dependências

- Preamble exigido: biblioteca padrão e namespace std, ll, vi, sz — todos
  presentes no template real. Nenhum header selecionado usa rep/all/pb/fi/se
  ou outro define ausente.
- JumpTable declara localmente ull; TreeLCA inclui JumpTable e TreeTour.
- Kruskal inclui UnionFind; TwoSAT inclui StrongComponents; HeavyLight
  inclui TreeTour. Nenhuma destas dependências depende da ordem do capítulo.
- BF/FW estão nos seus namespaces, prevenindo colisão das suas sentinelas.
- `graph-instantiations.json` contém um main completo por header para a
  compilação isolada global, incluindo instâncias int/ll/unsigned e callbacks.
  A confirmação dessa compilação isolada fica no relatório global; o runner
  deste capítulo confirma a integração com o template real e capítulos 2–7.

## Cobertura por algoritmo

| Algoritmo | Verificação adicional nesta revisão |
|---|---|
| Dijkstra | Heap densa com entradas antigas, paralelas decrescentes, zeros e isolados; sentinelas 2, 3, 2^63 e ULLONG_MAX sem overflow. |
| 0–1 BFS | Cadeia zero sobre grafo denso de arestas 1; fontes repetidas e lista vazia. |
| Bellman–Ford | Todos os 19683 grafos de três vértices com aresta ausente/-1/+1; oráculo enumera caminhos e ciclos simples, confirma predecessores finitos. |
| Floyd–Warshall | Mesma enumeração, todos os pares; mantém testes de saturação de ciclos negativos e pesos próximos da sentinela. |
| Kahn | Todos os 65536 grafos dirigidos de quatro vértices; existência de ordem comparada com as 24 permutações. |
| Kruskal | Todas as 729 configurações ausente/-7/+11 no K4; oráculo enumera subconjuntos que ligam exatamente os componentes necessários. |
| SCC e condensação | Todos os grafos dirigidos em quatro vértices; alcançabilidade, equivalência dos componentes e DAG sem duplicados. |
| Lowlink | Todas as 729 multiplicidades 0/1/2 nas seis arestas não orientadas de K4, sempre com loops; remoção de aresta/vértice como oráculo. |
| 2-SAT | Todos os multiconjuntos de três cláusulas nos seis literais de três variáveis; enumeração de atribuições e solve repetido. |
| Hierholzer | Todas as 6561 sequências de quatro arestas em três vértices, todos os inícios, dirigido e não dirigido; procura exaustiva de percursos por IDs. |
| Dinic | Todas as 19683 atribuições 0/1/2 nos nove arcos de K3; cortes enumerados, conservação, reversas; LLONG_MAX/ULLONG_MAX; nova capacidade exige anular fluxo anterior. |
| Min-cost flow | Todas as 729 configurações dos seis arcos de K3 com custo reduzido 0/1 e potenciais que criam custos negativos/ciclos zero; todos os fluxos/circulações viáveis enumerados; limite zero e custo total INT_MAX. |
| Hopcroft–Karp | Todos os 65536 grafos 4x4 contra DP por subconjuntos; caminho alternante com 1000 vértices à esquerda. |
| Minimum vertex cover | Em todos os casos de matching: cobre cada aresta, sem IDs repetidos, tamanho igual ao matching máximo. |
| Gale–Shapley | Todos os 46656 perfis estritos completos para 3+3 pessoas; todas as seis permutações verificam estabilidade e otimalidade dos proponentes. |
| JumpTable | Todos os 625 grafos funcionais parciais em quatro vértices; órbita e ciclo independentes, -1 e saltos 0, 1, 2, 3, 4, 15, 2^63, 2^64-1. |
| TreeTour, LCA e HLD | Cada árvore rotulada de 2–5 vértices via Prüfer, todas as raízes; BFS independente, subárvores, todos os pares, SegTree/LazySegTree reais. Mantidas cadeias de 100000 vértices. |
| Tree diameter | Mesmas árvores com pesos int/ll/long double, zeros; caso adicional com diâmetro LLONG_MAX exato. |

## Execução

Comando, na raiz do notebook:

```
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-07.sh
```

Exit status 0. O log integral está em `ch07.log`.
Ambos os modos passaram, com `-std=gnu++20 -Wall -Wextra -Wshadow
-Wconversion -Werror`; release `-O2`; debug `-O1 -g -DLOCAL
-D_GLIBCXX_DEBUG -fsanitize=address,undefined -fno-omit-frame-pointer`.
LeakSanitizer está desligado devido ao ambiente com ptrace; ASan e UBSan
estão ativos. As contagens abaixo são por modo, não somadas duas vezes.

- PathsMST: 25446 grafos de caminhos, 505412 distâncias, 69536 grafos
  topológicos, 1929 florestas, 78376 subconjuntos de arestas.
- Connectivity: 71067 SCC, 6489 lowlink, 20003 resultados de 2-SAT,
  60328 Euler, mais os casos estruturais com 100000 vértices/arestas.
- FlowMatching: 21490 Dinic, 1687 min-cost flow, 67007 matching bipartido,
  46937 stable matching, 314896 matchings completos enumerados e
  2597130 verificações. Casos estruturais/manuais adicionais são contados
  nas verificações, embora nem todos aumentem os contadores de redes.
- Trees: 2365778 verificações, 456685 saltos, 109855 pares LCA/distância,
  389914 verificações de caminhos, 2858 diâmetros e cadeia iterativa de
  100000 vértices.

## Limites que continuam a importar

- Dijkstra só com pesos inteiros não negativos; distâncias finitas abaixo
  de inf. Bellman–Ford original usa pesos int e nós inicializados de novo.
- Somatórios e produtos devem caber nos tipos, conforme cada contrato.
  Sentinelas não representam valores finitos válidos.
- Min-cost flow exige ausência de ciclos negativos em toda a rede residual,
  incluindo componentes desligados; custos reduzidos/potenciais respeitam
  os limites documentados. Não é um algoritmo genérico de cancelamento
  de circulações negativas.
- Dinic e Hopcroft–Karp fazem DFS recursiva: a profundidade O(V) exige uma
  stack adequada. Os percursos de conectividade e árvores são iterativos.
- TreeTour/LCA/HLD/TreeDiameter recebem uma árvore válida; diâmetro só com
  pesos não negativos. HLD emite segmentos sem ordenação direcional, como
  indicado no header; operações não comutativas exigem tratamento próprio.
- Inputs inválidos (vértices fora dos limites, árvore cíclica, overflow
  fora do contrato, ciclos negativos no MCMF) não passam a ser suportados.
