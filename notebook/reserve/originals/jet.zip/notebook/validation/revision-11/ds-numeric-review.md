# Revisão 11 — Data structures, Numerical, Number theory, Combinatorial

## Alterações de produção pedidas

- `RMQ.h` usa a construção `jmp` e a query sobreposta do KACTL original
  recebido em `notebook.zip`, com `STMin<T>`/`F` para trocar a operação.
  Comentário: `associative + idempotent`; associatividade isolada não basta.
  A construção original foi conservada e o seu limite `n < 2^30` ficou
  explícito. Query `const` e objeto `F` não mudam o algoritmo.
  O capítulo e os testes usam RMQ; o anterior SparseTable.h foi removido.
- `BinarySearch.h` conserva os corpos fornecidos em BinarySearch.cpp,
  alterando apenas espaços. API: `first_true`/`last_true`, `ll`, intervalo
  fechado `[l,r]`, monotonia e existência de pelo menos um true.
  `r-l` no first e `r-l+1` no last devem caber em ll. Não se inventou uma
  resposta para predicados sem true; não existe mais o optional anterior.
- Nenhuma outra implementação selecionada dos capítulos 3–6 precisou
  de correção: os novos casos executados respeitam os contratos publicados.
  UF/RollbackUF/SegTree originais mantêm os corpos intactos.

## Auditoria de dependências

Revistos os 32 headers importados pelos capítulos 3–6. Só dependem de
`ll`, `vi`, `sz` e da biblioteca standard disponibilizados pelo preâmbulo
real, mais tipos/funções definidos no próprio header ou includes diretos.
`ull` está definido em ModPower.h; ModComb, Prime64 e Factor64 incluem
essa dependência. `__lg`/builtins são funções GNU, não macros ausentes.
PBDS inclui os seus dois headers. Não há dependências ocultas de all,
rep, trav, pii, mp, pb ou de aliases de fixtures.

`ds-numeric-instantiations.json` contém um main por header, com operações
executadas, para a auditoria isolada conduzida pelo agente principal.
As integrações dos runners também usam o texto real de template.cpp.

## Cobertura e fundamentos por implementação

| Headers | Auditoria e oráculos |
|---|---|
| UF, RollbackUF, DynamicConnectivity | BFS independente; snapshots e no-op joins; cópias de arestas; lifetimes vazios e limites [l,r); uniões equilibradas em 32768 vértices; todas as combinações de dois lifetimes até 7 instantes. |
| Fenwick, Fenwick2D | Somas por varrimento; coordenadas extremas ll sem subtraí-las; deduplicação, queries com limites não registados; apenas pontos de update previamente registados. |
| SegTree, LazySegTree | Vetor plano, composição/exaustão de updates, árvore vazia, comprimentos perto de potências de dois; query vazia; aritmética intermediária em T. |
| RMQ | Fold independente com min/max/GCD/AND, operação com estado, projeção esquerda e banda não comutativa `(a.first,b.second)`; min/max com LLMIN/LLMAX; ranges não vazios. |
| OST, SqrtDecomposition | Vetor ordenado/varrimento, duplicados com ids, remoções, comparator inverso, thresholds externos, valores novos; PBDS usa comparator estrito. |
| PrefixSum2D, Difference2D | Grelha explícita, dimensões vazias, todas as submatrizes pequenas e magnitude ll segura; values() repetido. |
| BinarySearch, Bisection, GoldenSearch | Enumeração de fronteiras, janelas junto dos extremos ll, intervalos reais adjacentes e enormes, função unimodal com mínimos interiores/nos extremos/planos só no mínimo. |
| Gauss, GaussBinary, GaussMod | Racionais exatos, enumeração de soluções modulares/GF2, sistemas construídos com rank conhecido, inconsistência/free variables; escala binária 2^-400 a 2^400 com eps ajustado; GF2 até 512 bits. |
| ModPower, Matrix | cpp_int, produtos unsigned de 64 bits e expoentes extremos; matrizes contra dot products exatos; blocos de Jordan para expoente LLMAX; MOD32 usa ll e MOD63 usa 128 bits. |
| NTT | Convolução quadrática, DFT independente, transform/inverse nas duas ordens, fronteiras de padding; convoluções densas com resposta triangular analítica; ensaio separado no limite 2^23. |
| ExtGCD, ModInv, GeneralCRT | Bézout cpp_int, inversos/CRT por brute, sinais, incompatibilidade antes de overflow; todas as 24 ordens de merges de divisores de um múltiplo representável; LCM/produtos certificados exatos. |
| SPF, TrialDivision, Divisors | Primos/fatores/divisores por divisão/enumeração independente; quadrados junto do limite exclusivo; agrupamento de fatores, 1, potências de dois até 2^63 e unsigned máximo. |
| Prime64, Factor64 | Crivo/trial, certificados exatos de primos grandes, semiprimos, potências, pseudoprimos; família Carmichael de Chernick e 32 quadrados de primos próximos de 2^32. O cross-check Boost aleatório é adicional, não substitui estes oráculos exatos. |
| Binomial, ModComb | Pascal/cpp_int, quociente de fatoriais independente até n=1500, limites int/ll/ull; multinomiais por enumeração; linhas p-1/p-2 por Wilson até p=65537. |
| PermCycles e notas combinatórias | Órbitas, inversões, sorting swaps e composição; todos os n<=8, ciclos com labels permutados e inversos até 200003 elementos; inclusão-exclusão, stars/bars e Catalan por enumeração independente. |

## Limites da conclusão

Testes não constituem prova de correção universal. Resultados condicionados
pelos contratos: índices válidos, memória disponível, operações e somas
representáveis, primos nos algoritmos que os exigem e aritmética finita.
Gaussian real depende da escala/eps e pode perder rank em problemas mal
condicionados; binary search fornecido exige existência e largura segura.
Pollard rho tem tempo esperado e reinícios aleatórios, sem limite
determinístico de execução. Nenhuma garantia de 100% é inferida.

## Execução

Estado final e contagens nos logs brutos `ch03.log`, `ch04.log`,
`ch05.log`, `ch06.log` e `ch04-ntt-max.log`. Cada runner principal executa
release e ASan/UBSan com STL-debug. Em StaticOrdered, o stress extenso
PBDS usa ASan/UBSan sem STL-debug devido ao custo de validação interna;
integração e Adversarial com PBDS até 33 elementos mantêm STL-debug.
LeakSanitizer desligado devido ao ambiente com ptrace. Oráculos Boost
são usados só nos testes; não há dependência Boost de produção.

## Resultado confirmado

Todos os quatro runners terminaram com código 0. Não existem warnings
de compilação, falhas de assertions, diagnósticos ASan ou UB nos logs.

| Nova suite por modo | Checks adicionais |
|---|---:|
| Adversarial Data structures | 2 627 946 |
| Adversarial Numerical | 72 988 |
| Adversarial Number theory | 64 434 |
| Adversarial Combinatorial | 153 970 |

O novo Search/ModPower passou 532 411 checks por modo. Os oráculos
Number theory incluem 130 Carmichael de Chernick e 32 quadrados de
primos grandes. O ensaio separado NTT release atingiu 2^23 elementos e
comparou 9 493 651 coeficientes incluindo os restantes casos dessa suite.
A regressão DirectedMST também passou. Os logs registram as restantes
contagens das suites pré-existentes, integralmente repetidas nesta revisão.

O primeiro ensaio adicional DS foi interrompido por custo excessivo da
validação interna PBDS com 513 elementos, sem qualquer falha reportada.
Depois de limitar apenas esse caso redundante a 33 elementos, o runner
completo foi repetido nos dois modos; ch03.log é o registo integral da
execução final. O stress extenso PBDS permaneceu na suite dedicada.
