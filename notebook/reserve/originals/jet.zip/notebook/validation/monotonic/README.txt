Run from the notebook root:

g++ -std=c++17 -O2 -Wall -Wextra -Wconversion stress-tests/chapter-03/Monotonic.cpp -o /tmp/monotonic-test
/tmp/monotonic-test

g++ -std=c++17 -O1 -g -D_GLIBCXX_ASSERTIONS -fsanitize=address,undefined -fno-omit-frame-pointer stress-tests/chapter-03/Monotonic.cpp -o /tmp/monotonic-sanitized
ASAN_OPTIONS=detect_leaks=0 /tmp/monotonic-sanitized

Leak detection was disabled because this execution environment uses ptrace.
AddressSanitizer, UndefinedBehaviorSanitizer and STL assertions remained enabled.
