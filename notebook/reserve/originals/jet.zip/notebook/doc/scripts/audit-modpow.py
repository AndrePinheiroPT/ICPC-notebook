#!/usr/bin/env python3
"""Instantiate affected headers with the actual Contest preamble, C++17."""
from pathlib import Path
import json
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
pre, sep, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep, 'Contest template main not found'
smokes = json.loads((root / 'validation/revision-11/ds-numeric-instantiations.json').read_text())
affected = (
    'content/numerical/ModPow.h', 'content/number-theory/ModMulLL.h',
    'content/numerical/GaussMod.h', 'content/numerical/NTT.h',
    'content/number-theory/Prime64.h', 'content/number-theory/Factor64.h',
    'content/combinatorial/ModComb.h',
)
with tempfile.TemporaryDirectory(prefix='notebook-modpow-audit-') as temp:
    tmp = Path(temp)
    for header in affected:
        src = tmp / 'single.cpp'
        binary = tmp / 'single'
        src.write_text(pre + '\n#include ' + json.dumps(str(root / header)) + '\n' + smokes[header])
        args = ['g++', '-std=gnu++17', '-O1', '-Wall', '-Wextra', '-Werror', str(src)]
        subprocess.run(args + ['-o', str(binary)], check=True)
        subprocess.run([str(binary)], check=True)
        subprocess.run(args + ['-DLOCAL', '-fsyntax-only'], check=True)
        print('PASS isolated + instantiated + LOCAL:', header, flush=True)

    # The legacy path forwards to the new file; including both must be safe.
    src = tmp / 'compat.cpp'
    src.write_text(pre + '\n' + '\n'.join('#include ' + json.dumps(str(root / h)) for h in (
        'content/number-theory/ModMulLL.h', 'content/number-theory/ModPow.h',
        'content/numerical/ModPow.h')) + '\nint main() { assert(modpow(2,10)==1024); '
        'assert(modpow(-2LL,3,5LL)==2); }\n')
    subprocess.run(['g++', '-std=gnu++17', '-Wall', '-Wextra', '-Werror',
                    str(src), '-o', str(tmp / 'compat')], check=True)
    subprocess.run([str(tmp / 'compat')], check=True)
    print('PASS compatibility include order', flush=True)

    # Compile the headers actually printed; ignore commented kactlimport lines.
    chapters = ('math', 'data-structures', 'numerical', 'number-theory',
                'combinatorial', 'graph', 'geometry', 'strings', 'various')
    headers = [f'content/{c}/{h}' for c in chapters for h in re.findall(
        r'^\s*\\kactlimport\{([^}]+\.h)\}',
        (root / 'content' / c / 'chapter.tex').read_text(), re.MULTILINE)]
    src = tmp / 'all.cpp'
    src.write_text(pre + '\n' + '\n'.join('#include ' + json.dumps(str(root / h))
                                         for h in headers) + '\nint main() {}\n')
    subprocess.run(['g++', '-std=gnu++17', '-Wall', '-Wextra', '-Werror',
                    '-fsyntax-only', str(src)], check=True)
    print(f'PASS combined: {len(headers)} active headers', flush=True)
