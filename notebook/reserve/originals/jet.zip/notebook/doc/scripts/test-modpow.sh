#!/usr/bin/env bash
set -euo pipefail
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)

# These runners generate the Contest preamble and exercise all consumers.
bash "$root/doc/scripts/test-chapter-04.sh"
bash "$root/doc/scripts/test-chapter-05.sh"
bash "$root/doc/scripts/test-chapter-06.sh"

tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-modpow.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
extra=()
if [[ -n "${BOOST_INCLUDEDIR:-}" ]]; then
  extra+=(-isystem "$BOOST_INCLUDEDIR")
fi
for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -D_GLIBCXX_DEBUG -fsanitize=address,undefined
      -fno-omit-frame-pointer)
  fi
  echo "$mode: ModMulLL"
  g++ "${flags[@]}" "${extra[@]}" \
    "$root/stress-tests/number-theory/ModMulLL.cpp" -o "$tmp/modmul-$mode"
  "$tmp/modmul-$mode"
done
python3 "$root/doc/scripts/audit-modpow.py"
