#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-ch08.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
extra=()
if [[ -n "${BOOST_INCLUDEDIR:-}" ]]; then
  extra+=(-isystem "$BOOST_INCLUDEDIR")
fi
python3 - "$root" "$tmp/integration.cpp" <<'PY'
from pathlib import Path
import re, sys
root = Path(sys.argv[1])
preamble, sep, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep, 'Contest template main not found'
imports = []
for chapter in ('math','data-structures','numerical','number-theory','combinatorial','graph','geometry'):
    text = (root / 'content' / chapter / 'chapter.tex').read_text()
    for name in re.findall(r'\\kactlimport\{([^}]+\.h)\}', text):
        imports.append(f'#include "content/{chapter}/{name}"\n')
fixture = (root / 'stress-tests/chapter-08/Integration.inc').read_text()
point = ('#pragma GCC diagnostic push\n'
         '#pragma GCC diagnostic ignored "-Wshadow"\n'
         '#pragma GCC diagnostic ignored "-Wconversion"\n'
         '#include "content/geometry/Point.h"\n'
         '#pragma GCC diagnostic pop\n')
Path(sys.argv[2]).write_text(preamble + point + ''.join(imports) + fixture)
PY
for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion -Werror)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -DLOCAL -D_GLIBCXX_DEBUG
      -fsanitize=address,undefined -fno-omit-frame-pointer)
  fi
  echo "$mode: integration with actual Contest template and chapters 2-8"
  g++ "${flags[@]}" -I "$root" "$tmp/integration.cpp" -o "$tmp/integration-$mode"
  "$tmp/integration-$mode"
  for name in Primitives Polygons Circles Spatial Adversarial; do
    echo "$mode: $name"
    g++ "${flags[@]}" "${extra[@]}" "$root/stress-tests/chapter-08/$name.cpp" -o "$tmp/$name-$mode"
    "$tmp/$name-$mode"
  done
done
