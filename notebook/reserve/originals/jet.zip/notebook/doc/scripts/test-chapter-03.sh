#!/usr/bin/env bash
set -euo pipefail
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-ch03.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT

# Assemble the actual Contest preamble with the integration fixture.
python3 - "$root" "$tmp/integration.cpp" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
preamble, sep, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep, 'Contest template main not found'
fixture = (root / 'stress-tests/chapter-03/Integration.inc').read_text()
Path(sys.argv[2]).write_text(preamble + fixture)
PY

for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -DLOCAL -D_GLIBCXX_DEBUG
      -fsanitize=address,undefined -fno-omit-frame-pointer)
  fi
  echo "$mode: integration with actual Contest template"
  g++ "${flags[@]}" -I "$root" "$tmp/integration.cpp" -o "$tmp/integration-$mode"
  "$tmp/integration-$mode"
  for name in Connectivity FenwickPrefix Segment StaticOrdered Adversarial; do
    echo "$mode: $name"
    extra=()
    if [[ "$mode" == debug && "$name" == StaticOrdered ]]; then
      # Full PBDS debug validation is quadratic per mutation. The exact
      # template integration above checks PBDS with _GLIBCXX_DEBUG; run
      # the long randomized suite with ASan/UBSan and normal PBDS.
      extra+=(-U_GLIBCXX_DEBUG)
      echo '  Full stress: ASan/UBSan; PBDS STL-debug covered by integration.'
    fi
    g++ "${flags[@]}" "${extra[@]}" "$root/stress-tests/chapter-03/$name.cpp" -o "$tmp/$name-$mode"
    "$tmp/$name-$mode"
  done
done

# UnionFindRollback keeps the API used by this existing graph algorithm.
echo 'release: DirectedMST compatibility regression'
g++ -std=gnu++17 -O2 "$root/stress-tests/graph/DirectedMST.cpp" -o "$tmp/DirectedMST"
"$tmp/DirectedMST"
