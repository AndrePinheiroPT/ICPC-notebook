#!/usr/bin/env bash
set -euo pipefail
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-ch04.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
extra=()
if [[ -n "${BOOST_INCLUDEDIR:-}" ]]; then
  extra+=(-isystem "$BOOST_INCLUDEDIR")
fi
python3 - "$root" "$tmp/integration.cpp" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
preamble, sep, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep, 'Contest template main not found'
fixture = (root / 'stress-tests/chapter-04/Integration.inc').read_text()
Path(sys.argv[2]).write_text(preamble + fixture)
PY
for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -DLOCAL -D_GLIBCXX_DEBUG
      -fsanitize=address,undefined -fno-omit-frame-pointer)
  fi
  echo "$mode: integration with actual Contest template"
  g++ "${flags[@]}" -I "$root" "$tmp/integration.cpp" -o "$tmp/integration-$mode"
  "$tmp/integration-$mode"
  for name in Search SearchFinite Gauss MatrixBinary NTT Adversarial; do
    echo "$mode: $name"
    g++ "${flags[@]}" "${extra[@]}" "$root/stress-tests/chapter-04/$name.cpp" -o "$tmp/$name-$mode"
    "$tmp/$name-$mode"
  done
done
if [[ "${RUN_MAX:-0}" == 1 ]]; then
  echo 'release: NTT maximum supported length'
  "$tmp/NTT-release" --max
fi
