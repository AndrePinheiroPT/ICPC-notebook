# Estado do notebook

Última entrega: revisão geral de debugging/dependências e alterações 10–15.
Ver `REVISION-RELIABILITY.md` e `NOTEBOOK-RULES.md`.

- PDF final: 25 páginas com capa, 24 numeradas; 3 colunas, 9 pt e margens
  preservadas. Todas as páginas revistas visualmente; sem Overfull.
- Todos os 85 headers ativos compilaram isoladamente, com instanciações
  das APIs, usando apenas o preâmbulo real de Contest e includes explícitos.
  Compilação com LOCAL e compilação conjunta também passaram.
- Testes dos capítulos 1–10 reforçados e concluídos em release e ASan/UBSan.
  STL debug ativo, com a exceção documentada do stress extenso de PBDS;
  a integração e os novos casos pequenos dessa estrutura usam STL debug.
- NTT validada adicionalmente no tamanho máximo de 2^23 elementos.
- RMQ original com STMin/F substituiu SparseTable; KMP.h substituiu o nome
  PrefixFunction.h; BinarySearch usa o corpo fornecido e intervalos [l,r].
- Sums e Series do KACTL original integradas em Mathematics.
- Nenhum erro novo encontrado na implementação dentro dos contratos.
  Limites de tipos, precisão, monotonicidade e stack continuam aplicáveis.
- Logs completos, relatórios de revisão e instanciações isoladas:
  `validation/revision-11/`; resumo verificável em `validation/revision-11.json`.
- As alterações anteriores (originais KACTL, TRIE fornecido, simplificação
  dos tipos, descrições em bullets e blocos de bits) estão preservadas.
- Techniques continua igual ao ficheiro fornecido pelo utilizador.

O ZIP inclui fontes, PDF, runners, testes e logs. Headers legados não
selecionados não são impressos; a auditoria geral incide sobre o notebook
ativo. Os relatórios anteriores conservam os resultados e hashes históricos.
Os avisos de destinos internos duplicados do apêndice são herdados do template.
