# Revisão das implementações e C++17

Esta revisão parte de `notebook-light-visual-studio-espacamento.zip` e aplica as escolhas aprovadas após a comparação com as soluções de jet e zyndek. As únicas referências de implementação foram os ficheiros fornecidos pelo utilizador, incluindo o KACTL original do ZIP inicial.

## Substituições aprovadas

1. Fenwick: ciclos lowbit com índices internos a começar em 1, mantendo a interface pública 0-based e intervalos `[l,r)`.
2. Bellman-Ford: mantido; o núcleo já corresponde ao KACTL original.
3. Euler tour: abordagem iterativa do ficheiro enviado, adaptada à interface TreeTour existente. Corrigidos os cortes e texto alheio ao código presentes no ficheiro enviado.
4. LIS: mantida.
5. SCC: Kosaraju com duas DFS recursivas, preservando IDs topológicos, condensation DAG e compatibilidade com TwoSAT.
6. LCA: binary lifting do ficheiro enviado, completando o return final em falta e mantendo a interface reutilizável e a dependência JumpTable.
7. Topological sort: mantido.
8. Tree diameter: mantido.
9. Modular power: ciclo do KACTL original, conservando tipos genéricos e multiplicação modular segura exigida pelos consumidores.
10. Double hash: versão enviada, com a perda de garantias explicitamente aprovada e documentada. Atualizadas as chamadas afetadas.
11. Functional cycle: Floyd mantido, com sintaxe mais convencional.
12. Subset sum: DP escalar descendente de zyndek, conservando o retorno em bitset.

## Pedidos adicionais

- Acrescentados ou completados Usage curtos nos algoritmos sem implementação correspondente nas solutions, com argumentos, resultado e pré-condições relevantes.
- Template, comandos de compilação, implementações ativas e testes atuais convertidos para GNU C++17. Os recursos de C++20 foram substituídos, incluindo requires, midpoint/lerp e funções de bits.
- Confirmado `par[root] = -1` nas estruturas de árvores e nas raízes DFS de lowlink; predecessores temporários de MinCostFlow passam também a começar em -1. Índices de componentes, DSU e predecessores de ciclos negativos não são tratados como pais de uma árvore.
- Preservados capítulos, ordem dos imports e infraestrutura de geração. Os 18 ficheiros de layout, capítulos e geração registados em `validation/familiar/source-scope.json` são idênticos ao ZIP de partida.

## Validação executada

- 85 headers impressos compilados e instanciados individualmente com o preâmbulo real do template; compilação LOCAL e compilação conjunta dos 85 headers aprovadas.
- Testes de integração e dos comandos compilecp/debugcp, incluindo caminhos com espaços e DEBUG de estruturas aninhadas.
- Testes diferenciais com brute force/oráculos e casos limite em GNU C++17, em release e com AddressSanitizer/UndefinedBehaviorSanitizer e verificações STL.
- Fenwick: 1 244 888 verificações; subset sum: 22 386 casos contra brute force; ciclos funcionais: 36 232 casos.
- Grafos: suites Trees, Connectivity, PathsMST e FlowMatching, em release, sanitizers e STL debug. Incluem raízes diferentes de zero, florestas, ancestrais inexistentes, SCC/TwoSAT e uma cadeia de 100 000 vértices nas estruturas iterativas de árvores.
- Numerical, Number Theory e Combinatorial: buscas, sistemas lineares, NTT, aritmética modular, primalidade, fatorização e combinações. Novos testes de interpolação finita exercitam 1 899 buscas em 459 intervalos por modo.
- Geometry: Primitives, Polygons, Circles, Spatial e Adversarial. Strings: Hashing e Adversarial, incluindo oráculos de aritmética exata, concatenação e o novo contrato do hash.
- Exemplos Usage novos de matemática/numerical/number theory/combinatorial compilados e executados. Logs detalhados em `validation/cpp17-*.log`, respetivos JSON e `validation/familiar/*cpp17*.log`.
- PDF final: 26 páginas A4 landscape. Revisão visual das páginas a 100/145 dpi, sem cortes de código ou sobreposições. Mantidos 3 colunas, 9pt e o tema existente.

Os logs anteriores conservam os resultados e comandos históricos; os ficheiros com `cpp17` identificam os testes desta conversão. LeakSanitizer foi desativado por incompatibilidade com ptrace no ambiente; AddressSanitizer e UndefinedBehaviorSanitizer foram executados.

## Limites aceites e documentados

- Double hash usa base fixa, não inclui o comprimento na chave e reduz os símbolos pelos módulos. Não distingue todos os inteiros de 64 bits; os símbolos devem caber em ll. A concatenação exige potências já calculadas no objeto. É probabilístico, não uma prova de igualdade.
- SCC recursivo está sujeito ao limite da stack. Foi testado com profundidade 2 000 e com uma estrela rasa de 100 000 vértices; não se promete segurança para profundidade arbitrária.
- Subset sum passa a O(nN), sem a aceleração por palavras da operação bitset anterior.

Os testes suportam a correção nos contratos documentados, mas não constituem uma garantia absoluta de ausência de erros para todas as entradas.
