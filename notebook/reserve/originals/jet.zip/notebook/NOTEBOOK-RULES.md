# Regras acordadas para este notebook

- Formato intacto: três colunas, 9 pt, mesmas margens e estilo global.
- Código compacto, limpo, nomes curtos ao estilo KACTL.
- Implementar o algoritmo principal; não acrescentar pesquisas, variantes
  ou funções de conveniência sem pedido explícito.
- Generalizar tipos com templates quando natural; operações só quando simples.
- Reutilizar dependências e o template de Contest fornecido.
- Índices públicos zero-based, intervalos sempre `[l,r)`; índices internos
  one-based quando simplificarem a implementação.
- Descrições só em bullets: o que faz, complexidade e contratos essenciais.
  Usage apenas quando a utilização for menos óbvia.
- Mathematics: bullets, fórmulas e condições; sem explicações extensas.
- Preferir implementações padrão com vetores, sem apontadores desnecessários.
- Exceções pedidas: UF, RollbackUF e SegTree usam os corpos originais do KACTL.
  O SegTree original escolhe o tipo/operação através de T, f e unit.
- LazySegTree: apenas range add e range sum, com template de tipo.
- Prefix sums e difference arrays: apenas versões 2D.
- Rever um capítulo de cada vez, incluindo stress tests quando aplicáveis.
- Entregar ficheiros e PDF; não enviar implementações no chat.

## Revisão pedida após os capítulos 1–10

- Point.h, lineIntersection.h, BellmanFord.h e FloydWarshall.h usam os
  algoritmos originais do KACTL; metadados e disposição podem ser compactados.
- Dijkstra padrão com origem única e notas das otimizações principais.
- Trie usa o TRIE fornecido pelo utilizador, com API e conteúdo intactos;
  só se compacta a apresentação.
- Preferir ll aos 128 bits quando os limites convencionais do algoritmo
  o permitem; documentar limites e conservar 128 bits quando necessários.
- No PDF, as descrições aparecem diretamente em bullets, sem Description:.
- Bit operations em bloco de código simples; complexidades em tabela curta.

## Revisão geral e substituições seguintes

- Auditar dependências usando o preâmbulo real de template.cpp, sem
  introduzir macros/aliases de conveniência apenas para fazer compilar.
  Aliases locais e dependências explicitamente incluídas são válidos.
- RMQ.h: construção e consultas originais do KACTL, com operação
  parametrizada por STMin; a operação é associativa e idempotente.
- KMP.h é o nome do header com prefix function e matching KMP.
- BinarySearch.h usa first_true/last_true fornecidos pelo utilizador.
  Exceção explícita à convenção geral: intervalo fechado [l,r], solução
  existente e aritmética dos midpoints representável em ll.
- Mathematics inclui as fórmulas Sums/Series do original, integrando
  as somas já presentes para evitar repetição.
