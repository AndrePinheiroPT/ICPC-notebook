# Capítulos 9 e 10 — Strings e Various

> Registo histórico desta entrega. Para os contratos e alterações posteriores,
> ver [REVISION-ALGORITHMS.md](REVISION-ALGORITHMS.md).

Esta atualização seleciona oito headers de Strings e oito de Various,
mais notas curtas de DP e operações de bits. Segue as prioridades de
[NOTEBOOK-RULES.md](NOTEBOOK-RULES.md): implementações principais, nomes
curtos, tipos genéricos quando úteis, dependências reutilizadas e
intervalos `[l,r)` com índices a começar em zero.

Os headers legados permanecem intactos e não são importados nestes dois
capítulos. O trie passa para Strings; não se acrescentaram remoção no
trie, XOR trie, suffix tree, eertree ou novas implementações de RMQ.
A redução da seleção por orçamento de páginas não foi antecipada nesta
etapa; permanece uma decisão sobre o notebook completo. O estilo global
de três colunas e 9 pt mantém-se. O PDF desta atualização tem 26 páginas:
capa e 25 páginas numeradas.

## Strings: seleção e contratos

Strings são sequências de bytes, não de caracteres Unicode. Comprimentos,
índices, nós e contagens de padrões devem caber em `int`. Nas rotinas
genéricas de sequências, os elementos têm de suportar as comparações
indicadas; não é necessário reservar um símbolo separador.

| Header | Operação e contrato principal |
| --- | --- |
| `PrefixFunction.h` | `prefixFunction` devolve os maiores prefixos próprios que também são sufixos de cada prefixo. `kmpMatches` devolve todos os inícios, incluindo sobreposições; padrão vazio encontra as `n+1` fronteiras. Tempo linear. |
| `ZFunction.h` | `zFunction` calcula o LCP da sequência com cada sufixo, convencionando `z[0]=0`. Entrada vazia devolve vetor vazio. Tempo linear. |
| `DoubleHash.h` | Hash duplo com substrings `[l,r)` e concatenação; as chaves incluem o comprimento. Construção linear, extração constante; concatenação constante depois de existirem as potências necessárias. |
| `AlphabetTrie.h` | `Trie<K,BASE>` insere cópias, consulta multiplicidade exata e conta cópias com um prefixo. Aceita vazios e repetidos; alfabeto de bytes `[BASE,BASE+K)`. Inserção amortizada `O(K(|s|+1))`, consulta `O(|s|+1)`. |
| `Aho.h` | `Aho<K,BASE>` atribui IDs distintos, mesmo a padrões repetidos. Todas as inserções antecedem a única chamada a `build`. Depois, `go`, `count` e `report` avançam, contam ou enumeram ocorrências. |
| `Suffixes.h` | Suffix array e rank com `n` posições, sem sufixo vazio. `lcp[i]` compara `sa[i]` e `sa[i+1]`, logo tem comprimento `max(0,n-1)`. Construção `O(n log n)`, espaço linear. |
| `Palindromes.h` | Manacher devolve `{odd,even}`: raio ímpar `k` representa `[i-k+1,i+k)`; raio par representa `[i-k,i+k)`. O ímpar inclui o centro. Tempo linear; vazio dá dois vetores vazios. |
| `LeastRotation.h` | Índice da primeira rotação lexicograficamente mínima; devolve zero no vazio. Tempo linear e espaço auxiliar constante. `char` é comparado como byte sem sinal; outros tipos usam a sua ordem. |

`DoubleHash` usa dois módulos primos, bases aleatórias partilhadas entre
objetos e potências partilhadas. Strings usam bytes sem sinal; vetores
inteiros até 64 bits usam a sua representação convertida para `uint64_t`.
Cada símbolo é codificado em quatro dígitos de 16 bits, evitando reduzir
um inteiro grande diretamente a um único resíduo. O hash não conserva
a identidade do tipo original: por exemplo, `-1` convertido de `ll` e
`ULLONG_MAX` têm a mesma representação. A igualdade de chaves permanece
probabilística; os testes não demonstram ausência universal de colisões.
Comprimentos e somas de comprimentos devem ser menores que `INT_MAX`.
O crescimento da tabela de potências tem custo linear no aumento.

Em Aho, os IDs só são guardados no nó terminal; output links permitem
enumerar sem copiar listas para todos os estados. Construção/espaço
`O(KV+P)` para `V` nós e `P` padrões; avanço/contagem `O(1)` e enumeração
`O(1+saída)`. Padrões vazios contam em cada fronteira: consultar também
o estado inicial zero antes de consumir o texto. Para somar ocorrências
ao longo do texto, usar um acumulador suficientemente largo, normalmente
`ll`. Estados e transições também ficam disponíveis para DP no autómato.

Suffix array e rotação usam ordem de bytes sem sinal, incluindo `0`,
`128` e `255`. O LCP de dois sufixos distintos reutiliza
`SparseTable<int>` do capítulo 3 sobre `lcp`, consultando
`[min(rank[i],rank[j]),max(rank[i],rank[j]))`; para `i==j`, vale `n-i`.
O header de suffix array não duplica nem importa automaticamente a RMQ.
As notas incluem ainda a cadeia de borders e a condição de divisibilidade
para o período candidato obtido pela função prefixo.

## Various: seleção e contratos

| Header | Operação e contrato principal |
| --- | --- |
| `Subsequence.h` | `lis` devolve índices de uma LIS; a opção `nondecreasing` dá LNDS. Empates arbitrários, vazio permitido, ordenação estrita fraca dos elementos. `O(n log n)` tempo e `O(n)` espaço. |
| `SubsetBits.h` | Somas alcançáveis em `[0,N)`, com `N>0` em compilação. Cada peso é usado no máximo uma vez; pesos `int/ll` não negativos, zeros permitidos, pesos `>=N` ignorados. Guarda alcançabilidade, sem reconstrução. |
| `SOS.h` | Agregação in-place sobre submáscaras ou supermáscaras, incluindo a própria. Tamanho `2^k>0`; operação associativa e comutativa, soma por omissão, intermediários representáveis em `T`. `O(k 2^k)` operações. |
| `CoverIntervals.h` | Cobertura de `[L,R)` com o menor número de intervalos contínuos `[l,r)`. Devolve IDs originais em ordem, `nullopt` se impossível, vetor vazio se `L==R`. Extremos ordenados, sem NaN. `O(n log n)`. |
| `Histogram.h` | Maior retângulo do histograma, devolvendo `(área,l,r)` para barras `[l,r)`. Alturas inteiras não negativas, larguras positivas; para largura unitária usar uns. Somas de larguras e áreas cabem em `__int128` com sinal. `O(n)`; vazio/tudo zero dá `(0,0,0)`. |
| `FunctionalCycle.h` | Floyd devolve comprimento do prefixo e do ciclo, em `ll`. Transição determinística e eventualmente periódica; igualdade personalizada deve ser uma equivalência preservada pela transição. `O(mu+lambda)` chamadas e `O(1)` estados guardados; contar também o custo de cada estado/chamada. |
| `LineHull.h` | CHT dinâmica para máximos inteiros: inserir retas `kx+m` em qualquer ordem e consultar em `x`, com coeficientes e consultas `ll`. Declives repetidos permitidos; consulta exige pelo menos uma reta. Inserção amortizada e consulta `O(log n)`. |
| `GregorianDays.h` | Data gregoriana válida para número de dias, com `1970-01-01=0`. Calendário proléptico, ano astronómico zero e anos entre `-10^12` e `10^12`; mês/dia começam em um. Resultado `ll`, tempo constante. |

`LineHull` reutiliza `floorDiv` de `IntDivision.h`, capítulo 2. Diferenças
para interseções, limites entre retas e avaliação usam `__int128`; os
produtos não passam primeiro por `ll`. Para mínimos, negar coeficientes
e resposta, desde que essas negações sejam representáveis — em particular,
não negar `LLONG_MIN` em `ll`. Não se fornece remoção de retas.

`GregorianDays` reutiliza a mesma divisão com floor para anos negativos.
O ano zero precede o ano 1; o calendário não inclui lacunas de adoção
histórica. As notas dão diferenças de dias, contagem inclusiva e dia da
semana. Intervalos discretos fechados só devem virar `[a,b+1)` se `b+1`
couber. Em histogramas após compressão, usar larguras geométricas, não
diferenças entre ranks comprimidos.

## Notas de DP e bits

`DPNotes.tex` reúne condições e recorrências curtas para Kadane linear e
circular; knapsack 0/1, ilimitado e limitado; LCS, longest common substring
e edit distance; meet-in-the-middle; digit DP; Held–Karp; DP de intervalos
e minimax; otimizações divide-and-conquer e Knuth; Nim e Sprague–Grundy.
Não se acrescentaram implementações paralelas destes modelos.

As condições delicadas estão explícitas: Kadane circular não pode devolver
um subarray vazio; pesos zero podem tornar knapsack ilimitado sem limite;
reconstrução 0/1 não deve reutilizar predecessores mutáveis de uma só linha;
digit DP define zeros iniciais e validade da memoização entre limites;
atalhos de Held–Karp permitem visitas incidentais apenas quando o modelo
o autoriza. As otimizações de DP exigem monotonicidade dos ótimos e as
condições suficientes indicadas, não apenas uma recorrência parecida.
Knuth usa consistentemente o maior minimizador. Sprague–Grundy aplica-se
a jogos imparciais terminantes, de vitória pela última jogada, com
componentes independentes.

`BitNotes.tex` usa explicitamente inteiros sem sinal de 64 bits: índices
de shift válidos, máscara completa sem deslocar por 64, operações sobre
o bit mais baixo, diferenças entre builtins e operações C++20 no zero,
propriedades de XOR com aritmética alargada, enumeração de submáscaras,
custos `3^k` versus SOS e estimativas de tempo/memória. Os valores de `n`
são estimativas de número de operações, não garantias de tempo de prova.

## Testes e reprodução

Na raiz do notebook:

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapters-09-10.sh
```

São necessários Bash, Python 3 e GNU++20. Boost.Multiprecision é usado
apenas pelos oráculos dos testes; os dezasseis headers não dependem de
Boost. Se necessário, definir `BOOST_INCLUDEDIR` para a pasta de includes;
o runner passa-a como include de sistema, mantendo warnings próprios
como erros. Em ambientes sem a restrição de ptrace, a variável que
desativa LeakSanitizer pode ser omitida; ASan e UBSan continuam ativos.

O runner executa release `-O2` e debug com `-DLOCAL`, `_GLIBCXX_DEBUG`,
AddressSanitizer e UndefinedBehaviorSanitizer. Ambas as configurações
usam `-Wall -Wextra -Wshadow -Wconversion -Werror`. Antes das suites,
compila os headers selecionados dos capítulos 2–10 juntos, com o
preâmbulo extraído do template real de Contest e `Integration.inc`.
Isto verifica integração e dependências; não substitui a execução de
todas as suites históricas dos capítulos anteriores.

Os testes têm sementes fixas; as bases internas do hash continuam
aleatórias. Os oráculos enumeram soluções pequenas ou usam métodos
independentes, incluindo polinómios completos em `cpp_int` para o hash.

| Suite | Contagens registadas |
| --- | --- |
| `Patterns.cpp` | 7 168 sequências; 8 486 KMP; 310 autómatos; 39 940 fronteiras; 59 532 IDs reportados; 35 700 consultas trie; 1 292 791 verificações. |
| `Suffixes.cpp` | 10 648 casos brute; 875 342 consultas LCP com a SparseTable real; 1 714 984 verificações, incluindo sequências de 200 000 bytes. |
| `Hashing.cpp` | 1 112 sequências; 65 827 substrings; 431 313 verificações, incluindo 100 000 símbolos. |
| `SequencesMasks.cpp` | 29 686 LIS/LNDS contra 4 176 342 subsequências; 22 386 subset sums contra 13 258 179 subconjuntos; 12 470 SOS. |
| `IntervalsHistogram.cpp` | 15 334 coberturas contra 3 529 636 subconjuntos; 65 991 histogramas contra 7 365 158 intervalos; casos estruturais de 100 000 elementos. |
| `LinesDatesCycles.cpp` | 1 038 903 consultas de retas; 1 369 622 datas; 35 821 ciclos; 2 741 159 verificações. |
| `Notes.cpp` | 10 345 arrays circulares; 3 485 Knuth / 112 166 intervalos; 3 485 casos de grupos / 143 189 estados; 1 100 casos de bits; 2 048 conjuntos de submáscaras; 1 237 177 verificações. |

As contagens têm granularidades diferentes e não são somadas como se
fossem casos independentes. Em STL debug, os casos estruturais grandes
de LIS usam 2 000 elementos, porque a validação de `lower_bound` percorre
o intervalo; os restantes oráculos mantêm-se.

Detalhes em [README de Strings](stress-tests/chapter-09/README.md) e
[README de Various](stress-tests/chapter-10/README.md). O log agregado é
`validation/chapters-09-10-tests.log`. A execução agregada passou em
release e ASan/UBSan/STL debug, incluindo integração e as sete suites.

## PDF e revisão visual

O PDF foi compilado e as páginas 2 e 19–24 foram inspecionadas visualmente.
Não há avisos `Overfull`; permanecem 38 avisos de destinos duplicados do
apêndice, herdados. Não foram alterados fontes, margens, três colunas ou
tamanho 9 pt. As 26 páginas totais incluem a capa; as páginas numeradas
são 25. Os logs e relatórios das entregas anteriores são históricos.
