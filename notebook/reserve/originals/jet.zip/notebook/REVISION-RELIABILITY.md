# Revisão geral: testes, dependências e substituições

Esta revisão cobre todos os algoritmos selecionados para impressão nos
capítulos 1–10. Os headers legados que não entram no PDF não foram tratados
como parte do notebook ativo. Os logs e as instanciações mínimas estão em
`validation/revision-11/`.

## Alterações 10–15

| Pedido | Resultado |
| --- | --- |
| Debugging geral | Novas suites adversariais em todos os grupos de capítulos, além das suites existentes. Casos exaustivos pequenos, limites inteiros, oráculos independentes e propriedades de transformação. |
| Macros e aliases | Cada header ativo é compilado isoladamente com o preâmbulo real de Contest e um main que instancia a API. O mesmo source é compilado com LOCAL; todos os headers também são compilados em conjunto. Não se acrescentam macros/aliases para ocultar dependências. |
| RMQ | Substitui SparseTable.h. Construção e consulta do RMQ original, com STMin e operação parametrizada. O comentário assinala associatividade e idempotência; mínimo, máximo e GCD são válidos, soma não. |
| Sums e Series | Fórmulas do KACTL fornecido: adicionados soma de quartas potências e intervalo geométrico à secção de somas existente; adicionadas as cinco séries com os domínios de convergência. Evitou-se duplicar as somas já presentes. |
| KMP | PrefixFunction.h passou a KMP.h; implementação preservada, imports e testes atualizados. |
| BinarySearch | Corpo do BinarySearch.cpp fornecido preservado, exceto whitespace. first_true e last_true usam ll e intervalo fechado [l,r], exigem uma resposta existente e diferenças representáveis. |

O template, as três colunas, os 9 pt e as margens foram preservados. Os
limites teóricos n<2^30 da RMQ original e n<INT_MAX em Strings ficaram
explícitos. MinCostFlow distingue agora melhor os limites dos custos das
arestas/distâncias reduzidas e o custo total. As notas da grelha espacial
incluem os offsets usados ao consultar células vizinhas.

## Validação

| Grupo | Novas verificações representativas |
| --- | --- |
| Contest / Mathematics | Configuração e DEBUG reais; aritmética exata em fronteiras de múltiplos, leitura de sequências de tokens, somas comparadas com inteiros ilimitados e séries dentro da convergência. |
| Data structures | UF equilibrado, rollback, vidas de arestas sobrepostas, coordenadas extremas, RMQ com operação idempotente não comutativa e estruturas vazias. |
| Numerical | Pesquisa fornecida nos limites válidos de ll, Gauss com escalas distintas e módulos grandes, GF(2) nas fronteiras de palavras, potências de matrizes com fórmula analítica e NTT densa/limite máximo. |
| Number theory / Combinatorial | Produtos modulares largos, CRT e overflow, números de Carmichael, quadrados de primos grandes, fatorização e identidades combinatórias verificadas independentemente. |
| Graph | Enumerações exaustivas de grafos pequenos: caminhos, componentes, SAT, Euler, capacidades, matchings, preferências, árvores enraizadas e mapas de sucessores. |
| Geometry | Predicados exatos, translações/permutação dos extremos, limites de ll, transformações de polígonos, círculos analíticos e grelha comparada com todos os pares. |
| Strings | Relações de reversão e bijeção do alfabeto, LCP direto contra RMQ, padrões vazios/repetidos/bytes, trie contra set e concatenação de hashes. |
| Various | Ordenação personalizada de LIS, GCD em SOS, histogramas expandidos em barras unitárias, transformações de intervalos, ordem de inserção da CHT, ciclos renomeados, períodos gregorianos, minimax/Grundy e knapsack por enumeração. |

As suites usam GNU++20 em release e ASan/UBSan, com STL debug nos runners.
A suite extensa de PBDS usa ASan/UBSan sem STL debug, cujo verificador
interno tem custo excessivo; a integração e a nova suite pequena de PBDS
continuam a usar STL debug. A NTT no tamanho máximo tem uma execução
adicional otimizada. LeakSanitizer está desligado neste ambiente por causa
da restrição de ptrace; AddressSanitizer e UndefinedBehaviorSanitizer
continuam ativos. Boost é apenas dependência dos oráculos.

A revisão independente encontrou uma data inválida no novo teste de
calendário (1900-02-29); o teste foi corrigido para transitar para 01-03.
Dois avisos de indentação no novo teste também foram corrigidos. O log
`ch09-10-attempt1.log` conserva esse primeiro ensaio; `ch09-10.log` é a
execução completa bem-sucedida. Estes problemas pertenciam aos novos
testes, não à implementação do calendário.

## Limites da conclusão

Não foi encontrado um novo erro de implementação nos domínios documentados.
Os testes reforçam a confiança, mas não demonstram ausência absoluta de
bugs. Continuam a valer os contratos dos headers: aritmética representável,
entrada válida, monotonicidade, condições algébricas e memória/stack
suficientes. Geometria real e Gauss dependem de precisão/condicionamento;
double rolling hash continua probabilístico. A profundidade recursiva de
Dinic e matching deve caber na stack. Não se alteraram estas escolhas sem
pedido, nem se transformaram falhas fora do contrato em sucessos dos testes.

## Reprodução

Na raiz do notebook, com g++, Bash, Python 3 e Boost disponíveis:

```sh
export ASAN_OPTIONS=detect_leaks=0
bash doc/scripts/test-chapters-01-02.sh
bash doc/scripts/test-chapter-03.sh
bash doc/scripts/test-chapter-04.sh
bash doc/scripts/test-chapter-05.sh
bash doc/scripts/test-chapter-06.sh
bash doc/scripts/test-chapter-07.sh
bash doc/scripts/test-chapter-08.sh
bash doc/scripts/test-chapters-09-10.sh
python3 doc/scripts/audit-template.py
```

Se Boost não estiver no include path do sistema, definir BOOST_INCLUDEDIR.
Os relatórios anteriores conservam o histórico das respetivas entregas;
este documento e REVISION-ALGORITHMS.md descrevem as substituições atuais.
