# Atualização dos capítulos 1 e 2

## Conteúdo

- **Contest:** integra o template, a configuração GNU++20 e o troubleshooting
  fornecidos. O conteúdo dos três ficheiros foi preservado byte a byte.
  A configuração chama-se `content/contest/config.sh` para ser importada pelo
  preprocessor LaTeX existente sem problemas com underscores no título.
- **Mathematics:** equações quadráticas, divisão inteira com sinais,
  alinhamento de múltiplos/progressões, somas, aritmética exata, probabilidade,
  esperança, binomial/geométrica e processos aleatórios por estados.
- Novas rotinas: `IntDivision.h`, `ModAlign.h` e `Int128.h`.
  Usam o preâmbulo do template de Contest. `nextTerm` considera uma progressão
  com índice não negativo, começando em `t0`; os alinhamentos são inclusivos
  (primeiro valor maior ou igual a `x`).
- As notas estão em inglês, como o restante notebook. Gauss é referenciado
  como ferramenta do capítulo Numerical; não foi duplicado em Mathematics.

`content/kactl.tex`, o estilo LaTeX, fontes, margens, três colunas e tamanho
9 pt foram preservados. Os fontes dos capítulos 3 em diante e do apêndice
permanecem os do ZIP recebido, ainda por rever nas próximas etapas.
O documento completo continua com 36 páginas, incluindo a capa.

## Compilar o PDF

Na pasta `notebook`, executar `make kactl`. Requer Python 3 e os pacotes LaTeX
já usados pelo projeto. O resultado é `kactl.pdf`.
O ZIP inclui o PDF compilado; os ficheiros temporários de `build/` não são
necessários e não foram incluídos.

## Reproduzir os testes

Na pasta `notebook`:

```sh
bash doc/scripts/test-chapters-01-02.sh
```

Requer Bash, Python 3, GNU C++20 e os headers de Boost.Multiprecision.
Se Boost não estiver no include path do sistema:

```sh
BOOST_INCLUDEDIR=/caminho/para/include bash doc/scripts/test-chapters-01-02.sh
```

O script testa o template/configuração fornecidos, a integração com todos
os novos headers e os três stress tests matemáticos. Executa release e
debug com AddressSanitizer, UndefinedBehaviorSanitizer e verificações STL.
As fixtures `.inc` são fragmentos montados com o template real; os três
ficheiros `.cpp` de matemática também podem ser compilados isoladamente.

Na validação desta entrega, o ambiente com ptrace não permitiu executar
LeakSanitizer, pelo que se usou `ASAN_OPTIONS=detect_leaks=0`. ASan e UBSan
continuaram ativos. A configuração fornecida não foi alterada para desligar
leaks; essa variável só é necessária em ambientes com a mesma restrição.

## Resultados

Ambas as configurações passaram, com GCC 11.4 e Boost 1.74:

| Teste | Casos por configuração |
| --- | ---: |
| Divisão inteira, quatro desigualdades exatas por par | 850 845 |
| Próximo múltiplo | 337 539 |
| Próximo termo de progressão | 1 936 866 |
| Formatação decimal de inteiros de 128 bits | 40 765 |
| Leitura de tokens válidos de 128 bits | 81 541 |
| Leitura de tokens inválidos ou EOF | 2 028 |

São 3 249 584 casos, além dos testes de integração e do template. Os testes
usam seeds fixas, enumeração de valores pequenos, extremos e amostras
aleatórias; o oracle usa inteiros arbitrários. Os 51 927 alinhamentos cujo
resultado não é representável foram identificados pelo oracle e excluídos:
não fazem parte do contrato nem são contados como sucessos.

Verificaram-se também os intervalos de tipos, conservação da saída em
leituras inválidas, consumo completo do token, caminhos com espaços nas
funções de compilação e ausência de efeitos do DEBUG em release.
As fórmulas matemáticas foram revistas; não foram transformadas em testes
que apenas repetiriam a mesma expressão.

O PDF foi compilado e as páginas afetadas foram inspecionadas visualmente.
Não há novos avisos de overflow de caixas LaTeX nos capítulos editados.
Os três avisos `Overfull` preexistentes em Tridiagonal, Bit hacks e SIMD
permanecem nos capítulos não editados. Não foi executada a suite completa
dos algoritmos antigos; a validação desta entrega abrange os capítulos 1 e 2.
