#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using boost::multiprecision::cpp_int;
#include "../../content/combinatorial/Binomial.h"

static size_t families = 0, distributions = 0, catalans = 0;

void inclusionExclusion() {
	for (int u = 0; u <= 5; ++u) for (int k = 0; k <= 3; ++k) {
		unsigned full = (1U<<u)-1;
		for (unsigned code = 0; code < (1U<<(u*k)); ++code) {
			vector<unsigned> a(k);
			unsigned tmp = code, united = 0;
			for (auto& x : a) { x = tmp&full; tmp >>= u; united |= x; }
			ll avoid = 0;
			for (unsigned s = 0; s < (1U<<k); ++s) {
				unsigned inter = full;
				for (int i = 0; i < k; ++i) if (s>>i&1) inter &= a[i];
				avoid += (__builtin_popcount(s)&1 ? -1 : 1)*__builtin_popcount(inter);
			}
			assert(avoid == u-__builtin_popcount(united));
			++families;
		}
	}
}

ll stars(int n, int k) {
	if (n < 0) return 0;
	if (!k) return n == 0;
	return binom(n+k-1,k-1);
}
ll enumerate(int n, const vector<int>& lo, const vector<int>& hi, size_t i=0) {
	if (i == lo.size()) return n == 0;
	ll ans = 0;
	for (int x = lo[i]; x <= hi[i] && x <= n; ++x)
		ans += enumerate(n-x,lo,hi,i+1);
	return ans;
}
void starsBars() {
	for (int n = 0; n <= 12; ++n) for (int k = 0; k <= 6; ++k) {
		assert(stars(n,k) == enumerate(n,vector<int>(k,0),vector<int>(k,n)));
		assert(stars(n-k,k) == enumerate(n,vector<int>(k,1),vector<int>(k,n)));
		distributions += 2;
	}
	mt19937 rng(73463);
	for (int run = 0; run < 3000; ++run) {
		int k = int(rng()%6), n = int(rng()%20);
		vector<int> lo(k), hi(k);
		int rem = n;
		for (int i = 0; i < k; ++i) {
			lo[i] = int(rng()%4); hi[i] = lo[i]+int(rng()%5);
			rem -= lo[i];
		}
		ll ans = 0;
		for (unsigned s = 0; s < (1U<<k); ++s) {
			int left = rem;
			for (int i = 0; i < k; ++i) if (s>>i&1) left -= hi[i]-lo[i]+1;
			ans += (__builtin_popcount(s)&1 ? -1 : 1)*stars(left,k);
		}
		assert(ans == enumerate(n,lo,hi));
		++distributions;
	}
}

ll parentheses(int open, int close) {
	if (!open && !close) return 1;
	ll ans = 0;
	if (open) ans += parentheses(open-1,close);
	if (close > open) ans += parentheses(open,close-1);
	return ans;
}
void catalan() {
	vector<cpp_int> c(101);
	c[0] = 1;
	for (int n = 1; n <= 100; ++n)
		for (int i = 0; i < n; ++i) c[n] += c[i]*c[n-1-i];
	for (int n = 0; n <= 100; ++n) {
		cpp_int b = binom<cpp_int>(2*n,n);
		assert(c[n] == b/(n+1));
		assert(c[n] == b-binom<cpp_int>(2*n,n+1));
		if (n <= 12) assert(c[n] == parentheses(n,n));
		++catalans;
	}
	// No division is needed in the recurrence, even for composite moduli
	// or when factorials become zero modulo m.
	for (int m : {1,2,3,4,6,8,10,12,1000}) {
		vector<ll> a(101); a[0] = 1%m;
		for (int n = 1; n <= 100; ++n) {
			for (int i = 0; i < n; ++i) a[n] = (a[n]+a[i]*a[n-1-i])%m;
			assert(c[n]%m == a[n]);
			++catalans;
		}
	}
}

int main() {
	inclusionExclusion(); starsBars(); catalan();
	cout << "Identities: " << families << " set families, " << distributions
	     << " distributions, " << catalans << " Catalan checks passed\n";
}
