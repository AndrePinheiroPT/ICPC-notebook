# Stress tests — Combinatorial

Executar bash doc/scripts/test-chapter-06.sh na raiz do notebook.
GNU++20; Boost multiprecision apenas nos oráculos. BOOST_INCLUDEDIR é
opcional. No ambiente com ptrace: ASAN_OPTIONS=detect_leaks=0.

O runner usa release e ASan/UBSan/STL debug, com -Werror. Primeiro integra
os headers selecionados dos capítulos 2–6 com o template real de Contest.

Combinations.cpp: Pascal cpp_int e produto descendente independente para
binomiais; fatoriais exatos para resíduos, identidades de inversos e
multinomiais por enumeração. Testa limites dos tipos e dos índices.
Permutations.cpp: órbitas por elemento, inversões, swaps por posições,
composição repetida e padrões conhecidos; enumeração completa até n=8.
Identities.cpp: conjuntos exaustivos, distribuições por enumeração e
Catalan por parênteses, recorrência e fórmulas. Inclui casos vazios,
limites superiores/inferiores conjuntos e módulos compostos.

Sementes fixas tornam os testes reproduzíveis. Ver CHAPTER-06.md para
contratos, contagens e limites; nenhum teste pressupõe as macros all/rep.

## Revisão 11

- Adversarial.cpp: binomiais até 1500 por quociente independente de
  fatoriais cpp_int, linhas extremas por identidades de Wilson para
  primos até 65537, ciclos conjugados por permutações aleatórias de
  índices e permutações inversas até 200003 elementos.
- Resultados: validation/revision-11/ch06.log.
