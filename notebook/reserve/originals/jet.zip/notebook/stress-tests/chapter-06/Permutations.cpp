#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/combinatorial/PermCycles.h"

static mt19937 rng(0xC1C12026);
static uint64_t permutations = 0, orbits = 0, parityChecks = 0;
static uint64_t swapChecks = 0, orderChecks = 0, largePatterns = 0;

void check(const vi& p) {
	int n = sz(p);
	vi saved = p, got = cycleLengths(p), count(n+1), want;
	assert(p == saved);
	// Independent orbit period for every element, without a visited array.
	for (int i = 0; i < n; ++i) {
		int at = i, k = 0;
		do { at = p[at]; ++k; assert(k <= n); } while (at != i);
		++count[k]; ++orbits;
	}
	for (int k = 1; k <= n; ++k) {
		assert(count[k]%k == 0);
		for (int j = 0; j < count[k]/k; ++j) want.push_back(k);
	}
	sort(got.begin(),got.end());
	assert(got == want);
	assert(accumulate(got.begin(),got.end(),0) == n);
	int parity = 0;
	for (int i = 0; i < n; ++i) for (int j = i+1; j < n; ++j)
		parity ^= p[i] > p[j];
	assert(parity == ((n-sz(got))&1)); ++parityChecks;

	// Independently sort by swapping each misplaced value into its position.
	vi a = p, pos(n);
	for (int i = 0; i < n; ++i) pos[a[i]] = i;
	int swaps = 0;
	for (int i = 0; i < n; ++i) if (a[i] != i) {
		int j = pos[i];
		swap(a[i],a[j]);
		pos[a[i]] = i; pos[a[j]] = j; ++swaps;
	}
	for (int i = 0; i < n; ++i) assert(a[i] == i);
	assert(swaps == n-sz(got)); ++swapChecks;

	if (n <= 10) {
		ll order = 1;
		for (int k : got) order = lcm(order,ll(k));
		vi id(n), cur(n), next(n);
		iota(id.begin(),id.end(),0); cur = id;
		ll actual = 0;
		do {
			for (int i = 0; i < n; ++i) next[i] = p[cur[i]];
			cur.swap(next); ++actual;
			assert(actual <= 2520); // Independent bound lcm(1,...,10).
		} while (cur != id);
		assert(actual == order); ++orderChecks;
	}
	++permutations;
}

void known(const vi& p, vi want) {
	vi got = cycleLengths(p);
	sort(got.begin(),got.end()); sort(want.begin(),want.end());
	assert(got == want);
	assert(accumulate(got.begin(),got.end(),0) == sz(p));
	++permutations; ++largePatterns;
}

int main() {
	for (int n = 0; n <= 8; ++n) {
		vi p(n); iota(p.begin(),p.end(),0);
		do { check(p); } while (next_permutation(p.begin(),p.end()));
	}
	check({0,2,1,4,5,3,7,8,9,6}); // Cycle lengths 1,2,3,4.
	for (int test = 0; test < 600; ++test) {
		int n = 9 + int(rng()%492);
		vi p(n); iota(p.begin(),p.end(),0);
		shuffle(p.begin(),p.end(),rng);
		check(p);
	}
	for (int n : {1,2,99999,100000}) {
		vi p(n); iota(p.begin(),p.end(),0);
		known(p,vi(n,1));
		for (int i = 0; i < n; ++i) p[i] = (i+1)%n;
		known(p,{n});
		for (int i = 0; i < n; ++i) p[i] = n-1-i;
		vi want(n/2,2);
		if (n&1) want.push_back(1);
		known(p,want);
	}
	cout << "Permutations: " << permutations << " cases, " << orbits
	     << " independent orbit periods, " << parityChecks << " inversion parities, "
	     << swapChecks << " sorting-swap counts, " << orderChecks
	     << " repeated-application orders, " << largePatterns << " known patterns\n";
}
