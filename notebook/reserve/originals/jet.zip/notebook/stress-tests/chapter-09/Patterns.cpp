#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/strings/KMP.h"
#include "../../content/strings/ZFunction.h"
#include "../../content/strings/Palindromes.h"
#include "../../content/strings/LeastRotation.h"
#include "../../content/strings/Aho.h"
#include "../../content/strings/AlphabetTrie.h"

static mt19937_64 rng(0x491dab5389ULL);
static uint64_t checks=0, sequenceCases=0, matchCases=0, ahoCases=0;
static uint64_t ahoBoundaries=0, reports=0, trieQueries=0;
void ck(bool ok, const char* msg) {
	++checks;
	if (!ok) { cerr << "FAILED Patterns: " << msg << '\n'; abort(); }
}
int rnd(int n) { return int(rng()%uint64_t(n)); }
vi bytes(string_view s) {
	vi a;
	for (unsigned char c : s) a.push_back(c);
	return a;
}
vector<string> words(int alphabet, int maxLen, int base='a') {
	vector<string> out{string{}}, last = out;
	for (int n=1; n<=maxLen; ++n) {
		vector<string> next;
		for (const auto& s : last) for (int c=0; c<alphabet; ++c)
			next.push_back(s+char(base+c));
		out.insert(out.end(),next.begin(),next.end());
		last.swap(next);
	}
	return out;
}
template<class S> void sequenceCase(const S& s, const vi& a) {
	int n=sz(a);
	vi pi(n), z(n);
	array<vi,2> pal{vi(n,1),vi(n)};
	for (int i=0; i<n; ++i) {
		for (int k=1; k<=i; ++k)
			if (equal(a.begin(),a.begin()+k,a.begin()+i+1-k)) pi[i]=k;
		if (i) while (i+z[i]<n && a[z[i]]==a[i+z[i]]) ++z[i];
	}
	// Enumerate every substring; symmetry determines its centre/radius.
	for (int l=0; l<n; ++l) for (int r=l+1; r<=n; ++r) {
		bool ok=true;
		for (int i=l; i<r; ++i) if (a[i]!=a[l+r-1-i]) ok=false;
		if (!ok) continue;
		int len=r-l;
		if (len%2) pal[0][(l+r-1)/2]=max(pal[0][(l+r-1)/2],(len+1)/2);
		else pal[1][(l+r)/2]=max(pal[1][(l+r)/2],len/2);
	}
	int rot=0;
	vi best=a;
	for (int i=1; i<n; ++i) {
		vi candidate;
		for (int k=0; k<n; ++k) candidate.push_back(a[(i+k)%n]);
		if (candidate<best) best=move(candidate), rot=i;
	}
	ck(prefixFunction(s)==pi,"prefix borders");
	ck(zFunction(s)==z,"Z independent LCP");
	ck(palindromes(s)==pal,"Manacher vs all palindromic substrings");
	ck(leastRotation(s)==rot,"rotation enumeration and earliest tie");
	++sequenceCases;
}
template<class S, class P> vi naiveMatch(const S& s,const P& p) {
	vi ans;
	for (int i=0; i+sz(p)<=sz(s); ++i) {
		bool yes=true;
		for (int j=0; j<sz(p); ++j) if (s[i+j]!=p[j]) yes=false;
		if (yes) ans.push_back(i);
	}
	return ans;
}
template<class S, class P> void matchCase(const S& s,const P& p) {
	ck(kmpMatches(s,p)==naiveMatch(s,p),"KMP direct matching incl empty/overlap");
	++matchCases;
}
template<int K, int BASE>
void ahoCase(const vector<string>& patterns,const vector<string>& texts) {
	Aho<K,BASE> ac;
	for (int i=0; i<sz(patterns); ++i) ck(ac.add(patterns[i])==i,"Aho stable distinct IDs");
	ac.build();
	int stored=0;
	for (const auto& node : ac.t) stored+=sz(node.ids);
	ck(stored==sz(patterns),"Aho stores each output ID once");
	for (const auto& s : texts) {
		int v=0;
		vi frequencies(patterns.size());
		ll total=0;
		for (int i=0; i<=sz(s); ++i) {
			if (i) v=ac.go(v,(unsigned char)s[i-1]);
			vi expected, got;
			for (int id=0; id<sz(patterns); ++id) {
				int len=sz(patterns[id]);
				if (len<=i && s.compare(size_t(i-len),size_t(len),patterns[id])==0)
					expected.push_back(id);
			}
			ac.report(v,[&](int id) {
				ck(0<=id && id<sz(patterns),"Aho reported ID range");
				got.push_back(id); ++frequencies[id]; ++reports;
			});
			sort(got.begin(),got.end());
			ck(got==expected,"Aho reports exact suffix patterns per boundary");
			ck(ac.count(v)==sz(expected),"Aho count includes duplicates and empties");
			total+=ac.count(v); ++ahoBoundaries;
		}
		ll expectedTotal=0;
		for (int id=0; id<sz(patterns); ++id) {
			int f=sz(naiveMatch(s,patterns[id]));
			ck(frequencies[id]==f,"Aho each pattern occurrence count");
			expectedTotal+=f;
		}
		ck(total==expectedTotal,"Aho streamed total incl initial boundary");
	}
	++ahoCases;
}
void trieCase(const vector<string>& insertions,const vector<string>& queries) {
	TRIE trie;
	set<string> seen;
	static_assert(is_same_v<decltype(trie.find(string{})),bool>);
	static_assert(is_same_v<decltype(trie.prefix(string{})),bool>);
	ck(trie.idx==1 && trie.get_node("")==0,"trie initial root");
	ck(sz(trie.t)==TRIE::MAX_TRIE_SZ && sz(trie.end)==TRIE::MAX_TRIE_SZ,
		"trie fixed preallocation");
	auto verify=[&] {
		for (const auto& q : queries) {
			bool exact=seen.count(q)!=0,pref=q.empty();
			for (const auto& s : seen) {
				pref|=s.size()>=q.size() && equal(q.begin(),q.end(),s.begin());
			}
			ck(trie.find(q)==exact,"trie exact membership vs set");
			ck(trie.prefix(q)==pref,"trie prefix existence incl empty root");
			int node=trie.get_node(q);
			ck((node!=-1)==pref,"trie get_node existence");
			if (node!=-1) ck(0<=node && node<trie.idx && bool(trie.end[node])==exact,
				"trie node ID and terminal flag");
			++trieQueries;
		}
	};
	verify();
	for (const auto& s : insertions) {
		int before=trie.idx;
		bool duplicate=seen.count(s)!=0;
		trie.add(s); seen.insert(s);
		if (duplicate) ck(trie.idx==before,"duplicate insertion uses no nodes");
		verify();
	}
}

void smallTests() {
	for (const auto& s : words(3,7)) {
		sequenceCase(s,bytes(s));
		vi a=bytes(s);
		for (int& x : a) x=(x-'a')*3-4;
		sequenceCase(a,a);
	}
	auto texts=words(2,6), pats=words(2,4);
	for (const auto& s : texts) for (const auto& p : pats) {
		matchCase(s,p); matchCase(bytes(s),bytes(p));
	}
	string every;
	for (int c=0;c<256;++c) every+=char(c);
	sequenceCase(every,bytes(every));
	reverse(every.begin(),every.end()); sequenceCase(every,bytes(every));
	for (int run=0;run<600;++run) {
		string s, p;
		int n=rnd(31), m=rnd(10);
		for (int i=0;i<n;++i) s+=char(rnd(run%2?256:4));
		for (int i=0;i<m;++i) p+=char(rnd(run%2?256:4));
		sequenceCase(string_view(s),bytes(s));
		matchCase(string_view(s),p);
	}
	for (string s : {string{},string("\0\xff\x80\0",4),string("abababab"),
		string("aaaaaaaa"),string("bbaaccaadd"),string("baabaaba")}) {
		sequenceCase(s,bytes(s)); matchCase(s,s); matchCase(s,string{});
	}
	auto pool=words(2,2), input=words(2,4);
	for (int mask=0;mask<(1<<sz(pool));++mask) {
		vector<string> pat;
		for (int i=0;i<sz(pool);++i) if ((mask>>i)&1) pat.push_back(pool[i]);
		if (mask%3==0 && !pat.empty()) pat.push_back(pat[0]);
		ahoCase<2,'a'>(pat,input);
	}
	for (int run=0;run<180;++run) {
		vector<string> pat, input2;
		for (int i=rnd(18);i--; ) {
			string s;
			for (int j=rnd(9);j--;) s+=char('a'+rnd(3));
			pat.push_back(s);
			if (rnd(4)==0) pat.push_back(s);
		}
		for (int i=0;i<8;++i) {
			string s;
			for (int j=rnd(31);j--;) s+=char('a'+rnd(3));
			input2.push_back(s);
		}
		ahoCase<3,'a'>(pat,input2);
	}
	vector<string> bp={"",string("\0",1),string("\xff",1),string("\x80\0",2),
		string("\0\xff",2),string("\xff",1),""};
	vector<string> bt={"",every,string("\x80\0\xff\0\xff",5),string(10,'\0')};
	ahoCase<256,0>(bp,bt);
	vector<string> high={"",string(1,char(240)),string(1,char(255)),
		string{char(240),char(255)},string{char(255),char(240)}};
	ahoCase<16,240>(high,high);
	// The supplied trie has one fixed a-z alphabet and boolean semantics.
	// Reuse one instance for all short insertions: each constructor clears
	// 200005*26 entries, so do not construct one per random input.
	vector<string> insertions={"a","ab","a","","","abc","z","za","az"};
	auto queries=words(2,4);
	for (int i=0;i<130;++i) {
		string s;
		for (int j=rnd(15);j--;) s+=char('a'+rnd(26));
		insertions.push_back(s); queries.push_back(s);
		queries.push_back(s.substr(0,s.size()/2));
		if (i%3==0) insertions.push_back(s);
	}
	queries.insert(queries.end(),{"abc","abcd","z","za","zz","azy"});
	trieCase(insertions,queries);
}
void largeTests() {
	int n=200000;
	string s(size_t(n),'a');
	auto pi=prefixFunction(s), z=zFunction(s);
	auto pal=palindromes(s);
	for (int i=0;i<n;++i) {
		ck(pi[i]==i,"long repeated prefix");
		ck(z[i]==(i?n-i:0),"long repeated Z");
		ck(pal[0][i]==min(i+1,n-i),"long odd palindrome");
		ck(pal[1][i]==min(i,n-i),"long even palindrome");
	}
	ck(leastRotation(s)==0,"long rotation all equal");
	auto matches=kmpMatches(s,string(4096,'a'));
	ck(sz(matches)==n-4096+1,"long overlapping KMP count");
	for (int i=0;i<sz(matches);++i) ck(matches[i]==i,"long overlapping KMP starts");
	for (int i=0;i<n;++i) s[i]=(i%2?'a':'b');
	ck(leastRotation(s)==1,"long periodic rotation tie");
	Aho<2,'a'> ac;
	ac.add("");ac.add("");
	for (int k=1;k<=512;++k) ac.add(string(size_t(k),'a'));
	ac.build();
	int v=0;
	ck(ac.count(0)==2,"empty Aho matches at initial boundary");
	for (int i=1;i<=10000;++i) {
		v=ac.go(v,'a'); ck(ac.count(v)==2+min(i,512),"long suffix-chain counts");
	}
	vi all; ac.report(v,[&](int id) { all.push_back(id); });
	sort(all.begin(),all.end());
	ck(sz(all)==514,"suffix-chain final outputs");
	for (int i=0;i<sz(all);++i) ck(all[i]==i,"suffix-chain IDs");
	int stored=0;for (const auto& node:ac.t) stored+=sz(node.ids);
	ck(stored==514 && sz(ac.t)==513,"no propagated output vectors");
	v=ac.go(v,'b'); ck(ac.count(v)==2,"failure to root preserves empty matches");
	TRIE trie;
	string deep(size_t(TRIE::MAX_TRIE_SZ-1),'a');
	trie.add(deep);
	ck(trie.idx==TRIE::MAX_TRIE_SZ,"trie capacity includes root");
	trie.add(deep); trie.add("");
	ck(trie.idx==TRIE::MAX_TRIE_SZ,"full trie duplicate/empty insertion");
	ck(trie.find(deep) && trie.find(""),"deep trie exact membership");
	ck(trie.prefix("") && trie.prefix(string(50000,'a')),"deep trie prefix");
	ck(!trie.find(string(50000,'a')),"existing prefix is not necessarily a word");
	ck(!trie.prefix(deep+"b") && trie.get_node(deep+"b")==-1,"deep missing trie extension");
	ck(trie.get_node(deep)==TRIE::MAX_TRIE_SZ-1,"last valid node ID");
}
int main() {
	smallTests();largeTests();
	cout << "Patterns: " << sequenceCases << " sequences, " << matchCases
	     << " KMP cases, " << ahoCases << " automata, " << ahoBoundaries
	     << " boundaries, " << reports << " reported IDs, " << trieQueries
	     << " trie queries; " << checks << " checks passed.\n";
}
