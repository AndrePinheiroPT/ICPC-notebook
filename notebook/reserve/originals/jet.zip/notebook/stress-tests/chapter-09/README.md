# Stress tests — Strings

Na raiz do notebook, executar:

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapters-09-10.sh
```

O runner conjunto usa GNU++17, release e ASan/UBSan com STL debug e
`-Werror`. Antes das suites, integra os headers selecionados dos capítulos
2–10 com o preâmbulo real de Contest. `Integration.inc` é um fragmento
para essa montagem, não um programa autónomo.

Boost só é necessário para o oráculo de `Hashing.cpp`; definir
`BOOST_INCLUDEDIR` quando não estiver disponível nos includes do sistema.
O runner usa `-isystem` para os headers externos. Desativar LeakSanitizer
é necessário neste ambiente com ptrace; ASan/UBSan permanecem ativos.

- `Patterns.cpp`: prefixos por enumeração de borders, Z por comparação
  direta, palíndromos por todos os substrings e rotação por enumeração
  das rotações. KMP é comparado com matching direto; Aho com os padrões
  que terminam em cada fronteira, incluindo a fronteira inicial. Cobre vazios, sobreposições,
  padrões repetidos, bytes `0/128/255`, alfabeto de 256 bytes e base 240,
  sequências genéricas de inteiros e casos longos até 200 000 elementos.
  Verifica que Aho guarda cada ID apenas uma vez, sem propagar listas.
  O TRIE fornecido pelo utilizador é testado separadamente contra um set:
  alfabeto fixo a–z, find/prefix booleanos, get_node, palavra vazia,
  prefixo vazio sempre existente e inserções idempotentes. Inclui o
  preenchimento exato dos 200 005 nós e inserção duplicada já no limite.
  Só se constroem duas instâncias grandes, evitando repetir a inicialização
  da estrutura pré-alocada em cada caso aleatório.
- `Suffixes.cpp`: compara a ordem com comparações diretas de sufixos e
  cada LCP com um scan independente. Consulta pares de sufixos usando
  `RMQ<int>` do capítulo 3 em `[minrank,maxrank)`. Inclui enumeração
  ternária até comprimento 8, todos os bytes e casos repetidos/periódicos
  de 200 000 bytes, sem reservar um sentinela.
- `Hashing.cpp`: usa o preâmbulo real do Contest e constrói o polinómio
  completo em `cpp_int` antes de reduzir módulo cada primo. Verifica
  substrings e concatenação, remoção por concatenação, vazios, negativos,
  LLONG_MIN/MAX, char com o sinal nativo e unsigned char. Inclui chamadas
  entre objetos, o limite das potências por objeto e 100 000 símbolos.
  Testa as colisões esperadas da versão fornecida: comprimentos diferentes,
  símbolos congruentes nos dois módulos e a base fixa. Não pressupõe
  ausência de colisões nem aceita unsigned long long acima de LLONG_MAX.

Contagens: Patterns tem 1 414 044 verificações e 54 648 consultas TRIE;
Suffixes 1 714 984;
Hashing 431 313. São contagens por suite, não uma contagem homogénea de
casos. As três suites e a integração passaram release e ASan/UBSan/STL
debug no runner conjunto. O registo da execução agregada fica em
`validation/revision-10/ch09-10.log`; contratos atuais em
[REVISION-ALGORITHMS.md](../../REVISION-ALGORITHMS.md).
O relatório CHAPTERS-09-10.md e o log anterior são históricos.

## Revisão geral seguinte

Nova revisão: Adversarial.cpp acrescenta 512 093 verificações por modo. KMP.h substitui PrefixFunction.h e RMQ substitui SparseTable nas consultas LCP.

Logs atuais: `validation/revision-11/`. As suites novas incluem o preâmbulo
real do Contest, gerado pelo runner como ContestPreamble.h. Não acrescentam
macros ou aliases ao algoritmo. Ver REVISION-RELIABILITY.md para os métodos
e limites da validação.

## Substituição aprovada — DoubleHash fornecido

`Hashing.cpp`: 1 112 sequências, 66 270 substrings, 69 272 comparações com
oráculo de inteiros arbitrários e 486 054 verificações por execução.
Passou em release, ASan/UBSan/STL debug e release com `-funsigned-char`.
`Adversarial.cpp` mantém 512 093 verificações e usa agora
`h.concat(x,y,lenY)`. Logs desta substituição: `validation/familiar-hash*.log`.
As contagens anteriores acima são registos das revisões históricas.

## Compatibilidade C++17

As suites afetadas pela compatibilidade passaram novamente em GNU++17,
release e ASan/UBSan/STL debug. Resultados atuais em
`validation/cpp17-geometry-*.log` e `validation/cpp17-strings-*.log`.
