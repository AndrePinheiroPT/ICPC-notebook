#include "ContestPreamble.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/strings/DoubleHash.h"
using boost::multiprecision::cpp_int;
using DH = DoubleHash;
using H = array<ll,2>;
static long long cases=0,checks=0,substrings=0,oracles=0;
static void ck(bool ok) {++checks;if(!ok)abort();}

// Arbitrary-precision polynomial: no modular prefix/extraction formula.
static H exact(const vector<ll>& a) {
	++oracles;
	cpp_int value=0;
	for(ll x:a) value=value*911382323+x;
	H ans;
	for(int j=0;j<2;++j) {
		cpp_int r=value%(j ? 1000000009 : 1000000007);
		if(r<0) r+=(j ? 1000000009 : 1000000007);
		ans[j]=r.convert_to<ll>();
	}
	return ans;
}
static void test(const vector<ll>& a,bool oracle) {
	++cases;DH h(a);
	ck(sz(h.h)==sz(a)+1 && sz(h.p)==sz(a)+1);
	for(int l=0;l<=sz(a);++l) for(int r=l;r<=sz(a);++r) {
		++substrings;
		vector<ll> q(a.begin()+l,a.begin()+r);
		DH fresh(q);H key=h.get(l,r);
		ck(key==fresh.get(0,sz(q)));
		if(oracle) ck(key==exact(q));
		for(int m=l;m<=r;++m)
			ck(h.concat(h.get(l,m),h.get(m,r),r-m)==key);
	}
	for(int i=0;i<sz(a);++i) {
		vector<ll> q=a;q.erase(q.begin()+i);DH removed(q);
		ck(h.concat(h.get(0,i),h.get(i+1,sz(a)),sz(a)-i-1)
			==removed.get(0,sz(q)));
	}
}
int main() {
	mt19937_64 rng(0x9102026);
	for(int n=0;n<=8;++n) for(int mask=0;mask<(1<<n);++mask) {
		vector<ll>a(n);for(int i=0;i<n;++i)a[i]=(mask>>i)&1;
		test(a,true);
	}
	for(int t=0;t<600;++t) {
		vector<ll>a(rng()%20);
		for(ll&x:a) {x=ll(rng()>>1);if(rng()&1) x=-x;}
		test(a,true);
	}
	test({LLONG_MIN,LLONG_MAX,-1000000016000000063LL,
		1000000016000000063LL,-1,0,1,1000000007,1000000009},true);
	for(int t=0;t<1000;++t) {
		string s(rng()%60,'\0');vector<ll> native,bytes;
		vector<unsigned char> raw;
		for(char& c:s) {
			c=char(rng()%256);native.push_back((ll)c);
			raw.push_back(static_cast<unsigned char>(c));
			bytes.push_back(raw.back());
		}
		DH h(s),g(native),v{string_view(s)},u(raw);
		ck(h.get(0,sz(s))==g.get(0,sz(s)));
		ck(h.get(0,sz(s))==v.get(0,sz(s)));
		ck(h.get(0,sz(s))==exact(native));
		ck(u.get(0,sz(raw))==exact(bytes));
	}
	vector<int> ints{0,-1,INT_MIN,INT_MAX,42};
	vector<ll> longs(ints.begin(),ints.end());
	ck(DH(ints).get(0,sz(ints))==DH(longs).get(0,sz(longs)));
	vector<unsigned long long> ulls{0,1,42,static_cast<unsigned long long>(LLONG_MAX)};
	vector<ll> fit(ulls.begin(),ulls.end());
	ck(DH(ulls).get(0,sz(ulls))==exact(fit));
	// Approved limits: keys do not store length; residues alias large symbols.
	DH empty(vector<ll>{}),zero(vector<ll>{0}),zeros(vector<ll>{0,0});
	ck(empty.get(0,0)==zero.get(0,1));
	ck(zeros.get(0,2)==zero.get(0,1));
	ck(DH(vector<ll>{1000000016000000063LL}).get(0,1)==zero.get(0,1));
	ck(DH(vector<ll>{-1000000016000000063LL}).get(0,1)==zero.get(0,1));
	// Fixed-base collisions can also occur between equal-length sequences.
	ck(DH(vector<ll>{1,0}).get(0,2)==DH(vector<ll>{0,911382323}).get(0,2));
	// Per-object powers: RHS may use the full capacity; result may be longer.
	vector<ll> a{1,-2,LLONG_MIN,0},twice=a;
	twice.insert(twice.end(),a.begin(),a.end());DH small(a);
	ck(small.concat(small.get(0,4),small.get(0,4),4)==exact(twice));
	ck(small.concat(small.get(0,4),H{},0)==small.get(0,4));
	// Concatenation across distinct objects follows the same fixed bases.
	for(int t=0;t<1000;++t) {
		vector<ll> x(rng()%40),y(rng()%40);
		for(ll&v:x)v=ll(rng()%2001)-1000;
		for(ll&v:y)v=ll(rng()%2001)-1000;
		DH hx(x),hy(y);vector<ll> joined=x;
		joined.insert(joined.end(),y.begin(),y.end());
		ck(hy.concat(hx.get(0,sz(x)),hy.get(0,sz(y)),sz(y))==exact(joined));
	}
	vector<ll> longInput(100000);for(ll&x:longInput)x=ll(rng()>>1);
	DH large(longInput);
	for(int i=0;i<1000;++i) {
		int l=int(rng()%longInput.size()),r=int(rng()%longInput.size());
		if(l>r)swap(l,r);
		int m=l+(r-l)/2;
		ck(large.concat(large.get(l,m),large.get(m,r),r-m)==large.get(l,r));
	}
	cout<<"Hashing: "<<cases<<" sequence cases, "<<substrings
		<<" substrings, "<<oracles<<" independent big-integer oracles, "
		<<checks<<" checks; 100000-symbol case passed\n";
}
