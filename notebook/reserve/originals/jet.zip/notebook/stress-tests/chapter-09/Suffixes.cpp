#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/strings/Suffixes.h"
#include "../../content/data-structures/RMQ.h"
static mt19937_64 rng(0xa6109493ULL);
static uint64_t checks=0,cases=0,lcpQueries=0;
void ck(bool ok,const char* msg) {
	++checks;
	if (!ok) { cerr<<"FAILED Suffixes: "<<msg<<'\n';abort(); }
}
int rnd(int n) { return int(rng()%uint64_t(n)); }
int common(string_view s,int a,int b) {
	int k=0;
	while (a+k<sz(s) && b+k<sz(s) && s[a+k]==s[b+k]) ++k;
	return k;
}
void test(const string& s) {
	int n=sz(s);
	Suffixes a{string_view(s)};
	vi want(n);iota(want.begin(),want.end(),0);
	sort(want.begin(),want.end(),[&](int x,int y) {
		int i=x,j=y;
		while (i<n && j<n && s[i]==s[j]) ++i,++j;
		if (i==n || j==n) return i==n && j!=n;
		return (unsigned char)s[i]<(unsigned char)s[j];
	});
	ck(a.sa==want,"suffix ordering via direct byte comparison");
	ck(sz(a.rank)==n && sz(a.lcp)==max(0,n-1),"sizes without empty suffix");
	for (int r=0;r<n;++r) ck(a.rank[a.sa[r]]==r,"inverse suffix ranks");
	for (int r=0;r+1<n;++r)
		ck(a.lcp[r]==common(s,a.sa[r],a.sa[r+1]),"adjacent LCP direct scan");
	RMQ<int> rmq(a.lcp);
	for (int i=0;i<n;++i) for (int j=0;j<n;++j) {
		if (n>40 && rnd(20)) continue;
		int l=a.rank[i],r=a.rank[j];if (l>r) swap(l,r);
		int got=i==j?n-i:rmq.query(l,r);
		ck(got==common(s,i,j),"LCP via actual chapter3 RMQ [minrank,maxrank)");
		++lcpQueries;
	}
	++cases;
}
void smallTests() {
	vector<string> level{string{}};
	for (int n=0;n<=8;++n) {
		for (const auto& s:level) test(s);
		if (n==8) break;
		vector<string> next;
		for (const auto& s:level) for (int c:{0,128,255})
			next.push_back(s+char(c));
		level.swap(next);
	}
	for (const string& s:{string("banana"),string("mississippi"),string("abababab"),
		string("\0\0\0",3),string("\xff\0\xff\x80\0",5)}) test(s);
	string all;
	for (int c=0;c<256;++c) all+=char(c);
	test(all);reverse(all.begin(),all.end());test(all);
	for (int run=0;run<800;++run) {
		string s;
		int n=rnd(100);
		for (int i=0;i<n;++i) s+=char(rnd(run%2?256:4));
		test(s);
	}
	Suffixes banana("banana");
	ck(banana.sa==vi({5,3,1,0,4,2}) && banana.lcp==vi({1,3,0,0,2}),"banana regression");
}
void largeTests() {
	int n=200000;
	Suffixes a(string(size_t(n),'\0'));
	for (int i=0;i<n;++i) {
		ck(a.sa[i]==n-1-i && a.rank[i]==n-1-i,"long identical suffix ordering");
		if (i+1<n) ck(a.lcp[i]==i+1,"long identical LCP");
	}
	string s(size_t(n),'\0');
	for (int i=0;i<n;++i) s[i]=char(i%2?255:0);
	Suffixes b(s);
	vi want;
	for (int byte:{0,255}) for (int i=n-1;i>=0;--i)
		if ((unsigned char)s[i]==byte) want.push_back(i);
	ck(b.sa==want,"long periodic byte suffix ordering");
	for (int i=0;i+1<n;++i) {
		int u=b.sa[i],v=b.sa[i+1];
		int expected=s[u]==s[v]?min(n-u,n-v):0;
		ck(b.lcp[i]==expected,"long periodic LCP");
	}
	RMQ<int> rmq(b.lcp);
	for (int k=0;k<10000;++k) {
		int u=rnd(n),v=rnd(n),l=b.rank[u],r=b.rank[v];
		if (l>r) swap(l,r);
		int got=u==v?n-u:rmq.query(l,r);
		ck(got==(s[u]==s[v]?min(n-u,n-v):0),"long periodic RMQ LCP");
		++lcpQueries;
	}
}
int main() {
	smallTests();largeTests();
	cout<<"Suffixes: "<<cases<<" brute cases, "<<lcpQueries
		<<" RMQ LCP queries; "<<checks<<" checks passed, including 200000-byte cases\n";
}
