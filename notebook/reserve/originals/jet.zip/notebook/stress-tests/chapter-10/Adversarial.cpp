#include "ContestPreamble.h"
#include "../../content/various/Subsequence.h"
#include "../../content/various/SubsetBits.h"
#include "../../content/various/SOS.h"
#include "../../content/various/CoverIntervals.h"
#include "../../content/various/Histogram.h"
#include "../../content/various/LineHull.h"
#include "../../content/various/FunctionalCycle.h"
#include "../../content/various/GregorianDays.h"

static mt19937_64 gen(0xbaff7122026ULL);
static uint64_t checks=0;
void ck(bool ok){++checks;if(!ok)abort();}
int rnd(int n){return int(gen()%unsigned(n));}
struct Key {
 int order,payload;
 bool operator<(const Key& b) const {return order<b.order;}
};
void sequences() {
 for(int run=0;run<1200;++run){
  int n=rnd(35);vector<Key>a;for(int i=0;i<n;++i)a.push_back({rnd(9)-4,rnd(1000)});
  for(bool equal:{false,true}){
   auto got=lis(a,equal);int best=0;vi dp(n,1);
   for(int i=0;i<n;++i){for(int j=0;j<i;++j)if(equal?a[j].order<=a[i].order:a[j].order<a[i].order)dp[i]=max(dp[i],dp[j]+1);best=max(best,dp[i]);}
   ck(sz(got)==best);
   for(int i=1;i<sz(got);++i){ck(got[i-1]<got[i]);ck(equal?a[got[i-1]].order<=a[got[i]].order:a[got[i-1]].order<a[got[i]].order);}
  }
  vector<ll>w;for(int i=0;i<10;++i)w.push_back(rnd(130));if(run%7==0)w.push_back(LLONG_MAX);
  auto got=subsetBits<129>(w);vector<bool>reach(129);reach[0]=true;
  for(ll x:w){auto prev=reach;for(int s=0;s<129;++s)if(s>=x)reach[s]=reach[s]||prev[size_t(s-x)];}
  for(int s=0;s<129;++s)ck(got[size_t(s)]==reach[s]);
  shuffle(w.begin(),w.end(),gen);ck(subsetBits<129>(w)==got);
  int k=rnd(8);vector<int>base(size_t(1)<<k);for(int& x:base)x=rnd(1000);
  for(bool upper:{false,true}){
   auto agg=base;sos(agg,upper,[](int x,int y){return gcd(x,y);});
   for(int m=0;m<sz(base);++m){int g=0;for(int s=0;s<sz(base);++s)if(upper?(s&m)==m:(s&m)==s)g=gcd(g,base[s]);ck(agg[m]==g);}
  }
 }
}
ll expandedArea(const vi& h,const vi& w){
 vi a;for(int i=0;i<sz(h);++i)for(int j=0;j<w[i];++j)a.push_back(h[i]);
 ll best=0;for(int l=0;l<sz(a);++l){int low=INT_MAX;for(int r=l;r<sz(a);++r){low=min(low,a[r]);best=max(best,ll(low)*(r-l+1));}}
 return best;
}
void intervals(){
 for(int run=0;run<3000;++run){
  int n=rnd(14);vi h(n),w(n);for(int& x:h)x=rnd(21);for(int& x:w)x=1+rnd(5);
  ll expected=expandedArea(h,w);auto [area,l,r]=largestRectangle(h,w);ck(area==expected);
  if(area){int low=*min_element(h.begin()+l,h.begin()+r);ck(ll(low)*accumulate(w.begin()+l,w.begin()+r,0LL)==area);}
  reverse(h.begin(),h.end());reverse(w.begin(),w.end());ck(get<0>(largestRectangle(h,w))==area);
  for(int& x:h) x*=7;
  for(int& x:w) x*=3;
  ck(get<0>(largestRectangle(h,w))==area*21);
  vector<pair<ll,ll>> seg;for(int i=0;i<10;++i){ll x=rnd(21)-10,y=rnd(21)-10;if(x>y)swap(x,y);seg.push_back({x,y});}
  auto first=coverIntervals(seg,-7LL,8LL);shuffle(seg.begin(),seg.end(),gen);
  for(auto& [x,y]:seg){x=13*x-1000000000000LL;y=13*y-1000000000000LL;}
  auto second=coverIntervals(seg,-91LL-1000000000000LL,104LL-1000000000000LL);
  ck(bool(first)==bool(second));if(first)ck(first->size()==second->size());
 }
}
void linesCyclesDates(){
 for(int run=0;run<250;++run){
  vector<pair<ll,ll>>line;for(int i=0;i<80;++i)line.push_back({rnd(101)-50,rnd(201)-100});
  LineHull a,b;for(auto [k,m]:line)a.add(k,m);
  reverse(line.begin(),line.end());for(auto [k,m]:line)b.add(k,m);
  for(ll x=-140;x<=140;++x){ll expected=LLONG_MIN;for(auto [k,m]:line)expected=max(expected,k*x+m);ck(a.query(x)==expected);ck(b.query(x)==expected);}
  int mu=rnd(400),len=1+rnd(400);vector<int>p(size_t(mu+len));iota(p.begin(),p.end(),0);shuffle(p.begin(),p.end(),gen);vi next(sz(p));
  for(int i=0;i<sz(p)-1;++i) next[p[i]]=p[i+1];
  next[p.back()]=p[mu];
  ck((floydCycle(p[0],[&](int v){return next[v];})==pair<ll,ll>{mu,len}));
 }
 for(ll y:{-1000000000000LL,-400LL,0LL,1900LL,2000LL,999999999600LL}){
  for(int m=1;m<=12;++m)for(int d=1;d<=28;++d){ck(gregorianDays(y+400,m,d)-gregorianDays(y,m,d)==146097);bool leap=y%4==0 && (y%100!=0 || y%400==0);
   ll next=(m==2 && d==28 && !leap)?gregorianDays(y,3,1):gregorianDays(y,m,d+1);
   ck(next-gregorianDays(y,m,d)==1);}
 }
}
void gamesAndKnapsack(){
 // Independent exhaustive minimax on a sum of subtraction games.
 for(int rule=1;rule<16;++rule){
  vi grundy(16);for(int n=0;n<16;++n){set<int>s;for(int x=1;x<=4;++x)if((rule>>(x-1)&1)&&x<=n)s.insert(grundy[n-x]);while(s.count(grundy[n]))++grundy[n];}
  bool win[16][16]{};for(int a=0;a<16;++a)for(int b=0;b<16;++b){for(int x=1;x<=4;++x)if(rule>>(x-1)&1){if(x<=a&&!win[a-x][b])win[a][b]=true;if(x<=b&&!win[a][b-x])win[a][b]=true;}ck(win[a][b]==bool(grundy[a]^grundy[b]));}
 }
 for(int run=0;run<500;++run){
  int cap=rnd(25),n=1+rnd(5);vi w(n),v(n),count(n);for(int i=0;i<n;++i){w[i]=rnd(8);v[i]=rnd(21)-10;count[i]=rnd(6);}
  int expected=0;auto enumerate=[&](auto&& self,int i,int weight,int value)->void{if(weight>cap)return;if(i==n){expected=max(expected,value);return;}for(int k=0;k<=count[i];++k)self(self,i+1,weight+k*w[i],value+k*v[i]);};enumerate(enumerate,0,0,0);
  vi dp(cap+1);for(int i=0;i<n;++i){int remain=count[i];for(int p=1;remain;p*=2){int q=min(p,remain);remain-=q;for(int x=cap;x>=q*w[i];--x)dp[x]=max(dp[x],dp[x-q*w[i]]+q*v[i]);}}
  ck(dp[cap]==expected);
 }
}
int main(){sequences();intervals();linesCyclesDates();gamesAndKnapsack();cout<<"Various adversarial: "<<checks<<" checks; custom ordering, GCD SOS, expanded histograms, cover transformations, CHT permutations, labelled cycles, calendar periods, Grundy/minimax and bounded knapsack passed\n";}
