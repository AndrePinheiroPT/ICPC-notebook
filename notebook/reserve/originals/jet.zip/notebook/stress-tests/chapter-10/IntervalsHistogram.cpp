#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/various/CoverIntervals.h"
#include "../../content/various/Histogram.h"

using I = __int128;
mt19937_64 rng(0x10c0a3e);
size_t coverCases = 0, histCases = 0, subsets = 0, histRanges = 0;
int rnd(int n) { return int(rng()%unsigned(n)); }

// Reduce continuous coverage to elementary cells, then enumerate every
// choice of input intervals as a set-cover problem, independently of greedy.
template<class T>
int bruteCover(const vector<pair<T,T>>& seg, T L, T R) {
	if (L == R) return 0;
	vector<T> cuts{L,R};
	for (auto [l,r] : seg) {
		if (L < l && l < R) cuts.push_back(l);
		if (L < r && r < R) cuts.push_back(r);
	}
	sort(cuts.begin(),cuts.end());
	cuts.erase(unique(cuts.begin(),cuts.end()),cuts.end());
	assert(sz(cuts) <= 64);
	uint64_t full = (uint64_t(1) << (sz(cuts)-1))-1;
	vector<uint64_t> coverage(seg.size());
	for (int i = 0; i < sz(seg); ++i)
		for (int j = 1; j < sz(cuts); ++j)
			if (seg[i].first <= cuts[j-1] && cuts[j] <= seg[i].second)
				coverage[i] |= uint64_t(1) << (j-1);
	vector<uint64_t> masks(size_t(1) << sz(seg));
	int best = sz(seg)+1;
	for (unsigned mask = 1; mask < masks.size(); ++mask) {
		unsigned bit = unsigned(__builtin_ctz(mask));
		masks[mask] = masks[mask & (mask-1)] | coverage[bit];
		if (masks[mask] == full)
			best = min(best,__builtin_popcount(mask));
		++subsets;
	}
	return best <= sz(seg) ? best : -1;
}

template<class T>
void checkCover(const vector<pair<T,T>>& seg, T L, T R) {
	++coverCases;
	int expected = bruteCover(seg,L,R);
	auto copy = seg;
	auto actual = coverIntervals(seg,L,R);
	assert(copy == seg);
	assert(bool(actual) == (expected >= 0));
	if (!actual) return;
	assert(sz(*actual) == expected);
	vector<bool> seen(seg.size());
	T reached = L;
	for (int id : *actual) {
		assert(0 <= id && id < sz(seg) && !seen[id]);
		seen[id] = true;
		assert(seg[id].first <= reached && reached < seg[id].second);
		reached = seg[id].second;
	}
	assert(reached >= R);
}

template<class H, class W>
void checkHistogram(const vector<H>& h, const vector<W>& w) {
	++histCases;
	I expected = 0;
	for (int l = 0; l < sz(h); ++l) {
		H height = h[l];
		I width = 0;
		for (int r = l; r < sz(h); ++r) {
			height = min(height,h[r]); width += w[r];
			expected = max(expected,I(height)*width); ++histRanges;
		}
	}
	auto hc = h;
	auto wc = w;
	assert(expected <= LLONG_MAX);
	I totalWidth=0;
	for (W x : w) totalWidth+=I(x);
	assert(totalWidth <= LLONG_MAX);
	auto [area,l,r] = largestRectangle(h,w);
	static_assert(is_same_v<decltype(area),ll>);
	assert(h == hc && w == wc && area == expected);
	assert(0 <= l && l <= r && r <= sz(h));
	if (!expected) assert(l == 0 && r == 0);
	else {
		assert(l < r);
		H height = h[l];
		I width = 0;
		for (int i = l; i < r; ++i) {
			height = min(height,h[i]); width += w[i];
		}
		assert(I(height)*width == area);
	}
}

void intervals() {
	vector<pair<int,int>> types;
	for (int l = -1; l <= 1; ++l)
		for (int r = l; r <= 1; ++r) types.push_back({l,r});
	int ways = 1;
	for (int n = 0; n <= 4; ++n) {
		for (int mask = 0; mask < ways; ++mask) {
			vector<pair<int,int>> seg(n);
			int code = mask;
			for (auto& interval : seg) {
				interval = types[code%sz(types)]; code /= sz(types);
			}
			for (auto [L,R] : types) checkCover(seg,L,R);
		}
		ways *= sz(types);
	}
	for (int run = 0; run < 3000; ++run) {
		vector<pair<int,int>> seg(rnd(13));
		for (auto& [l,r] : seg) {
			l = rnd(21)-10; r = rnd(21)-10;
			if (l > r) swap(l,r);
		}
		int L = rnd(17)-8, R = rnd(17)-8;
		if (L > R) swap(L,R);
		checkCover(seg,L,R);
		vector<pair<ll,ll>> shifted;
		for (auto [l,r] : seg) shifted.push_back({LLONG_MIN+100+l,LLONG_MIN+100+r});
		checkCover(shifted,LLONG_MIN+100+L,LLONG_MIN+100+R);
	}
	checkCover(vector<pair<ll,ll>>{{LLONG_MIN,0},{0,LLONG_MAX}},LLONG_MIN,LLONG_MAX);
	checkCover(vector<pair<ll,ll>>{{LLONG_MIN,-1},{0,LLONG_MAX}},LLONG_MIN,LLONG_MAX);
	checkCover(vector<pair<long double,long double>>{{0,1},{1.5L,2}},0.0L,2.0L);
	checkCover(vector<pair<long double,long double>>{{0,1.5L},{1.5L,2}},0.0L,2.0L);
	constexpr int n = 100000;
	vector<pair<int,int>> chain;
	for (int i = 0; i < n; ++i) chain.push_back({i,i+1});
	shuffle(chain.begin(),chain.end(),rng);
	auto all = coverIntervals(chain,0,n);
	assert(all && sz(*all) == n);
	for (int i = 0; i < n; ++i) assert(chain[(*all)[i]] == make_pair(i,i+1));
	chain.push_back({0,n});
	auto one = coverIntervals(chain,0,n);
	assert(one && *one == vi{n});
}

void histograms() {
	int ways = 1;
	for (int n = 0; n <= 6; ++n) {
		for (int mask = 0; mask < ways; ++mask) {
			vi h(n),w(n);
			int code = mask;
			for (int i = 0; i < n; ++i) {
				h[i] = code%3; w[i] = (code%6)/3+1; code /= 6;
			}
			checkHistogram(h,w);
		}
		ways *= 6;
	}
	for (int run = 0; run < 5000; ++run) {
		int n = rnd(61);
		vector<ll> h(n);
		vi w(n);
		for (int i = 0; i < n; ++i) {
			h[i] = rnd(51); w[i] = 1+rnd(15);
		}
		checkHistogram(h,w);
		vector<ll> widths(w.begin(),w.end());
		for (ll& x : widths) x *= 1000000000000LL;
		checkHistogram(h,widths);
	}
	checkHistogram(vector<ll>{LLONG_MAX},vi{1});
	checkHistogram(vector<ll>(2,LLONG_MAX/2),vi{1,1});
	checkHistogram(vi{1,1},vector<ll>{LLONG_MAX-1,1});
	checkHistogram(vi{0,0},vector<ll>{LLONG_MAX-1,1});
	checkHistogram(vi(4,INT_MAX),vi(4,1));
	checkHistogram(vector<unsigned long long>{ULLONG_MAX/2},vi{1});
	checkHistogram(vi{2,2,2},vector<ll>(3,LLONG_MAX/6));
	constexpr int n = 100000;
	vi h(n),w(n,1);
	iota(h.begin(),h.end(),1);
	auto [area,l,r] = largestRectangle(h,w);
	assert(area == I(n+1)*(n+1)/4 && 0 <= l && l < r && r <= n);
	h.assign(n,7);
	I width = 0;
	for (int i = 0; i < n; ++i) width += w[i] = 1+i%17;
	auto plateau = largestRectangle(h,w);
	assert(plateau == make_tuple(ll(7*width),0,n));
	h.assign(n,0);
	assert(largestRectangle(h,w) == make_tuple(0LL,0,0));
}

int main() {
	intervals(); histograms();
	cout << "IntervalsHistogram: " << coverCases << " interval-cover cases ("
		<< subsets << " subsets), " << histCases << " histogram cases ("
		<< histRanges << " brute ranges); 100000-interval/bar structural cases passed\n";
}
