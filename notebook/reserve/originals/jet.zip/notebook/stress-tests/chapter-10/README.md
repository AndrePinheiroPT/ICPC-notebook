# Stress tests — Various

Na raiz do notebook, executar:

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapters-09-10.sh
```

Requer GNU++20, Bash e Python 3. O runner conjunto executa release e
ASan/UBSan/STL debug, com warnings como erros. Boost é uma dependência
apenas dos oráculos que o incluem, não dos algoritmos; usar
`BOOST_INCLUDEDIR` se os headers não estiverem instalados no sistema.
LeakSanitizer é desativado neste ambiente com ptrace, mantendo ASan/UBSan.

`Integration.inc` é montado com o preâmbulo real de Contest e todos os
headers selecionados dos capítulos 2–10. Exercita também dependências
reutilizadas: `RMQ` no LCP, `IntDivision` em CHT/datas, DSU,
combinatória, árvores, fluxo e geometria. Não substitui as suites completas
das entregas anteriores.

- `SequencesMasks.cpp`: LIS/LNDS contra DP quadrática e enumeração de
  subsequências, validando índices e reconstrução; subset sum contra
  todos os subconjuntos; SOS contra agregação explícita de todos os
  sub/superconjuntos. Inclui vazios onde permitidos, repetidos, limites
  de bitsets entre palavras, pesos grandes, soma/min/OR e tipos genéricos.
  Casos estruturais: 100 000 pesos e SOS de 20 bits. LIS usa 100 000
  elementos em release e 2 000 em STL debug, cuja validação interna de
  `lower_bound` percorre os intervalos.
- `IntervalsHistogram.cpp`: cobertura mínima por enumeração de conjuntos
  de intervalos sobre células elementares, independentemente do greedy;
  histograma por todos os intervalos de barras, verificando a área e os
  limites reconstruídos. Cobre vazios, falhas, intervalos encostados,
  tipos `int/ll/long double` nas coberturas e larguras variáveis no
  histograma. O histograma devolve `ll`; o oráculo em 128 bits verifica
  previamente que valores, soma de larguras e áreas cabem nesse domínio.
  Inclui 100 000 intervalos/barras e limites representáveis de `ll`.
- `LinesDatesCycles.cpp`: CHT contra todas as retas inseridas, com ordem
  arbitrária, declives repetidos, breakpoints negativos/fracionários e
  limites válidos de `ll`, comparando em `__int128`. Os testes verificam
  também o domínio de diferenças, quocientes, produtos e somas da CHT;
  consultas exigem `x > -LLONG_MAX`, acima do sentinela negativo.
  Datas contra percurso diário
  independente de -800 a 2400 e contagem de anos bissextos até ±10^12,
  incluindo ano zero e calendário proléptico. Floyd contra órbitas
  visitadas explicitamente, todos os grafos funcionais pequenos e estados
  genéricos; testa também uma equivalência compatível com a transição.
- `Notes.cpp`: Kadane contra todos os intervalos circulares não vazios;
  Knuth contra DP cúbica de todos os splits, incluindo o maior minimizador;
  divide-and-conquer contra DP quadrática com custos somados diretamente;
  bits de 32/64 bits contra aritmética mais larga e enumeração independente
  de submáscaras. A suite valida condições delicadas das notas, não
  demonstra que qualquer custo de um problema satisfaça Monge/Knuth.

Contagens registadas: 29 686 casos LIS/LNDS, 22 386 subset sums e 12 470
SOS; 15 334 coberturas e 65 994 histogramas; 987 452 consultas CHT,
1 369 622 datas e 36 232 ciclos. LinesDatesCycles soma 13 870 587 checks,
incluindo os checks do domínio dos inputs. As categorias não devem ser
somadas como uma única medida de cobertura. `Notes.cpp` tem 1 524 277 verificações:
10 345 arrays circulares, 3 485 casos Knuth / 112 166 intervalos,
3 485 casos de grupos / 143 189 estados, 2 200 casos de bits e 2 048
conjuntos de submáscaras. Todas as suites e a integração passaram em
release e ASan/UBSan/STL debug no runner conjunto.

Inputs usam sementes fixas. Resultados e progresso do runner em
`validation/revision-10/ch09-10.log`; contratos atuais em
[REVISION-ALGORITHMS.md](../../REVISION-ALGORITHMS.md).
O relatório CHAPTERS-09-10.md e o log anterior são históricos.

## Revisão geral seguinte

Nova revisão: Adversarial.cpp acrescenta 427 440 verificações por modo; inclui oráculos independentes e propriedades de transformação, além das suites anteriores.

Logs atuais: `validation/revision-11/`. As suites novas incluem o preâmbulo
real do Contest, gerado pelo runner como ContestPreamble.h. Não acrescentam
macros ou aliases ao algoritmo. Ver REVISION-RELIABILITY.md para os métodos
e limites da validação.
