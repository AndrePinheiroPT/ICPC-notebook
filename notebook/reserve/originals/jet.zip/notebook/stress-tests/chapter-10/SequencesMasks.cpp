#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/various/Subsequence.h"
#include "../../content/various/SubsetBits.h"
#include "../../content/various/SOS.h"

mt19937_64 rng(0x10e51a5);
size_t lisCases = 0, subsetCases = 0, sosCases = 0;
size_t enumeratedSubsequences = 0, enumeratedSubsets = 0;
int rnd(int n) { return int(rng()%unsigned(n)); }

template<class T>
int bruteLIS(const vector<T>& a, bool nondecreasing) {
	int best = 0;
	for (unsigned mask = 0; mask < (1U << sz(a)); ++mask) {
		int last = -1, length = 0;
		bool valid = true;
		for (int i = 0; i < sz(a); ++i) if ((mask >> i)&1U) {
			if (last >= 0)
				valid &= nondecreasing ? !(a[i] < a[last]) : a[last] < a[i];
			last = i; ++length;
		}
		if (valid) best = max(best,length);
		++enumeratedSubsequences;
	}
	return best;
}

template<class T>
void checkLIS(const vector<T>& a, bool brute = true) {
	for (bool nondecreasing : {false,true}) {
		++lisCases;
		vi dp(sz(a),1);
		int expected = 0;
		for (int i = 0; i < sz(a); ++i) {
			for (int j = 0; j < i; ++j)
				if (nondecreasing ? !(a[i] < a[j]) : a[j] < a[i])
					dp[i] = max(dp[i],dp[j]+1);
			expected = max(expected,dp[i]);
		}
		if (brute) assert(expected == bruteLIS(a,nondecreasing));
		auto copy = a;
		vi ids = lis(a,nondecreasing);
		assert(a == copy && sz(ids) == expected);
		for (int j = 0; j < sz(ids); ++j) {
			int i = ids[j];
			assert(0 <= i && i < sz(a));
			if (j) {
				int prev = ids[j-1];
				assert(prev < i);
				assert(nondecreasing ? !(a[i] < a[prev]) : a[prev] < a[i]);
			}
		}
	}
}

template<size_t N, class T>
void checkSubset(const vector<T>& w) {
	++subsetCases;
	vector<__int128> sums(size_t(1) << sz(w));
	bitset<N> expected;
	expected[0] = 1;
	for (unsigned mask = 1; mask < sums.size(); ++mask) {
		unsigned bit = unsigned(__builtin_ctz(mask));
		sums[mask] = sums[mask & (mask-1)]+w[bit];
		if (sums[mask] < __int128(N)) expected[size_t(sums[mask])] = 1;
	}
	assert(subsetBits<N>(w) == expected);
	enumeratedSubsets += sums.size();
}

template<class T, class Op>
void checkSOS(const vector<T>& original, Op op) {
	for (bool supersets : {false,true}) {
		++sosCases;
		auto actual = original;
		sos(actual,supersets,op);
		for (int mask = 0; mask < sz(original); ++mask) {
			T expected = original[mask];
			for (int other = 0; other < sz(original); ++other) {
				if (other == mask) continue;
				bool related = supersets ? (other & mask) == mask
					: (other & mask) == other;
				if (related) expected = op(expected,original[other]);
			}
			assert(actual[mask] == expected);
		}
	}
}

void sequences() {
	int ways = 1;
	for (int n = 0; n <= 8; ++n) {
		for (int mask = 0; mask < ways; ++mask) {
			vi a(n);
			int code = mask;
			for (int& x : a) x = code%3-1, code /= 3;
			checkLIS(a);
		}
		ways *= 3;
	}
	for (int run = 0; run < 2500; ++run) {
		vi a(rnd(81));
		for (int& x : a) x = rnd(101)-50;
		checkLIS(a,sz(a) <= 10);
		vector<ll> shifted;
		for (int x : a) shifted.push_back(LLONG_MIN+100+x);
		checkLIS(shifted,false);
	}
	checkLIS(vector<ll>{LLONG_MAX,LLONG_MIN,0,LLONG_MIN,LLONG_MAX});
	checkLIS(vector<string>{"z","aa","ab","aa","b","b","zz"});
#ifdef _GLIBCXX_DEBUG
	// Debug lower_bound checks scan the full range before searching.
	constexpr int n = 2000;
#else
	constexpr int n = 100000;
#endif
	vi a(n); iota(a.begin(),a.end(),0);
	for (bool nondecreasing : {false,true}) {
		vi ids = lis(a,nondecreasing);
		assert(ids == a);
	}
	reverse(a.begin(),a.end());
	assert(lis(a).size() == 1 && lis(a,true).size() == 1);
	a.assign(n,7);
	assert(lis(a).size() == 1 && sz(lis(a,true)) == n);
}

void subsetSums() {
	int ways = 1;
	for (int n = 0; n <= 6; ++n) {
		for (int mask = 0; mask < ways; ++mask) {
			vi w(n);
			int code = mask;
			for (int& x : w) x = code%4, code /= 4;
			checkSubset<1>(w); checkSubset<7>(w); checkSubset<65>(w);
		}
		ways *= 4;
	}
	for (int run = 0; run < 1500; ++run) {
		vector<ll> w(rnd(15));
		for (ll& x : w) x = rnd(301);
		if (!w.empty() && run%5 == 0) w[0] = LLONG_MAX;
		checkSubset<2>(w); checkSubset<64>(w);
		checkSubset<129>(w); checkSubset<257>(w);
	}
	checkSubset<65>(vector<ll>{0,64,65,66,LLONG_MAX});
	checkSubset<129>(vector<unsigned long long>{0,64,64,128,ULLONG_MAX});
	checkSubset<1024>(vector<ll>{511,512,512,1023,1024,LLONG_MAX});
	// The approved scalar DP costs O(nN), unlike the old word shifts.
	vi ones(10000,1);
	assert(subsetBits<1001>(ones).all());
	ones.assign(10000,0);
	assert(subsetBits<1001>(ones).count() == 1);
}

void transforms() {
	auto minOp = [](ll a,ll b) { return min(a,b); };
	for (int k = 0; k <= 3; ++k) {
		int n = 1 << k;
		for (int mask = 0; mask < (1 << n); ++mask) {
			vector<ll> a(n);
			for (int i = 0; i < n; ++i) a[i] = (mask >> i)&1;
			checkSOS(a,plus<ll>{}); checkSOS(a,minOp);
			checkSOS(a,bit_or<ll>{});
		}
	}
	for (int run = 0; run < 1800; ++run) {
		int n = 1 << rnd(8);
		vector<ll> a(n);
		for (ll& x : a) x = rnd(2001)-1000;
		checkSOS(a,plus<ll>{}); checkSOS(a,minOp);
		vector<unsigned long long> bits(n);
		for (auto& x : bits) x = rng();
		checkSOS(bits,bit_or<unsigned long long>{});
		vi ints(n);
		for (int& x : ints) x = rnd(11)-5;
		auto got = ints;
		sos(got);
		for (int mask = 0; mask < n; ++mask) {
			int expected = 0;
			for (int sub = mask;; sub = (sub-1)&mask) {
				expected += ints[sub];
				if (!sub) break;
			}
			assert(got[mask] == expected);
		}
	}
	checkSOS(vector<ll>{LLONG_MIN,LLONG_MAX,0,1},minOp);
	constexpr int k = 20;
	for (bool supersets : {false,true}) {
		vector<ll> a(1 << k,1);
		sos(a,supersets);
		for (int mask = 0; mask < sz(a); ++mask) {
			int bits = __builtin_popcount(unsigned(mask));
			assert(a[mask] == (1LL << (supersets ? k-bits : bits)));
		}
	}
}

int main() {
	sequences(); subsetSums(); transforms();
	cout << "SequencesMasks: " << lisCases << " LIS/LNDS cases ("
		<< enumeratedSubsequences << " enumerated subsequences), "
		<< subsetCases << " subset-sum cases (" << enumeratedSubsets
		<< " enumerated subsets), " << sosCases << " SOS cases; "
		<< "large LIS, 10000 weights and 20-bit SOS passed\n";
}
