#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
using U = unsigned long long;
using W = __uint128_t;
static_assert(numeric_limits<U>::digits == 64);
static mt19937_64 rng(0x107E52026ULL);
static uint64_t checks=0, circularCases=0, knuthCases=0, knuthStates=0;
static uint64_t groupCases=0, groupStates=0, bitCases=0, submaskCases=0;
void ck(bool ok,const char* msg) {
	++checks;
	if (!ok) {cerr << "Notes FAILED: " << msg << '\n'; abort();}
}
int rnd(int n) {return int(rng()%unsigned(n));}

void circularCase(const vector<ll>& a) {
	int n=sz(a);
	ll want=LLONG_MIN;
	// Every start and every allowed nonempty length, including the full circle.
	for (int l=0;l<n;++l) {
		ll sum=0;
		for (int len=1;len<=n;++len) {
			sum+=a[(l+len-1)%n]; want=max(want,sum);
		}
	}
	ll end=a[0],best=a[0],small=a[0],mn=a[0],sum=a[0];
	int minStart=0, minLen=1;
	for (int i=1;i<n;++i) {
		end=max(a[i],end+a[i]); best=max(best,end);
		if (a[i]<small+a[i]) small=a[i],minStart=i;
		else small+=a[i];
		if (small<=mn) mn=small,minLen=i-minStart+1;
		sum+=a[i];
	}
	ll got=best<0 ? best : max(best,sum-mn);
	ck(got==want,"circular Kadane vs every nonempty circular interval");
	if (best>=0 && sum-mn>best)
		ck(minLen<n,"strictly better circular answer has a nonempty complement");
	++circularCases;
}
void testCircular() {
	for (int n=1;n<=8;++n) {
		int total=1;for (int i=0;i<n;++i) total*=3;
		for (int code=0;code<total;++code) {
			int v=code;vector<ll>a(n);
			for (ll& x:a) {x=array<ll,3>{-2,0,3}[v%3];v/=3;}
			circularCase(a);
		}
	}
	for (int it=0;it<500;++it) {
		vector<ll>a(1+rnd(40));for (ll& x:a)x=rnd(41)-20;
		circularCase(a);
	}
	circularCase({0});circularCase({-7});circularCase({7});
	circularCase(vector<ll>(50,0));circularCase({8,-10,9});
}

void knuthCase(const vector<ll>& a) {
	int n=sz(a);
	const ll INF=LLONG_MAX/4;
	vector<vector<ll>> full(n+1,vector<ll>(n+1)),fast=full;
	vector<vi> opt(n+1,vi(n+1)),q=opt;
	vector<ll> pref(n+1);
	for (int i=0;i<n;++i) {
		pref[i+1]=pref[i]+a[i];opt[i][i+1]=q[i][i+1]=i+1;
	}
	for (int len=2;len<=n;++len) for (int l=0;l+len<=n;++l) {
		int r=l+len;
		ll cost=0;for (int i=l;i<r;++i) cost+=a[i];
		full[l][r]=INF;
		// Full cubic reference: every legal split; last minimizer on ties.
		for (int k=l+1;k<r;++k) {
			ll val=cost+full[l][k]+full[k][r];
			if (val<=full[l][r]) full[l][r]=val,opt[l][r]=k;
		}
		ck(opt[l][r-1]<=opt[l][r] && opt[l][r]<=opt[l+1][r],
		   "Knuth monotonicity holds for complete-search greatest minimizers");
		int lo=max(l+1,q[l][r-1]),hi=min(r-1,q[l+1][r]);
		ck(lo<=hi,"Knuth bounded candidate set is nonempty");
		fast[l][r]=INF;
		for (int k=lo;k<=hi;++k) {
			ll val=pref[r]-pref[l]+fast[l][k]+fast[k][r];
			if (val<=fast[l][r]) fast[l][r]=val,q[l][r]=k;
		}
		ck(fast[l][r]==full[l][r] && q[l][r]==opt[l][r],
		   "Knuth restricted splits preserve value and greatest minimizer");
		++knuthStates;
	}
	ck(fast[0][n]==full[0][n],"Knuth whole/empty/singleton interval");
	++knuthCases;
}

void groupsCase(const vector<ll>& a) {
	int n=sz(a),G=min(n,5);
	const ll INF=LLONG_MAX/4;
	vector<vector<ll>> full(G+1,vector<ll>(n+1,INF));
	vector<vi> opt(G+1,vi(n+1,-1));
	full[0][0]=0;
	vector<ll> prev=full[0],cur(n+1),pref(n+1);
	for (int i=0;i<n;++i) pref[i+1]=pref[i]+a[i];
	for (int g=1;g<=G;++g) {
		// Quadratic row reference: accumulate each suffix sum directly.
		for (int j=g;j<=n;++j) {
			ll s=0;
			for (int k=j-1;k>=g-1;--k) {
				s+=a[k];if (full[g-1][k]==INF) continue;
				ll val=full[g-1][k]+s*s;
				if (val<full[g][j] || (val==full[g][j] && k>opt[g][j]))
					full[g][j]=val,opt[g][j]=k;
			}
		}
		fill(cur.begin(),cur.end(),INF);
		vi got(n+1,-1);
		function<void(int,int,int,int)> solve=[&](int l,int r,int lo,int hi) {
			if (l>=r) return;
			int j=l+(r-l)/2,best=-1;
			for (int k=lo;k<=min(j-1,hi);++k) {
				if (prev[k]==INF) continue;
				ll s=pref[j]-pref[k],val=prev[k]+s*s;
				if (val<=cur[j]) cur[j]=val,best=k;
			}
			ck(best>=0,"divide-and-conquer midpoint has a feasible split");
			got[j]=best;
			solve(l,j,lo,best);solve(j+1,r,best,hi);
		};
		solve(g,n+1,g-1,n-1);
		for (int j=0;j<=n;++j) {
			ck(cur[j]==full[g][j] && got[j]==opt[g][j],
			   "divide-and-conquer equals full-search value and greatest minimizer");
			if (j>g) ck(opt[g][j-1]<=opt[g][j],"Monge row minimizers are nondecreasing");
			++groupStates;
		}
		prev=cur;
	}
	++groupCases;
}
void testOptimizations() {
	for (int n=0;n<=7;++n) {
		int total=1;for (int i=0;i<n;++i)total*=3;
		for (int code=0;code<total;++code) {
			int v=code;vector<ll>a(n);
			for (ll& x:a) {x=v%3;v/=3;}
			knuthCase(a);groupsCase(a);
		}
	}
	for (int trial=0;trial<200;++trial) {
		vector<ll>a(rnd(41));for (ll& x:a)x=rnd(30);
		knuthCase(a);groupsCase(a);
	}
	for (int n:{1,2,3,16,64}) {
		knuthCase(vector<ll>(n,0));groupsCase(vector<ll>(n,0));
	}
}

void bitsCase(U x,U y) {
	array<W,65> pow{};pow[0]=1;
	for (int i=1;i<=64;++i)pow[i]=pow[i-1]*2;
	int ones=0,first=64,last=-1;
	for (int i=0;i<64;++i) {
		bool set=bool((W(x)/pow[i])%2);
		ones+=set;if (set)first=min(first,i),last=i;
		U b=U(1)<<i;
		ck(U((W(x)*pow[i])%pow[64])==(x<<i),"unsigned left shift modulo 2^64");
		ck(U(W(x)/pow[i])==(x>>i),"unsigned right shift is floor division");
		ck(bool(x&b)==set && ((x>>i)&1)==U(set),"bit test/extraction");
		ck((x|b)==U(W(x)+(set?W(0):pow[i])),"set bit arithmetic oracle");
		ck((x&~b)==U(W(x)-(set?pow[i]:W(0))),"clear bit arithmetic oracle");
		ck((x^b)==U(set?W(x)-pow[i]:W(x)+pow[i]),"toggle bit arithmetic oracle");
	}
	U low=first==64?0:U(pow[first]);
	ck((x&-x)==low && (x&(x-1))==x-low,"lowest-set-bit operations incl zero");
	ck((x>0 && (x&(x-1))==0)==(ones==1),"power-of-two condition");
	ck(__builtin_popcountll(x)==ones,"64-bit popcount");
	ck((x ? __builtin_ctzll(x) : 64)==first &&
	   (x ? __builtin_clzll(x) : 64)==63-last,"guarded zero counts incl zero");
	if (x) ck(__builtin_ctzll(x)==first && __builtin_clzll(x)==63-last,
	          "builtins on their nonzero domain");
	for (int n=0;n<=64;++n) {
		U mask=n==64?~U(0):(U(1)<<n)-1;
		ck(mask==U(pow[n]-1),"low-bit mask incl n=0 and n=64");
		W lowBits=W(x)%pow[n];
		ck((x^mask)==U(W(x)-lowBits+W(mask)-lowBits),"flip low n bits preserves upper bits");
	}
	ck(W(x^y)==W(x)+W(y)-2*W(x&y),"XOR sum identity in wide arithmetic");
	++bitCases;
}
void testBits32() {
	static_assert(numeric_limits<unsigned>::digits == 32);
	for (int trial=0;trial<1100;++trial) {
		unsigned x=trial<100?unsigned(trial):unsigned(rng());
		unsigned y=unsigned(rng());
		int ones=0,first=32,last=-1;
		for (int i=0;i<32;++i) {
			U b=U(1)<<i;bool set=bool((U(x)/b)%2);
			ones+=set;if(set)first=min(first,i),last=i;
			ck((x<<i)==unsigned(U(x)*b),"32-bit unsigned left shift");
			ck((x>>i)==U(x)/b,"32-bit unsigned right shift");
			ck(bool(x&(1U<<i))==set && ((x>>i)&1U)==unsigned(set),"32-bit test bit");
			ck((x|(1U<<i))==x+(set?0:b),"32-bit set bit");
			ck((x&~(1U<<i))==x-(set?b:0),"32-bit clear bit");
			ck((x^(1U<<i))==(set?x-b:x+b),"32-bit toggle bit");
			unsigned mask=(1U<<i)-1;
			ck(U(mask)==b-1,"32-bit low mask");
			ck((x^mask)==U(x)-2*(x% b)+mask,"32-bit invert low mask");
		}
		ck(__builtin_popcount(x)==ones,"32-bit popcount");
		if(x)ck(__builtin_ctz(x)==first && __builtin_clz(x)==31-last,"32-bit ctz/clz");
		ck(bool(x && !(x&(x-1)))==(ones==1),"32-bit power of two including zero");
		ck((x&-x)==(first==32?0U:1U<<first),"32-bit isolate lowest bit");
		ck(U(x^y)==U(x)+y-2*U(x&y),"32-bit XOR identity");
		++bitCases;
	}
	ck(~0U==UINT_MAX && ~0ULL==ULLONG_MAX,"all bits masks");
}
void testBits() {
	vector<U> xs{0,1,2,3,ULLONG_MAX,ULLONG_MAX-1,U(1)<<63,(U(1)<<63)-1,
	             0xAAAAAAAAAAAAAAAAULL,0x5555555555555555ULL};
	for (U x:xs)for (U y:xs)bitsCase(x,y);
	for (int i=0;i<1000;++i)bitsCase(rng(),rng());
	U expectedTotal=1;
	for (int k=0;k<=10;++k) {
		U total=0;
		for (U m=0;m<(U(1)<<k);++m) {
			vector<U> got,want;
			for (U s=m;;s=(s-1)&m) {got.push_back(s);if (!s)break;}
			for (U s=0;s<(U(1)<<k);++s)if ((s&~m)==0)want.push_back(s);
			reverse(want.begin(),want.end());
			ck(got==want,"submask walk vs enumeration incl zero");
			total+=got.size();++submaskCases;
		}
		ck(total==expectedTotal,"all masks/submasks count is 3^k");expectedTotal*=3;
	}
	U m=(U(1)<<63)|5;
	vector<U> got;
	for (U s=m;;s=(s-1)&m){got.push_back(s);if (!s)break;}
	vector<U>want{m,m-1,m-4,U(1)<<63,5,4,1,0};
	ck(got==want,"submask enumeration includes bit 63 without signed arithmetic");
	++submaskCases;
}
int main() {
	testCircular();testOptimizations();testBits();testBits32();
	cout << "Notes: " << circularCases << " circular arrays, " << knuthCases
	     << " Knuth cases/" << knuthStates << " intervals, " << groupCases
	     << " group cases/" << groupStates << " states, " << bitCases
	     << " bit cases, " << submaskCases << " submask sets; " << checks << " checks passed.\n";
}
