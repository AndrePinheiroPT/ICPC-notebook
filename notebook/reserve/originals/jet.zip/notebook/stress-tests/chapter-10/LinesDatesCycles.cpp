#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/various/LineHull.h"
#include "../../content/various/GregorianDays.h"
#include "../../content/various/FunctionalCycle.h"
using Wide = __int128_t;
static mt19937_64 rng(0x10DA7EF10DULL);
static uint64_t checks = 0, lineQueries = 0, dates = 0, cycles = 0;
void require(bool ok, const char* msg) {
	++checks;
	if (!ok) { cerr << "LinesDatesCycles FAILED: " << msg << '\n'; abort(); }
}
int rnd(int n) { return int(rng()%unsigned(n)); }
void queryLines(const LineHull& hull, const vector<pair<ll,ll>>& lines, ll x) {
	Wide want = LLONG_MIN;
	require(x > -LLONG_MAX,"query stays above negative sentinel");
	// Enumerate every inserted line, independently of hull breakpoints.
	for (auto [k,m] : lines) {
		Wide product=Wide(k)*x, value=product+m;
		require(LLONG_MIN <= product && product <= LLONG_MAX &&
			LLONG_MIN <= value && value <= LLONG_MAX,"valid ll evaluation domain");
		want = max(want,value);
	}
	static_assert(is_same_v<decltype(hull.query(x)),ll>);
	require(hull.query(x) == want, "line envelope vs all inserted lines");
	++lineQueries;
}
void lineCase(const vector<pair<ll,ll>>& lines, const vector<ll>& xs) {
	LineHull hull;
	vector<pair<ll,ll>> inserted;
	for (auto line : lines) {
		for (auto prev : inserted) if (prev.first != line.first) {
			auto a=prev,b=line;
			if (a.first > b.first) swap(a,b);
			Wide num=Wide(b.second)-a.second,den=Wide(a.first)-b.first;
			require(LLONG_MIN <= num && num <= LLONG_MAX &&
				LLONG_MIN <= den && den <= LLONG_MAX,"valid ll breakpoint differences");
			require(!(num==LLONG_MIN && den==-1),"valid ll breakpoint quotient");
		}
		hull.add(line.first,line.second); inserted.push_back(line);
		for (ll x : xs) queryLines(hull,inserted,x);
		if (!hull.empty()) {
			auto prev = hull.begin();
			for (auto it = next(prev); it != hull.end(); ++it) {
				require(prev->p < it->p, "strictly increasing hull breakpoints");
				prev = it;
			}
		}
	}
}
void testLines() {
	vector<pair<ll,ll>> small;
	for (ll k = -2; k <= 2; ++k) for (ll m = -2; m <= 2; ++m) small.emplace_back(k,m);
	vector<ll> grid;
	for (ll x = -6; x <= 6; ++x) grid.push_back(x);
	for (auto a : small) for (auto b : small) for (auto c : small) lineCase({a,b,c},grid);
	lineCase({{1,0},{3,1}},grid); lineCase({{3,1},{1,0}},grid); // Floor(-1/2), not truncation.
	vector<ll> edge{-1000000000LL,-999999999LL,-2,-1,0,1,2,999999999LL,1000000000LL};
	vector<pair<ll,ll>> boundary;
	for (ll k : edge) for (ll m : edge) boundary.emplace_back(k,m);
	for (int it = 0; it < 12; ++it) {
		shuffle(boundary.begin(),boundary.end(),rng); lineCase(boundary,edge);
	}
	for (int test = 0; test < 700; ++test) {
		vector<pair<ll,ll>> lines;
		int n = 1+rnd(60);
		for (int i = 0; i < n; ++i) {
			ll k = test%4 ? ll(rng()%2000000001ULL)-1000000000LL : ll(rnd(7)-3);
			ll m = test%3 ? ll(rng()%2000000001ULL)-1000000000LL : ll(rnd(51)-25);
			lines.emplace_back(k,m);
		}
		vector<ll> xs = edge;
		for (int i = 0; i < 8; ++i) xs.push_back(ll(rng()%2000000001ULL)-1000000000LL);
		lineCase(lines,xs);
	}
	// Valid boundaries keep every product, sum and breakpoint in signed ll.
	vector<ll> wideX{LLONG_MIN+2,-1,0,1,LLONG_MAX};
	lineCase({{-1,0},{0,0},{1,0}},wideX);
	lineCase({{1,0},{-1,0},{0,0}},wideX);
	lineCase({{0,LLONG_MAX},{0,LLONG_MAX-1},{0,LLONG_MAX}},wideX);
	lineCase({{0,LLONG_MIN},{0,LLONG_MIN+1},{0,LLONG_MIN}},wideX);
	lineCase({{LLONG_MIN,0},{LLONG_MIN+1,0}},vector<ll>{0,1});
	lineCase({{LLONG_MAX,0},{LLONG_MAX-1,0}},vector<ll>{-1,0,1});
	lineCase({{0,LLONG_MAX},{1,0}},wideX);
	lineCase({{1,0},{0,LLONG_MAX}},wideX);
	lineCase({{0,0},{1,LLONG_MAX}},vector<ll>{LLONG_MIN+2,-1,0});
	lineCase({{1,LLONG_MAX},{0,0}},vector<ll>{LLONG_MIN+2,-1,0});
	lineCase({{0,-LLONG_MAX},{1,0}},vector<ll>{LLONG_MIN+2,-1,0,1});
	lineCase({{0,0},{2,LLONG_MIN}},vector<ll>{0,1,LLONG_MAX/2});
	lineCase({{2,LLONG_MIN},{0,0}},vector<ll>{0,1,LLONG_MAX/2});
}

bool leap(ll y) { return y%4 == 0 && (y%100 != 0 || y%400 == 0); }
int monthDays(ll y, int m) {
	static const int md[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
	return md[m]+int(m == 2 && leap(y));
}
ll countFloor(ll a, ll b) { return a/b-ll(a < 0 && a%b != 0); }
ll yearStart(ll y) {
	// Count full common years and leap years starting at astronomical year 0.
	// This uses Jan-based 4/100/400 divisibility, not March eras or month polynomials.
	return 365*y+countFloor(y+3,4)-countFloor(y+99,100)+countFloor(y+399,400);
}
ll dateOracle(ll y, int m, int d) {
	ll days = yearStart(y)-yearStart(1970)+d-1;
	for (int month = 1; month < m; ++month) days += monthDays(y,month);
	return days;
}
void testDates() {
	require(gregorianDays(1970,1,1) == 0,"Gregorian epoch");
	require(gregorianDays(1969,12,31) == -1,"day before epoch");
	require(gregorianDays(2000,1,1) == 10957,"known 2000 epoch distance");
	require(gregorianDays(2000,2,29) == 11016,"known leap date");
	// Independent day-by-day walk: calculate the start by summing complete years.
	ll walk = 0;
	for (ll y = -800; y < 1970; ++y) walk -= leap(y) ? 366 : 365;
	for (ll y = -800; y <= 2400; ++y)
		for (int m = 1; m <= 12; ++m)
			for (int d = 1; d <= monthDays(y,m); ++d) {
				require(gregorianDays(y,m,d) == walk,"exhaustive civil day walk");
				++walk; ++dates;
			}
	vector<ll> ys{-1000000000000LL,-999999999999LL,-400,-100,-4,-1,0,1,4,100,
	              400,1582,1600,1700,1800,1900,2000,2100,999999999999LL,1000000000000LL};
	for (ll y : ys) for (int m = 1; m <= 12; ++m) for (int d : {1,monthDays(y,m)}) {
		require(gregorianDays(y,m,d) == dateOracle(y,m,d),"extreme/special Gregorian years");
		++dates;
	}
	for (int test = 0; test < 200000; ++test) {
		ll y = ll(rng()%2000000000001ULL)-1000000000000LL;
		int m = 1+rnd(12), d = 1+rnd(monthDays(y,m));
		require(gregorianDays(y,m,d) == dateOracle(y,m,d),"random date leap-count oracle");
		if (y <= 999999999600LL)
			require(gregorianDays(y+400,m,d)-gregorianDays(y,m,d) == 146097,
			        "400-year date periodicity");
		++dates;
	}
	for (ll y : ys)
		require(gregorianDays(y,3,1)-gregorianDays(y,2,28) == (leap(y) ? 2 : 1),
		        "Gregorian century/year-zero leap rule");
	require(gregorianDays(1582,10,15)-gregorianDays(1582,10,4) == 11,
	        "proleptic dates have no historical adoption gap");
}

pair<ll,ll> cycleOracle(const vi& nextState, int start) {
	vi seen(nextState.size(),-1);
	int steps = 0, v = start;
	while (seen[v] < 0) { seen[v] = steps++; v = nextState[v]; }
	return {seen[v],steps-seen[v]};
}
void functionalGraph(const vi& nextState) {
	for (int start = 0; start < sz(nextState); ++start) {
		auto got = floydCycle(start,[&](int x) {return nextState[x];});
		require(got == cycleOracle(nextState,start),"Floyd vs explicit visited orbit");
		++cycles;
	}
}
void testCycles() {
	for (int n = 1; n <= 5; ++n) {
		int total = 1;
		for (int i = 0; i < n; ++i) total *= n;
		for (int code = 0; code < total; ++code) {
			int cur = code; vi to(n);
			for (int& v : to) {v = cur%n; cur /= n;}
			functionalGraph(to);
		}
	}
	for (int test = 0; test < 500; ++test) {
		int n = 1+rnd(80); vi to(n);
		for (int& v : to) v = rnd(n);
		functionalGraph(to);
	}
	for (int mu : {0,1,2,17,1000,100000}) for (int len : {1,2,13,50000}) {
		ll calls = 0;
		auto nextState = [&](int v) {++calls; return v+1 == mu+len ? mu : v+1;};
		require(floydCycle(0,nextState) == pair<ll,ll>{mu,len},"known long prefix/cycle");
		require(calls <= 6LL*(mu+len)+3,"Floyd linear function call count"); ++cycles;
	}
	for (int a = 1; a < 12; ++a) for (int b = 1; b < 12; ++b) {
		auto nextState = [=](pair<int,int> p) {return pair{(p.first+1)%a,(p.second+1)%b};};
		require(floydCycle(pair{0,0},nextState) == pair<ll,ll>{0,lcm(a,b)},"generic pair state");
		++cycles;
	}
	struct State { int v; }; // Deliberately has no operator==.
	auto nextState = [](State s) {return State{s.v == 6 ? 2 : s.v+1};};
	auto eq = [](State a, State b) {return a.v == b.v;};
	require(floydCycle(State{0},nextState,eq) == pair<ll,ll>{2,5},"custom state equality");
	// A congruent equivalence ignores the bounded auxiliary counter.
	// Full states repeat every lcm(5,97)=485 steps; equivalence classes every 5.
	auto withCounter = [](pair<int,int> s) {
		return pair{s.first == 6 ? 2 : s.first+1,(s.second+1)%97};
	};
	auto sameClass = [](pair<int,int> a, pair<int,int> b) {
		return a.first == b.first;
	};
	require(floydCycle(pair{0,0},withCounter) == pair<ll,ll>{2,485},
	        "full state includes auxiliary counter");
	require(floydCycle(pair{0,0},withCounter,sameClass) == pair<ll,ll>{2,5},
	        "quotient cycle ignores congruent auxiliary counter");
	auto strNext = [](string s) {return s == "a" ? string("ab") : s == "ab" ? string("cde") : string("ab");};
	require(floydCycle(string("a"),strNext) == pair<ll,ll>{1,2},"generic string state");
	auto rotateState = [](vi v) {rotate(v.begin(),v.begin()+1,v.end()); return v;};
	require(floydCycle(vi{0,1,2},rotateState) == pair<ll,ll>{0,3},"generic vector state");
	require(floydCycle(false,[](bool b) {return !b;}) == pair<ll,ll>{0,2},"bool state");
	cycles += 6;
}

int main() {
	testLines(); testDates(); testCycles();
	cout << "LinesDatesCycles: " << lineQueries << " brute envelope queries, " << dates
	     << " Gregorian dates, " << cycles << " cycle cases; " << checks << " checks passed.\n";
}
