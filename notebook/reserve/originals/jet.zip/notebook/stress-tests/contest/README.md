# Contest template checks

Run from the notebook root:

```sh
bash stress-tests/contest/run.sh
```

Requires Bash, Python 3 and g++ with C++17. Tests the supplied template and shell
functions unchanged, both optimized and with LOCAL, STL debug, ASan and UBSan.
Checks aliases/constants, string and pair formatting, nested containers, DEBUG
side effects and paths containing spaces, with and without the `.cpp` suffix.
Temporary sources and binaries are removed on exit.
`Smoke.inc` supplies the test main; the script combines it with the template's
preamble, so the existing standalone `*.cpp` runner does not pick up a fragment.

If the execution environment disallows LeakSanitizer (for example under ptrace),
run `ASAN_OPTIONS=detect_leaks=0 bash stress-tests/contest/run.sh`. AddressSanitizer,
UndefinedBehaviorSanitizer and STL debug checks remain enabled.
