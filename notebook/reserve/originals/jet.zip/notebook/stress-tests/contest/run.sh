#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/contest tests.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT

# Exercise the supplied functions unchanged, including paths containing spaces.
source "$root/content/contest/config.sh"
cp -- "$root/content/contest/template.cpp" "$tmp/original template.cpp"
compilecp "$tmp/original template.cpp"
"$tmp/original template"
debugcp "$tmp/original template"
"$tmp/original template.dbg"

python3 - "$root" "$tmp/smoke test.cpp" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
template = (root / 'content/contest/template.cpp').read_text()
preamble, sep, _ = template.partition('int main() {')
assert sep, 'Contest template main not found'
smoke = (root / 'stress-tests/contest/Smoke.inc').read_text()
Path(sys.argv[2]).write_text(preamble + smoke)
PY
compilecp "$tmp/smoke test"
"$tmp/smoke test"
debugcp "$tmp/smoke test.cpp"
"$tmp/smoke test.dbg"
