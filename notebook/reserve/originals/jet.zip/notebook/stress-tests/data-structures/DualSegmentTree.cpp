#include "../utilities/template.h"
#include "../../content/data-structures/DualSegmentTree.h"

struct Update {
	int l, r;
	ll val;
};

static constexpr uint64_t SEED = 0xD0A15E67AEEULL;
mt19937_64 rng(SEED);

int rnd(int l, int r) {
	return uniform_int_distribution<int>(l, r)(rng);
}

ll rndVal() {
	return uniform_int_distribution<ll>(-1000000000000LL,
	                                    1000000000000LL)(rng);
}

[[noreturn]] void fail(int n, int tc, int op, int pos, ll expected,
		ll got, const vector<Update>& history) {
	cerr << "seed=" << SEED << " n=" << n << " tc=" << tc
	     << " op=" << op << " pos=" << pos << '\n';
	cerr << "expected=" << expected << " got=" << got << '\n';
	for (const Update& u : history)
		cerr << "update(" << u.l << ", " << u.r << ", " << u.val << ")\n";
	exit(1);
}

void check(DualSegTree& st, const vector<ll>& brute, int pos,
		int tc, int op, const vector<Update>& history) {
	ll got = st.query(pos);
	if (got != brute[pos])
		fail((int)brute.size(), tc, op, pos, brute[pos], got, history);
}

void exhaustiveIntervals() {
	DualSegTree empty(0);
	empty.update(0, 0, 123);

	for (int n = 1; n <= 32; n++) {
		for (int l = 0; l <= n; l++) {
			for (int r = l; r <= n; r++) {
				DualSegTree st(n);
				vector<ll> brute(n, 0);
				vector<Update> history;

				for (int i = 0; i < n; i++)
					check(st, brute, i, -1, 0, history);

				auto apply = [&](int a, int b, ll val) {
					st.update(a, b, val);
					history.push_back({a, b, val});
					for (int i = a; i < b; i++) brute[i] += val;
				};

				apply(l, r, 7);
				apply(0, r, -11);
				apply(l, n, 13);
				apply(r, r, 1000000000000LL); // empty update

				for (int i = 0; i < n; i++)
					check(st, brute, i, -1, 4, history);
			}
		}
	}
}

void randomStress() {
	const int cases = 4000;
	const int operations = 750;

	for (int tc = 0; tc < cases; tc++) {
		int n = rnd(1, 128);
		DualSegTree st(n);
		vector<ll> brute(n, 0);
		vector<Update> history;

		for (int op = 0; op < operations; op++) {
			if (rnd(0, 3) != 0) {
				int l = rnd(0, n), r = rnd(0, n);
				if (l > r) swap(l, r);

				switch (op % 20) {
				case 0: l = 0; r = n; break; // entire array
				case 1: r = l; break;        // empty interval
				case 2: l = 0; break;        // touches left edge
				case 3: r = n; break;        // touches right edge
				}

				ll val = rndVal();
				st.update(l, r, val);
				history.push_back({l, r, val});
				for (int i = l; i < r; i++) brute[i] += val;
			}

			int pos = rnd(0, n - 1);
			check(st, brute, pos, tc, op, history);

			if (op % 100 == 0)
				for (int i = 0; i < n; i++)
					check(st, brute, i, tc, op, history);
		}

		for (int i = 0; i < n; i++)
			check(st, brute, i, tc, operations, history);
	}
}

int main() {
	exhaustiveIntervals();
	randomStress();
}