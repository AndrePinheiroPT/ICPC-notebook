#include "../utilities/template.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/number-theory/ModMulLL.h"
using boost::multiprecision::cpp_int;

int main() {
	mt19937_64 rng(0x4d6f644d756cULL);
	size_t checks = 0;
	auto check = [&](ull a, ull b, ull m) {
		assert(m > 0);
		a %= m; b %= m;
		cpp_int expected = cpp_int(a)*cpp_int(b)%cpp_int(m);
		assert(cpp_int(modmul(a,b,m)) == expected);
		++checks;
	};
	vector<ull> v{0,1,2,3,1ULL<<32,(1ULL<<63)-1,
		1ULL<<63,ULLONG_MAX-58,ULLONG_MAX-1,ULLONG_MAX};
	for (ull m : v) if (m)
		for (ull a : v) for (ull b : v) check(a,b,m);
	for (int i = 0; i < 100000; ++i) {
		ull a = rng(), b = rng(), m = rng() | 1ULL;
		check(a,b,m);
	}
	cout << "ModMulLL: " << checks
		<< " arbitrary-precision product checks passed\n";
}
