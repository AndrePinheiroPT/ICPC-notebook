#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/numerical/NTT.h"

static mt19937_64 rng(0x5b98ad426137ULL);
static uint64_t convolutions = 0, transforms = 0, coefficients = 0;

void require(bool ok, const char* reason) {
	if (!ok) { cerr << "FAILED NTT: " << reason << '\n'; abort(); }
}

// Independent O(n*m) oracle, reducing after each product to avoid overflow.
vector<int> schoolbook(const vector<int>& a, const vector<int>& b) {
	if (a.empty() || b.empty()) return {};
	vector<int> c(a.size()+b.size()-1);
	for (size_t i = 0; i < a.size(); ++i)
		for (size_t j = 0; j < b.size(); ++j)
			c[i+j] = int((c[i+j]+ll(a[i])*b[j]) % NTT::mod);
	return c;
}

void convolution(const vector<int>& a, const vector<int>& b) {
	vector<int> want = schoolbook(a, b);
	vector<int> got = NTT::conv(a, b);
	require(got == want, "schoolbook mismatch/incorrect output length");
	++convolutions;
	coefficients += got.size();
}

vector<int> randomPoly(int n) {
	vector<int> a(n);
	for (int& x : a) x = int(rng()%NTT::mod);
	return a;
}

// Direct polynomial evaluation checks the forward convention, not just
// cancellation between a potentially wrong forward/inverse pair.
void directTransform(const vector<int>& a) {
	int n = sz(a);
	ll root = modpow(3, (NTT::mod-1)/n, NTT::mod), at = 1;
	vector<int> want(n), got = a;
	for (int k = 0; k < n; ++k) {
		ll w = 1, val = 0;
		for (int x : a) {
			val = (val+w*x) % NTT::mod;
			w = w*at % NTT::mod;
		}
		want[k] = int(val);
		at = at*root % NTT::mod;
	}
	NTT::ntt(got);
	require(got == want, "forward transform convention");
	++transforms; coefficients += got.size();
}

void roundtrip(const vector<int>& a) {
	vector<int> b = a;
	NTT::ntt(b); NTT::ntt(b, true);
	require(b == a, "forward/inverse roundtrip");
	transforms += 2; coefficients += b.size();
	NTT::ntt(b, true); NTT::ntt(b);
	require(b == a, "inverse/forward roundtrip");
	transforms += 2; coefficients += b.size();
}

// Optional boundary test: exact maximum output length. A scalar times
// four nonzero coefficients has an O(N) analytic oracle and needs ~64 MiB
// during convolution. It also catches padding 2^k to 2^(k+1).
void maximumLength() {
	constexpr int n = 1 << 23;
	vector<int> b(n);
	b[0] = 1; b[17] = 7; b[n/2] = NTT::mod-1; b[n-1] = 314159;
	vector<int> c = NTT::conv({NTT::mod-1}, move(b));
	require(sz(c) == n, "maximum output length");
	for (int i = 0; i < n; ++i) {
		int want = i == 0 ? NTT::mod-1 : i == 17 ? NTT::mod-7
		         : i == n/2 ? 1 : i == n-1 ? NTT::mod-314159 : 0;
		require(c[i] == want, "maximum length sparse/scalar convolution");
	}
	++convolutions; coefficients += c.size();
}

int main(int argc, char** argv) {
	vector<vector<int>> edge{{}, {0}, {1}, {NTT::mod-1},
	                         {0,0,0}, {1,2,3}, {NTT::mod-1,NTT::mod-1}};
	for (const auto& a : edge) for (const auto& b : edge) convolution(a, b);
	// Exhaustive tiny coefficient polynomials, including trailing zeros.
	for (int n = 0; n <= 4; ++n) for (int m = 0; m <= 4; ++m)
		for (int maskA = 0; maskA < (1<<n); ++maskA)
			for (int maskB = 0; maskB < (1<<m); ++maskB) {
				vector<int> a(n), b(m);
				for (int i = 0; i < n; ++i) a[i] = ((maskA>>i)&1) ? NTT::mod-1 : 0;
				for (int i = 0; i < m; ++i) b[i] = ((maskB>>i)&1) ? NTT::mod-1 : 0;
				convolution(a, b);
			}
	for (int trial = 0; trial < 700; ++trial)
		convolution(randomPoly(int(rng()%161)), randomPoly(int(rng()%161)));
	for (int bit = 1; bit <= 9; ++bit) for (int d = -1; d <= 1; ++d) {
		int s = (1<<bit)+d;
		for (int n : {1, max(1,s/2), s}) convolution(randomPoly(n), randomPoly(s-n+1));
	}
	// Large linear-time schoolbook cases around a transform-length boundary.
	for (int d = -1; d <= 1; ++d)
		convolution({NTT::mod-1, 0, 17}, randomPoly((1<<16)-2+d));
	for (int bit = 0; bit <= 16; ++bit) {
		int n = 1 << bit;
		vector<int> a = randomPoly(n);
		roundtrip(a);
		vector<int> constant(n, NTT::mod-1), impulse(n);
		impulse[n-1] = NTT::mod-1;
		roundtrip(constant); roundtrip(impulse);
		if (bit <= 5) { directTransform(a); directTransform(impulse); }
	}
	if (argc > 1) {
		require(argc == 2 && string(argv[1]) == "--max", "unknown argument");
		maximumLength();
	}
	cout << "Tests passed! NTT: " << convolutions << " convolutions, "
	     << transforms << " direct/roundtrip transforms, " << coefficients
	     << " coefficients compared" << (argc > 1 ? " (includes N=2^23)" : "") << ".\n";
}
