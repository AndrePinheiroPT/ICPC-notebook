#include <bits/stdc++.h>
using namespace std;
#include "../../content/numerical/Bisection.h"
#include "../../content/numerical/GoldenSearch.h"

uint64_t intervals = 0, searches = 0, evaluations = 0;
template<class T> void run() {
    T tiny = numeric_limits<T>::denorm_min();
    T low = numeric_limits<T>::min(), high = numeric_limits<T>::max();
    T eps = numeric_limits<T>::epsilon();
    vector<T> edges{0,tiny,-tiny,16*tiny,-16*tiny,low,-low,
        2*low,-2*low,high,-high,high/2,-high/2,
        nextafter(high,T(0)),-nextafter(high,T(0)),1,-1};
    sort(edges.begin(),edges.end());
    edges.erase(unique(edges.begin(),edges.end()),edges.end());
    for (T l : edges) for (T r : edges) if (l <= r) {
        ++intervals;
        auto valid = [&](T x) {
            ++evaluations;
            assert(isfinite(x) && l <= x && x <= r);
        };
        if (l == r) {
            assert(gss(l,r,[&](T x) {valid(x); return T(0);}) == l);
            ++searches; continue;
        }
        vector<T> cuts{r,nextafter(l,r)};
        if (l < 0 && r >= 0) cuts.push_back(0);
        for (T cut : cuts) {
            T got = bisect(l,r,[&](T x) {valid(x); return x >= cut;},200000);
            assert(got == cut); ++searches;
        }
        // Monotone functions have known endpoint minima. Scaling avoids
        // overflowing the objective even across the entire finite domain.
        T scale = max(abs(l),abs(r));
        for (int sign : {-1,1}) {
            T got = gss(l,r,[&](T x) {valid(x); return T(sign)*(x/scale);},200000);
            valid(got);
            T want = sign > 0 ? l : r;
            assert(abs(got/scale-want/scale) <= eps*128+tiny/scale*4);
            ++searches;
        }
    }
}
int main() {
    run<float>(); run<double>(); run<long double>();
    cout << "SearchFinite: " << intervals << " finite intervals, "
        << searches << " searches, " << evaluations
        << " in-range finite evaluations passed\n";
}
