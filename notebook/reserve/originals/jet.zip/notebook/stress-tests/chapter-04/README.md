# Stress tests — Numerical

Executar `bash doc/scripts/test-chapter-04.sh` na raiz do notebook.
GNU++20; Boost multiprecision/rational para referências independentes.
`BOOST_INCLUDEDIR` é opcional; `RUN_MAX=1` inclui NTT no limite 2^23.
No ambiente com ptrace: `ASAN_OPTIONS=detect_leaks=0`.

O runner compila release e ASan/UBSan com STL debug e começa por integrar
todos os headers com o template real de Contest. Search usa enumeração,
fronteiras e cpp_int; Gauss usa cpp_rational e enumeração modular;
MatrixBinary usa atribuições booleanas exaustivas, cpp_int e recorrências;
NTT usa convolução quadrática, DFT direta e roundtrips. Sementes fixas
permitem reprodução. A documentação resumida está em `CHAPTER-04.md`.

## Revisão 11

- Search.cpp valida o BinarySearch fornecido: first_true/last_true,
  intervalo fechado, existência de um true, subtrações representáveis.
  Enumeração de todos os pivots em intervalos pequenos, janelas nos
  extremos ll e amostras largas válidas. Não testa a antiga API optional.
- Adversarial.cpp: Gaussian com escalas 2^-400 a 2^400 e eps ajustado,
  sistemas modulares construídos por operações que preservam rank,
  GF2 até 512 bits, potências enormes de blocos de Jordan contra cpp_int
  e convoluções densas com coeficientes analíticos triangulares.
- Resultados: validation/revision-11/ch04.log e ch04-ntt-max.log.
