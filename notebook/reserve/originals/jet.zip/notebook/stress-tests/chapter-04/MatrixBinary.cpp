#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/numerical/GaussBinary.h"
#include "../../content/numerical/Matrix.h"
using boost::multiprecision::cpp_int;

mt19937_64 rng(0xB1042026);
uint64_t systems = 0, assignments = 0, entries = 0, powers = 0;

template<size_t K> bool satisfies(const vector<bitset<K>>& a,
                                 int m, const vi& x) {
	if (sz(x) != m) return false;
	for (int v : x) if (v != 0 && v != 1) return false;
	for (const auto& row : a) {
		int b = 0;
		for (int c = 0; c < m; ++c) b ^= int(row[c])*x[c];
		if (b != int(row[m])) return false;
	}
	return true;
}

// Oracle enumerates all assignments; solution count also determines rank.
template<size_t K> void small(const vector<bitset<K>>& a, int m) {
	int count = 0;
	vi x(m);
	for (int mask = 0; mask < (1 << m); ++mask) {
		for (int j = 0; j < m; ++j) x[j] = (mask >> j)&1;
		count += satisfies(a,m,x); ++assignments;
	}
	auto b = a;
	int rank = gaussBinary(b,m,x);
	if (!count) assert(rank == -1);
	else {
		int want = m;
		for (int v = count; v > 1; v /= 2) --want;
		assert(rank == want);
		assert(satisfies(a,m,x));
		// Returned pivots have their columns eliminated in all other rows.
		vi pivot(m);
		for (int i = 0; i < rank; ++i) {
			int c = 0; while (c < m && !b[i][c]) ++c;
			assert(c < m); pivot[c] = 1;
			for (int j = 0; j < sz(b); ++j)
				assert(bool(b[j][c]) == (i == j));
		}
		for (int c = 0; c < m; ++c)
			if (!pivot[c]) assert(x[c] == 0);
	}
	++systems;
}

void binarySmall() {
	for (int n = 0; n <= 3; ++n) for (int m = 0; m <= 3; ++m)
		for (int mask = 0; mask < (1 << (n*(m+1))); ++mask) {
			vector<bitset<16>> a(n);
			for (int i = 0; i < n; ++i)
				for (int j = 0; j <= m; ++j)
					a[i][j] = (mask >> (i*(m+1)+j))&1;
			small(a,m);
		}
	for (int test = 0; test < 6000; ++test) {
		int n = int(rng()%12), m = int(rng()%9);
		vector<bitset<16>> a(n);
		for (auto& row : a)
			for (int j = 0; j <= m; ++j) row[j] = rng()&1;
		if (n > 1 && test%3 == 0) a[1] = a[0];
		if (n > 1 && test%7 == 0) a[1] = a[0], a[1].flip(m);
		// Bits above the augmented system have no mathematical meaning.
		for (auto& row : a) row[15] = true;
		small(a,m);
	}
	small(vector<bitset<1>>{},0);
	small(vector<bitset<1>>{bitset<1>(0)},0);
	small(vector<bitset<1>>{bitset<1>(1)},0);
}

void binaryWide() {
	for (int m : {1,63,64,65,127,128,129,255,256}) {
		vi want(m);
		for (int& x : want) x = int(rng()&1);
		vector<bitset<257>> a(m);
		// Unit lower triangular matrix: known full rank without Gaussian oracle.
		for (int i = 0; i < m; ++i) {
			a[i][i] = true;
			for (int j = 0; j < i; ++j) a[i][j] = rng()&1;
			for (int j = 0; j <= i; ++j)
				a[i][m] = bool(a[i][m]) ^ (bool(a[i][j]) && want[j]);
		}
		shuffle(a.begin(),a.end(),rng);
		a.push_back(a.front());
		a.push_back(bitset<257>{});
		auto b = a; vi x;
		assert(gaussBinary(b,m,x) == m && x == want);
		assert(satisfies(a,m,x)); ++systems;
		a.back().set(m); b = a;
		assert(gaussBinary(b,m,x) == -1); ++systems;
		// Sparse underdetermined system spans the top and bottom bits.
		a.assign(1,{}); a[0][0] = true; a[0][m-1] = true;
		a[0][m] = true; b = a;
		assert(gaussBinary(b,m,x) == 1);
		assert(satisfies(a,m,x)); ++systems;
	}
}

template<class T, int N, ll M>
Mat<T,N,M> product(const Mat<T,N,M>& a, const Mat<T,N,M>& b) {
	Mat<T,N,M> c;
	// Independent dot products; cpp_int keeps even a whole MOD63 dot exact.
	for (int i = 0; i < N; ++i) for (int j = 0; j < N; ++j) {
		if constexpr (is_integral_v<T>) {
			cpp_int v = 0;
			for (int k = 0; k < N; ++k) v += cpp_int(a.d[i][k])*b.d[k][j];
			if constexpr (M) v %= M;
			assert(v >= numeric_limits<T>::lowest());
			assert(v <= numeric_limits<T>::max());
			c.d[i][j] = v.template convert_to<T>();
		} else {
			long double v = 0;
			for (int k = 0; k < N; ++k) v += a.d[i][k]*b.d[k][j];
			c.d[i][j] = v;
		}
	}
	return c;
}

template<class T, int N, ll M>
void equal(const Mat<T,N,M>& a, const Mat<T,N,M>& b) {
	for (int i = 0; i < N; ++i) for (int j = 0; j < N; ++j) {
		if constexpr (is_floating_point_v<T>)
			assert(abs(a.d[i][j]-b.d[i][j]) <=
			       1e-12L*max(1.L,abs(b.d[i][j])));
		else assert(a.d[i][j] == b.d[i][j]);
		++entries;
	}
}

template<class T, int N, ll M = 0> void matrices() {
	for (int test = 0; test < 160; ++test) {
		Mat<T,N,M> a, b, id;
		for (int i = 0; i < N; ++i) id.d[i][i] = 1;
		for (auto* p : {&a,&b}) for (auto& row : p->d) for (T& v : row) {
			if constexpr (M) {
				v = T(rng()%uint64_t(M));
				if (test%4 == 0) v = T(M-1);
			} else if constexpr (is_integral_v<T>) v = T(int(rng()%5)-2);
			else v = T(int(rng()%5)-2)/2;
		}
		equal(a*b,product(a,b)); equal(a*id,a); equal(id*a,a);
		auto want = id;
		for (int p = 0; p <= 8; ++p) {
			equal(a^p,want); ++powers;
			if (p < 8) want = product(want,a);
		}
	}
}

template<class T, ll M = 0> void longPowers() {
	Mat<T,2,M> a, id;
	a.d[0][1] = a.d[1][0] = 1;
	id.d[0][0] = id.d[1][1] = 1;
	for (ll p : {0LL,1LL,2LL,63LL,64LL,LLONG_MAX-1,LLONG_MAX}) {
		equal(a^p,p&1 ? a : id); ++powers;
	}
}

void transitions() {
	// Fibonacci transition: verify independently by scalar iteration.
	Mat<ll,2,1000000007> a;
	a.d = {{{1,1},{1,0}}};
	ll prev = 0, cur = 1;
	for (int k = 0; k <= 1000; ++k) {
		auto b = a^k;
		assert(b.d[0][0] == cur && b.d[0][1] == prev);
		ll next = (prev+cur)%1000000007; prev = cur; cur = next;
		++powers; entries += 2;
	}
	// A^1 must not unnecessarily square extreme ordinary integers.
	for (int v : {INT_MIN,INT_MAX}) {
		Mat<int,1> b; b.d[0][0] = v;
		assert((b^0).d[0][0] == 1 && (b^1).d[0][0] == v);
		powers += 2; entries += 2;
	}
	for (ll v : {LLONG_MIN,LLONG_MAX}) {
		Mat<ll,1> b; b.d[0][0] = v;
		assert((b^0).d[0][0] == 1 && (b^1).d[0][0] == v);
		powers += 2; entries += 2;
	}
}

int main() {
	binarySmall(); binaryWide();
	matrices<int,0>(); matrices<int,1>(); matrices<int,2>(); matrices<int,4>();
	matrices<ll,1>(); matrices<ll,3>(); matrices<long double,3>();
	matrices<int,3,2>(); matrices<int,3,2147483647>();
	matrices<ll,1,LLONG_MAX>(); matrices<ll,3,LLONG_MAX>();
	longPowers<int>(); longPowers<ll>(); longPowers<long double>();
	longPowers<ll,LLONG_MAX>(); transitions();
	cout << "MatrixBinary: " << systems << " GF2 systems, " << assignments
	     << " brute assignments, " << powers << " matrix powers, " << entries
	     << " verified matrix entries\n";
}
