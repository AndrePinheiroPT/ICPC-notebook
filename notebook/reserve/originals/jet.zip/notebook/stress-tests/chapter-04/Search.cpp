#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/numerical/BinarySearch.h"
#include "../../content/numerical/Bisection.h"
#include "../../content/numerical/GoldenSearch.h"
#include "../../content/numerical/ModPow.h"
using boost::multiprecision::cpp_int;
static mt19937_64 rng(0x2026092704ULL);
static uint64_t checks = 0;
void check(bool b) { ++checks; assert(b); }
ll signedBits(uint64_t x) {
    ll y; static_assert(sizeof y == sizeof x);
    memcpy(&y,&x,sizeof y); return y;
}

void integerRange(ll l, ll r, ll cut, bool last) {
    // Exactly the supplied code's contract: closed interval, true exists,
    // and midpoint subtractions/addition are representable.
    assert(l <= cut && cut <= r);
    int calls = 0;
    auto pred = [&](ll x) {
        assert(l <= x && x <= r); ++calls;
        return last ? x <= cut : x >= cut;
    };
    ll got = last ? last_true(l,r,pred) : first_true(l,r,pred);
    check(got == cut && calls <= 64);
}
void integers() {
    for (int l = -40; l <= 40; ++l)
        for (int r = l; r <= 40; ++r)
            for (int cut = l; cut <= r; ++cut) {
                integerRange(l,r,cut,false); integerRange(l,r,cut,true);
            }
    vector<ll> edge{LLONG_MIN,LLONG_MIN+1,-1,0,1,LLONG_MAX-1,LLONG_MAX};
    for (ll l : edge) for (ll r : edge) if (l <= r) {
        cpp_int width = cpp_int(r)-l;
        if (width > LLONG_MAX) continue;
        for (ll cut : edge) if (l <= cut && cut <= r) {
            integerRange(l,r,cut,false);
            if (width < LLONG_MAX) integerRange(l,r,cut,true);
        }
    }
    // Signed boundaries, all-true predicates and every pivot position
    // in narrow windows near the two integer endpoints.
    for (ll l : {LLONG_MIN,LLONG_MIN+1,-100LL,-1LL,0LL,LLONG_MAX-128})
        for (ll w = 0; w <= 127; ++w)
            for (ll d = 0; d <= w; ++d) {
                integerRange(l,l+w,l+d,false);
                integerRange(l,l+w,l+d,true);
            }
    for (int i = 0; i < 40000; ++i) {
        ll l = signedBits(rng()), r = signedBits(rng());
        if (l > r) swap(l,r);
        cpp_int width = cpp_int(r)-l;
        if (width >= LLONG_MAX) continue;
        ll w = width.convert_to<ll>();
        ll cut = l+ll(rng()%(uint64_t(w)+1));
        integerRange(l,r,cut,false); integerRange(l,r,cut,true);
    }
}

template<class T> void reals() {
    T eps = numeric_limits<T>::epsilon();
    for (int i = 0; i < 12000; ++i) {
        T target = T(int(rng()%200001)-100000)/13;
        T l = target-T(1+rng()%100000), r = target+T(1+rng()%100000);
        int count = 0;
        T got = bisect(l,r,[&](T x) { ++count; return x >= target; });
        T err = max(T(1),abs(target))*eps*8 + (r-l)*ldexp(T(1),-100);
        check(got >= target && got-target <= err && count <= 100);
        count = 0;
        T peak = target;
        T best = gss(l,r,[&](T x) { ++count; return abs(x-peak); });
        T ge = max(T(1),max(abs(l),abs(r)))*eps*128 + (r-l)*T(1e-20L);
        check(abs(best-target) <= ge && count <= 102);
    }
    for (T x : {T(0),T(1),T(1e10),T(-1e10)}) {
        T y = nextafter(x,numeric_limits<T>::infinity());
        int count = 0;
        check(bisect(x,y,[&](T t) { ++count; return t >= y; }) == y && count <= 1);
        check(gss(x,x,[](T t) { return t; }) == x);
    }
    // Finite extreme endpoints whose subtraction would overflow.
    T hi = numeric_limits<T>::max()/T(1.1), lo = -hi;
    T z = bisect(lo,hi,[](T x) { return x >= 0; },20000);
    check(z == 0);
    T g = gss(lo,hi,[&](T x) { return abs(x/hi); },20000);
    check(isfinite(g) && abs(g/hi) < eps*128);
    // Endpoint minima, smooth quadratics, and a flat minimum interval.
    for (int i = 0; i < 100; ++i) {
        T a = T(i), b = a+T(20);
        check(abs(gss(a,b,[](T x) { return x; })-a) <= max(T(1),b)*eps*128);
        check(abs(gss(a,b,[](T x) { return -x; })-b) <= max(T(1),b)*eps*128);
        T c = a+T(7.125);
        check(abs(gss(a,b,[&](T x) { return (x-c)*(x-c); })-c) <= b*eps*128);
    }
    T flat = gss(T(-20),T(20),[](T x) { return max(T(0),abs(x)-T(2)); });
    check(abs(flat) <= T(2)+eps*128);
}

void powers() {
    // Oracle multiplies e times using arbitrary precision, no binary powering.
    for (int m = 1; m <= 50; ++m) for (int a = -50; a <= 50; ++a)
        for (int e = 0; e <= 25; ++e) {
            cpp_int v = 1;
            for (int j = 0; j < e; ++j) v *= a;
            v %= m; if (v < 0) v += m;
            check(modpow(a,e,m) == v.convert_to<ll>());
        }
    for (int i = 0; i < 10000; ++i) {
        ll a = signedBits(rng());
        ll m = ll(rng() & uint64_t(LLONG_MAX)); if (!m) m = 1;
        int e = int(rng()%81);
        cpp_int v = 1;
        for (int j = 0; j < e; ++j) { v *= a; v %= m; }
        v %= m; if (v < 0) v += m;
        check(modpow(a,e,m) == v.convert_to<ll>());
    }
    check(modpow(LLONG_MIN,2,LLONG_MAX) == 1);
    check(modpow(LLONG_MIN,1,LLONG_MAX) == LLONG_MAX-1);
    check(modpow(LLONG_MAX-1,LLONG_MAX,LLONG_MAX) == LLONG_MAX-1);
    check(modpow(-1,LLONG_MAX,2) == 1);
    check(modpow(0,0,1) == 0);
}

int main() {
    integers(); reals<double>(); reals<long double>(); powers();
    cout << "Search/ModPow: " << checks << " checks passed\n";
}
