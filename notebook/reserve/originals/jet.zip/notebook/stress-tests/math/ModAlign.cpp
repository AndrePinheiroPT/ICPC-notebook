#include "../utilities/template.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/math/ModAlign.h"
using boost::multiprecision::cpp_int;

static uint64_t multiples = 0, terms = 0, excluded = 0;
static mt19937_64 rng(0x86cb82b5936ULL);

// Oracle works with arbitrary-precision integers, independently of the
// implementation's overflow-avoiding arithmetic. Calls stay within contract.
cpp_int first(const cpp_int& x, const cpp_int& k) {
	cpp_int z = (x/k)*k;
	return z < x ? cpp_int(z+k) : z;
}

template<class T> void multiple(T x, T k) {
	if (k <= 0) return;
	cpp_int X = x, K = k, want = first(X, K);
	if (want > cpp_int(numeric_limits<T>::max())) { ++excluded; return; }
	cpp_int got = nextMultiple<T>(x, k);
	if (!(got == want && got >= X && got%K == 0 && got-K < X)) {
		cerr << "nextMultiple failed: x=" << X << " k=" << K
		     << " want=" << want << " got=" << got << '\n'; abort();
	}
	++multiples;
}

template<class T> void term(T x, T t0, T k) {
	if (k <= 0) return;
	cpp_int X = x, T0 = t0, K = k;
	cpp_int want = X <= T0 ? T0 : cpp_int(T0+first(cpp_int(X-T0), K));
	if (want > cpp_int(numeric_limits<T>::max())) { ++excluded; return; }
	cpp_int got = nextTerm<T>(x, t0, k);
	if (!(got == want && got >= X && got >= T0 && (got-T0)%K == 0 &&
	      got-K < max(X, T0))) {
		cerr << "nextTerm failed: x=" << X << " t0=" << T0 << " k=" << K
		     << " want=" << want << " got=" << got << '\n'; abort();
	}
	++terms;
}

template<class T> T sample() {
	if constexpr (is_signed_v<T>) {
		using U = make_unsigned_t<T>;
		U u = static_cast<U>(rng());
		T v = static_cast<T>(u & static_cast<U>(numeric_limits<T>::max()));
		return (u >> numeric_limits<T>::digits) ? T(-1)-v : v;
	} else return static_cast<T>(rng());
}

template<class T> void test() {
	int low = is_signed_v<T> ? -24 : 0, high = is_signed_v<T> ? 24 : 48;
	for (int x = low; x <= high; ++x) for (int k = 1; k <= 24; ++k) {
		multiple(T(x), T(k));
		for (int t0 = low; t0 <= high; ++t0) term(T(x), T(t0), T(k));
	}
	vector<T> edge{0, 1, 2, numeric_limits<T>::max(),
	               T(numeric_limits<T>::max()-1), T(numeric_limits<T>::max()-2)};
	vector<T> steps{1, 2, 3, numeric_limits<T>::max(),
	                T(numeric_limits<T>::max()-1)};
	if constexpr (is_signed_v<T>)
		edge.insert(edge.end(), {-1, -2, numeric_limits<T>::min(),
		                         T(numeric_limits<T>::min()+1),
		                         T(numeric_limits<T>::min()+2)});
	for (int bit = 1; bit < numeric_limits<T>::digits; ++bit) {
		T p = T(T(1) << bit);
		edge.insert(edge.end(), {T(p-1), p, T(p+1)});
		steps.insert(steps.end(), {T(p-1), p, T(p+1)});
		if constexpr (is_signed_v<T>)
			edge.insert(edge.end(), {T(-p-1), T(-p), T(-p+1)});
	}
	// Full extreme cross-product, especially cases where x-t0 would overflow.
	for (T x : edge) for (T k : steps) {
		multiple(x, k);
		for (int j = 0; j < (is_signed_v<T> ? 11 : 6); ++j)
			term(x, edge[size_t(j)], k);
	}
	for (int i = 0; i < 30000; ++i) {
		T x = sample<T>(), t0 = sample<T>(), k = sample<T>();
		if (k > 0) { multiple(x, k); term(x, t0, k); }
		k = steps[size_t(rng()%steps.size())];
		multiple(x, k); term(x, t0, k);
		term(x, edge[size_t(rng()%edge.size())], k);
		term(edge[size_t(rng()%edge.size())], t0, k);
	}
}

int main() {
	test<int32_t>(); test<uint32_t>(); test<int64_t>(); test<uint64_t>();
	using W = __int128_t;
	W half = W(1) << 126, low = -half-half, high = half+(half-1);
	vector<W> edge{low, low+1, low+2, -half-1, -half, -half+1,
	               -2, -1, 0, 1, 2, half-1, half, half+1, high-2, high-1, high};
	vector<W> steps{1, 2, 3, half-1, half, half+1, high-2, high-1, high};
	for (W x : edge) for (W k : steps) {
		multiple(x, k);
		for (W t0 : edge) term(x, t0, k);
	}
	cout << "Tests passed! ModAlign: " << multiples << " multiples, " << terms
	     << " progression terms; " << excluded
	     << " cases excluded because the mathematical result is unrepresentable.\n";
}
