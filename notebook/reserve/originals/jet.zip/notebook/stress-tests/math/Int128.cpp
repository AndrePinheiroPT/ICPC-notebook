#include "../utilities/template.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/math/Int128.h"
using boost::multiprecision::cpp_int;

static uint64_t formats = 0, valid = 0, invalid = 0;
static mt19937_64 rng(0xade8105cb364ULL);
const i128 HALF = i128(1) << 126;
const i128 LOW = -HALF-HALF, HIGH = HALF+(HALF-1);

// Independent decimal oracle: split the unsigned magnitude into 64-bit
// pieces and let cpp_int perform the base-10 conversion.
cpp_int big(i128 x) {
	u128 u = static_cast<u128>(x);
	if (x < 0) u = u128(0)-u;
	cpp_int z = uint64_t(u >> 64);
	z <<= 64;
	z += uint64_t(u);
	return x < 0 ? cpp_int(-z) : z;
}

void parse(const string& s, bool expected, i128 want = 0) {
	istringstream in(" \t\n"+s+"\tEND");
	i128 x = 3141592653589793LL;
	bool ok = read128(in, x);
	if (ok != expected || x != (expected ? want : i128(3141592653589793LL))) {
		cerr << "read128 failed on token (length " << s.size() << "): "
		     << s.substr(0, 100) << " expected success=" << expected
		     << " actual=" << ok << " value=" << big(x) << '\n'; abort();
	}
	// Allow either failbit convention; token consumption must be complete.
	in.clear();
	string tail;
	if (!(in >> tail) || tail != "END") {
		cerr << "read128 did not consume exactly one token\n"; abort();
	}
	(expected ? valid : invalid)++;
}

void value(i128 x) {
	string want = big(x).convert_to<string>();
	if (toString(x) != want) {
		cerr << "toString failed for " << want << '\n'; abort();
	}
	++formats;
	parse(want, true, x);
	string mag = x < 0 ? want.substr(1) : want;
	parse((x < 0 ? "-" : "+")+string(7, '0')+mag, true, x);
}

int main() {
	for (int x = -10000; x <= 10000; ++x) value(i128(x));
	for (i128 x : {LOW, LOW+1, LOW+2, HIGH, HIGH-1, HIGH-2, -HALF, HALF}) value(x);
	for (int bit = 1; bit < 127; ++bit) {
		i128 p = i128(1) << bit;
		for (i128 x : {p-1, p, p+1, -p-1, -p, -p+1}) value(x);
	}
	for (int i = 0; i < 20000; ++i) {
		u128 u = (u128(rng()) << 64) | rng();
		u128 sign = u128(1) << 127;
		i128 x = static_cast<i128>(u & (sign-1));
		if (u & sign) x += LOW;
		value(x);
	}
	for (string s : {"0", "-0", "+0", "00000", "+00000", "-00000"}) parse(s, true, 0);
	parse(string(2000, '0')+"1", true, 1);
	parse("-"+string(2000, '0')+"1", true, -1);
	for (string s : {"+", "-", "++1", "--1", "+-1", "-+1", "x", "1a",
	                 "a1", "0x10", "0b11", "1.0", "1e3", "1_000", "1,000",
	                 "1+", "1-", "NaN", "inf"}) parse(s, false);
	parse(string("1\0", 2), false);
	parse(string(10000, '9'), false);
	parse("-"+string(10000, '9'), false);
	cpp_int limit = cpp_int(1) << 127;
	for (int i = 0; i < 1000; ++i) {
		cpp_int positive = limit+cpp_int(rng());
		cpp_int negative = -limit-1-cpp_int(rng());
		parse(positive.convert_to<string>(), false);
		parse(negative.convert_to<string>(), false);
	}
	parse(limit.convert_to<string>(), false);
	parse((cpp_int(-limit-1)).convert_to<string>(), false);
	for (string s : {"", " ", "\n\t"}) {
		istringstream in(s);
		i128 x = 456;
		if (read128(in, x) || x != 456) { cerr << "EOF contract failed\n"; abort(); }
		++invalid;
	}
	istringstream in("+17 -0 -23");
	for (i128 want : {i128(17), i128(0), i128(-23)}) {
		i128 x = 99;
		if (!read128(in, x) || x != want) { cerr << "sequential input failed\n"; abort(); }
		++valid;
	}
	i128 last = 73;
	if (read128(in, last) || last != 73) { cerr << "terminal EOF failed\n"; abort(); }
	++invalid;
	cout << "Tests passed! Int128: " << formats << " formatting cases, " << valid
	     << " valid tokens, " << invalid << " invalid/EOF cases.\n";
}
