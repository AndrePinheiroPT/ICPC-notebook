#include "../utilities/template.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/math/IntDivision.h"
using boost::multiprecision::cpp_int;

// A positive denominator makes inequalities an independent oracle:
// floor: q*b <= a < (q+1)*b; ceil: (q-1)*b < a <= q*b.
static uint64_t cases = 0;
static mt19937_64 rng(0x734c805af311ULL);

template<class T> void check(T a, T b) {
	if (!b) return;
	if constexpr (numeric_limits<T>::is_signed)
		if (a == numeric_limits<T>::min() && b == T(-1)) return;
	cpp_int x = a, y = b;
	if (y < 0) { x = -x; y = -y; }
	cpp_int f = floorDiv<T>(a, b), c = ceilDiv<T>(a, b);
	if (!(f*y <= x && x < (f+1)*y && (c-1)*y < x && x <= c*y)) {
		cerr << "division failed: a=" << cpp_int(a) << " b=" << cpp_int(b)
		     << " floor=" << f << " ceil=" << c << '\n';
		abort();
	}
	++cases;
}

template<class T> T sample() {
	if constexpr (is_signed_v<T>) {
		using U = make_unsigned_t<T>;
		U u = static_cast<U>(rng());
		T v = static_cast<T>(u & static_cast<U>(numeric_limits<T>::max()));
		return (u >> numeric_limits<T>::digits) ? T(-1)-v : v;
	} else return static_cast<T>(rng());
}

template<class T> void test() {
	int low = is_signed_v<T> ? -128 : 0;
	int high = is_signed_v<T> ? 127 : 255;
	for (int a = low; a <= high; ++a)
		for (int b = low; b <= high; ++b) check(T(a), T(b));
	vector<T> edge{0, 1, 2, numeric_limits<T>::max(),
	               T(numeric_limits<T>::max()-1), T(numeric_limits<T>::max()-2)};
	if constexpr (is_signed_v<T>) {
		edge.insert(edge.end(), {-1, -2, numeric_limits<T>::min(),
		                         T(numeric_limits<T>::min()+1),
		                         T(numeric_limits<T>::min()+2)});
	}
	for (int bit = 1; bit < numeric_limits<T>::digits; ++bit) {
		T p = T(T(1) << bit);
		edge.insert(edge.end(), {T(p-1), p, T(p+1)});
		if constexpr (is_signed_v<T>)
			edge.insert(edge.end(), {T(-p-1), T(-p), T(-p+1)});
	}
	for (T a : edge) for (T b : edge) check(a, b);
	for (int i = 0; i < 30000; ++i) {
		T a = sample<T>(), b = sample<T>();
		check(a, b);
		check(a, edge[size_t(rng()%edge.size())]);
		check(edge[size_t(rng()%edge.size())], b);
	}
}

int main() {
	test<int32_t>(); test<uint32_t>(); test<int64_t>(); test<uint64_t>();
	using W = __int128_t;
	W half = W(1) << 126, low = -half-half, high = half+(half-1);
	vector<W> edge{low, low+1, low+2, -half-1, -half, -half+1,
	               -2, -1, 0, 1, 2, half-1, half, half+1, high-2, high-1, high};
	for (W a : edge) for (W b : edge) check(a, b);
	cout << "Tests passed! IntDivision: " << cases
	     << " input pairs, four exact inequalities per pair.\n";
}
