# Testes do capítulo 2

Os três executáveis usam `boost::multiprecision::cpp_int` como referência exata,
seeds fixas e os headers reais do notebook. Não há implementações substitutas
dos algoritmos em teste.

| Teste | Método | Casos na execução de 2026-09-26 |
| --- | --- | --- |
| `IntDivision.cpp` | Caracterização de floor/ceil por quatro desigualdades exatas; enumeração pequena, bordas e amostras de 32/64 bits; extremos signed128. | 850 845 pares |
| `ModAlign.cpp` | Referência com inteiros ilimitados, alinhamento e minimalidade; enumeração pequena, bordas e amostras de 32/64 bits; extremos signed128, incluindo diferenças `x-t0` não representáveis. | 337 539 múltiplos e 1 936 866 termos |
| `Int128.cpp` | Conversão decimal de referência por `cpp_int`, construído a partir de duas metades de 64 bits; valores pequenos, potências de dois, extremos e 20 000 amostras cobrindo signed128; validação de tokens e consumo da entrada. | 40 765 formatos, 81 541 tokens válidos e 2 028 casos inválidos/EOF |

Os testes respeitam os contratos: não chamam divisão por zero, mínimo signed
dividido por -1, nem alinhamentos cujo resultado matemático não cabe no tipo.
O oracle excluiu 51 927 alinhamentos dessa última categoria. Estes não contam
como sucessos do algoritmo. O leitor de inteiros verifica entrada inválida,
overflow, sinais sem dígitos, zeros iniciais longos e preservação da saída ao
falhar; cada chamada deve consumir exatamente um token.

Validação realizada: GNU++20 otimizado e GNU++20 com AddressSanitizer e
UndefinedBehaviorSanitizer, sem falhas. Também compilam em C++17. As flags
`-Wall -Wextra -Wshadow -Wconversion` não reportaram avisos no nosso código.
Boost é uma dependência dos testes; quando estiver fora do include path do
sistema, fornecer o seu diretório com `-isystem`. LeakSanitizer foi desligado
com `ASAN_OPTIONS=detect_leaks=0` devido à restrição de ptrace do ambiente.

Os testes são evidência de correção dos contratos indicados, não uma prova
exaustiva de todos os inteiros de 64/128 bits.

## Revisão geral seguinte

Nova revisão: Adversarial.cpp acrescenta 680 895 verificações por modo de aritmética correlacionada, I/O e fórmulas Sums/Series.

Logs atuais: `validation/revision-11/`. As suites novas incluem o preâmbulo
real do Contest, gerado pelo runner como ContestPreamble.h. Não acrescentam
macros ou aliases ao algoritmo. Ver REVISION-RELIABILITY.md para os métodos
e limites da validação.
