#include "ContestPreamble.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/math/IntDivision.h"
#include "../../content/math/ModAlign.h"
#include "../../content/math/Int128.h"
using boost::multiprecision::cpp_int;
static uint64_t checks=0;
void ck(bool ok) {++checks; if(!ok) abort();}
int main() {
 mt19937_64 gen(0x27da119baULL);
 for(int run=0;run<60000;++run) {
  ll k=ll(gen()%1000000001)+1, q=ll(gen()%18000000001ULL)-9000000000LL;
  ll a=q*k+ll(gen()%unsigned(k));
  for(ll b:{k,-k}) {
   cpp_int A=a,B=b; if(B<0){A=-A;B=-B;}
   cpp_int f=floorDiv(a,b),c=ceilDiv(a,b);
   ck(f*B<=A && A<(f+1)*B);ck((c-1)*B<A && A<=c*B);
  }
  ll m=nextMultiple(a,k);
  ck(m>=a && m%k==0 && cpp_int(m)-a<k);
  ll t0=ll(gen()%9000000000000000001ULL); if(gen()&1) t0=-t0;
  cpp_int X=a,T=t0,K=k,expected=T;
  if(X>T)expected=T+((X-T+K-1)/K)*K;
  if(expected<=LLONG_MAX) ck(cpp_int(nextTerm(a,t0,k))==expected);
  i128 x=i128(q)*i128(a)*i128(k); string token=toString(x);
  i128 result=0; istringstream in(" \t"+token+"\n-0 +0 nope 17");
  ck(read128(in,result)&&result==x);ck(read128(in,result)&&result==0);
  ck(read128(in,result)&&result==0);ck(!read128(in,result)&&result==0);
  ck(read128(in,result)&&result==17);
 }
 cpp_int s1=0,s2=0,s3=0,s4=0;
 for(int n=0;n<=4000;++n) {
  cpp_int N=n;s1+=N;s2+=N*N;s3+=N*N*N;s4+=N*N*N*N;
  ck(s1==N*(N+1)/2);ck(s2==N*(N+1)*(2*N+1)/6);
  ck(s3==N*N*(N+1)*(N+1)/4);ck(s4==N*(N+1)*(2*N+1)*(3*N*N+3*N-1)/30);
 }
 for(int c=-5;c<=5;++c)for(int a=0;a<=15;++a)for(int b=a;b<=30;++b){
  cpp_int power=1,lo=1,total=0;
  for(int j=0;j<=b;++j){if(j==a)lo=power;if(j>=a)total+=power;power*=c;}
  ck(total==(c==1?cpp_int(b-a+1):cpp_int((power-lo)/(c-1))));
 }
 for(int i=-75;i<=75;++i) {
  long double x=i/100.L,e=1,term=1,logsum=0,sq=1,bin=1,sinSum=0,cosSum=0;
  for(int j=1;j<=100;++j) {term*=x/j;e+=term;bin*=((1.5L-j)*x/j);sq+=bin;logsum+=(j%2?1:-1)*powl(x,j)/j;}
  long double st=x,ct=1;sinSum=st;cosSum=ct;
  for(int j=1;j<=30;++j){st*=-x*x/((2*j)*(2*j+1));ct*=-x*x/((2*j-1)*(2*j));sinSum+=st;cosSum+=ct;}
  ck(fabsl(e-expl(x))<1e-15L);ck(fabsl(logsum-log1pl(x))<1e-13L);
  ck(fabsl(sq-sqrtl(1+x))<1e-14L);ck(fabsl(sinSum-sinl(x))<1e-15L);ck(fabsl(cosSum-cosl(x))<1e-15L);
 }
 cout<<"Math adversarial: "<<checks<<" exact-boundary/I-O/formula checks passed\n";
}
