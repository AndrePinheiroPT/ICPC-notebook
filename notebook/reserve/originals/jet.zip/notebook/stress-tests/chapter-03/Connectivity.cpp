#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/data-structures/UnionFind.h"
#include "../../content/data-structures/DynamicConnectivity.h"

using Edge = pair<int,int>;
mt19937 rng(0xC0312026);
long long joins = 0, snapshots = 0, states = 0, checks = 0;
int rnd(int n) { assert(n > 0); return int(rng() % unsigned(n)); }

// Independent graph oracle: BFS, without any union-find.
vi labels(int n, const vector<Edge>& edges) {
	vector<vi> g(n);
	for (auto [u,v] : edges) {
		g[u].push_back(v); g[v].push_back(u);
	}
	vi c(n,-1);
	for (int s = 0; s < n; ++s) if (c[s] < 0) {
		queue<int> q; q.push(s); c[s] = s;
		while (!q.empty()) {
			int u = q.front(); q.pop();
			for (int v : g[u]) if (c[v] < 0)
				c[v] = s, q.push(v);
		}
	}
	return c;
}

template<class U> void verify(U& uf, int n,
                              const vector<Edge>& edges) {
	vi c = labels(n,edges), cnt(n);
	for (int x : c) ++cnt[x];
	int comps = 0;
	for (int x : cnt) comps += x > 0;
	assert(count_if(uf.e.begin(), uf.e.end(),
	                [](int x) { return x < 0; }) == comps);
	for (int a = 0; a < n; ++a) {
		assert(uf.size(a) == cnt[c[a]]);
		int root = uf.find(a);
		assert(0 <= root && root < n && uf.e[root] < 0);
		assert(-uf.e[root] == cnt[c[a]]);
		for (int b = 0; b < n; ++b)
			assert((uf.find(a) == uf.find(b)) == (c[a] == c[b]));
	}
	++checks;
}

void ordinary() {
	for (int n = 0; n <= 14; ++n) for (int rep = 0; rep < 100; ++rep) {
		UF uf(n); vector<Edge> edges;
		verify(uf,n,edges);
		if (!n) continue;
		for (int j = 0; j < 100; ++j) {
			int a = rnd(n), b = rnd(n);
			vi c = labels(n,edges);
			assert(uf.sameSet(a,b) == (c[a] == c[b]));
			assert(uf.join(a,b) == (c[a] != c[b]));
			edges.push_back({a,b});
			verify(uf,n,edges); ++joins;
			assert(!uf.join(a,a));
			assert(!uf.join(b,a));
			verify(uf,n,edges); joins += 2;
		}
	}
}

void rollback() {
	struct Snap { int t; vector<Edge> edges; vi e; };
	for (int n = 0; n <= 14; ++n) for (int rep = 0; rep < 100; ++rep) {
		RollbackUF uf(n); vector<Edge> edges;
		vector<Snap> st{{uf.time(), edges, uf.e}};
		verify(uf,n,edges);
		for (int j = 0; j < 100; ++j) {
			int op = rnd(5);
			if (op == 0) {
				st.push_back({uf.time(),edges,uf.e});
				++snapshots;
			} else if (op == 1 || !n) {
				int i = rnd(sz(st));
				auto s = st[i];
				uf.rollback(s.t); edges = s.edges;
				assert(uf.e == s.e);
				assert(uf.time() == s.t);
				st.resize(i+1); ++snapshots;
			} else {
				int a = rnd(n), b = rnd(n), t = uf.time();
				vi c = labels(n,edges);
				bool changed = c[a] != c[b];
				assert(uf.join(a,b) == changed);
				assert(uf.time() == t + 2*changed);
				edges.push_back({a,b}); ++joins;
				vi saved = uf.e;
				assert(!uf.join(a,a) && !uf.join(b,a));
				assert(saved == uf.e);
				assert(uf.time() == t + 2*changed); joins += 2;
			}
			verify(uf,n,edges);
			vi saved = uf.e;
			uf.rollback(uf.time());
			assert(uf.e == saved);
		}
		uf.rollback(0); edges.clear();
		verify(uf,n,edges);
	}
}

struct Interval { int l, r, u, v; };
void intervals(int n, int q, const vector<Interval>& es) {
	DynamicConnectivity dc(n,q);
	for (auto [l,r,u,v] : es) dc.add(l,r,u,v);
	for (int repeat = 0; repeat < 2; ++repeat) {
		int next = 0;
		dc.run([&](int t, RollbackUF& uf) {
			assert(t == next++);
			vector<Edge> edges;
			for (auto [l,r,u,v] : es)
				if (l <= t && t < r) edges.push_back({u,v});
			verify(uf,n,edges); ++states;
		});
		assert(next == q && dc.uf.time() == 0);
		vector<Edge> empty;
		verify(dc.uf,n,empty);
	}
}

void dynamicIntervals() {
	intervals(0,0,{}); intervals(0,5,{});
	intervals(4,0,{});
	intervals(1,1,{{0,1,0,0},{0,0,0,0},{1,1,0,0}});
	intervals(4,4,{{0,0,0,1},{0,1,0,1},{1,4,1,2},
	                {2,2,2,2},{1,4,2,1},{3,4,2,3}});
	for (int rep = 0; rep < 2500; ++rep) {
		int n = rnd(15), q = rnd(41);
		vector<Interval> es;
		if (n) for (int j = rnd(61); j--; ) {
			int l = rnd(q+1), r = rnd(q+1);
			if (l > r) swap(l,r);
			es.push_back({l,r,rnd(n),rnd(n)});
			if (rnd(5) == 0) es.push_back(es.back());
		}
		intervals(n,q,es);
	}
}

struct Event { int kind, u, v; }; // 1 add, -1 remove, 0 query.
void events(int n, const vector<Event>& ev) {
	int q = sz(ev);
	DynamicConnectivity dc(n,q);
	map<Edge,pair<int,int>> alive; // multiplicity, opening time
	for (int t = 0; t < q; ++t) {
		auto [kind,u,v] = ev[t];
		if (!kind) continue;
		if (u > v) swap(u,v);
		auto& [count,start] = alive[{u,v}];
		if (kind == 1) { if (count++ == 0) start = t; }
		else {
			assert(count > 0);
			if (--count == 0) dc.add(start,t,u,v);
		}
	}
	for (auto [e,p] : alive)
		if (p.first) dc.add(p.second,q,e.first,e.second);
	int next = 0;
	dc.run([&](int t, RollbackUF& uf) {
		assert(t == next++);
		// Replay individual edge copies, independently of interval building.
		vector<Edge> copies;
		for (int i = 0; i <= t; ++i) {
			auto [kind,u,v] = ev[i];
			if (u > v) swap(u,v);
			if (kind == 1) copies.push_back({u,v});
			else if (kind == -1) {
				auto it = find(copies.begin(),copies.end(),Edge{u,v});
				assert(it != copies.end()); copies.erase(it);
			}
		}
		verify(uf,n,copies); ++states;
	});
	assert(next == q && dc.uf.time() == 0);
	assert(count_if(dc.uf.e.begin(), dc.uf.e.end(),
	                [](int x) { return x < 0; }) == n);
}

void dynamicEvents() {
	events(3,{{1,0,1},{1,1,0},{-1,0,1},{0,0,0},
	          {-1,1,0},{1,1,0},{1,1,2},{-1,0,1},
	          {1,2,2},{-1,2,2},{0,0,0}});
	events(0,{}); events(0,{{0,0,0},{0,0,0}});
	for (int rep = 0; rep < 1500; ++rep) {
		int n = rnd(14)+1, q = rnd(61);
		vector<Event> ev; vector<Edge> alive;
		for (int t = 0; t < q; ++t) {
			int op = rnd(3);
			if (op == 0) ev.push_back({0,0,0});
			else if (op == 1 || alive.empty()) {
				int u = rnd(n), v = rnd(n);
				ev.push_back({1,u,v}); alive.push_back({u,v});
			} else {
				int k = rnd(sz(alive)); auto [u,v] = alive[k];
				ev.push_back({-1,v,u}); alive.erase(alive.begin()+k);
			}
		}
		events(n,ev);
	}
}

int main() {
	ordinary(); rollback(); dynamicIntervals(); dynamicEvents();
	cout << "Connectivity tests passed: " << joins << " joins, "
	     << snapshots << " snapshots/restorations, " << states
	     << " offline time states, " << checks << " BFS comparisons.\n";
}
