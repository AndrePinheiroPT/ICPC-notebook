#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/data-structures/RMQ.h"
#include "../../content/data-structures/OrderedSet.h"
#include "../../content/data-structures/SqrtDecomposition.h"

static mt19937_64 rng(0x436be752a810ULL);
static uint64_t sparseChecks = 0, orderedChecks = 0, sqrtChecks = 0;

void require(bool ok, const char* message) {
	if (!ok) { cerr << message << '\n'; abort(); }
}

struct Maximum {
	ll operator()(ll a, ll b) const { return max(a, b); }
};
struct Gcd {
	ll operator()(ll a, ll b) const { return gcd(a, b); }
};
struct BitAnd {
	int operator()(int a, int b) const { return a & b; }
};
struct First {
	ll operator()(ll a, ll) const { return a; }
};
struct Near {
	ll p;
	explicit Near(ll pivot) : p(pivot) {}
	ll operator()(ll a, ll b) const {
		return pair{abs(a-p), a} < pair{abs(b-p), b} ? a : b;
	}
};

// A direct left fold is independent of the table's overlapping intervals.
template<class T, class F> void allRanges(const vector<T>& a, F f) {
	const RMQ<T, F> st(a, f);
	for (int l = 0; l < sz(a); ++l) {
		T want = a[l];
		for (int r = l+1; r <= sz(a); ++r) {
			if (r > l+1) want = f(want, a[r-1]);
			require(st.query(l, r) == want, "RMQ range mismatch");
			++sparseChecks;
		}
	}
}

void sparseTable() {
	RMQ<int> empty({});
	require(empty.jmp.size() == 1 && empty.jmp[0].empty(), "empty table");
	for (int n = 0; n <= 100; ++n) {
		vector<ll> a(n), nonnegative(n);
		vector<int> bits(n);
		for (int i = 0; i < n; ++i) {
			a[i] = ll(rng()%2001)-1000;
			nonnegative[i] = ll(rng()%1001);
			bits[i] = int(rng()%1024);
		}
		allRanges(a, STMin<ll>{});
		allRanges(a, Maximum{});
		allRanges(nonnegative, Gcd{});
		allRanges(bits, BitAnd{});
		allRanges(a, First{}); // Idempotent but not commutative.
		allRanges(a, Near(17)); // Stateful, not default-constructible.
	}
	vector<ll> edge{LLONG_MIN, LLONG_MAX, 0, -1, 1,
	                LLONG_MIN, LLONG_MAX, 1, 0};
	allRanges(edge, STMin<ll>{});
	allRanges(edge, Maximum{});
	const RMQ<ll> defaults(edge);
	require(defaults.query(1, 5) == -1, "default operation/type");
	++sparseChecks;
}

template<class T, class C>
void snapshot(const OST<T, C>& t, const vector<T>& a) {
	require(t.size() == a.size(), "OST size mismatch");
	auto it = t.begin();
	for (const T& x : a) {
		require(it != t.end() && *it == x, "OST iteration mismatch");
		++it; ++orderedChecks;
	}
	require(it == t.end(), "OST extra key");
	for (size_t k : {a.size(), a.size()+5}) {
		require(t.find_by_order(k) == t.end(), "OST kth out of range");
		++orderedChecks;
	}
}

template<class T, class C>
void ranks(const OST<T, C>& t, const vector<T>& a, T x, C cmp) {
	size_t want = 0;
	for (const T& y : a) want += cmp(y, x);
	require(t.order_of_key(x) == want, "OST rank mismatch");
	++orderedChecks;
	if (!a.empty()) {
		size_t k = size_t(rng()%a.size());
		auto it = t.find_by_order(k);
		require(it != t.end() && *it == a[k], "OST kth mismatch");
		++orderedChecks;
	}
}

void orderedSet() {
	OST<int> t;
	vector<int> a;
	snapshot(t, a);
	for (int step = 0; step < 30000; ++step) {
		int x = int(rng()%1001)-500;
		auto it = find(a.begin(), a.end(), x);
		if (rng()%2) {
			bool fresh = it == a.end();
			require(t.insert(x).second == fresh, "OST duplicate insert");
			if (fresh) { a.push_back(x); sort(a.begin(), a.end()); }
		} else {
			bool found = it != a.end();
			require(bool(t.erase(x)) == found, "OST erase mismatch");
			if (found) a.erase(it);
		}
		++orderedChecks;
		ranks(t, a, int(rng()%1201)-600, less<int>{});
		if (step%100 == 0) snapshot(t, a);
	}
	snapshot(t, a);
	using P = pair<ll,int>;
	OST<P> duplicates;
	vector<P> values;
	int id = 0;
	for (int step = 0; step < 12000; ++step) {
		if (values.empty() || rng()%2) {
			ll x = ll(rng()%17)-8;
			if (step%31 == 0) x = LLONG_MIN;
			if (step%37 == 0) x = LLONG_MAX;
			P p{x, id++};
			require(duplicates.insert(p).second, "OST pair insert");
			values.push_back(p); sort(values.begin(), values.end());
		} else {
			size_t k = size_t(rng()%values.size());
			require(duplicates.erase(values[k]), "OST exact duplicate erase");
			values.erase(values.begin()+ptrdiff_t(k));
		}
		++orderedChecks;
		ll x = ll(rng()%21)-10;
		P key{x, -1};
		ranks(duplicates, values, key, less<P>{});
		size_t want = 0;
		for (auto p : values) want += p.first < x;
		require(duplicates.order_of_key(key) == want, "OST duplicate value rank");
		++orderedChecks;
		if (step%100 == 0) snapshot(duplicates, values);
	}
	snapshot(duplicates, values);
	OST<int, greater<int>> descending;
	vector<int> rev{9, 3, 0, -7};
	for (int x : rev) descending.insert(x);
	snapshot(descending, rev);
	for (int x = -10; x <= 10; ++x) ranks(descending, rev, x, greater<int>{});
}

template<class T>
void counts(const SqrtDecomposition<T>& s, const vector<T>& a,
            int l, int r, T x) {
	int less = 0;
	for (int i = l; i < r; ++i) less += a[i] < x;
	require(s.countLess(l, r, x) == less, "sorted blocks countLess");
	++sqrtChecks;
}

void sortedBlocks() {
	SqrtDecomposition<ll> empty;
	counts(empty, vector<ll>{}, 0, 0, 7LL);
	for (int n = 0; n <= 24; ++n) {
		vector<int> a(n);
		for (int& x : a) x = int(rng()%7)-3;
		SqrtDecomposition<int> s(a);
		for (int l = 0; l <= n; ++l) for (int r = l; r <= n; ++r)
			for (int x = -4; x <= 4; ++x) counts(s, a, l, r, x);
	}
	for (int trial = 0; trial < 80; ++trial) {
		int n = int(rng()%501);
		vector<ll> a(n);
		for (ll& x : a) x = ll(rng()%21)-10;
		SqrtDecomposition<ll> s(a);
		for (int step = 0; step < 400; ++step) {
			if (n && rng()%2) {
				int i = int(rng()%uint64_t(n));
				ll x = ll(rng()%2000001)-1000000;
				if (step%17 == 0) x = LLONG_MIN;
				if (step%23 == 0) x = LLONG_MAX;
				if (step%7 == 0) x = a[i];
				s.set(i, x); a[i] = x;
				counts(s, a, i, i+1, x);
			}
			int l = int(rng()%uint64_t(n+1));
			int r = int(rng()%uint64_t(n+1));
			if (l > r) swap(l, r);
			ll x = ll(rng()%31)-15;
			counts(s, a, l, r, x);
			counts(s, a, 0, n, LLONG_MIN);
			counts(s, a, 0, n, LLONG_MAX);
			counts(s, a, r, r, x);
		}
	}
}

int main() {
	sparseTable(); orderedSet(); sortedBlocks();
	cout << "Tests passed! StaticOrdered: " << sparseChecks << " sparse queries, "
	     << orderedChecks << " ordered-set checks, " << sqrtChecks
	     << " sorted-block count queries.\n";
}
