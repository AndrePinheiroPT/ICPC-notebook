#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/data-structures/Fenwick.h"
#include "../../content/data-structures/Fenwick2D.h"
#include "../../content/data-structures/PrefixSum2D.h"
#include "../../content/data-structures/Difference2D.h"

mt19937_64 rng(0x46454e5749434bULL);
unsigned long long checks = 0, cases = 0;
int pick(int n) { return int(rng() % n); }
void check(bool ok, const char* what) {
	++checks;
	if (!ok) {
		cerr << "FAILED " << what << " at check " << checks << '\n';
		exit(1);
	}
}
template<class T> T value() {
	T scale = sizeof(T) > sizeof(int) ? T(1000000000) : T(1);
	return T(pick(2001) - 1000) * scale;
}
template<class T> T sum(const vector<T>& a, int l, int r) {
	return accumulate(a.begin()+l, a.begin()+r, T{});
}
template<class T> void oneDimension() {
	for (int run = 0; run < 250; ++run) {
		++cases;
		int n = run % 51;
		vector<T> a(n);
		for (auto& x : a) x = value<T>();
		Fenwick<T> f(n);
		for (int i = 0; i < n; ++i) f.add(i,a[i]);
		for (int l = 0; l <= n; ++l)
			for (int r = l; r <= n; ++r) {
				check(f.query(l,r) == sum(a,l,r), "Fenwick initial range");
				check(f.query(r) == sum(a,0,r), "Fenwick initial prefix");
			}
		for (int step = 0; step < 150; ++step) {
			if (n && step % 3 == 0) {
				int i = pick(n); T v = value<T>();
				f.add(i,v); a[i] += v;
			}
			int l = pick(n+1), r = pick(n+1);
			if (l > r) swap(l,r);
			check(f.query(r) == sum(a,0,r), "Fenwick prefix");
			check(f.query(l,r) == sum(a,l,r), "Fenwick range");
		}
	}
	check(Fenwick<T>().query(0) == T{}, "empty Fenwick prefix");
	check(Fenwick<T>().query(0,0) == T{}, "empty Fenwick range");
}
template<class T> T rect(const vector<vector<T>>& a,
		int r1, int c1, int r2, int c2) {
	T ans{};
	for (int r = r1; r < r2; ++r)
		for (int c = c1; c < c2; ++c) ans += a[r][c];
	return ans;
}
template<class T> void denseTwoDimensions() {
	for (int run = 0; run < 180; ++run) {
		++cases;
		int n = run % 11, m = (run / 11) % 11;
		vector<vector<T>> a(n,vector<T>(m)), b = a;
		for (auto& row : a) for (auto& x : row) x = value<T>();
		PrefixSum2D<T> p(n,m,a);
		Difference2D<T> d(n,m);
		for (int step = 0; step < 160; ++step) {
			int r1 = pick(n+1), r2 = pick(n+1);
			int c1 = pick(m+1), c2 = pick(m+1);
			if (r1 > r2) swap(r1,r2);
			if (c1 > c2) swap(c1,c2);
			check(p.query(r1,c1,r2,c2) ==
				rect(a,r1,c1,r2,c2), "prefix 2D rectangle");
			check(p.query(0,0,r2,c2) ==
				rect(a,0,0,r2,c2), "prefix 2D prefix");
			T v = value<T>();
			d.add(r1,c1,r2,c2,v);
			for (int r = r1; r < r2; ++r)
				for (int c = c1; c < c2; ++c) b[r][c] += v;
			if (step % 7 == 0) {
				check(d.values() == b, "difference 2D");
				check(d.values() == b, "difference 2D repeat");
			}
		}
		check(d.values() == b, "difference 2D final");
		check(p.query(0,0,n,m) == rect(a,0,0,n,m), "full 2D");
	}
}
template<class C> vector<C> coordinates() {
	C lo = numeric_limits<C>::lowest(), hi = numeric_limits<C>::max();
	vector<C> v{lo, C(lo+1), C(-10), C(-1), C(0),
		C(1), C(10), C(hi-1), hi};
	if (sizeof(C) > sizeof(int)) {
		v.push_back(C(-5000000000000LL));
		v.push_back(C(5000000000000LL));
	}
	return v;
}
template<class T, class C> void sparseTwoDimensions() {
	vector<C> pool = coordinates<C>();
	for (int run = 0; run < 180; ++run) {
		++cases;
		vector<pair<C,C>> points;
		map<pair<C,C>,T> a;
		for (int i = 0; i < run % 29; ++i) {
			C x = pool[pick(sz(pool))], y = pool[pick(sz(pool))];
			points.emplace_back(x,y); a[{x,y}] = T{};
			if (i % 3 == 0) points.emplace_back(x,y);
		}
		Fenwick2D<T,C> f(points);
		for (int step = 0; step < 180; ++step) {
			if (!points.empty() && step % 2 == 0) {
				auto [x,y] = points[pick(sz(points))];
				T v = value<T>();
				f.add(x,y,v); a[{x,y}] += v;
			}
			// Bounds need not have been registered.
			C x1 = step % 3 ? pool[pick(sz(pool))] : C(pick(25)-12);
			C x2 = step % 3 ? pool[pick(sz(pool))] : C(pick(25)-12);
			C y1 = step % 3 ? pool[pick(sz(pool))] : C(pick(25)-12);
			C y2 = step % 3 ? pool[pick(sz(pool))] : C(pick(25)-12);
			if (x1 > x2) swap(x1,x2);
			if (y1 > y2) swap(y1,y2);
			T pref{}, area{};
			for (auto [xy,v] : a) {
				auto [x,y] = xy;
				if (x < x2 && y < y2) pref += v;
				if (x1 <= x && x < x2 && y1 <= y && y < y2)
					area += v;
			}
			check(f.query(x2,y2) == pref, "Fenwick 2D prefix");
			check(f.query(x1,y1,x2,y2) == area, "Fenwick 2D rectangle");
			check(f.query(x1,y1,x1,y2) == 0, "Fenwick 2D empty width");
			check(f.query(x1,y1,x2,y1) == 0, "Fenwick 2D empty height");
		}
	}
	check(Fenwick2D<T,C>().query(C(0),C(0)) == 0, "empty compressed");
}
int main() {
	oneDimension<int>();
	oneDimension<ll>();
	denseTwoDimensions<int>();
	denseTwoDimensions<ll>();
	sparseTwoDimensions<int,int>();
	sparseTwoDimensions<int,ll>();
	sparseTwoDimensions<ll,int>();
	sparseTwoDimensions<ll,ll>();
	cout << "Fenwick/Prefix/Difference: " << cases
		<< " cases, " << checks << " brute checks passed\n";
}
