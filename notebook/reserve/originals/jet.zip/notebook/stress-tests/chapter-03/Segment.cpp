#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/data-structures/SegmentTree.h"
#include "../../content/data-structures/LazySegTree.h"

static uint64_t checks = 0;
static mt19937 rng(20260926);
static int rnd(int n) { return int(rng() % unsigned(n)); }
static void check(bool ok) { ++checks; assert(ok); }

void testSeg() {
    for (int n : {0,1,2,3,7,8,9,31,64,97}) {
        vector<int> a(n,INT_MIN);
        SegTree st(n);
        for (int it = 0; it < 20000; ++it) {
            if (n && rnd(2)) {
                int p = rnd(n), x = rnd(2001)-1000;
                if (it%17 == 0) x = INT_MIN;
                if (it%23 == 0) x = INT_MAX;
                a[p] = x; st.update(p,x);
            }
            int l = rnd(n+1), r = rnd(n+1);
            if (l > r) swap(l,r);
            int want = INT_MIN;
            for (int i = l; i < r; ++i) want = max(want,a[i]);
            check(st.query(l,r) == want);
        }
        SegTree def(n,7);
        for (int l = 0; l <= n; ++l) for (int r = l; r <= n; ++r)
            check(def.query(l,r) == (l == r ? INT_MIN : 7));
    }
}

template<class T> void range(LazySegTree<T>& st,
                            const vector<T>& a, int l, int r) {
    T want = 0;
    for (int i = l; i < r; ++i) want += a[i];
    check(st.query(l,r) == want);
}

template<class T> void testLazy() {
    for (int n : {0,1,2,3,7,8,9,31,64,97}) {
        vector<T> a(n);
        for (T& x : a) x = T(rnd(201)-100);
        LazySegTree<T> st(a);
        for (int it = 0; it < 20000; ++it) {
            int l = rnd(n+1), r = rnd(n+1);
            if (l > r) swap(l,r);
            if (it % 11 == 0) l = 0, r = n;
            T x = T(rnd(201)-100);
            st.add(l,r,x);
            for (int i = l; i < r; ++i) a[i] += x;
            range(st,a,l,r);
            l = rnd(n+1); r = rnd(n+1);
            if (l > r) swap(l,r);
            range(st,a,l,r); range(st,a,0,n);
        }
    }
    // Repeated pending tags, cancellation and partial overlap, no queries.
    vector<T> a(17,4); LazySegTree<T> st(a);
    for (int j = 0; j < 100; ++j) {
        int l = j%3, r = 17-j%5; T x = T(j%7-3);
        st.add(l,r,x);
        for (int i = l; i < r; ++i) a[i] += x;
    }
    st.add(0,17,19); st.add(0,17,-19);
    for (int l = 0; l <= 17; ++l) for (int r = l; r <= 17; ++r)
        range(st,a,l,r);
    for (T x : {numeric_limits<T>::lowest(), numeric_limits<T>::max()}) {
        vector<T> b(1,x); LazySegTree<T> t(b);
        range(t,b,0,1); t.add(0,1,0); range(t,b,0,1);
    }
    if constexpr (is_same_v<T,ll>) {
        vector<T> b(17,1000000000000LL); LazySegTree<T> t(b);
        t.add(0,17,2000000000000LL);
        for (T& x : b) x += 2000000000000LL;
        t.add(3,16,-4000000000000LL);
        for (int i = 3; i < 16; ++i) b[i] -= 4000000000000LL;
        for (int l = 0; l <= 17; ++l) for (int r = l; r <= 17; ++r)
            range(t,b,l,r);
    }
}

void exhaustive(LazySegTree<ll> st, vector<ll> a, int depth) {
    if (!depth) {
        for (int l = 0; l <= 3; ++l) for (int r = l; r <= 3; ++r)
            range(st,a,l,r);
        return;
    }
    for (auto [l,r] : vector<pair<int,int>>{{0,3},{0,2},{1,3},{1,2},{2,2}})
        for (ll x : {-1LL,0LL,1LL}) {
            auto t = st; auto b = a;
            t.add(l,r,x);
            for (int i = l; i < r; ++i) b[i] += x;
            exhaustive(t,b,depth-1);
        }
}

int main() {
    testSeg(); testLazy<int>(); testLazy<ll>();
    exhaustive(LazySegTree<ll>(vector<ll>{-1,0,1}),{-1,0,1},4);
    cout << "Segment: " << checks << " verified assertions\n";
}
