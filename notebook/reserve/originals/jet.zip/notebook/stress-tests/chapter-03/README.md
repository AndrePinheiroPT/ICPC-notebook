# Testes do capítulo 3

Da raiz do notebook: `bash doc/scripts/test-chapter-03.sh`.

- `Integration.inc`: 12 headers montados com o preâmbulo real de Contest.
- `Connectivity.cpp`: BFS para UF, rollback e intervalos de conectividade.
- `FenwickPrefix.cpp`: vetores/grelhas para Fenwick 1D/2D, PrefixSum2D e
  Difference2D. Não testa nem inclui versões 1D de prefix/difference.
- `Segment.cpp`: varrimento linear para o SegTree KACTL e a lazy add/sum;
  int/ll, limites e composição de updates sem queries intermédias.
- `StaticOrdered.cpp`: referências lineares para sparse table e blocos;
  vetores ordenados para PBDS.

Seeds fixas, release e debug com ASan/UBSan. `_GLIBCXX_DEBUG` fica ativo,
exceto no stress longo StaticOrdered devido ao custo de validação PBDS;
PBDS também é exercitado com esse modo no teste de integração.
Não se usa `-DNDEBUG`. Em ambientes com ptrace pode ser necessário
`ASAN_OPTIONS=detect_leaks=0`.

A regressão antiga de DirectedMST corre no fim em release.
Os `.cpp` são autónomos; a fixture `.inc` deve usar o script.
Resultados atuais: `CHAPTER-03.md` e `validation/chapter-03-tests.log`.

## Revisão 11

- SparseTable foi substituída por RMQ.h do KACTL com STMin/F.
- Adversarial.cpp: UF/Rollback equilibrados com 32768 vértices, todos os
  pares de intervalos de duas arestas até 7 instantes, RMQ com operação
  idempotente não comutativa, limites binários dos comprimentos e
  coordenadas ll extremas. Oráculos: fórmulas de blocos e varrimentos.
- A suite Adversarial mantém STL-debug ativo; PBDS adicional fica até 33
  elementos porque a validação interna é cúbica. StaticOrdered mantém
  o stress extenso com ASan/UBSan e a integração cobre PBDS STL-debug.
- Resultados desta revisão: validation/revision-11/ch03.log.
