#include <bits/stdc++.h>
using namespace std;
#include "../../content/data-structures/MonotonicStack.h"
#include "../../content/data-structures/MonotonicDeque.h"

long long checks = 0;
template<class T> void check(const vector<T>& v) {
	int n = (int)v.size();
	vector<int> want(n, -1);
	for (int i = 0; i < n; ++i)
		for (int j = i+1; j < n; ++j)
			if (v[j] > v[i]) { want[i] = j; break; }
	assert(nextGreater(v) == want);
	++checks;
	for (int k = 1; k <= n+2; ++k) {
		vector<T> mins;
		for (int l = 0; l+k <= n; ++l)
			mins.push_back(*min_element(v.begin()+l, v.begin()+l+k));
		assert(slidingMin(v, k) == mins);
		++checks;
	}
	assert(slidingMin(v, INT_MAX).empty());
	++checks;
}

int main() {
	check<int>({});
	check<int>({5});
	check<int>({1, 2, 3, 4});
	check<int>({4, 3, 2, 1});
	check<int>({2, 2, 2, 2});
	check<int>({2, 1, 2, 3, 3, 0});
	check<int>({INT_MIN, INT_MAX, INT_MIN, 0, INT_MAX});
	check<long long>({LLONG_MAX, LLONG_MIN, 0, LLONG_MAX});
	check<double>({1.5, -2.5, -2.5, 4.0, 0.25});
	// Exhaust all arrays over {-1,0,1}, lengths 0..8.
	for (int n = 0, lim = 1; n <= 8; ++n, lim *= 3)
		for (int mask = 0; mask < lim; ++mask) {
			vector<int> v(n);
			int x = mask;
			for (int& a : v) { a = x%3-1; x /= 3; }
			check(v);
		}
	mt19937 rng(20260928);
	for (int t = 0; t < 3000; ++t) {
		vector<long long> v(rng()%81);
		for (auto& x : v) x = (long long)(rng()%21)-10;
		check(v);
	}
	// Large increasing, decreasing and equal inputs exercise amortized O(n).
	int n = 1000000;
	vector<int> v(n);
	for (int mode = 0; mode < 3; ++mode) {
		for (int i = 0; i < n; ++i)
			v[i] = mode == 0 ? i : mode == 1 ? n-i : 7;
		auto next = nextGreater(v);
		auto mins = slidingMin(v, n/2);
		assert((int)mins.size() == n-n/2+1);
		for (int i = 0; i < n; ++i)
			assert(next[i] == (mode == 0 && i+1 < n ? i+1 : -1));
		for (int i = 0; i < (int)mins.size(); ++i)
			assert(mins[i] == (mode == 0 ? i : mode == 1 ? n-(i+n/2-1) : 7));
	}
	cout << "PASS: " << checks << " brute-force comparisons; 3 large patterns\n";
}
