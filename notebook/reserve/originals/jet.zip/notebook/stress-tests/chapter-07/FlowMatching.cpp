#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/graph/DinicFlow.h"
#include "../../content/graph/MinCostFlow.h"
#include "../../content/graph/BipartiteMatching.h"
#include "../../content/graph/StableMatching.h"

static mt19937_64 rng(0x772781d29aULL);
static uint64_t checks = 0, dinicCases = 0, costCases = 0;
static uint64_t matchingCases = 0, stableCases = 0, stableEnumerated = 0;
void require(bool ok, const char* msg) {
	++checks;
	if (!ok) { cerr << "FAILED FlowMatching: " << msg << '\n'; abort(); }
}
int pick(int n) { return int(rng()%uint64_t(n)); }
struct Arc { int u, v; ll cap, cost; int id = -1; };

ll mincut(int n, const vector<Arc>& es) {
	ll best = LLONG_MAX;
	for (int mask = 0; mask < (1<<n); ++mask)
		if ((mask&1) && !(mask&(1<<(n-1)))) {
			ll c = 0;
			for (auto e : es) if ((mask&(1<<e.u)) && !(mask&(1<<e.v))) c += e.cap;
			best = min(best,c);
		}
	return best;
}

template<class T> void dinicCase(int n, vector<Arc> es) {
	DinicFlow<T> f(n);
	for (auto& e : es) { e.id = sz(f.g[e.u]); f.add(e.u,e.v,T(e.cap)); }
	T got = f.flow(0,n-1);
	require(ll(got) == mincut(n,es), "Dinic/mincut enumeration");
	require(f.lev[0] >= 0 && f.lev[n-1] < 0, "Dinic cut endpoints");
	ll cut = 0;
	vector<ll> balance(n);
	for (auto e : es) {
		auto a = f.g[e.u][e.id];
		auto b = f.g[e.v][a.rev];
		require(b.to == e.u && b.rev == e.id, "Dinic reverse index/self-loop");
		require(a.cap >= 0 && b.cap >= 0 && ll(a.cap)+ll(b.cap) == e.cap,
		        "Dinic residual capacity");
		ll sent = e.cap-ll(a.cap);
		balance[e.u] += sent; balance[e.v] -= sent;
		if (f.lev[e.u] >= 0 && f.lev[e.v] < 0) cut += e.cap;
	}
	for (int v = 0; v < n; ++v)
		require(balance[v] == (v == 0 ? ll(got) : v == n-1 ? -ll(got) : 0),
		        "Dinic conservation");
	require(cut == ll(got), "Dinic final residual mincut");
	require(f.flow(0,n-1) == 0, "Dinic repeated call returns additional flow");
	++dinicCases;
}

void testDinic() {
	for (int n = 2; n <= 6; ++n) dinicCase<int>(n,{});
	for (int test = 0; test < 1800; ++test) {
		int n = 2+pick(5);
		vector<Arc> es;
		for (int j = pick(14); j > 0; --j) es.push_back({pick(n),pick(n),pick(10),0});
		if (test%2) dinicCase<int>(n,es); else dinicCase<ll>(n,es);
	}
	dinicCase<ll>(4,{{0,0,7000000000000LL,0},{0,1,4000000000000LL,0},
	                 {0,1,3000000000000LL,0},{1,3,6000000000000LL,0},
	                 {0,2,2000000000000LL,0},{2,3,2000000000000LL,0},
	                 {3,3,9000000000000LL,0}});
}

// Enumerate every original edge flow. Feasible circulations are included;
// generated costs guarantee that no negative cycle exists initially.
pair<ll,ll> bruteCost(int n, const vector<Arc>& es, ll lim) {
	vector<ll> bal(n);
	pair<ll,ll> best{-1,LLONG_MAX};
	function<void(int,ll)> rec = [&](int i, ll cost) {
		if (i == sz(es)) {
			if (bal[0] < 0 || bal[0] > lim || bal[n-1] != -bal[0]) return;
			for (int v = 1; v+1 < n; ++v) if (bal[v]) return;
			if (bal[0] > best.first || (bal[0] == best.first && cost < best.second))
				best = {bal[0],cost};
			return;
		}
		auto e = es[i];
		for (ll x = 0; x <= e.cap; ++x) {
			bal[e.u] += x; bal[e.v] -= x;
			rec(i+1,cost+x*e.cost);
			bal[e.u] -= x; bal[e.v] += x;
		}
	};
	rec(0,0);
	return best;
}

template<class T, class C>
void residualCost(const MinCostFlow<T,C>& f, const vector<Arc>& es,
                  pair<ll,ll> total) {
	vector<ll> bal(f.g.size());
	ll cost = 0;
	for (auto e : es) {
		auto a = f.g[e.u][e.id], b = f.g[e.v][a.rev];
		require(b.to == e.u && b.rev == e.id && a.cost == -b.cost,
		        "MinCostFlow reverse index/cost");
		require(a.cap >= 0 && b.cap >= 0 && ll(a.cap)+ll(b.cap) == e.cap,
		        "MinCostFlow residual capacity");
		ll sent = e.cap-ll(a.cap);
		bal[e.u] += sent; bal[e.v] -= sent; cost += sent*e.cost;
	}
	for (int v = 0; v < sz(bal); ++v)
		require(bal[v] == (v == 0 ? total.first : v+1 == sz(bal) ? -total.first : 0),
		        "MinCostFlow conservation");
	require(cost == total.second, "MinCostFlow actual edge cost");
}

template<class T, class C> void costCase(int n, vector<Arc> es, int lim) {
	MinCostFlow<T,C> f(n);
	for (auto& e : es) {
		e.id = sz(f.g[e.u]); f.add(e.u,e.v,T(e.cap),C(e.cost));
	}
	auto p = f.flow(0,n-1,T(lim));
	pair<ll,ll> got{ll(p.first),ll(p.second)};
	require(got == bruteCost(n,es,lim), "MinCostFlow bounded optimum");
	residualCost(f,es,got);
	auto q = f.flow(0,n-1);
	got.first += ll(q.first); got.second += ll(q.second);
	require(got == bruteCost(n,es,LLONG_MAX), "MinCostFlow continued optimum");
	residualCost(f,es,got);
	require(f.flow(0,n-1) == pair<T,C>{0,0}, "MinCostFlow saturated repeat");
	++costCases;
}

void testCost() {
	for (int n = 2; n <= 5; ++n) costCase<int,ll>(n,{},0);
	for (int test = 0; test < 950; ++test) {
		int n = 2+pick(4), m = pick(8);
		vi h(n);
		for (int& x : h) x = pick(11)-5;
		vector<Arc> es;
		for (int j = 0; j < m; ++j) {
			int u = pick(n), v = pick(n), cap = pick(3), cost;
			if (test%2) { // Cost = potential difference + nonnegative weight.
				cost = h[v]-h[u]+pick(6);
			} else { // DAG edges permit arbitrary negative costs.
				if (u > v) swap(u,v);
				cost = u == v ? pick(6) : pick(15)-7;
			}
			es.push_back({u,v,cap,cost});
		}
		if (test%3 == 0) costCase<int,int>(n,es,pick(7));
		else if (test%3 == 1) costCase<int,ll>(n,es,pick(7));
		else costCase<ll,ll>(n,es,pick(7));
	}
	// Residual rerouting is essential: the first cheapest unit uses 1->2.
	costCase<int,ll>(4,{{0,1,1,0},{0,2,1,0},{1,2,1,-4},
	                    {1,3,1,0},{2,3,1,0},{1,1,2,0},{2,2,0,-8}},1);
	// Negative edges outside the source component still enter initial BF.
	costCase<ll,ll>(6,{{0,1,2,3},{1,5,2,-1},{2,3,1,-9},
	                   {3,4,2,4},{2,4,1,0},{0,1,1,6}},1);
	MinCostFlow<ll,ll> big(3);
	big.add(0,1,1000000LL,-1000000000000LL);
	big.add(1,2,1000000LL,4000000000000LL);
	require(big.flow(0,2) == pair<ll,ll>{1000000LL,3000000000000000000LL},
	        "MinCostFlow large capacities/cost product");
	++costCases;
}

int bruteMatching(const vector<vi>& g, int m) {
	vector<bool> possible(1<<m), next;
	possible[0] = true;
	for (const auto& es : g) {
		next = possible;
		for (int mask = 0; mask < (1<<m); ++mask) if (possible[mask])
			for (int v : es) if (!(mask&(1<<v))) next[mask|(1<<v)] = true;
		possible.swap(next);
	}
	int ans = 0;
	for (int mask = 0; mask < (1<<m); ++mask) if (possible[mask])
		ans = max(ans,__builtin_popcount(unsigned(mask)));
	return ans;
}

void matchingCase(int n, int m, const vector<pair<int,int>>& es) {
	BipartiteMatching b(n,m);
	for (auto [u,v] : es) b.add(u,v);
	int got = b.solve();
	require(got == bruteMatching(b.g,m), "Hopcroft-Karp/brute matching");
	int count = 0;
	for (int u = 0; u < n; ++u) if (b.l[u] >= 0) {
		int v = b.l[u];
		require(v < m && b.r[v] == u, "matching reciprocity");
		require(find(b.g[u].begin(),b.g[u].end(),v) != b.g[u].end(), "matched edge exists");
		++count;
	}
	for (int v = 0; v < m; ++v) if (b.r[v] >= 0)
		require(b.r[v] < n && b.l[b.r[v]] == v, "reverse matching reciprocity");
	require(count == got, "matching cardinality");
	auto [left,right] = b.cover();
	vi a(n), c(m);
	for (int u : left) { require(0 <= u && u < n && !a[u], "cover left ids"); a[u] = 1; }
	for (int v : right) { require(0 <= v && v < m && !c[v], "cover right ids"); c[v] = 1; }
	for (auto [u,v] : es) require(a[u] || c[v], "cover every edge");
	require(sz(left)+sz(right) == got, "minimum vertex cover cardinality");
	require(b.solve() == got, "matching solve rebuilds");
	++matchingCases;
}

void testMatching() {
	for (int n = 0; n <= 7; ++n) for (int m = 0; m <= 7; ++m) matchingCase(n,m,{});
	for (int test = 0; test < 1400; ++test) {
		int n = pick(8), m = pick(8);
		vector<pair<int,int>> es;
		if (n && m) for (int j = pick(35); j > 0; --j) es.emplace_back(pick(n),pick(m));
		matchingCase(n,m,es);
	}
	for (int n = 1; n <= 7; ++n) {
		vector<pair<int,int>> es;
		for (int u = 0; u < n; ++u) for (int v = 0; v < n; ++v) {
			es.emplace_back(u,v); es.emplace_back(u,v);
		}
		matchingCase(n,n,es);
	}
}

bool stable(const vector<vi>& a, const vector<vi>& b, const vi& match) {
	int n = sz(a);
	if (sz(match) != n) return false;
	vi r(n,-1);
	for (int u = 0; u < n; ++u) {
		int v = match[u];
		if (v < 0 || v >= n || r[v] >= 0) return false;
		r[v] = u;
	}
	for (int u = 0; u < n; ++u) for (int v : a[u]) {
		if (v == match[u]) break;
		const auto& pref = b[v];
		if (find(pref.begin(),pref.end(),u) < find(pref.begin(),pref.end(),r[v])) return false;
	}
	return true;
}

void stableCase(const vector<vi>& a, const vector<vi>& b) {
	int n = sz(a);
	vi got = stableMatching(a,b), perm(n);
	require(stable(a,b,got), "Gale-Shapley stability/perfect matching");
	iota(perm.begin(),perm.end(),0);
	int found = 0;
	do {
		++stableEnumerated;
		if (!stable(a,b,perm)) continue;
		++found;
		for (int u = 0; u < n; ++u)
			require(find(a[u].begin(),a[u].end(),got[u]) <=
			        find(a[u].begin(),a[u].end(),perm[u]), "proposer optimality");
	} while (next_permutation(perm.begin(),perm.end()));
	require(found > 0, "existence of an independently enumerated stable matching");
	++stableCases;
}

void testStable() {
	for (int n = 0; n <= 6; ++n) for (int trial = 0; trial < 40; ++trial) {
		vector<vi> a(n,vi(n)), b = a;
		for (auto& row : a) { iota(row.begin(),row.end(),0); shuffle(row.begin(),row.end(),rng); }
		for (auto& row : b) { iota(row.begin(),row.end(),0); shuffle(row.begin(),row.end(),rng); }
		stableCase(a,b);
	}
	int n = 40;
	vector<vi> a(n,vi(n)), b = a;
	for (auto& row : a) iota(row.begin(),row.end(),0);
	for (auto& row : b) { iota(row.begin(),row.end(),0); reverse(row.begin(),row.end()); }
	vi match = stableMatching(a,b);
	require(stable(a,b,match), "quadratic proposal case stable");
	for (int u = 0; u < n; ++u) require(match[u] == n-1-u, "quadratic proposal result");
	++stableCases;
}

void exhaustiveAndAdversarial() {
	// All capacities 0,1,2 on every arc (including loops) of a 3-vertex graph.
	for (int code = 0; code < 19683; ++code) {
		vector<Arc> es; int copy = code;
		for (int u = 0; u < 3; ++u) for (int v = 0; v < 3; ++v) {
			int cap = copy%3; copy /= 3; es.push_back({u,v,cap,0});
		}
		dinicCase<int>(3,es);
	}
	dinicCase<ll>(2,{{0,1,LLONG_MAX/2,0},{0,1,LLONG_MAX/2+1,0},
	                  {0,0,LLONG_MAX,0},{1,1,LLONG_MAX,0}});
	DinicFlow<unsigned long long> full(3);
	full.add(0,1,ULLONG_MAX); full.add(1,2,ULLONG_MAX);
	require(full.flow(0,2) == ULLONG_MAX, "unsigned full-width flow");
	require(full.flow(0,2) == 0, "unsigned residual saturation");
	// Dynamically adding capacity can require rerouting an earlier max flow.
	DinicFlow<int> reroute(6);
	for (auto [u,v] : vector<pair<int,int>>{{0,1},{1,3},{3,5}}) reroute.add(u,v,1);
	require(reroute.flow(0,5) == 1, "incremental flow setup");
	for (auto [u,v] : vector<pair<int,int>>{{0,2},{2,3},{1,4},{4,5}}) reroute.add(u,v,1);
	require(reroute.flow(0,5) == 1, "incremental flow reverses old middle edge");

	// Every absent/0/1 reduced-cost choice on the six non-loop arcs of K3.
	// Potential differences produce negative edges and zero-cost cycles.
	vi potential{7,-9,3};
	for (int code = 0; code < 729; ++code) {
		vector<Arc> es; int copy = code;
		for (int u = 0; u < 3; ++u) for (int v = 0; v < 3; ++v) if (u != v) {
			int digit = copy%3; copy /= 3;
			if (digit) es.push_back({u,v,1,potential[v]-potential[u]+digit-1});
		}
		costCase<int,ll>(3,es,code%3);
	}
	// A zero limit must preserve residuals; positive-cost loops never carry flow.
	costCase<ll,ll>(3,{{0,0,2,4},{0,1,2,-9},{1,2,2,10},{2,2,2,0}},0);
	MinCostFlow<int,int> wide(2);
	wide.add(0,1,INT_MAX,1);
	require(wide.flow(0,1) == pair<int,int>{INT_MAX,INT_MAX},
	        "flow and total cost may reach type maximum");

	// Every 4x4 bipartite graph, including deficient Hall sets and isolates.
	for (unsigned mask = 0; mask < (1U<<16); ++mask) {
		vector<pair<int,int>> es;
		for (int u = 0; u < 4; ++u) for (int v = 0; v < 4; ++v)
			if (mask >> (4*u+v) & 1U) es.push_back({u,v});
		matchingCase(4,4,es);
	}
	// A long alternating path is discovered only after the greedy first phase.
	const int n = 1000;
	BipartiteMatching chain(n,n);
	for (int u = 0; u+1 < n; ++u) { chain.add(u,u+1); chain.add(u,u); }
	chain.add(n-1,n-1);
	require(chain.solve() == n, "long alternating augmentation");
	auto cover = chain.cover();
	require(sz(cover.first)+sz(cover.second) == n, "long alternating cover");

	// Every complete strict preference profile on 3+3 participants.
	vector<vi> perms; vi p{0,1,2};
	do { perms.push_back(p); } while (next_permutation(p.begin(),p.end()));
	for (int code = 0; code < 46656; ++code) {
		vector<vi> a(3), b(3); int copy = code;
		for (auto& row : a) { row = perms[copy%6]; copy /= 6; }
		for (auto& row : b) { row = perms[copy%6]; copy /= 6; }
		stableCase(a,b);
	}
}

int main() {
	testDinic(); testCost(); testMatching(); testStable();
	exhaustiveAndAdversarial();
	cout << "FlowMatching: " << dinicCases << " Dinic, " << costCases
	     << " min-cost flow, " << matchingCases << " bipartite matching, "
	     << stableCases << " stable matching cases; " << stableEnumerated
	     << " complete matchings enumerated, " << checks << " checks passed.\n";
}
