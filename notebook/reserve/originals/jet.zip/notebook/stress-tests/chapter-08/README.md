# Stress tests — Geometry

Executar bash doc/scripts/test-chapter-08.sh na raiz do notebook.
GNU++17, Boost apenas para os oráculos. BOOST_INCLUDEDIR é opcional.
Em ambiente com ptrace, usar ASAN_OPTIONS=detect_leaks=0.

Release e ASan/UBSan/STL debug com -Werror; integra primeiro os headers
selecionados dos capítulos 2–8 com o template real de Contest.

- Primitives.cpp: cpp_int/Cramer racional e caixas para predicados e
  interseções; projeções por equações independentes. Grelha exaustiva,
  Point<ll> com diferenças/produtos/somas a caber ll, degenerações e
  escalas de erro geométrico. Point e lineInter são os corpos originais
  KACTL; interseções fracionárias usam Point<long double>.
- Polygons.cpp: hull por gift wrapping, localização por winding number,
  diâmetro por todos os pares, cortes por interseções racionais. Inclui
  polígonos degenerados, fronteiras, ordem invertida e cortes sucessivos.
- Circles.cpp: soluções analíticas e oráculo racional por todos os
  círculos candidatos para MEC. Casos quase degenerados, escalas,
  translações e regressão da instabilidade de roundoff do MEC.
- Adversarial.cpp: fronteiras válidas de ll (incluindo coordenadas perto
  de LLONG_MIN/LLONG_MAX), união com área LLONG_MAX, polígonos sob
  transformações inteiras, círculos e projeções com soluções analíticas,
  e receita da grelha/radius queries comparada com todos os pares.
  Inclui raio zero, duplicados e coordenadas negativas.
- Spatial.cpp: closest pair por pares enumerados; área de união por
  raster/células independentes. Retângulos vazios, contidos, repetidos,
  áreas/comprimentos a caber ll e casos estruturais grandes.

Sementes dos inputs fixas; shuffle interno do MEC aleatório. STL debug
valida cada lower_bound linearmente: apenas os casos estruturais grandes
de Spatial são reduzidos nessa configuração, mantendo os mesmos oráculos.
Apenas os includes do Point original suprimem -Wshadow/-Wconversion
no harness. As construções reais usam sqrtl(dist2()) para não reduzir
a precisão através do dist() original, que devolve double.

## Compatibilidade C++17

As suites afetadas pela compatibilidade passaram novamente em GNU++17,
release e ASan/UBSan/STL debug. Resultados atuais em
`validation/cpp17-geometry-*.log` e `validation/cpp17-strings-*.log`.
