# Stress tests — Number theory

Executar `bash doc/scripts/test-chapter-05.sh` na raiz do notebook.
Requer GNU++20 e headers Boost; BOOST_INCLUDEDIR é opcional.
No ambiente com ptrace: ASAN_OPTIONS=detect_leaks=0.

O runner valida release e ASan/UBSan com STL debug. Integra primeiro os
headers selecionados dos capítulos 2–5 com o template real de Contest.

- Modular: produtos/potências contra cpp_int, tipos int/ll/uint32/uint64,
  bases negativas, extremos, módulo 1 e expoente 0/ULLONG_MAX.
- EuclidCRT: Bézout com inteiros exatos; inversos e CRT por força bruta,
  compatibilidade, sinais, módulos 1 e limites de overflow.
- SieveDivisors: menor primo por brute, fatorização por trial division,
  listas completas por enumeração, limites exclusivos e fatores repetidos.
- PrimeFactor: primalidade e fatorização com referências independentes,
  pseudoprimos, certificados de primos grandes, potências e semiprimos.

As sementes dos testes são fixas; Pollard usa reinícios pseudoaleatórios.
Consultar os próprios casos para os oráculos e contratos cobertos.

## Revisão 11

- Adversarial.cpp: todas as 24 ordens de merges CRT construídos com
  divisores de um múltiplo comum representável, identidades de famílias
  diofantinas exatas, inversos com valores negativos, família Carmichael
  de Chernick com fatores certificados por divisão,32 quadrados de primos
  próximos de 2^32, crivos perto dos quadrados e divisores de 2^63.
- Resultados: validation/revision-11/ch05.log.
