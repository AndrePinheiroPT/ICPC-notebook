#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/number-theory/ExtGCD.h"
#include "../../content/number-theory/ModInv.h"
#include "../../content/number-theory/GeneralCRT.h"
using boost::multiprecision::cpp_int;

mt19937_64 rng(0x5C0E2026);
uint64_t bezout = 0, inverses = 0, merges = 0;
uint64_t incompatible = 0, overflows = 0, bruteCandidates = 0;

cpp_int gcdBig(cpp_int a, cpp_int b) {
	if (a < 0) a = -a;
	if (b < 0) b = -b;
	while (b != 0) {
		cpp_int r = a%b; a = b; b = r;
	}
	return a;
}

cpp_int norm(cpp_int a, const cpp_int& m) {
	a %= m;
	return a < 0 ? cpp_int(a+m) : a;
}

ll signedSample() {
	ll v = ll(rng() & uint64_t(LLONG_MAX));
	return rng()&1 ? v : -v;
}

template<class T> void checkGcd(T a, T b) {
	T x = 0, y = 0, g = extGcd(a,b,x,y);
	assert(g >= 0 && g == std::gcd(a,b));
	assert(cpp_int(a)*x + cpp_int(b)*y == g);
	assert(cpp_int(g) == gcdBig(cpp_int(a),cpp_int(b)));
	++bezout;
}

template<class T> void testGcd() {
	for (int a = -64; a <= 64; ++a)
		for (int b = -64; b <= 64; ++b) checkGcd(T(a),T(b));
	T hi = numeric_limits<T>::max();
	vector<T> edge{0,1,-1,2,-2,hi,T(hi-1),T(-hi),T(-hi+1)};
	for (int bit = 1; bit < numeric_limits<T>::digits; ++bit) {
		T p = T(T(1) << bit);
		for (T v : {T(p-1),p,T(p+1)}) {
			edge.push_back(v); edge.push_back(T(-v));
		}
	}
	for (T a : edge) for (T b : edge) checkGcd(a,b);
	for (int i = 0; i < 30000; ++i) {
		T a = T(rng() & uint64_t(hi)), b = T(rng() & uint64_t(hi));
		if (rng()&1) a = -a;
		if (rng()&1) b = -b;
		checkGcd(a,b);
	}
	// Consecutive Fibonacci numbers force long Euclidean recursion.
	T a = 0, b = 1;
	while (a <= hi-b) {
		for (T x : {a,T(-a)}) for (T y : {b,T(-b)}) checkGcd(x,y);
		T c = a+b; a = b; b = c;
	}
}

void checkInv(ll a, ll m, bool brute = false) {
	auto x = modInv(a,m);
	cpp_int M = m, A = norm(cpp_int(a),M);
	bool exists = gcdBig(A,M) == 1;
	assert(bool(x) == exists);
	if (x) {
		assert(0 <= *x && *x < m);
		assert(norm(cpp_int(a)*(*x),M) == 1);
	}
	if (brute) {
		optional<ll> want;
		for (ll k = 0; k < m; ++k) {
			++bruteCandidates;
			if (ll(A)*k % m == 1) { want = k; break; }
		}
		assert(x == want);
	}
	++inverses;
}

void testInverse() {
	for (ll m = 2; m <= 80; ++m)
		for (ll a = -160; a <= 160; ++a) checkInv(a,m,true);
	vector<ll> edge{LLONG_MIN,LLONG_MIN+1,-2,-1,0,1,2,LLONG_MAX-1,LLONG_MAX};
	for (ll m : {2LL,3LL,4LL,5LL,2147483647LL,1000000007LL,LLONG_MAX-1,LLONG_MAX})
		for (ll a : edge) checkInv(a,m);
	for (int i = 0; i < 30000; ++i)
		checkInv(signedSample(),ll(rng()%uint64_t(LLONG_MAX-1))+2);
}

void checkCRT(ll a, ll m, ll b, ll n, bool brute = false) {
	auto got = crtMerge(a,m,b,n);
	cpp_int M = m, N = n, A = norm(cpp_int(a),M), B = norm(cpp_int(b),N);
	cpp_int g = gcdBig(M,N), lcm = M/g*N;
	// Incompatibility has priority, even if the lcm also overflows.
	if ((A-B)%g != 0) {
		assert((got == pair<ll,ll>{-1,0})); ++incompatible;
	} else if (lcm > LLONG_MAX) {
		assert((got == pair<ll,ll>{0,-1})); ++overflows;
	} else {
		assert(cpp_int(got.second) == lcm);
		assert(0 <= got.first && got.first < got.second);
		assert(cpp_int(got.first)%M == A);
		assert(cpp_int(got.first)%N == B);
	}
	if (brute) {
		ll L = ll(lcm), aa = ll(A), bb = ll(B);
		pair<ll,ll> want{-1,0};
		for (ll r = 0; r < L; ++r) {
			++bruteCandidates;
			if (r%m == aa && r%n == bb) { want = {r,L}; break; }
		}
		assert(got == want);
	}
	++merges;
}

void testCRT() {
	for (ll m = 1; m <= 12; ++m) for (ll n = 1; n <= 12; ++n)
		for (ll a = -m; a <= m; ++a) for (ll b = -n; b <= n; ++b)
			checkCRT(a,m,b,n,true);
	vector<ll> residues{LLONG_MIN,LLONG_MIN+1,-2,-1,0,1,2,LLONG_MAX-1,LLONG_MAX};
	vector<ll> moduli{1,2,3,4,6,49,2147483647,3037000499,3037000500,
	                  3037000501,LLONG_MAX/49,LLONG_MAX-3,LLONG_MAX-1,LLONG_MAX};
	for (ll m : moduli) for (ll n : moduli)
		for (ll a : residues) for (ll b : residues) checkCRT(a,m,b,n);
	for (int i = 0; i < 30000; ++i) {
		ll m = ll(rng()%uint64_t(LLONG_MAX))+1;
		ll n = ll(rng()%uint64_t(LLONG_MAX))+1;
		checkCRT(signedSample(),m,signedSample(),n);
		// Shared factors, divisibility, and representable or overflowing LCMs.
		ll d = ll(rng()%1000000000)+1;
		m = d*(ll(rng()%1000000000)+1);
		n = d*(ll(rng()%1000000000)+1);
		checkCRT(signedSample(),m,signedSample(),n);
		ll a = signedSample();
		checkCRT(a,m,a,n); // compatible even when its modulus is too large.
	}
	assert((crtMerge(0,LLONG_MAX-1,1,LLONG_MAX-3) == pair<ll,ll>{-1,0}));
	assert((crtMerge(0,LLONG_MAX-1,0,LLONG_MAX-3) == pair<ll,ll>{0,-1}));
	// Repeated merging, including the empty system's neutral pair (0,1).
	for (int i = 0; i < 2000; ++i) {
		ll hidden = signedSample();
		pair<ll,ll> cur{0,1};
		ll L = 1;
		for (int j = int(rng()%13); j--; ) {
			ll m = ll(rng()%12)+1;
			cur = crtMerge(cur.first,cur.second,hidden,m);
			L = std::lcm(L,m);
			assert(cur.second == L);
			assert(cpp_int(cur.first) == norm(cpp_int(hidden),cpp_int(L)));
			++merges;
		}
	}
}

int main() {
	testGcd<int>(); testGcd<ll>(); testInverse(); testCRT();
	cout << "EuclidCRT: " << bezout << " Bezout identities, " << inverses
	     << " inverses, " << merges << " CRT merges (" << incompatible
	     << " incompatible, " << overflows << " overflow), " << bruteCandidates
	     << " brute-force candidates\n";
}
