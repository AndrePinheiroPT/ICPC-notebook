#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/number-theory/SPF.h"
#include "../../content/number-theory/TrialDivision.h"
#include "../../content/number-theory/Divisors.h"

mt19937_64 rng(0x5350465f32303236ULL);
unsigned long long checks = 0, factorizations = 0, lists = 0;
void check(bool ok, const char* what) {
	++checks;
	if (!ok) {
		cerr << "FAILED " << what << " at check " << checks << '\n';
		exit(1);
	}
}
bool prime(ull n) {
	if (n < 2) return false;
	for (ull d = 2; d <= n/d; ++d)
		if (n%d == 0) return false;
	return true;
}
template<class T> void factorCheck(T n, const vector<T>& f) {
	++factorizations;
	check(is_sorted(f.begin(),f.end()), "factor ordering");
	__uint128_t product = 1;
	for (T p : f) {
		check(prime(ull(p)), "factor is prime");
		product *= __uint128_t(p);
	}
	check(product == __uint128_t(n), "factor product");
}
template<class T> void listCheck(T n, const vector<T>& f,
		const vector<T>* want = nullptr) {
	++lists;
	vector<T> d = divisors(f);
	sort(d.begin(),d.end());
	check(!d.empty() && d.front() == 1 && d.back() == n,
		"divisor endpoints");
	check(adjacent_find(d.begin(),d.end()) == d.end(),
		"divisors unique");
	for (T x : d) check(x > 0 && n%x == 0, "divisor validity");
	ull count = 1;
	for (int i = 0; i < sz(f);) {
		int j = i;
		while (j < sz(f) && f[j] == f[i]) ++j;
		count *= ull(j-i+1); i = j;
	}
	check(d.size() == count, "complete divisor count");
	if (want) check(d == *want, "divisors vs exhaustive oracle");
}

void limits() {
	for (int lim : {0,1,2,3,4,7,8,9,31,32,33,100,1000,10001}) {
		SPF s(lim);
		check(sz(s.p) == lim, "SPF exact exclusive limit");
		if (lim > 0) check(s.p[0] == 0, "SPF zero sentinel");
		if (lim > 1) check(s.p[1] == 1, "SPF one sentinel");
		for (int x = 2; x < lim; ++x) {
			int least = 2;
			while (x%least) ++least;
			check(s.p[x] == least, "SPF smallest factor brute");
		}
	}
}
void exhaustive() {
	SPF s(10001);
	for (int n = 1; n <= 10000; ++n) {
		vi f = s.factor(n);
		factorCheck(n,f);
		auto a = trialDivision(n);
		check(f == a, "SPF vs trial int");
		factorCheck(n,a);
		vector<ll> b = trialDivision(ll(n));
		vector<ull> c = trialDivision(ull(n));
		check(vector<ll>(f.begin(),f.end()) == b, "SPF vs trial ll");
		check(vector<ull>(f.begin(),f.end()) == c, "SPF vs trial ull");
		vector<int> want;
		for (int d = 1; d <= n; ++d) if (n%d == 0) want.push_back(d);
		listCheck(n,f,&want);
		vector<ll> wantLL(want.begin(),want.end());
		vector<ull> wantULL(want.begin(),want.end());
		listCheck(ll(n),b,&wantLL);
		listCheck(ull(n),c,&wantULL);
	}
}
void randomSmall() {
	SPF s(200001);
	for (int run = 0; run < 1000; ++run) {
		int n = int(rng()%200000)+1;
		auto f = s.factor(n);
		check(f == trialDivision(n), "random SPF vs trial");
		factorCheck(n,f);
		vi want;
		for (int d = 1; d <= n/d; ++d) if (n%d == 0) {
			want.push_back(d);
			if (d != n/d) want.push_back(n/d);
		}
		sort(want.begin(),want.end());
		listCheck(n,f,&want);
	}
}
template<class T> void known(T n, vector<T> want) {
	auto f = trialDivision(n);
	check(f == want, "known factorization");
	factorCheck(n,f);
	listCheck(n,f);
}
void extremes() {
	known<int>(1,{});
	known<ll>(1,{});
	known<ull>(1,{});
	known<int>(INT_MAX,{2147483647});
	known<ll>(LLONG_MAX,{7,7,73,127,337,92737,649657});
	known<ull>(ULLONG_MAX,{3,5,17,257,641,65537,6700417});
	known<ull>(ULLONG_MAX-1,{2,7,7,73,127,337,92737,649657});
	known<ull>(ull(1)<<63,vector<ull>(63,2));
	known<ll>(ll(1)<<62,vector<ll>(62,2));
	known<int>(1<<30,vector<int>(30,2));
	known<ll>(4294967291LL,{4294967291LL});
	// Divisor generation must not form one extra power.
	listCheck<ull>(ull(1)<<63,vector<ull>(63,2));
	// Product of grouped primes uses the largest representable value.
	listCheck<ull>(ULLONG_MAX,{3,5,17,257,641,65537,6700417});
	for (int k = 2; k <= 46340; k += 157) {
		ll square = ll(k)*k;
		auto f = trialDivision(square);
		factorCheck(square,f);
		listCheck(square,f);
	}
}
int main() {
	limits(); exhaustive(); randomSmall(); extremes();
	cout << "SieveDivisors: " << factorizations << " factorizations, "
		<< lists << " divisor lists, " << checks << " brute/property checks passed\n";
}
