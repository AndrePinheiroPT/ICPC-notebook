#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/number-theory/ModInv.h"
#include "../../content/number-theory/GeneralCRT.h"
#include "../../content/number-theory/SPF.h"
#include "../../content/number-theory/TrialDivision.h"
#include "../../content/number-theory/Factor64.h"
#include "../../content/number-theory/Divisors.h"
using boost::multiprecision::cpp_int;
static mt19937_64 rng(0x5a110026ULL);
static size_t checks = 0, carmichaels = 0;
void check(bool b) { ++checks; assert(b); }
bool trialPrime(ull x) {
    if (x < 2) return false;
    for (ull d = 2; d <= x/d; ++d) if (x%d == 0) return false;
    return true;
}
cpp_int norm(cpp_int x, cpp_int m) { x %= m; return x < 0 ? cpp_int(x+m) : x; }
void mergeOrder() {
    // Construct four divisors of a known representable common multiple.
    // Every intermediate LCM fits, including CRT with shared factors.
    vector<ll> primes{2,3,5,7,11,13,17,19,23,29,31,37,41};
    for (int t = 0; t < 600; ++t) {
        ll base = 1; vector<ll> factors;
        for (int j = 0; j < 30; ++j) {
            ll p = primes[size_t(rng()%primes.size())];
            if (base > LLONG_MAX/p) break;
            base *= p; factors.push_back(p);
        }
        array<ll,4> m{1,1,1,1};
        for (ll p : factors) for (ll& x : m) if (rng()%2) x *= p;
        uint64_t bits = rng(); ll hidden;
        static_assert(sizeof hidden == sizeof bits);
        memcpy(&hidden,&bits,sizeof hidden);
        array<int,4> order{0,1,2,3};
        do {
            pair<ll,ll> got{0,1}; cpp_int wantMod = 1;
            for (int j : order) {
                got = crtMerge(got.first,got.second,hidden,m[j]);
                wantMod = wantMod/gcd(wantMod.convert_to<ll>(),m[j])*m[j];
                check(got.second == wantMod && cpp_int(got.first) == norm(hidden,wantMod));
            }
        } while (next_permutation(order.begin(),order.end()));
        ll a = ll(rng() & uint64_t(LLONG_MAX)), x, y;
        ll g = extGcd(a,base,x,y);
        check(cpp_int(a)*x+cpp_int(base)*y == g);
        for (ll s : {-1000000000LL,-1LL,0LL,1LL,1000000000LL}) {
            cpp_int X = cpp_int(x)+cpp_int(base/g)*s;
            cpp_int Y = cpp_int(y)-cpp_int(a/g)*s;
            check(cpp_int(a)*X+cpp_int(base)*Y == g);
        }
        if (base > 1) {
            auto inv = modInv(hidden,base);
            ll residue = norm(hidden,base).convert_to<ll>();
            check(bool(inv) == (gcd(residue,base) == 1));
            if (inv) check(norm(cpp_int(hidden)*(*inv),base) == 1);
        }
    }
}
void pseudoprimes() {
    // Chernick's family: three trial-certified prime factors. Each member
    // is composite and fools a plain coprime-base Fermat test.
    for (ull k = 1; k <= 8000; ++k) {
        ull a = 6*k+1, b = 12*k+1, c = 18*k+1;
        if (!trialPrime(a) || !trialPrime(b) || !trialPrime(c)) continue;
        ull n = a*b*c;
        check(!isPrime64(n));
        check(factor64(n) == vector<ull>({a,b,c}));
        cpp_int two = boost::multiprecision::powm(cpp_int(2),cpp_int(n-1),cpp_int(n));
        check(two == 1); ++carmichaels;
    }
    // Different odd prime squares close to UINT64_MAX, exact trial oracle.
    int count = 0;
    for (ull p = 4294967291ULL; count < 32; p -= 2) if (trialPrime(p)) {
        ull n = p*p;
        check(!isPrime64(n)); check(factor64(n) == vector<ull>({p,p}));
        ++count;
    }
}
void sieveBoundaries() {
    for (int p = 2; p <= 127; ++p) if (trialPrime(ull(p))) {
        for (int d : {-1,0,1,2}) {
            int lim = p*p+d; SPF s(lim);
            for (int x = max(2,lim-8); x < lim; ++x) {
                auto f = s.factor(x); auto tf = trialDivision(x);
                check(f == tf);
                auto ds = divisors(f); sort(ds.begin(),ds.end());
                vi want;
                for (int z = 1; z <= x; ++z) if (x%z == 0) want.push_back(z);
                check(ds == want);
            }
        }
    }
    // Every divisor of a high prime power must be a distinct single bit;
    // no unnecessary overflow computing 2^64 is allowed.
    auto ds = divisors(vector<ull>(63,2)); sort(ds.begin(),ds.end());
    check(ds.size() == 64);
    for (int i = 0; i < 64; ++i) check(ds[i] == (1ULL<<i));
}
int main() {
    mergeOrder(); pseudoprimes(); sieveBoundaries();
    cout << "Adversarial Number Theory: " << checks << " exact checks, "
         << carmichaels << " Chernick Carmichael numbers passed\n";
}
