/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item First multiple of k or term $t_0+jk$, $j\ge0$,
 *   at least x; $O(1)$.
 *   \item Integer T; $k>0$; result must fit T.
 *   \end{itemize}
 * Usage: nextMultiple(17LL,5LL); // 20
 *   nextTerm(17LL,3LL,5LL); // 18 = 3+3*5
 * Status: Stress-tested against arbitrary-precision arithmetic.
 */
#pragma once

template<class T> T nextMultiple(T x, T k) {
	T r = x % k;
	return r > 0 ? x + (k - r) : x - r;
}

template<class T> T nextTerm(T x, T t0, T k) {
	if (x <= t0) return t0;
	T a = x % k, b = t0 % k;
	if (a < 0) a += k;
	if (b < 0) b += k;
	return x + (a <= b ? b - a : k - (a - b));
}
