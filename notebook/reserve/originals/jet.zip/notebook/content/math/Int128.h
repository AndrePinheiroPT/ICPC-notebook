/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item toString(x) returns signed 128-bit decimal text;
 *   read128(in,x) reads one token into x. $O(d)$ for d digits.
 *   \item Invalid/overflow/EOF: read128 returns false,
 *   leaving x unchanged.
 *   \end{itemize}
 * Usage: i128 x;
 *   if (read128(cin,x)) cout << toString(x);
 * Status: Stress-tested against cpp_int, including invalid input.
 */
#pragma once

using i128 = __int128_t;
using u128 = __uint128_t;

string toString(i128 x) {
	u128 v = x < 0 ? -u128(x) : u128(x);
	string s;
	do {
		s += char('0' + v % 10);
		v /= 10;
	} while (v);
	if (x < 0) s += '-';
	reverse(s.begin(), s.end());
	return s;
}

bool read128(istream& in, i128& x) {
	string s;
	if (!(in >> s)) return false;
	bool neg = s[0] == '-';
	int i = neg || s[0] == '+';
	if (i == sz(s)) return false;
	u128 v = 0, lim = (u128(1) << 127) - !neg;
	for (; i < sz(s); ++i) {
		int d = s[i] - '0';
		if (d < 0 || d > 9) return false;
		if (v > (lim - d) / 10) return false;
		v = v * 10 + d;
	}
	x = neg && v ? -i128(v - 1) - 1 : i128(v);
	return true;
}
