/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Integer floor/ceil of $a/b$, either sign; $O(1)$.
 *   \item $b\ne0$; quotient must fit T (exclude MIN/$-1$).
 *   \end{itemize}
 * Status: Stress-tested against arbitrary-precision inequalities.
 */
#pragma once

template<class T> T floorDiv(T a, T b) {
	T q = a / b, r = a % b;
	return q - (r != 0 && ((r < 0) != (b < 0)));
}

template<class T> T ceilDiv(T a, T b) {
	T q = a / b, r = a % b;
	return q + (r != 0 && ((r < 0) == (b < 0)));
}
