/**
 * Author: Noam527; jet notebook (safe arithmetic)
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Product/power modulo $m>0$; integer T up to
 *   64 bits. modmul requires $0\le a,b<m$.
 *   modpow accepts a negative signed base, $e\ge0$;
 *   returns a residue in $[0,m)$. Base/modulus: same T.
 *   \item $O(1)$ / $O(\log(e+1))$ time, $O(1)$ space.
 *   Products use unsigned 128-bit arithmetic.
 *   \end{itemize}
 * Usage: ll x = modpow(-2LL,3,5LL); // 2
 *   ull y = modmul(ULLONG_MAX-1,ULLONG_MAX-1,ULLONG_MAX); // 1
 */
#pragma once

using ull = unsigned long long;

template<class T> T modmul(T a, T b, T m) {
	return T(__uint128_t(a)*b % m);
}
template<class T> T modpow(T b, ull e, T m) {
	T ans = 1 % m;
	b %= m;
	if constexpr (is_signed_v<T>)
		if (b < 0) b += m;
	for (; e; b = modmul(b,b,m), e /= 2)
		if (e & 1) ans = modmul(ans,b,m);
	return ans;
}
