/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item factor64(n): sorted prime factors with
 *  multiplicity, $n\ge1$; factor64(1) is empty.
 *  \item rho64 requires composite n. Brent's
 *  Pollard rho, batched gcds and random restarts.
 *  \item Expected $O(n^{1/4})$ per split;
 *  $O(\log n)$ space for the factorization.
 *  \end{itemize}
 * Usage: auto f = factor64(360);
 *   // {2,2,2,3,3,5}; use factor64, not rho64
 */
#pragma once
#include "Prime64.h"

ull rho64(ull n) {
	if (n % 2 == 0) return 2;
	if (n % 3 == 0) return 3;
	static mt19937_64 rng(
		chrono::steady_clock::now()
		.time_since_epoch().count());
	for (;;) {
		ull y = rng()%(n-1)+1, c = rng()%(n-1)+1;
		ull r = 1, g = 1, x = 0, ys = 0;
		auto f = [&](ull v) {
			ull z = modmul(v, v, n);
			return z < n-c ? z+c : z-(n-c);
		};
		while (g == 1) {
			x = y;
			for (ull i = 0; i < r; ++i) y = f(y);
			for (ull k = 0; k < r && g == 1;
					k += 128) {
				ys = y;
				ull q = 1;
				for (ull i = 0; i < min(128ULL,r-k);
						++i) {
					y = f(y);
					ull d = x > y ? x-y : y-x;
					q = modmul(q, d, n);
				}
				g = gcd(q, n);
			}
			r *= 2;
		}
		if (g == n) do {
			ys = f(ys);
			g = gcd(x > ys ? x-ys : ys-x, n);
		} while (g == 1);
		if (g < n) return g;
	}
}

vector<ull> factor64(ull n) {
	assert(n >= 1);
	if (n == 1) return {};
	if (isPrime64(n)) return {n};
	ull p = rho64(n);
	auto a = factor64(p), b = factor64(n/p);
	a.insert(a.end(), b.begin(), b.end());
	sort(a.begin(), a.end());
	return a;
}
