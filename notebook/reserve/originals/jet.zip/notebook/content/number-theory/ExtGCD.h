/**
 * Author: jet notebook, based on KACTL
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Inputs a,b; writes x,y and returns $g\ge0$,
 *   with $ax+by=g$;
 *   $g=\gcd(a,b)$, including $g=0$ for $(0,0)$.
 *   \item Signed int/ll; neither input may be
 *   the minimum value of its type.
 *   \item $O(\log(\max(|a|,|b|)+1))$ time
 *   and recursion space.
 *   \end{itemize}
 * Usage: ll x,y,g = extGcd(30LL,18LL,x,y);
 *   // g=6; 30*x+18*y=6
 */
#pragma once

template<class T>
T extGcd(T a, T b, T& x, T& y) {
	if (!b) {
		x = a < 0 ? -1 : 1; y = 0;
		return a < 0 ? -a : a;
	}
	T g = extGcd(b,T(a%b),y,x);
	y -= (a/b)*x;
	return g;
}
