/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Smallest prime factors p on $[0,lim)$;
 *   $p[0]=0$, $p[1]=1$ when present.
 *   \item factor(x): sorted prime factors with
 *   multiplicity; $1\le x<lim$, $lim\ge0$.
 *   \item Build $O(lim\log\log lim)$, space $O(lim)$;
 *   factorization $O(\log x)$.
 *   \end{itemize}
 * Usage: SPF s(101); auto f = s.factor(60);
 *   // f = {2,2,3,5}; s.p[91] = 7
 */
#pragma once

struct SPF {
	vi p;
	SPF(int lim) : p(lim) {
		iota(p.begin(), p.end(), 0);
		for (int i = 2; i <= (lim-1)/i; ++i)
			if (p[i] == i)
				for (ll j = ll(i)*i; j < lim; j += i)
					if (p[j] == j) p[j] = i;
	}
	vi factor(int x) const {
		assert(1 <= x && x < sz(p));
		vi f;
		for (; x > 1; x /= p[x]) f.push_back(p[x]);
		return f;
	}
};
