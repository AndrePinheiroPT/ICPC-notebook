/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Merges $x\equiv a\pmod m$ and
 *   $x\equiv b\pmod n$; positive m,n, any a,b.
 *   Returns $(r,M)$, $M=\mathrm{lcm}(m,n)$,
 *   $0\le r<M$; moduli need not be coprime.
 *   \item Returns $(-1,0)$ if incompatible;
 *   otherwise $(0,-1)$ if M does not fit ll.
 *   \item $O(\log(\max(m,n)))$ time/space.
 *   \end{itemize}
 * Usage: auto [r,m] = crtMerge(2,6,5,9);
 *   // x = 14 (mod 18); inspect m for failure
 */
#pragma once
#include "ExtGCD.h"

pair<ll,ll> crtMerge(ll a, ll m, ll b, ll n) {
	assert(m > 0 && n > 0);
	a %= m; if (a < 0) a += m;
	b %= n; if (b < 0) b += n;
	ll x, y, g = extGcd(m,n,x,y), d = b-a;
	if (d%g) return {-1,0};
	if (m/g > LLONG_MAX/n) return {0,-1};
	ll M = (m/g)*n;
	ll k = ll((__int128)(d/g)*x % (n/g));
	ll r = ll(((__int128)m*k+a)%M);
	return {r < 0 ? r+M : r,M};
}
