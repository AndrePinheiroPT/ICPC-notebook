/**
 * Author: Noam527
 * Description: Compatibility include; active ModPow.h is in Numerical.
 */
#pragma once

#include "../numerical/ModPow.h"
