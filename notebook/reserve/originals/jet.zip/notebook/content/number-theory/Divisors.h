/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Enumerates all positive divisors, unsorted;
 *   empty factorization (n=1) gives $\{1\}$.
 *   \item f: sorted prime factors with multiplicity;
 *   their product n must fit integer T.
 *   \item $O(\tau(n))$ time and output space.
 *   \end{itemize}
 * Usage: auto d = divisors(vector<ll>{2,2,3});
 *   // divisors of 12, unsorted
 */
#pragma once

template<class T>
vector<T> divisors(const vector<T>& f) {
	vector<T> d{1};
	for (int i = 0; i < sz(f);) {
		int k = sz(d), j = i;
		T power = 1;
		while (j < sz(f) && f[j] == f[i]) {
			power *= f[i];
			for (int q = 0; q < k; ++q)
				d.push_back(d[q]*power);
			++j;
		}
		i = j;
	}
	return d;
}
