/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Inverse of a modulo $m>1$, in $[0,m)$;
 *   nullopt if $\gcd(a,m)\ne1$. Any signed a.
 *   \item $O(\log m)$ time and recursion space.
 *   \end{itemize}
 */
#pragma once
#include "ExtGCD.h"

optional<ll> modInv(ll a, ll m) {
	assert(m > 1);
	a %= m;
	if (a < 0) a += m;
	ll x, y;
	if (extGcd(a,m,x,y) != 1) return nullopt;
	x %= m;
	return x < 0 ? x+m : x;
}
