/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Deterministic primality for all unsigned
 *  64-bit n; isPrime64(n) returns true iff prime.
 *  Uses seven Miller--Rabin bases.
 *  \item $O(\log n)$ modular products, $O(1)$ space.
 *  \end{itemize}
 * Usage: bool prime = isPrime64(1000000007ULL);
 */
#pragma once
#include "../numerical/ModPow.h"

bool isPrime64(ull n) {
	if (n < 2 || n % 2 == 0) return n == 2;
	int s = __builtin_ctzll(n-1);
	ull d = (n-1) >> s;
	for (ull a : {2ULL, 325ULL, 9375ULL, 28178ULL,
		450775ULL, 9780504ULL, 1795265022ULL}) {
		if (a % n == 0) continue;
		ull x = modpow(a%n, d, n);
		if (x == 1 || x == n-1) continue;
		int j = 1;
		for (; j < s; ++j) {
			x = modmul(x, x, n);
			if (x == n-1) break;
		}
		if (j == s) return false;
	}
	return true;
}
