/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Sorted prime factors with multiplicity;
 *   n=1 gives an empty vector.
 *   \item Integer T (int, ll, ull); $n\ge1$.
 *   \item $O(\sqrt n)$ time, $O(\log n)$ output.
 *   \end{itemize}
 */
#pragma once

template<class T> vector<T> trialDivision(T n) {
	assert(n >= 1);
	vector<T> f;
	for (T p = 2; p <= n/p; ++p)
		while (n % p == 0) f.push_back(p), n /= p;
	if (n > 1) f.push_back(n);
	return f;
}
