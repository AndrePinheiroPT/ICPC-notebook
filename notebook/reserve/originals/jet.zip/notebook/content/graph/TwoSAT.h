/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item n boolean variables; either(a,b) adds
 *   literal a OR b. solve returns satisfiability.
 *   answer[v] is 0/1, valid only on success.
 *   \item Literals: $2v$ means v, $2v+1$ means not v;
 *   negate with xor 1. either(a,a) forces literal a.
 *   \item $O(n+m)$ solve time/space for n variables
 *   and m clauses; each clause takes $O(1)$ amortized.
 *   \end{itemize}
 * Usage: TwoSAT sat(n); sat.either(2*a,2*b+1);
 *   bool ok = sat.solve(); // sat.answer if ok
 */
#pragma once
#include "StrongComponents.h"

struct TwoSAT {
	vector<vi> g;
	vi answer;
	TwoSAT(int n) : g(2*n) {}
	void either(int a, int b) {
		g[a^1].push_back(b);
		g[b^1].push_back(a);
	}
	bool solve() {
		SCC s(g);
		answer.resize(sz(g)/2);
		for (int v = 0; v < sz(answer); ++v) {
			int a = s.comp[2*v], b = s.comp[2*v+1];
			if (a == b) return false;
			answer[v] = a > b;
		}
		return true;
	}
};
