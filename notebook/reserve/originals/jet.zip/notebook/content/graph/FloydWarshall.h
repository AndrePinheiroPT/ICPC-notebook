/**
 * Author: Simon Lindholm
 * Date: 2016-12-15
 * License: CC0
 * Source: http://en.wikipedia.org/wiki/Floyd–Warshall_algorithm
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item FW::floydWarshall computes all pairs in
 *   place. Square ll matrix, minimum parallel-edge
 *   weights; FW::inf for absent edges.
 *   \item Sets diagonal to at most 0. inf is
 *   unreachable; -inf means unbounded below.
 *   $V\max|w|<inf$, where $inf=2^{62}$.
 *   \item $O(V^3)$ time, $O(1)$ extra space.
 *   \end{itemize}
 * Status: slightly tested
 */
#pragma once

namespace FW {
const ll inf = 1LL << 62;
void floydWarshall(vector<vector<ll>>& m) {
	int n = sz(m);
	for (int i = 0; i < n; i++)
		m[i][i] = min(m[i][i], 0LL);
	for (int k = 0; k < n; k++)
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if (m[i][k] != inf &&
						m[k][j] != inf) {
					auto newDist = max(
						m[i][k] + m[k][j], -inf);
					m[i][j] = min(m[i][j], newDist);
				}
	for (int k = 0; k < n; k++) if (m[k][k] < 0)
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if (m[i][k] != inf &&
						m[k][j] != inf)
					m[i][j] = -inf;
}
} // namespace FW
