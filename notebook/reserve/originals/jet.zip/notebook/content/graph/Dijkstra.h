/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Distances from source s; edges (to,weight),
 *   nonnegative integer weights. inf is unreachable.
 *   \item Valid source, $inf>0$; finite shortest
 *   distances $<inf$. Stale heap entries are skipped.
 *   \item $O((V+E)\log(V+E+1))$ time,
 *   $O(V+E)$ extra space.
 *   \end{itemize}
 */
#pragma once

vector<ll> dijkstra(const vector<vector<pair<int,int>>>& adj, int s) {
	int n = sz(adj);
	vector<ll> dist(n,INFLL);
	using P = pair<ll,int>;
	priority_queue<P,vector<P>,greater<P>> pq;
	dist[s] = 0;
	pq.push({0,s});

	while (!pq.empty()) {
		auto [d,u] = pq.top(); pq.pop();
		if (d != dist[u]) continue;

		for (auto [v,w] : adj[u]) {
			ll nd = d+w;
			if (nd < dist[v]) {
				dist[v] = nd;
				pq.push({nd,v});
			}
		}
	}
	return dist;
}
