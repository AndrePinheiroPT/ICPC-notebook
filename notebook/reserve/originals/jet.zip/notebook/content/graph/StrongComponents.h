/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item SCC(g): labels comp and deduplicated DAG dag.
 *   Component IDs increase along DAG edges.
 *   \item Directed adjacency lists, vertices $[0,n)$.
 *   Empty graph, loops and parallel edges are valid.
 *   \item Kosaraju: two recursive DFS passes.
 *   $O(n+m)$ time/space; call stack depth $O(n)$.
 *   \end{itemize}
 */
#pragma once

struct SCC {
	vi comp;
	vector<vi> dag;
	void dfs1(const vector<vi>& g, vi& seen,
			vi& order, int v) {
		seen[v] = 1;
		for (int u : g[v]) if (!seen[u])
			dfs1(g,seen,order,u);
		order.push_back(v);
	}
	void dfs2(const vector<vi>& rev, vi& group,
			int v, int c) {
		comp[v] = c; group.push_back(v);
		for (int u : rev[v]) if (comp[u] < 0)
			dfs2(rev,group,u,c);
	}
	SCC(const vector<vi>& g) : comp(sz(g),-1) {
		int n = sz(g);
		vector<vi> rev(n), groups;
		for (int v = 0; v < n; ++v)
			for (int u : g[v]) rev[u].push_back(v);
		vi seen(n), order;
		for (int v = 0; v < n; ++v) if (!seen[v])
			dfs1(g,seen,order,v);
		for (int i = n; i--;) {
			int s = order[i];
			if (comp[s] >= 0) continue;
			int c = sz(groups);
			groups.emplace_back();
			dfs2(rev,groups.back(),s,c);
		}
		dag.resize(sz(groups));
		vi mark(sz(groups),-1);
		for (int c = 0; c < sz(groups); ++c)
			for (int v : groups[c])
				for (int u : g[v]) {
					int d = comp[u];
					if (d != c && mark[d] != c) {
						mark[d] = c; dag[c].push_back(d);
					}
				}
	}
};
