/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item TreeLCA(g,root): undirected rooted tree.
 *   lca(a,b), ancestor(v,k) (-1 if absent),
 *   dist(a,b) in edges. Query vertices are valid.
 *   \item Binary lifting via JumpTable;
 *   inherits TreeTour fields. Empty input allowed.
 *   \item Build/space $O(n\log n)$;
 *   each query $O(\log n)$.
 *   \end{itemize}
 */
#pragma once
#include "TreeTour.h"
#include "JumpTable.h"

struct TreeLCA : TreeTour {
	JumpTable jt;
	static int levels(int n) {
		int d = 1;
		for (ll on = 1; on < n; on *= 2) ++d;
		return d;
	}
	TreeLCA(const vector<vi>& g, int root = 0)
		: TreeTour(g,root), jt(par,levels(sz(g))) {}
	int ancestor(int v, ull k) const {
		return k > ull(dep[v]) ? -1 : jt.jump(v,k);
	}
	int lca(int a, int b) const {
		if (dep[a] < dep[b]) swap(a,b);
		a = jt.jump(a,ull(dep[a]-dep[b]));
		if (a == b) return a;
		for (int i = sz(jt.up); i--;) {
			int c = jt.up[i][a], d = jt.up[i][b];
			if (c != d) a = c, b = d;
		}
		return jt.up[0][a];
	}
	int dist(int a, int b) const {
		int c = lca(a,b);
		return (dep[a]-dep[c])+(dep[b]-dep[c]);
	}
};
