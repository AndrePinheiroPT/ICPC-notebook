/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item All-pairs shortest paths, in-place; square
 *   matrix, minimum parallel-edge weight, inf if absent.
 *   Sets diagonal to at most 0; -inf means unbounded below.
 *   \item Signed int/ll; $V\max|w|<inf$.
 *   \item $O(V^3)$ time, $O(1)$ extra space.
 *   \end{itemize}
 */
#pragma once

template<class T>
void floyd(vector<vector<T>>& d,
		T inf = numeric_limits<T>::max()/4) {
	int n = sz(d);
	for (int i = 0; i < n; ++i)
		d[i][i] = min(d[i][i],T(0));
	for (int k = 0; k < n; ++k)
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				if (d[i][k] != inf && d[k][j] != inf) {
					__int128 x = (__int128)d[i][k]+d[k][j];
					if (x < d[i][j])
						d[i][j] = T(max(x,-(__int128)inf));
				}
	for (int k = 0; k < n; ++k) if (d[k][k] < 0)
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				if (d[i][k] != inf && d[k][j] != inf)
					d[i][j] = -inf;
}
