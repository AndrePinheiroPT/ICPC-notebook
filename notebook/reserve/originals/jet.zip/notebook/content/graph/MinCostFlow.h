/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item n vertices; add(u,v,cap,cost) adds u to v
 *  with capacity cap and cost per unit cost.
 *  flow(s,t,lim): minimum cost for as much
 *  additional flow as possible, at most lim;
 *  returns \{flow,cost\}. Bellman--Ford + potentials.
 *  \item $s\ne t$; integral capacities $\ge0$;
 *  C signed; no negative cycle in the residual,
 *  even disconnected. All arithmetic must fit;
 *  each augmentation's flow must also fit C;
 *  Edge costs, reduced distances and potentials
 *  have magnitude $<INF$.
 *  \item $O(V+VE+A(E+V)\log(V+E+1))$ time
 *  for A augmentations,
 *  $O(V+E)$ space. Each call rebuilds potentials.
 *  \end{itemize}
 * Usage: MinCostFlow<ll,ll> f(n); f.add(u,v,cap,cost);
 *   auto [sent,total] = f.flow(s,t,lim);
 */
#pragma once

template<class T = ll, class C = ll>
struct MinCostFlow {
	struct Edge { int to, rev; T cap; C cost; };
	const C INF = numeric_limits<C>::max()/4;
	vector<vector<Edge>> g;
	MinCostFlow(int n) : g(n) {}
	void add(int u, int v, T cap, C cost) {
		assert(cap >= 0 && -INF < cost && cost < INF);
		int a = sz(g[u]), b = sz(g[v]);
		g[u].push_back({v,b+(u==v),cap,cost});
		g[v].push_back({u,a,0,-cost});
	}
	pair<T,C> flow(int s, int t,
		T lim = numeric_limits<T>::max()) {
		int n = sz(g);
		assert(0 <= s && s < n && 0 <= t && t < n);
		assert(s != t && lim >= 0);
		vector<C> h(n), d(n);
		vi pv(n,-1), pe(n,-1);
		for (int k = 0; k < n; ++k) {
			bool change = false;
			for (int u = 0; u < n; ++u)
				for (auto e : g[u]) if (e.cap > 0)
					if (h[u]+e.cost < h[e.to]) {
						h[e.to] = h[u]+e.cost;
						change = true;
					}
			if (!change) break;
			assert(k+1 < n); // No negative cycle.
		}
		T f = 0; C cost = 0;
		while (f < lim) {
			fill(d.begin(), d.end(), INF);
			priority_queue<pair<C,int>,
				vector<pair<C,int>>,
				greater<pair<C,int>>> q;
			d[s] = 0; q.push({0,s});
			while (!q.empty()) {
				auto [du,u] = q.top(); q.pop();
				if (du != d[u]) continue;
				for (int i = 0; i < sz(g[u]); ++i) {
					auto e = g[u][i];
					if (e.cap <= 0) continue;
					C z = du+e.cost+h[u]-h[e.to];
					if (z < d[e.to]) {
						d[e.to] = z;
						pv[e.to] = u; pe[e.to] = i;
						q.push({z,e.to});
					}
				}
			}
			if (d[t] == INF) break;
			for (int v = 0; v < n; ++v)
				if (d[v] < INF) h[v] += d[v];
			T add = lim-f;
			for (int v = t; v != s; v = pv[v])
				add = min(add,g[pv[v]][pe[v]].cap);
			for (int v = t; v != s; v = pv[v]) {
				auto& e = g[pv[v]][pe[v]];
				e.cap -= add;
				g[v][e.rev].cap += add;
			}
			f += add; cost += C(add)*(h[t]-h[s]);
		}
		return {f,cost};
	}
};
