/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item g: adjacency lists (to,weight), weight 0/1;
 *   src: source vertices. Returns nearest-source
 *   distances; INT\_MAX means unreachable.
 *   \item $O(|src|+V+E)$ time, $O(V+E)$ extra space.
 *   \end{itemize}
 * Usage: auto d = zeroOneBfs(g,{s});
 */
#pragma once

vi zeroOneBfs(
		const vector<vector<pair<int,int>>>& g,
		const vi& src) {
	vi d(sz(g),INT_MAX);
	deque<pair<int,int>> q;
	for (int s : src) if (d[s] != 0) {
		d[s] = 0; q.push_back({0,s});
	}
	while (!q.empty()) {
		auto [dv,v] = q.front(); q.pop_front();
		if (dv != d[v]) continue;
		for (auto [u,w] : g[v]) if (dv+w < d[u]) {
			d[u] = dv+w;
			if (w) q.push_back({d[u],u});
			else q.push_front({d[u],u});
		}
	}
	return d;
}
