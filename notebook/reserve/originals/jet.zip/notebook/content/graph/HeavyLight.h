/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item g: undirected tree, root: valid vertex.
 *   Empty input allowed. Inherits TreeTour;
 *   tin/tout/ord use heavy-first subtree order.
 *   path(u,v,f) emits disjoint $[l,r)$ via f.
 *   \item Default: vertices. edges=true excludes
 *   the LCA; store each edge at its child's tin.
 *   Unordered segments: noncommutative queries
 *   need direction/reversal handling separately.
 *   \item Build/space $O(n)$;
 *   $O(\log n)$ callbacks per path.
 *   \end{itemize}
 * Usage: HeavyLight h(g,root); h.path(u,v,f,true);
 *   // f(l,r) uses h.tin indices.
 */
#pragma once
#include "TreeTour.h"

struct HeavyLight : TreeTour {
	vi head;
	HeavyLight(const vector<vi>& g, int root = 0)
		: TreeTour(g,root), head(sz(g)) {
		if (g.empty()) return;
		vi heavy(sz(g),-1);
		for (int v = 0; v < sz(g); ++v)
			for (int u : g[v]) if (par[u] == v) {
				int w = heavy[v];
				if (w < 0 ||
						tout[u]-tin[u] > tout[w]-tin[w])
					heavy[v] = u;
			}
		vi st{root}; ord.clear();
		while (!st.empty()) {
			int v = st.back(); st.pop_back();
			for (int u = v; u >= 0; u = heavy[u]) {
				head[u] = v;
				tin[u] = sz(ord); ord.push_back(u);
				tout[u] = tin[u]+1;
				for (int w : g[u])
					if (par[w] == u && w != heavy[u])
						st.push_back(w);
			}
		}
		for (int i = sz(ord); i--;) {
			int v = ord[i];
			if (par[v] >= 0)
				tout[par[v]] = max(tout[par[v]],tout[v]);
		}
	}
	template<class F>
	void path(int u, int v, F f,
			bool edges = false) const {
		while (head[u] != head[v]) {
			if (dep[head[u]] < dep[head[v]]) swap(u,v);
			f(tin[head[u]],tin[u]+1);
			u = par[head[u]];
		}
		if (dep[u] > dep[v]) swap(u,v);
		int l = tin[u]+int(edges), r = tin[v]+1;
		if (l < r) f(l,r);
	}
};
