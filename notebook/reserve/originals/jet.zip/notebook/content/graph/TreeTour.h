/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item TreeTour(g,root): undirected tree;
 *   iterative preorder and subtree sizes.
 *   par[root]=-1; dep counts edges from root.
 *   \item Each vertex occurs once in ord;
 *   subtree(v) is $[tin[v],tout[v])$ in ord.
 *   Empty input is allowed; else root is valid.
 *   \item $O(n)$ time and space.
 *   \end{itemize}
 */
#pragma once

struct TreeTour {
	vi par, dep, tin, tout, ord;
	TreeTour(const vector<vi>& g, int root = 0)
		: par(sz(g),-1), dep(sz(g)),
		  tin(sz(g)), tout(sz(g)) {
		if (g.empty()) return;
		vi st{root}, size(sz(g),1);
		while (!st.empty()) {
			int v = st.back(); st.pop_back();
			tin[v] = sz(ord); ord.push_back(v);
			for (int u : g[v]) if (u != par[v]) {
				par[u] = v; dep[u] = dep[v]+1;
				st.push_back(u);
			}
		}
		for (int i = sz(ord); i--;) {
			int v = ord[i];
			tout[v] = tin[v]+size[v];
			if (par[v] >= 0)
				size[par[v]] += size[v];
		}
	}
};
