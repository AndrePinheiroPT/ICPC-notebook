/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Bridges as edge IDs, unsorted;
 *   cut[v] is 1 iff v is an articulation point.
 *   \item n vertices; e lists undirected (u,v) edges.
 *   Vertices $[0,n)$; DFS roots have parent -1.
 *   Loops/parallel edges allowed; IDs are list indices.
 *   \item $O(n+m)$ time/space; iterative DFS.
 *   \end{itemize}
 * Usage: Lowlink b(n,edges); // b.bridges, b.cut
 */
#pragma once

struct Lowlink {
	vi bridges, cut;
	Lowlink(int n, const vector<pair<int,int>>& e)
		: cut(n) {
		vector<vector<pair<int,int>>> g(n);
		for (int i = 0; i < sz(e); ++i) {
			auto [u,v] = e[i];
			g[u].push_back({v,i});
			g[v].push_back({u,i});
		}
		vi tin(n,-1), low(n), par(n,-1), pe(n,-1);
		vi it(n), child(n), st;
		int timer = 0;
		for (int s = 0; s < n; ++s) if (tin[s] < 0) {
			tin[s] = low[s] = timer++;
			st.push_back(s);
			while (!st.empty()) {
				int v = st.back();
				if (it[v] < sz(g[v])) {
					auto [u,id] = g[v][it[v]++];
					if (id == pe[v]) continue;
					if (tin[u] < 0) {
						par[u] = v; pe[u] = id; ++child[v];
						tin[u] = low[u] = timer++;
						st.push_back(u);
					} else low[v] = min(low[v],tin[u]);
				} else {
					st.pop_back();
					int p = par[v];
					if (p < 0) cut[v] = child[v] > 1;
					else {
						low[p] = min(low[p],low[v]);
						if (low[v] > tin[p])
							bridges.push_back(pe[v]);
						if (par[p] >= 0 && low[v] >= tin[p])
							cut[p] = 1;
					}
				}
			}
		}
	}
};
