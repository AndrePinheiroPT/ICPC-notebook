/**
 * Author: jet notebook, based on KACTL
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Topological order. If size is less than V,
 *   a cycle exists; only a valid prefix is returned.
 *   \item $O(V+E)$ time, $O(V)$ extra space.
 *   \end{itemize}
 */
#pragma once

vi kahn(const vector<vi>& g) {
	vi in(sz(g)), q;
	for (auto& adj : g) for (int v : adj) ++in[v];
	for (int v = 0; v < sz(g); ++v)
		if (!in[v]) q.push_back(v);
	for (int i = 0; i < sz(q); ++i)
		for (int v : g[q[i]]) if (!--in[v])
			q.push_back(v);
	return q;
}
