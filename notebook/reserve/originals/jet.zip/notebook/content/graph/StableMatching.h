/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Gale--Shapley: a proposes to b; returns
 *  each proposer's partner, optimal for proposers.
 *  \item a[u] and b[v] list the opposite side in
 *  preference order. Both sides have n vertices;
 *  every row is
 *  a strict complete preference permutation of $[0,n)$.
 *  \item $O(n^2)$ time and space.
 *  \end{itemize}
 * Usage: auto partner = stableMatching(a,b);
 */
#pragma once

vi stableMatching(const vector<vi>& a,
		const vector<vi>& b) {
	int n = sz(a);
	vector<vi> rank(n,vi(n));
	for (int v = 0; v < n; ++v)
		for (int i = 0; i < n; ++i)
			rank[v][b[v][i]] = i;
	vi l(n,-1), r(n,-1), next(n), free(n);
	iota(free.begin(), free.end(), 0);
	while (!free.empty()) {
		int u = free.back(), v = a[u][next[u]++];
		int w = r[v];
		if (w < 0 || rank[v][u] < rank[v][w]) {
			free.pop_back(); l[u] = v; r[v] = u;
			if (w >= 0) {
				l[w] = -1; free.push_back(w);
			}
		}
	}
	return l;
}
