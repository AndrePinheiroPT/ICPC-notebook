/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Hopcroft--Karp; n left/m right vertices.
 *  add(u,v) joins left u to right v. solve() returns
 *  its maximum size, rebuilding partners l/r (-1 if
 *  unmatched). cover() returns left/right IDs of a
 *  minimum vertex cover.
 *  \item Call cover after solve, with no graph changes.
 *  Parallel edges and isolated vertices are allowed.
 *  Recursive DFS: stack for depth $O(V)$.
 *  \item Matching $O((V+E)\sqrt V)$;
 *  cover $O(V+E)$;
 *  $O(V+E)$ space.
 *  \end{itemize}
 * Usage: BipartiteMatching b(n,m); b.add(u,v);
 *   int k = b.solve(); auto [a,c] = b.cover();
 */
#pragma once

struct BipartiteMatching {
	int n, m;
	vector<vi> g;
	vi l, r, d;
	BipartiteMatching(int a, int b)
		: n(a), m(b), g(a), l(a,-1), r(b,-1),
		  d(a+1) {}
	void add(int u, int v) { g[u].push_back(v); }
	bool bfs() {
		fill(d.begin(), d.end(), n+1);
		queue<int> q;
		for (int u = 0; u < n; ++u) if (l[u] < 0)
			d[u] = 0, q.push(u);
		while (!q.empty()) {
			int u = q.front(); q.pop();
			if (d[u] >= d[n]) continue;
			for (int v : g[u]) {
				int w = r[v] < 0 ? n : r[v];
				if (d[w] == n+1) {
					d[w] = d[u]+1;
					if (w < n) q.push(w);
				}
			}
		}
		return d[n] <= n;
	}
	bool dfs(int u) {
		if (u == n) return true;
		for (int v : g[u]) {
			int w = r[v] < 0 ? n : r[v];
			if (d[w] == d[u]+1 && dfs(w)) {
				l[u] = v; r[v] = u; return true;
			}
		}
		d[u] = n+1;
		return false;
	}
	int solve() {
		fill(l.begin(), l.end(), -1);
		fill(r.begin(), r.end(), -1);
		int ans = 0;
		while (bfs()) for (int u = 0; u < n; ++u)
			if (l[u] < 0 && dfs(u)) ++ans;
		return ans;
	}
	pair<vi,vi> cover() const {
		vi a(n), b(m);
		queue<int> q;
		for (int u = 0; u < n; ++u) if (l[u] < 0)
			a[u] = 1, q.push(u);
		while (!q.empty()) {
			int u = q.front(); q.pop();
			for (int v : g[u])
				if (l[u] != v && !b[v]) {
					b[v] = 1;
					int w = r[v];
					if (w >= 0 && !a[w])
						a[w] = 1, q.push(w);
				}
		}
		pair<vi,vi> ans;
		for (int u = 0; u < n; ++u)
			if (!a[u]) ans.first.push_back(u);
		for (int v = 0; v < m; ++v)
			if (b[v]) ans.second.push_back(v);
		return ans;
	}
};
