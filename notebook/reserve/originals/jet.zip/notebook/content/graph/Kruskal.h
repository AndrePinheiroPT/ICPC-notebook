/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Undirected edges (u,v,weight); returns
 *   minimum spanning forest weight and edge IDs.
 *   Components $=V-\#IDs$; includes isolated vertices.
 *   \item $O(V+E\log(E+1))$ time, $O(V+E)$ space.
 *   Intermediate weight sums must fit T.
 *   \end{itemize}
 */
#pragma once
#include "../data-structures/UnionFind.h"

template<class T>
pair<T,vi> kruskal(int n,
		const vector<tuple<int,int,T>>& e) {
	vi ord(sz(e)), ids;
	iota(ord.begin(),ord.end(),0);
	sort(ord.begin(),ord.end(),[&](int a,int b) {
		return get<2>(e[a]) < get<2>(e[b]);
	});
	UF uf(n);
	T cost = 0;
	for (int i : ord) {
		auto [u,v,w] = e[i];
		if (uf.join(u,v)) {
			cost += w; ids.push_back(i);
		}
	}
	return {cost,ids};
}
