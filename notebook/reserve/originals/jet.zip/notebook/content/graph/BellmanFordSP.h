/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Directed edges (from,to,weight), source s.
 *   Returns inf if unreachable, -inf if a reachable
 *   negative cycle can reach the vertex.
 *   \item Signed int/ll; finite answers in $(-inf,inf)$.
 *   128-bit working distances avoid early saturation.
 *   \item $O(VE+V)$ time, $O(V+E)$ extra space.
 *   \end{itemize}
 */
#pragma once

template<class T>
vector<T> bellmanFord(int n,
		const vector<tuple<int,int,T>>& e, int s,
		T inf = numeric_limits<T>::max()/4) {
	using W = __int128;
	const W oo = W(1)<<126;
	vector<W> d(n,oo);
	vector<vi> g(n);
	for (auto [u,v,w] : e) g[u].push_back(v);
	vi bad(n), q;
	d[s] = 0;
	for (int i = 0; i < n; ++i) {
		bool changed = false;
		for (auto [u,v,w] : e)
			if (d[u] != oo && d[u]+w < d[v]) {
				d[v] = d[u]+w; changed = true;
				if (i == n-1 && !bad[v]) {
					bad[v] = 1; q.push_back(v);
				}
			}
		if (!changed) break;
	}
	for (int i = 0; i < sz(q); ++i)
		for (int v : g[q[i]]) if (!bad[v]) {
			bad[v] = 1; q.push_back(v);
		}
	vector<T> ans(n,inf);
	for (int v = 0; v < n; ++v) {
		if (bad[v]) ans[v] = -inf;
		else if (d[v] != oo) {
			assert(-W(inf) < d[v] && d[v] < W(inf));
			ans[v] = T(d[v]);
		}
	}
	return ans;
}
