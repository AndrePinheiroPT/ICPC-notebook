/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item n vertices; add(u,v,cap) adds a directed edge.
 *  flow(s,t) returns additional max flow from s to t;
 *  residual capacities remain in g.
 *  After flow, $lev[v]\ge0$ gives the s-side min cut.
 *  \item Integral capacities $\ge0$, $s\ne t$;
 *  capacities and total flow must fit T.
 *  Recursive DFS: stack for depth $O(V)$.
 *  \item $O(V^2E)$ time, $O(V+E)$ space.
 *  \end{itemize}
 * Usage: DinicFlow<ll> f(n); f.add(u,v,cap);
 *   ll sent = f.flow(s,t);
 */
#pragma once

template<class T = ll> struct DinicFlow {
	struct Edge { int to, rev; T cap; };
	vector<vector<Edge>> g;
	vi lev, it;
	DinicFlow(int n) : g(n), lev(n), it(n) {}
	void add(int u, int v, T cap) {
		assert(cap >= 0);
		int a = sz(g[u]), b = sz(g[v]);
		g[u].push_back({v,b+(u==v),cap});
		g[v].push_back({u,a,0});
	}
	bool bfs(int s, int t) {
		fill(lev.begin(), lev.end(), -1);
		queue<int> q;
		q.push(s); lev[s] = 0;
		while (!q.empty()) {
			int u = q.front(); q.pop();
			for (auto e : g[u])
				if (e.cap > 0 && lev[e.to] < 0) {
					lev[e.to] = lev[u]+1;
					q.push(e.to);
				}
		}
		return lev[t] >= 0;
	}
	T dfs(int u, int t, T f) {
		if (u == t) return f;
		for (int& i = it[u]; i < sz(g[u]); ++i) {
			auto& e = g[u][i];
			if (e.cap <= 0 || lev[e.to] != lev[u]+1)
				continue;
			T z = dfs(e.to, t, min(f,e.cap));
			if (z > 0) {
				e.cap -= z; g[e.to][e.rev].cap += z;
				return z;
			}
		}
		return 0;
	}
	T flow(int s, int t) {
		assert(0 <= s && s < sz(g));
		assert(0 <= t && t < sz(g) && s != t);
		T ans = 0;
		while (bfs(s,t)) {
			fill(it.begin(), it.end(), 0);
			while (T z = dfs(s,t,
					numeric_limits<T>::max())) ans += z;
		}
		return ans;
	}
};
