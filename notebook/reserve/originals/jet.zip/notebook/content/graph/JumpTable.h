/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Repeated successors on $[0,n)$; -1
 *   means absent and remains -1 after any jump.
 *   \item $1\le lg\le64$, $k<2^{lg}$; lg=64
 *   supports every unsigned 64-bit k.
 *   \item Build/space $O(n\,lg)$; jump $O(lg)$.
 *   \end{itemize}
 */
#pragma once

using ull = unsigned long long;

struct JumpTable {
	vector<vi> up;
	JumpTable(const vi& next, int lg)
		: up(lg,next) {
		assert(1 <= lg && lg <= 64);
		for (int j = 1; j < lg; ++j)
			for (int v = 0; v < sz(next); ++v) {
				int p = up[j-1][v];
				up[j][v] = p < 0 ? -1 : up[j-1][p];
			}
	}
	int jump(int v, ull k) const {
		assert(sz(up) == 64 || (k >> sz(up)) == 0);
		for (int j = 0; k && v >= 0; ++j, k >>= 1)
			if (k & 1) v = up[j][v];
		return v;
	}
};
