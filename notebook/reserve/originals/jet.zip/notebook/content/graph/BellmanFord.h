/**
 * Author: Simon Lindholm
 * Date: 2015-02-23
 * License: CC0
 * Source: http://en.wikipedia.org/wiki/Bellman-Ford_algorithm
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item BF::bellmanFord computes distances from s.
 *   int weights; default-initialized nodes.
 *   Mutates nodes and sorts edges; prev is a
 *   predecessor for finite reachable distances.
 *   \item BF::inf is LLONG\_MAX; inf unreachable,
 *   -inf for vertices reachable from negative cycles
 *   reachable from s. Valid source is required.
 *   \item Finite relaxation sums stay in $(-inf,inf)$;
 *   $V(E+1)\max|w|<inf$ is sufficient.
 *   $O(V(E+1)+E\log(E+1))$ time;
 *   $O(\log(E+1))$ extra sort space.
 *   \end{itemize}
 * Status: Tested on kattis:shortestpath3
 */
#pragma once

namespace BF {
const ll inf = LLONG_MAX;
struct Ed {
	int a, b, w, s() {
		return a < b ? a : -a;
	}
};
struct Node { ll dist = inf; int prev = -1; };

void bellmanFord(vector<Node>& nodes,
		vector<Ed>& eds, int s) {
	nodes[s].dist = 0;
	sort(eds.begin(), eds.end(), [](Ed a, Ed b) {
		return a.s() < b.s();
	});

	int lim = sz(nodes) / 2 + 2;
	// /3+100 with shuffled vertices
	for (int i = 0; i < lim; i++)
		for (Ed ed : eds) {
			Node cur = nodes[ed.a],
				&dest = nodes[ed.b];
			if (abs(cur.dist) == inf) continue;
			ll d = cur.dist + ed.w;
			if (d < dest.dist) {
				dest.prev = ed.a;
				dest.dist = (i < lim-1 ? d : -inf);
			}
		}
	for (int i = 0; i < lim; i++)
		for (Ed e : eds) {
			if (nodes[e.a].dist == -inf)
				nodes[e.b].dist = -inf;
		}
}
} // namespace BF
