/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Euler trail from src: vertices and edge IDs.
 *   Empty pair on invalid source/degrees or missing
 *   coverage. No edges: returns the vertex src only.
 *   \item n vertices; e lists (u,v) edges on $[0,n)$.
 *   directed selects orientation; IDs are list indices.
 *   Loops/parallel edges are valid.
 *   n=0 has no valid source and fails.
 *   \item $O(n+m)$ time/space; iterative traversal.
 *   \end{itemize}
 * Usage: auto [vs,ids] = eulerTrail(n,e,s,true);
 *   // true: directed; false: undirected
 */
#pragma once

pair<vi,vi> eulerTrail(int n,
		const vector<pair<int,int>>& e,
		int src, bool directed) {
	if (src < 0 || src >= n) return {};
	vector<vector<pair<int,int>>> g(n);
	vi deg(n);
	for (int i = 0; i < sz(e); ++i) {
		auto [u,v] = e[i];
		g[u].push_back({v,i}); ++deg[u];
		if (directed) --deg[v];
		else g[v].push_back({u,i}), ++deg[v];
	}
	int pos = 0, neg = 0;
	for (int v = 0; v < n; ++v) {
		if (directed) {
			if (deg[v] == 1 && v == src) ++pos;
			else if (deg[v] == -1) ++neg;
			else if (deg[v]) return {};
		} else pos += deg[v]&1;
	}
	if (directed && pos != neg) return {};
	if (!directed && pos &&
			(pos != 2 || !(deg[src]&1))) return {};
	vi it(n), used(sz(e)), path, ids;
	vector<pair<int,int>> st{{src,-1}};
	while (!st.empty()) {
		auto [v,id] = st.back();
		while (it[v] < sz(g[v]) &&
				used[g[v][it[v]].second]) ++it[v];
		if (it[v] == sz(g[v])) {
			path.push_back(v);
			if (id >= 0) ids.push_back(id);
			st.pop_back();
		} else {
			auto [u,k] = g[v][it[v]++];
			used[k] = 1; st.push_back({u,k});
		}
	}
	if (sz(ids) != sz(e)) return {};
	reverse(path.begin(),path.end());
	reverse(ids.begin(),ids.end());
	return {move(path),move(ids)};
}
