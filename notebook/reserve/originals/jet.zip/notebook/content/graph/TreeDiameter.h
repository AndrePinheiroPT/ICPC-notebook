/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Returns (length, endpoint, endpoint):
 *   two traversals of an undirected weighted tree.
 *   Use weight 1 for an unweighted tree.
 *   \item Nonnegative weights; path sums fit T.
 *   Empty tree gives (0,-1,-1); endpoints may coincide.
 *   \item $O(n)$ time and space, iterative.
 *   \end{itemize}
 */
#pragma once

template<class T>
tuple<T,int,int> treeDiameter(
		const vector<vector<pair<int,T>>>& g) {
	int n = sz(g);
	if (!n) return {T{},-1,-1};
	auto far = [&](int s) {
		vector<T> d(n);
		vi par(n,-1), q{s};
		int best = s;
		for (int i = 0; i < sz(q); ++i) {
			int v = q[i];
			if (d[v] > d[best]) best = v;
			for (auto [u,w] : g[v]) if (u != par[v]) {
				par[u] = v; d[u] = d[v]+w;
				q.push_back(u);
			}
		}
		return pair{best,d[best]};
	};
	int a = far(0).first;
	auto [b,d] = far(a);
	return {d,a,b};
}
