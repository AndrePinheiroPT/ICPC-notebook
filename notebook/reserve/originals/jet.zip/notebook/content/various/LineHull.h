/**
 * Author: Simon Lindholm
 * License: CC0
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Add lines $kx+m$ in any order; query
 *  integer maxima; ll inputs and result.
 *  Equal slopes allowed; query needs a line.
 *  Differences, products, sums and floor
 *  quotients must fit ll; $x>-LLONG\_MAX$.
 *  \item Add amortized $O(\log n)$, query
 *  $O(\log n)$; $O(n)$ space. No removals.
 *  \end{itemize}
 * Usage: LineHull h; h.add(k,m); // line y=k*x+m
 *  ll best = h.query(x); // maximum y at x
 */
#pragma once
#include "../math/IntDivision.h"

struct HullLine {
	ll k, m; mutable ll p;
	bool operator<(const HullLine& o) const {
		return k < o.k;
	}
	bool operator<(ll x) const {return p < x;}
};

struct LineHull : multiset<HullLine,less<>> {
	static constexpr ll inf = LLONG_MAX;
	bool isect(iterator x, iterator y) {
		if (y == end()) {
			x->p = inf; return false;
		}
		if (x->k == y->k)
			x->p = x->m > y->m ? inf : -inf;
		else x->p = floorDiv(y->m-x->m,x->k-y->k);
		return x->p >= y->p;
	}
	void add(ll k, ll m) {
		auto z = insert({k,m,0}), y = z++, x = y;
		while (isect(y,z)) z = erase(z);
		if (x != begin() && isect(--x,y))
			isect(x,y=erase(y));
		while ((y=x) != begin() &&
			(--x)->p >= y->p) isect(x,erase(y));
	}
	ll query(ll x) const {
		assert(!empty() && x > -inf);
		auto l = *lower_bound(x);
		return l.k*x+l.m;
	}
};
