/**
 * Author: zyndek; adapted for the notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Scalar 0/1 DP; returns a bitset of
 *   reachable subset sums in $[0,N)$;
 *   each weight used at most once, sum 0 included.
 *   N is a positive compile-time bound.
 *   \item Nonnegative int/ll weights; weights
 *   $\ge N$ are ignored. Zero weights are valid.
 *   \item $O(nN)$ time and
 *   $O(\lceil N/B\rceil)$ words; B bits per word.
 *   \end{itemize}
 */
#pragma once

template<size_t N, class T>
bitset<N> subsetBits(const vector<T>& w) {
	static_assert(N > 0);
	bitset<N> dp;
	dp[0] = 1;
	for (T x : w) if (uintmax_t(x) < N) {
		size_t c = size_t(x);
		for (size_t j = N-1; j > 0; --j)
			if (j >= c) dp[j] = dp[j] || dp[j-c];
	}
	return dp;
}
