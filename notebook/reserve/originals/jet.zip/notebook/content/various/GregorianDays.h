/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Gregorian date to days; 1970-01-01 is 0.
 *  Proleptic calendar, astronomical year 0
 *  (the year before 1 AD). $O(1)$ time/space.
 *  \item y: year, m: month, d: day. Valid date;
 *  month/day are 1-based. Returns signed days since epoch.
 *  $-10^{12}\le y\le10^{12}$; result fits ll.
 *  \end{itemize}
 * Usage: ll days = gregorianDays(y,m,d);
 *  // Subtract two results for elapsed days.
 */
#pragma once
#include "../math/IntDivision.h"

ll gregorianDays(ll y, int m, int d) {
	y -= m <= 2;
	ll era = floorDiv(y,400LL), z = y-era*400;
	int day = (153*(m+(m>2 ? -3 : 9))+2)/5+d-1;
	ll off = z*365+z/4-z/100+day;
	return era*146097+off-719468;
}
