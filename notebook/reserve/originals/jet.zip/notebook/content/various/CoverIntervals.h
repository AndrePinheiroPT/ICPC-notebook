/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Minimum number of intervals covering
 *   $[L,R)$; returns their input IDs in cover order.
 *   nullopt if impossible; empty IDs if L=R.
 *   \item Continuous $[l,r)$ intervals, $l\le r$;
 *   $L\le R$. Input unchanged; no NaN coordinates.
 *   \item $O(n\log n)$ time, $O(n)$ extra space.
 *   \end{itemize}
 */
#pragma once

template<class T> optional<vi> coverIntervals(
		const vector<pair<T,T>>& seg, T L, T R) {
	if (L == R) return vi{};
	vi ord(sz(seg)), ans;
	iota(ord.begin(),ord.end(),0);
	sort(ord.begin(),ord.end(),[&](int a,int b) {
		return seg[a] < seg[b];
	});
	int i = 0;
	while (L < R) {
		T reach = L;
		int id = -1;
		while (i < sz(ord) &&
				seg[ord[i]].first <= L) {
			int j = ord[i++];
			if (reach < seg[j].second)
				reach = seg[j].second, id = j;
		}
		if (id < 0) return nullopt;
		ans.push_back(id); L = reach;
	}
	return ans;
}
