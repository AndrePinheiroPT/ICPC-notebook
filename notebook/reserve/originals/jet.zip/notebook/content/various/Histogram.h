/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Largest rectangle as (area,l,r), using
 *   bars $[l,r)$. Empty/all-zero gives (0,0,0).
 *   Ties arbitrary; input unchanged.
 *   \item h: integer heights $\ge0$; w: widths $>0$.
 *   Equal sizes. Use a vector of 1 for unit widths.
 *   Values, width sums and areas must fit ll.
 *   \item $O(n)$ time and extra space.
 *   \end{itemize}
 * Usage: auto [area,l,r] = largestRectangle(h,w);
 */
#pragma once

template<class H, class W>
tuple<ll,int,int> largestRectangle(
		const vector<H>& h, const vector<W>& w) {
	int n = sz(h), left = 0, right = 0;
	vector<ll> x(n+1);
	for (int i = 0; i < n; ++i)
		x[i+1] = x[i]+ll(w[i]);
	vi st;
	ll best = 0;
	for (int r = 0; r <= n; ++r) {
		while (!st.empty() &&
				(r == n || h[st.back()] >= h[r])) {
			int j = st.back(); st.pop_back();
			int l = st.empty() ? 0 : st.back()+1;
			ll area = ll(h[j])*(x[r]-x[l]);
			if (area > best)
				best = area, left = l, right = r;
		}
		if (r < n) st.push_back(r);
	}
	return {best,left,right};
}
