/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item floydCycle(x,next) returns $(\mu,\lambda)$:
 *  prefix and cycle lengths from state x, under eq.
 *  \item eq is an equivalence preserved by next.
 *  Deterministic next; eventually periodic under eq.
 *  mu/lambda fit ll. $O(\mu+\lambda)$ calls,
 *  $O(1)$ stored states; count state costs too.
 *  \end{itemize}
 */
#pragma once

template<class T, class F,
	class Eq = equal_to<T>>
pair<ll,ll> floydCycle(T x, F next, Eq eq = {}) {
	T a = next(x), b = next(next(x));
	while (!eq(a,b)) {
		a = next(a);
		b = next(next(b));
	}
	ll mu = 0, len = 1;
	a = x;
	while (!eq(a,b)) {
		a = next(a);
		b = next(b);
		++mu;
	}
	b = next(a);
	while (!eq(a,b)) {
		b = next(b);
		++len;
	}
	return {mu,len};
}
