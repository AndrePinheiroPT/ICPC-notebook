/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item In-place aggregation over all submasks;
 *   supersets=true uses all supermasks instead.
 *   Each mask includes itself; no inverse needed.
 *   a[mask] holds its initial value; returns void.
 *   \item Size is $2^k>0$. op is associative and
 *   commutative; default sum, intermediates fit T.
 *   \item $O(k2^k)$ operations, $O(1)$ extra space.
 *   \end{itemize}
 * Usage: sos(a); // a[mask] = sum over its submasks
 *   sos(b,true); // sum over supermasks instead
 */
#pragma once

template<class T, class F = plus<T>>
void sos(vector<T>& a, bool supersets = false,
		F op = {}) {
	int n = sz(a);
	assert(n > 0 && !(n & (n-1)));
	for (int bit = 1; bit < n; bit <<= 1)
		for (int mask = 0; mask < n; ++mask)
			if (bool(mask & bit) != supersets)
				a[mask] = op(a[mask],a[mask^bit]);
}
