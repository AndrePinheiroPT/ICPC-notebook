/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Indices of a longest increasing subsequence.
 *   nondecreasing=true allows equal values (LNDS).
 *   Empty input gives an empty result; ties arbitrary.
 *   \item T has a strict weak ordering via less-than.
 *   $O(n\log n)$ time, $O(n)$ extra space.
 *   \end{itemize}
 */
#pragma once

template<class T> vi lis(const vector<T>& a,
		bool nondecreasing = false) {
	vi tail, par(sz(a),-1);
	auto less = [&](int u,int v) {
		return a[u] < a[v];
	};
	for (int i = 0; i < sz(a); ++i) {
		auto b = tail.begin(), e = tail.end();
		auto it = nondecreasing
			? upper_bound(b,e,i,less)
			: lower_bound(b,e,i,less);
		int k = int(it-tail.begin());
		if (k) par[i] = tail[k-1];
		if (it == e) tail.push_back(i);
		else *it = i;
	}
	vi ans;
	int v = tail.empty() ? -1 : tail.back();
	for (; v >= 0; v = par[v]) ans.push_back(v);
	reverse(ans.begin(),ans.end());
	return ans;
}
