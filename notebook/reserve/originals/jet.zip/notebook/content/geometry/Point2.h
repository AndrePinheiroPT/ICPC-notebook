/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item 2D point/vector; dot, cross, squared norm,
 *   Euclidean norm and CCW perpendicular. $O(1)$.
 *   T is signed integer or real; W is 128-bit
 *   for integral T, otherwise T.
 *   \item Point operations/differences must fit T;
 *   products/sums must fit W. Real predicates use
 *   eps=0 by default; choose $eps\ge0$ by scale.
 *   \item side: -1 right, 0 collinear, 1 left.
 *   onSeg includes endpoints, even if a=b.
 *   eps for side/onSeg is in squared-length units.
 *   Exact lexicographic ordering; no eps in sort.
 *   \end{itemize}
 */
#pragma once

using ld = long double;
template<class T> struct Point2 {
	using P = Point2;
	using W = conditional_t<is_integral_v<T>,
		__int128_t,T>;
	T x, y;
	Point2(T a=0, T b=0) : x(a), y(b) {}
	template<class U> explicit Point2(Point2<U> p)
		: x(T(p.x)), y(T(p.y)) {}
	bool operator<(P p) const {
		return tie(x,y) < tie(p.x,p.y);
	}
	bool operator==(P p) const {
		return x == p.x && y == p.y;
	}
	P operator+(P p) const {return {x+p.x,y+p.y};}
	P operator-(P p) const {return {x-p.x,y-p.y};}
	P operator*(T k) const {return {x*k,y*k};}
	P operator/(T k) const {return {x/k,y/k};}
	W dot(P p) const {
		return W(x)*p.x+W(y)*p.y;
	}
	W cross(P p) const {
		return W(x)*p.y-W(y)*p.x;
	}
	W cross(P a, P b) const {
		return (a-*this).cross(b-*this);
	}
	W dist2() const {return dot(*this);}
	ld dist() const {return sqrtl(ld(dist2()));}
	P perp() const {return {-y,x};}
};
using P2 = Point2<ld>;

template<class T> int geoSgn(T x, T eps=T{}) {
	return (x > eps)-(x < -eps);
}
template<class T>
int side(Point2<T> a, Point2<T> b, Point2<T> p,
		typename Point2<T>::W eps=0) {
	return geoSgn(a.cross(b,p),eps);
}
template<class T>
bool onSeg(Point2<T> a, Point2<T> b, Point2<T> p,
		typename Point2<T>::W eps=0) {
	return !side(a,b,p,eps) &&
		(p-a).dot(p-b) <= eps;
}
