/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exact union area of integer rectangles
 *   (x1,y1,x2,y2), interpreted as $[x1,x2)\times[y1,y2)$.
 *   Ordered bounds; empty rectangles are ignored.
 *   \item Lengths, products and total area must fit ll.
 *   Input unchanged; ll coordinates.
 *   \item $O(n\log n)$ time, $O(n)$ extra space.
 *   \end{itemize}
 * Usage: ll area = rectUnion(rect);
 *  // rect: vector<array<ll,4>>, {x1,y1,x2,y2}
 */
#pragma once

ll rectUnion(const vector<array<ll,4>>& rect) {
	vector<tuple<ll,ll,ll,int>> ev;
	vector<ll> y;
	for (auto [x1,y1,x2,y2] : rect)
		if (x1 < x2 && y1 < y2) {
			ev.push_back({x1,y1,y2,1});
			ev.push_back({x2,y1,y2,-1});
			y.push_back(y1); y.push_back(y2);
		}
	if (ev.empty()) return 0;
	sort(ev.begin(),ev.end());
	sort(y.begin(),y.end());
	y.erase(unique(y.begin(),y.end()),y.end());
	int n = sz(y)-1;
	vi cover(4*n);
	vector<ll> len(4*n);
	auto add = [&](auto&& self, int p,int l,int r,
			int a, int b, int d)->void {
		if (b <= l || r <= a) return;
		if (a <= l && r <= b) cover[p] += d;
		else {
			int m = l+(r-l)/2;
			self(self,2*p,l,m,a,b,d);
			self(self,2*p+1,m,r,a,b,d);
		}
		len[p] = cover[p] ? y[r]-y[l] :
			(r-l == 1 ? 0 : len[2*p]+len[2*p+1]);
	};
	ll area = 0;
	ll prev = get<0>(ev[0]);
	for (auto [x,y1,y2,d] : ev) {
		area += len[1]*(x-prev);
		int a = int(lower_bound(y.begin(),y.end(),y1)
			-y.begin());
		int b = int(lower_bound(y.begin(),y.end(),y2)
			-y.begin());
		add(add,1,0,n,a,b,d); prev = x;
	}
	return area;
}
