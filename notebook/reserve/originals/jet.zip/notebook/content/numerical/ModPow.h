/**
 * Author: Noam527
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item $b^e\bmod 1000000007$; $0\le b<mod$, $e\ge0$.
 *   Change mod only if $mod>1$ and $(mod-1)^2$ fits ll.
 *   \item $O(\log(e+1))$ time, $O(1)$ space.
 *   For a variable modulus, use modpow(b,e,m)
 *   from ModMulLL.h (Number theory).
 *   \end{itemize}
 */
#pragma once
#include "../number-theory/ModMulLL.h"

const ll mod = 1000000007; // faster if const

ll modpow(ll b, ll e) {
	ll ans = 1;
	for (; e; b = b * b % mod, e /= 2)
		if (e & 1) ans = ans * b % mod;
	return ans;
}
