/**
 * Author: jet notebook, based on KACTL (Ulf Lundstrom)
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Square matrix product and nonnegative integer
 *   powers; default construction is zero, $A^0=I$.
 *   \item MOD=0 uses ordinary T arithmetic. Otherwise,
 *   $2\le\mathrm{MOD}$ must fit integer T; entries must
 *   be in $[0,\mathrm{MOD})$. Products use ll for
 *   32-bit MOD, otherwise 128-bit.
 *   \item Product $O(N^3)$, power $O(N^3\log p)$;
 *   $O(N^2)$ space. Ordinary intermediates must fit T.
 *   \end{itemize}
 * Usage: Mat<ll,2,1000000007> a; a.d = {{{1,1},{1,0}}};
 *   auto b = a^k;
 */
#pragma once

template<class T, int N, ll MOD = 0> struct Mat {
	static_assert(N >= 0 && (MOD == 0 || MOD >= 2));
	static_assert(MOD == 0 || is_integral_v<T>);
	using M = Mat;
	using W = conditional_t<(MOD <= INT_MAX),
		ll,__int128_t>;
	array<array<T,N>,N> d{};
	M operator*(const M& b) const {
		M a;
		for (int i = 0; i < N; ++i)
			for (int j = 0; j < N; ++j)
				for (int k = 0; k < N; ++k) {
					if constexpr (MOD)
						a.d[i][k] = T((a.d[i][k] +
							W(d[i][j])*b.d[j][k]) % MOD);
					else a.d[i][k] += d[i][j]*b.d[j][k];
				}
		return a;
	}
	M operator^(ll p) const {
		assert(p >= 0);
		M a, b = *this;
		for (int i = 0; i < N; ++i) a.d[i][i] = 1;
		while (p) {
			if (p & 1) a = a*b;
			p >>= 1;
			if (p) b = b*b;
		}
		return a;
	}
};
