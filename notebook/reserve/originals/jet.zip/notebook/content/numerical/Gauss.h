/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Solves augmented $n\times(m+1)$ system;
 *   overwrites a. Returns rank, or -1 if inconsistent.
 *   On success, x is approximate; free variables zero.
 *   \item Floating T; inputs/intermediates must be finite.
 *   Absolute eps > 0; numerical rank depends on scaling.
 *   \item $O(nm\min(n,m))$.
 *   \end{itemize}
 * Usage: vector<vector<double>> a{{2,1,5},{1,-1,1}};
 *   vector<double> x; int rank = gauss(a,2,x);
 */
#pragma once

template<class T>
int gauss(vector<vector<T>>& a, int m,
		vector<T>& x, T eps = T(1e-12L)) {
	static_assert(is_floating_point_v<T>);
	assert(m >= 0 && eps > 0);
	int n = sz(a), r = 0;
	vi col;
	x.assign(m, T{});
	for (auto& row : a) assert(sz(row) == m+1);
	for (int c = 0; c < m && r < n; ++c) {
		int s = r;
		for (int i = r+1; i < n; ++i)
			if (abs(a[i][c]) > abs(a[s][c])) s = i;
		if (abs(a[s][c]) <= eps) continue;
		swap(a[r], a[s]);
		for (int i = r+1; i < n; ++i) {
			T f = a[i][c] / a[r][c];
			a[i][c] = 0;
			for (int j = c+1; j <= m; ++j)
				a[i][j] -= f * a[r][j];
		}
		col.push_back(c);
		++r;
	}
	for (int i = r; i < n; ++i)
		if (abs(a[i][m]) > eps) return -1;
	for (int i = r; i--;) {
		int c = col[i];
		T v = a[i][m];
		for (int j = c+1; j < m; ++j)
			v -= a[i][j] * x[j];
		x[c] = v / a[i][c];
	}
	return r;
}
