/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item NTT and convolution modulo 998244353,
 *  with primitive root 3; ntt(a,inv) mutates a.
 *  inv selects the inverse. conv(a,b) returns
 *  polynomial-product coefficients, empty if either is empty.
 *  \item Inputs in $[0,mod)$. Transform size is a
 *  positive power of two, at most $2^{23}$;
 *  convolution output must also fit this limit.
 *  \item $O(N\log N)$ time; convolution uses
 *  $O(N)$ space, with N the padded length.
 *  \end{itemize}
 * Usage: auto c = NTT::conv(vi{1,2},vi{3,4});
 *   // c = {3,10,8}
 */
#pragma once
#include "ModPow.h"

namespace NTT {
constexpr int mod = 998244353;

void ntt(vector<int>& a, bool inv = false) {
	int n = sz(a);
	assert(n > 0 && !(n & (n-1)) && n <= (1<<23));
	for (int i = 1, j = 0; i < n; ++i) {
		int bit = n >> 1;
		for (; j & bit; bit >>= 1) j ^= bit;
		j ^= bit;
		if (i < j) swap(a[i], a[j]);
	}
	int g = inv ? int(modpow(3, mod-2, mod)) : 3;
	for (int k = 1; k < n; k *= 2) {
		int z = int(modpow(g, (mod-1)/(2*k), mod));
		for (int i = 0; i < n; i += 2*k) {
			ll w = 1;
			for (int j = 0; j < k; ++j) {
				int u = a[i+j];
				int v = int(w*a[i+j+k] % mod);
				a[i+j] = u+v < mod ? u+v : u+v-mod;
				a[i+j+k] = u-v < 0 ? u-v+mod : u-v;
				w = w*z % mod;
			}
		}
	}
	if (inv) {
		ll r = modpow(n, mod-2, mod);
		for (int& x : a) x = int(x*r % mod);
	}
}

vector<int> conv(vector<int> a, vector<int> b) {
	if (a.empty() || b.empty()) return {};
	int s = sz(a)+sz(b)-1, n = 1;
	assert(s <= (1<<23));
	while (n < s) n *= 2;
	a.resize(n); b.resize(n);
	ntt(a); ntt(b);
	for (int i = 0; i < n; ++i)
		a[i] = int(ll(a[i])*b[i] % mod);
	ntt(a, true);
	a.resize(s);
	return a;
}
}
