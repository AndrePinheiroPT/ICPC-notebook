/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Solves augmented $n\times(m+1)$ system;
 *   overwrites a. Returns rank, or -1 if inconsistent.
 *   On success, x is a solution; free variables zero.
 *   \item Prime $2\le p\le$ INT\_MAX; entries in $[0,p)$.
 *   \item $O(nm\min(n,m)+\min(n,m)\log p)$.
 *   \end{itemize}
 * Usage: vector<vi> a{{2,1,5},{1,6,1}}; vi x;
 *   int rank = gaussMod(a,2,x,7);
 */
#pragma once
#include "ModPow.h"

int gaussMod(vector<vector<int>>& a, int m,
		vector<int>& x, int p) {
	assert(m >= 0 && p >= 2);
	int n = sz(a), r = 0;
	vi col;
	x.assign(m, 0);
	for (auto& row : a) assert(sz(row) == m+1);
	for (int c = 0; c < m && r < n; ++c) {
		int s = r;
		while (s < n && !a[s][c]) ++s;
		if (s == n) continue;
		swap(a[r], a[s]);
		ll inv = modpow(a[r][c], p-2, p);
		for (int j = c; j <= m; ++j)
			a[r][j] = int(a[r][j] * inv % p);
		for (int i = r+1; i < n; ++i) {
			int f = a[i][c];
			a[i][c] = 0;
			for (int j = c+1; j <= m; ++j)
				a[i][j] = int((a[i][j]
					- ll(f)*a[r][j]%p + p)%p);
		}
		col.push_back(c);
		++r;
	}
	for (int i = r; i < n; ++i)
		if (a[i][m]) return -1;
	for (int i = r; i--;) {
		int c = col[i];
		ll v = a[i][m];
		for (int j = c+1; j < m; ++j)
			v = (v - ll(a[i][j])*x[j]%p + p)%p;
		x[c] = int(v);
	}
	return r;
}
