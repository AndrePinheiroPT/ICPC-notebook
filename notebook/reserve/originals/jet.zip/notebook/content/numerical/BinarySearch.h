/**
 * Author: user supplied
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Integer search on closed $[l,r]$, $l\le r$;
 *   at least one true. first\_true: false then true;
 *   last\_true: true then false.
 *   \item $O(\log(r-l+1))$ tests. Signed ll;
 *   r-l (first) and r-l+1 (last) must fit ll.
 *   \end{itemize}
 */
#pragma once

// First true
template<class F>
ll first_true(ll l, ll r, F check) {
	while (l < r) {
		ll m = l + (r-l)/2;
		if (check(m)) r = m;
		else l = m+1;
	}
	return l;
}
// Last true
template<class F>
ll last_true(ll l, ll r, F check) {
	while (l < r) {
		ll m = l + (r-l+1)/2;
		if (check(m)) l = m;
		else r = m-1;
	}
	return l;
}
