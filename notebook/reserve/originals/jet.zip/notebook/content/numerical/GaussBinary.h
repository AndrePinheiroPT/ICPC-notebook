/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Solves $Ax=b$ over $\mathbb F_2$, returning
 *   rank or $-1$ if inconsistent. Modifies a; x is a
 *   particular solution only when rank is nonnegative.
 *   \item n augmented rows; m variables, RHS at bit m,
 *   $0\le m<K$. Free variables are set to zero.
 *   \item $O(nm\lceil K/w\rceil)$ time for word size w;
 *   $O(m+K/w)$ extra space, besides the bitset rows.
 *   \end{itemize}
 * Usage: vector<bitset<501>> a(n); vi x;
 *   int rank = gaussBinary(a,m,x); // m <= 500
 */
#pragma once

template<size_t K>
int gaussBinary(vector<bitset<K>>& a, int m, vi& x) {
	assert(0 <= m && size_t(m) < K);
	int n = sz(a), r = 0;
	vi col;
	x.assign(m,0);
	for (int c = 0; c < m && r < n; ++c) {
		int p = r;
		while (p < n && !a[p][c]) ++p;
		if (p == n) continue;
		swap(a[p],a[r]);
		for (int i = 0; i < n; ++i)
			if (i != r && a[i][c]) a[i] ^= a[r];
		col.push_back(c); ++r;
	}
	for (int i = r; i < n; ++i)
		if (a[i][m]) return -1;
	for (int i = 0; i < r; ++i) x[col[i]] = a[i][m];
	return r;
}
