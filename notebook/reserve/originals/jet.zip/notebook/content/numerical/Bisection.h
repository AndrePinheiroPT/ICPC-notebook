/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Real boundary search; f is false then true,
 *   with f(l)=false, f(r)=true. Returns the true side.
 *   \item $O(k)$ tests; width shrinks by $2^{-k}$ until
 *   floating-point resolution. Floating T; finite
 *   l,r; $l<r$, $k\ge0$.
 *   \end{itemize}
 * Usage: double x = bisect(0.,2.,[](double t) {
 *   return t*t >= 2; }); // sqrt(2), from above
 */
#pragma once

template<class T, class F>
T bisect(T l, T r, F f, int k = 100) {
	static_assert(is_floating_point_v<T>);
	assert(l < r && k >= 0);
	while (k--) {
		T m = l < 0 && r > 0 ? (l+r)/2
			: l+(r-l)/2;
		if (m == l || m == r) break;
		if (f(m)) r = m;
		else l = m;
	}
	return r;
}
