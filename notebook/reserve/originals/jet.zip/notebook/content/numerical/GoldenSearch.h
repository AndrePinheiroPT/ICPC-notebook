/**
 * Author: jet notebook, based on KACTL
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Approximate minimizer of unimodal f in $[l,r]$;
 *   no flat regions except at minima. Finite l,r and f.
 *   \item $O(k)$ evaluations; width factor
 *   $((\sqrt5-1)/2)^k$, limited by floating-point precision.
 *   Floating T; $l\le r$, $k\ge0$.
 *   \end{itemize}
 * Usage: double x = gss(-5.,5.,[](double t) {
 *   return (t-2)*(t-2); }); // x near 2
 */
#pragma once

template<class T, class F>
T gss(T l, T r, F f, int k = 100) {
	static_assert(is_floating_point_v<T>);
	assert(l <= r && k >= 0);
	T a = (sqrt(T(5))-1)/2;
	auto at = [&](T t) {
		return l < 0 && r > 0 ? l*(1-t)+r*t
			: l+(r-l)*t;
	};
	T x = at(1-a), y = at(a);
	T fx = f(x), fy = f(y);
	while (k--) {
		if (!(l < x && x < y && y < r)) break;
		if (fx < fy) {
			r = y; y = x; fy = fx;
			x = at(1-a); fx = f(x);
		} else {
			l = x; x = y; fx = fy;
			y = at(a); fy = f(y);
		}
	}
	return l < 0 && r > 0 ? (l+r)/2 : l+(r-l)/2;
}
