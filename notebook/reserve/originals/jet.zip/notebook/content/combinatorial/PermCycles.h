/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Cycle lengths, in any order; p must
 *   be a permutation of $[0,n)$. Empty is valid.
 *   \item $O(n)$ time and space.
 *   \end{itemize}
 */
#pragma once

vi cycleLengths(const vi& p) {
	vi len, vis(sz(p));
	for (int i = 0; i < sz(p); ++i) if (!vis[i]) {
		int j = i, k = 0;
		do {
			vis[j] = 1; ++k;
			j = p[j];
		} while (j != i);
		len.push_back(k);
	}
	return len;
}
