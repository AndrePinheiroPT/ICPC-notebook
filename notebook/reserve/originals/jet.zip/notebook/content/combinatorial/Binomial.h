/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exact $\binom nk$; $n\ge0$.
 *   Returns zero for $k<0$ or $k>n$.
 *   \item Integer T, including cpp\_int;
 *   result must fit T. Divides before multiplying.
 *   \item $O(r\log(n+1))$ fixed-width time,
 *   $r=\min(k,n-k)$; big-integer cost grows with bits.
 *   \end{itemize}
 * Usage: ll c = binom(5,2); // 10
 */
#pragma once

template<class T = ll> T binom(ll n, ll k) {
	assert(n >= 0);
	if (k < 0 || k > n) return T(0);
	k = min(k, n-k);
	T ans = 1;
	for (ll i = 1; i <= k; ++i) {
		ll a = n-k+i, b = i, g = gcd(a,b);
		a /= g; b /= g;
		ans = T(ans / b * a);
	}
	return ans;
}
