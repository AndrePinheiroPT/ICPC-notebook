/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item f/iv: factorials/inverse factorials.
 *   C(n,k) returns $\binom nk\bmod p$; invalid k returns zero.
 *   \item Prime p, integer T up to 64 bits;
 *   $1\le lim\le p$, $0\le n<lim$.
 *   \item Build $O(lim+\log p)$, space $O(lim)$;
 *   each query $O(1)$.
 *   \end{itemize}
 * Usage: ModComb<> c(101,1000000007LL);
 *   ll ways = c.C(100,3);
 */
#pragma once
#include "../numerical/ModPow.h"

template<class T = ll> struct ModComb {
	T p;
	vector<T> f, iv;
	ModComb(int lim, T prime)
		: p(prime), f(lim), iv(lim) {
		assert(p >= 2 && 1 <= lim && T(lim) <= p);
		f[0] = 1;
		for (int i = 1; i < lim; ++i)
			f[i] = modmul(f[i-1], T(i), p);
		iv[lim-1] = modpow(f[lim-1], ull(p-2), p);
		for (int i = lim-1; i > 0; --i)
			iv[i-1] = modmul(iv[i], T(i), p);
	}
	T C(ll n, ll k) const {
		assert(0 <= n && n < sz(f));
		if (k < 0 || k > n) return T(0);
		return modmul(f[n],
			modmul(iv[k], iv[n-k], p), p);
	}
};
