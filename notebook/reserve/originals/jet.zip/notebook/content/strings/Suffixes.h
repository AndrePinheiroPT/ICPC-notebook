/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item sa[i]: i-th suffix start; rank[sa[i]]=i.
 *  No empty suffix. lcp[i]=LCP(sa[i],sa[i+1]),
 *  length max(0,n-1); sa/rank have length n.
 *  \item Unsigned byte order; all 256 bytes valid.
 *  $O(n\log n)$ time, $O(n)$ extra space.
 *  \end{itemize}
 * Usage: Suffixes a(s); // s: input string
 *  RMQ<int> rmq(a.lcp);
 *  For i!=j: rmq.query(min(a.rank[i],a.rank[j]),
 *    max(a.rank[i],a.rank[j])); i==j gives n-i.
 */
#pragma once

struct Suffixes {
	vi sa, rank, lcp;
	Suffixes(string_view s) : sa(sz(s)),
		rank(sz(s)), lcp(max(0,sz(s)-1)) {
		int n = sz(s), c = 0;
		if (!n) return;
		iota(sa.begin(),sa.end(),0);
		sort(sa.begin(),sa.end(),[&](int a,int b) {
			return (unsigned char)s[a] <
				(unsigned char)s[b];
		});
		for (int i = 0; i < n; ++i) {
			if (!i || s[sa[i]] != s[sa[i-1]]) ++c;
			rank[sa[i]] = c-1;
		}
		vi y(n), r(n), cnt(n);
		for (int k = 1; c < n; k *= 2) {
			int p = 0;
			for (int i = n-k; i < n; ++i) y[p++] = i;
			for (int v : sa)
				if (v >= k) y[p++] = v-k;
			fill(cnt.begin(),cnt.begin()+c,0);
			for (int v : y) ++cnt[rank[v]];
			for (int i = 1; i < c; ++i)
				cnt[i] += cnt[i-1];
			for (int i = n; i--;)
				sa[--cnt[rank[y[i]]]] = y[i];
			auto next = [&](int v) {
				return v < n-k ? rank[v+k] : -1;
			};
			c = 1; r[sa[0]] = 0;
			for (int i = 1; i < n; ++i) {
				int a = sa[i-1], b = sa[i];
				if (rank[a] != rank[b] ||
						next(a) != next(b)) ++c;
				r[b] = c-1;
			}
			rank.swap(r);
			if (c == n) break;
		}
		for (int i = 0, h = 0; i < n; ++i) {
			int rnk = rank[i];
			if (rnk == n-1) { h = 0; continue; }
			int j = sa[rnk+1];
			while (h < n-i && h < n-j &&
					s[i+h] == s[j+h]) ++h;
			lcp[rnk] = h;
			if (h) --h;
		}
	}
};
