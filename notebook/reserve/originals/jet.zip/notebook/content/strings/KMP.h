/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item pi[i]: longest proper prefix that is
 *  also a suffix of s[0,i+1). Equality only.
 *  \item KMP returns all match starts, including
 *  overlaps. Empty pattern: all n+1 boundaries.
 *  No separator/sentinel; arbitrary bytes valid.
 *  \item Prefix $O(m)$; KMP $O(n+m)$ time,
 *  $O(m)$ space plus returned matches.
 *  \end{itemize}
 * Usage: auto pi = prefixFunction(s);
 *  auto pos = kmpMatches(s,p);
 *  // s: text, p: pattern; pos: 0-based starts
 */
#pragma once

template<class S>
vi prefixFunction(const S& s) {
	vi p(sz(s));
	for (int i = 1; i < sz(s); ++i) {
		int j = p[i-1];
		while (j && s[i] != s[j]) j = p[j-1];
		if (s[i] == s[j]) ++j;
		p[i] = j;
	}
	return p;
}
template<class S, class P>
vi kmpMatches(const S& s, const P& p) {
	vi ans;
	int n = sz(s), m = sz(p), j = 0;
	if (!m) {
		ans.resize(n+1);
		iota(ans.begin(),ans.end(),0);
		return ans;
	}
	vi pi = prefixFunction(p);
	for (int i = 0; i < n; ++i) {
		while (j && s[i] != p[j]) j = pi[j-1];
		if (s[i] == p[j]) ++j;
		if (j == m) {
			ans.push_back(i-m+1); j = pi[j-1];
		}
	}
	return ans;
}
