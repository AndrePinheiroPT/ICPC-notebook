/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Manacher returns \{odd,even\} radii.
 *  odd[i]=k: palindrome $[i-k+1,i+k)$;
 *  even[i]=k: palindrome $[i-k,i+k)$.
 *  Odd includes the centre; even counts pairs.
 *  \item $O(n)$ time/space; equality only.
 *  Empty input gives two empty arrays.
 *  \end{itemize}
 * Usage: auto [odd,even] = palindromes(s);
 *  // s: string/vector; radii per input position
 */
#pragma once

template<class S>
array<vi,2> palindromes(const S& s) {
	int n = sz(s);
	array<vi,2> p{vi(n),vi(n)};
	for (int e = 0; e < 2; ++e)
		for (int i = 0,l = 0,r = -1; i < n; ++i) {
			int k = i > r ? 1-e :
				min(p[e][l+(r-i)+e],r-i+1);
			while (k+e <= i && k < n-i &&
					s[i-k-e] == s[i+k]) ++k;
			p[e][i] = k;
			if (i+k-1 > r)
				l = i-k+1-e, r = i+k-1;
		}
	return p;
}
