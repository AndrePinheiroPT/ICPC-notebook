/**
 * Author: supplied by user
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Fixed-base double rolling hash. get(l,r)
 *  returns two residues for $[l,r)$, without length.
 *  Compare only equal lengths; collisions are possible.
 *  \item Integral symbols must fit ll. Plain char
 *  keeps its signedness; use unsigned char for bytes.
 *  Values differing by $1000000016000000063$
 *  have identical residues (including 0).
 *  \item concat(x,y,lenY) hashes x followed by y;
 *  x/y are normalized hashes, lenY is y's length,
 *  $0\le lenY\le n$ for this object's original input.
 *  \item Build/space $O(n)$; get/concat $O(1)$.
 *  \end{itemize}
 * Usage: DoubleHash h(s);
 *  auto k = h.concat(h.get(0,i),h.get(i+1,sz(s)),
 *                    sz(s)-i-1);
 */
#pragma once

struct DoubleHash {
	static constexpr array<ll,2> mod{1000000007,
		1000000009};
	static constexpr ll A = 911382323;
	vector<array<ll,2>> h, p;
	template<class Seq> DoubleHash(const Seq& s)
		: h(sz(s)+1), p(sz(s)+1,array<ll,2>{1,1}) {
		for (int i = 0; i < sz(s); ++i)
			for (int k = 0; k < 2; ++k) {
				ll x = (ll)s[i]%mod[k];
				if (x < 0) x += mod[k];
				h[i+1][k] = (h[i][k]*A+x)%mod[k];
				p[i+1][k] = p[i][k]*A%mod[k];
			}
	}
	array<ll,2> get(int l, int r) const {
		assert(0 <= l && l <= r && r < sz(h));
		array<ll,2> ans;
		for (int k = 0; k < 2; ++k)
			ans[k] = (h[r][k]-h[l][k]*p[r-l][k]%mod[k]
				+mod[k])%mod[k];
		return ans;
	}
	array<ll,2> concat(array<ll,2> x,
			array<ll,2> y, int lenY) const {
		assert(0 <= lenY && lenY < sz(p));
		for (int k = 0; k < 2; ++k)
			x[k] = (x[k]*p[lenY][k]+y[k])%mod[k];
		return x;
	}
};
