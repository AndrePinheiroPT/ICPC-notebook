/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item z[i]: LCP of s and suffix s[i,n).
 *  Convention z[0]=0; empty input gives empty.
 *  \item $O(n)$ time/space; equality only.
 *  \end{itemize}
 */
#pragma once

template<class S> vi zFunction(const S& s) {
	int n = sz(s), l = 0, r = 0;
	vi z(n);
	for (int i = 1; i < n; ++i) {
		if (i < r) z[i] = min(r-i,z[i-l]);
		while (z[i] < n-i && s[z[i]] == s[i+z[i]])
			++z[i];
		if (i+z[i] > r) l = i, r = i+z[i];
	}
	return z;
}
