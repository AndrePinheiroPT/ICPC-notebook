/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item First index of the smallest rotation;
 *  empty input gives 0. char uses unsigned-byte
 *  order; other element types use their order.
 *  \item $O(n)$ time, $O(1)$ extra space.
 *  \end{itemize}
 * Usage: int k = leastRotation(s); // string/vector s
 *  // smallest rotation starts at index k
 */
#pragma once

template<class S>
int leastRotation(const S& s) {
	int n = sz(s);
	ll i = 0, j = 1, k = 0;
	auto at = [&](ll pos) {
		auto c = s[size_t(pos%n)];
		if constexpr (is_same_v<decltype(c),char>)
			return (unsigned char)c;
		else return c;
	};
	while (i < n && j < n && k < n) {
		auto a = at(i+k), b = at(j+k);
		if (a == b) { ++k; continue; }
		if (b < a) {
			i += k+1;
			if (i <= j) i = j+1;
		} else {
			j += k+1;
			if (j <= i) j = i+1;
		}
		k = 0;
	}
	return n ? int(min(i,j)) : 0;
}
