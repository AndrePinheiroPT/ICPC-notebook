/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item add returns a pattern ID; duplicates
 *  get distinct IDs. Alphabet $[BASE,BASE+K)$.
 *  Add only before build; build exactly once.
 *  \item After build: go advances the state;
 *  count gives matching suffixes, report visits
 *  their IDs. Empty patterns match each boundary,
 *  including initial state 0 before any input.
 *  \item add $O(K(|s|+1))$ amortized;
 *  V nodes/P patterns: build/space
 *  $O(KV+P)$; go/count $O(1)$; report $O(1+out)$.
 *  Output lists are not copied along suffix links.
 *  \end{itemize}
 * Usage: Aho<> a; int id = a.add(pattern); a.build();
 *  int v = 0; v = a.go(v,ch); // read one byte
 *  int hits = a.count(v); // patterns ending here
 *  a.report(v,emit); // emit(id) receives each match
 */
#pragma once

template<int K = 26, int BASE = 'a'>
struct Aho {
	static_assert(BASE >= 0 && K > 0 &&
		K <= 256-BASE);
	struct Node {
		array<int,K> next;
		int link = 0, out = -1, cnt = 0;
		vi ids;
		Node() { next.fill(-1); }
	};
	vector<Node> t = vector<Node>(1);
	int patterns = 0;
	bool built = false;
	int code(unsigned char ch) const {
		int c = int(ch)-BASE;
		assert(0 <= c && c < K); return c;
	}
	int add(string_view s) {
		assert(!built);
		int v = 0;
		for (unsigned char ch : s) {
			int c = code(ch), u = t[v].next[c];
			if (u < 0) {
				t[v].next[c] = u = sz(t);
				t.emplace_back();
			}
			v = u;
		}
		t[v].ids.push_back(patterns);
		++t[v].cnt;
		return patterns++;
	}
	void build() {
		assert(!built); built = true;
		queue<int> q; q.push(0);
		while (!q.empty()) {
			int v = q.front(); q.pop();
			if (v) {
				int p = t[v].link;
				t[v].out = t[p].ids.empty() ?
					t[p].out : p;
				t[v].cnt += t[p].cnt;
			}
			for (int c = 0; c < K; ++c) {
				int u = t[v].next[c];
				int w = v ? t[t[v].link].next[c] : 0;
				if (u < 0) t[v].next[c] = w;
				else t[u].link = w, q.push(u);
			}
		}
	}
	int go(int v, unsigned char ch) const {
		assert(built); return t[v].next[code(ch)];
	}
	int count(int v) const {
		assert(built); return t[v].cnt;
	}
	template<class F>
	void report(int v, F f) const {
		assert(built);
		for (int u = v; u >= 0; u = t[u].out)
			for (int id : t[u].ids) f(id);
	}
};
