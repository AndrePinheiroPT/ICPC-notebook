/**
 * Author: supplied by user
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Fixed lowercase a-z trie. add inserts;
 *  find/prefix return bool; get\_node returns
 *  node ID or -1. Duplicates are idempotent.
 *  Empty prefix always exists; empty word can
 *  be inserted. Root 0 counts towards capacity.
 *  \item At most 200005 nodes; assertions check
 *  alphabet/capacity. Init/space $O(MAX\cdot26)$;
 *  each operation $O(|s|+1)$.
 *  \end{itemize}
 */
#pragma once

struct TRIE {
	static constexpr int MAX_TRIE_SZ = 200'005;
	static constexpr int ALPHA = 26;
	static constexpr char FIRST = 'a';
	vector<array<int,ALPHA>> t;
	vector<char> end;
	int idx;
	TRIE() : t(MAX_TRIE_SZ),
		end(MAX_TRIE_SZ,false), idx(1) {}
	void add(const string& s) {
		int i = 0;
		for (char c : s) {
			int x = c - FIRST;
			assert(0 <= x && x < ALPHA);
			if (t[i][x] == 0) {
				assert(idx < MAX_TRIE_SZ);
				t[i][x] = idx++;
			}
			i = t[i][x];
		}
		end[i] = true;
	}
	int get_node(const string& s) const {
		int i = 0;
		for (char c : s) {
			int x = c - FIRST;
			assert(0 <= x && x < ALPHA);
			if (t[i][x] == 0) return -1;
			i = t[i][x];
		}
		return i;
	}
	bool find(const string& s) const {
		int i = get_node(s);
		return i != -1 && end[i];
	}
	bool prefix(const string& s) const {
		return get_node(s) != -1;
	}
};
