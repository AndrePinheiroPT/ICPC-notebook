/**
 * Author: jet notebook
 * Source: CPH, chapter 28 (lazy propagation).
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Range add and range sum on $[l,r)$.
 *   \item Build $O(n)$; add/query $O(\log n)$; space $O(n)$.
 *   \end{itemize}
 */
#pragma once

template<class T> struct LazySegTree {
	int n;
	vector<T> s, lz;
	LazySegTree(const vector<T>& a) : n(sz(a)),
		s(4*n), lz(4*n) {
		if (n) build(1, 0, n, a);
	}
	void build(int p, int l, int r,
			const vector<T>& a) {
		if (r-l == 1) { s[p] = a[l]; return; }
		int m = l + (r-l)/2;
		build(2*p,l,m,a); build(2*p+1,m,r,a);
		s[p] = s[2*p] + s[2*p+1];
	}
	void apply(int p, int len, T x) {
		s[p] += x*len; lz[p] += x;
	}
	void push(int p, int l, int r) {
		if (lz[p] == 0) return;
		int m = l + (r-l)/2;
		apply(2*p, m-l, lz[p]);
		apply(2*p+1, r-m, lz[p]);
		lz[p] = 0;
	}
	void add(int l, int r, T x,
			int p, int a, int b) {
		if (r <= a || b <= l || l == r) return;
		if (l <= a && b <= r) {
			apply(p,b-a,x); return;
		}
		push(p,a,b);
		int m = a + (b-a)/2;
		add(l,r,x,2*p,a,m); add(l,r,x,2*p+1,m,b);
		s[p] = s[2*p] + s[2*p+1];
	}
	void add(int l, int r, T x) {
		add(l,r,x,1,0,n);
	}
	T query(int l, int r, int p, int a, int b) {
		if (r <= a || b <= l || l == r) return 0;
		if (l <= a && b <= r) return s[p];
		push(p,a,b);
		int m = a + (b-a)/2;
		return query(l,r,2*p,a,m)
			+ query(l,r,2*p+1,m,b);
	}
	T query(int l, int r) {
		return query(l,r,1,0,n);
	}
};
