/**
 * Author: Angelo Fernandes
 * Date: 2026-8-31
 * License: no licence
 * Source: eu
 * Description: Zero-indexed dual segment tree supporting range updates and point queries.
 * Update bounds are inclusive to the left and exclusive to the right.
 * Can be changed by modifying T, f and unit; f must be associative and commutative.
 * Time: O(\log N)
 * Status: stress-tested
 */
#pragma once

struct DualSegTree {
	typedef long long T;
	static constexpr T unit = 0;
	T f(T a, T b) { return a + b; } // any commutative associative fn
	vector<T> s; int n;
	DualSegTree(int m = 0, T def = unit) : s(2*m, unit), n(m) {
		fill(s.begin() + n, s.end(), def);
	}
	void update(int a, int b, T val) { // update [a, b)
		for (a += n, b += n; a < b; a /= 2, b /= 2) {
			if (a % 2) { s[a] = f(s[a], val); a++; }
			if (b % 2) { --b; s[b] = f(s[b], val); }
		}
	}
	T query(int pos) {
		T res = unit;
		for (pos += n; pos >= 1; pos /= 2) res = f(res, s[pos]);
		return res;
	}
};