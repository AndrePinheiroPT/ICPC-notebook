/**
 * Author: Lukas Polacek, Simon Lindholm
 * Date: 2019-12-26
 * License: CC0
 * Source: folklore
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Disjoint sets on $[0,n)$ with undo; no path
 *   compression. No-op joins add no history.
 *   \item join(a,b) returns whether sets merged;
 *   find(x) returns its root, size(x) its set size.
 *   \item Roll back only to a snapshot of the current
 *   history, obtained with time().
 *   \item $O(\log n)$ find/join, $O(1)$ snapshot;
 *   $O(k)$ rollback for $k$ undone joins, $O(n)$ space.
 *   \end{itemize}
 * Usage: RollbackUF uf(n); int t = uf.time();
 *   uf.join(a,b); uf.rollback(t); // restore snapshot
 */
#pragma once

struct RollbackUF {
	vector<int> e; vector<pair<int,int>> st;
	RollbackUF(int n) : e(n, -1) {}
	int size(int x) { return -e[find(x)]; }
	int find(int x) { return e[x] < 0 ? x : find(e[x]); }
	int time() { return sz(st); }
	void rollback(int t) {
		for (int i = time(); i --> t;)
			e[st[i].first] = st[i].second;
		st.resize(t);
	}
	bool join(int a, int b) {
		a = find(a), b = find(b);
		if (a == b) return false;
		if (e[a] > e[b]) swap(a, b);
		st.push_back({a, e[a]});
		st.push_back({b, e[b]});
		e[a] += e[b]; e[b] = a;
		return true;
	}
};
