/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Add to $[r_1,r_2)\times[c_1,c_2)$ from zero.
 *  values() returns the grid without changing the structure.
 *  \item Add $O(1)$, values/space $O(n(m+1))$.
 *  Intermediate values must fit T.
 *  \end{itemize}
 */
#pragma once

template<class T> struct Difference2D {
	int n, m;
	vector<vector<T>> d;
	Difference2D(int rows, int cols)
		: n(rows), m(cols), d(n) {
		assert(n >= 0 && m >= 0);
		for (auto& row : d) row.resize(m);
	}
	void add(int r1, int c1, int r2, int c2,
			T delta) {
		assert(0 <= r1 && r1 <= r2 && r2 <= n);
		assert(0 <= c1 && c1 <= c2 && c2 <= m);
		if (r1 == r2 || c1 == c2) return;
		d[r1][c1] += delta;
		if (r2 < n) d[r2][c1] -= delta;
		if (c2 < m) d[r1][c2] -= delta;
		if (r2 < n && c2 < m) d[r2][c2] += delta;
	}
	vector<vector<T>> values() const {
		auto a = d;
		for (int r = 0; r < n; ++r)
			for (int c = 0; c < m; ++c) {
				if (r) a[r][c] += a[r-1][c];
				if (c) a[r][c] += a[r][c-1];
				if (r && c) a[r][c] -= a[r-1][c-1];
			}
		return a;
	}
};
