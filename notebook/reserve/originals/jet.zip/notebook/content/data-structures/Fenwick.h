/**
 * Author: jet, zyndek; adapted for the notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Fenwick(n): n>=0, initially zero.
 *  \item add(i,x) adds x; query(r)/query(l,r)
 *  return sums on $[0,r)$/$[l,r)$. Public indices
 *  are 0-based; the internal tree is 1-based.
 *  \item Build/space $O(n)$; operations $O(\log n)$.
 *  Intermediate values and sums must fit T.
 *  \end{itemize}
 */
#pragma once

template<class T> struct Fenwick {
	int n;
	vector<T> t;
	Fenwick(int m = 0) : n(m), t(size_t(m)+1) {}
	void add(int i, T delta) {
		assert(0 <= i && i < n);
		for (ll k = ll(i)+1; k <= n; k += k & -k)
			t[k] += delta;
	}
	T query(int r) const {
		assert(0 <= r && r <= n);
		T ans{};
		for (; r > 0; r -= r & -r) ans += t[r];
		return ans;
	}
	T query(int l, int r) const {
		assert(0 <= l && l <= r && r <= n);
		return query(r) - query(l);
	}
};
