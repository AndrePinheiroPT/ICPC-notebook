/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Offline connectivity; edge lifetimes $[l,r)$.
 *   For repeated edges, add one interval per active copy.
 *   \item n vertices, Q times; $0\le l\le r\le Q$.
 *   add(l,r,u,v) activates edge u-v; run(f) returns
 *   void and calls f(t,uf) for each time $t\in[0,Q)$.
 *   \item I intervals, Q times: $O(n+Q+I\log Q\log n)$
 *   plus callbacks; space $O(n+Q+I\log Q)$.
 *   \end{itemize}
 * Usage: DynamicConnectivity dc(n,Q); dc.add(l,r,u,v);
 *   dc.run(f); // f(t,uf) queries find/size only
 */
#pragma once
#include "UnionFindRollback.h"

struct DynamicConnectivity {
	int q, n = 1;
	RollbackUF uf;
	vector<vector<pair<int,int>>> s;
	DynamicConnectivity(int N, int Q)
		: q(Q), uf(N) {
		while (n < q) n *= 2;
		s.resize(2*n);
	}
	void add(int l, int r, int u, int v) {
		for (l += n, r += n; l < r; l /= 2, r /= 2) {
			if (l & 1) s[l++].push_back({u,v});
			if (r & 1) s[--r].push_back({u,v});
		}
	}
	template<class F> void dfs(int k, F& f) {
		int t = uf.time();
		for (auto [u,v] : s[k]) uf.join(u,v);
		if (k >= n) {
			if (k-n < q) f(k-n,uf);
		} else {
			dfs(2*k,f); dfs(2*k+1,f);
		}
		uf.rollback(t);
	}
	template<class F> void run(F f) { dfs(1,f); }
};
