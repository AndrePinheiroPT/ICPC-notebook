/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item nextGreater(v): next index j>i with v[j]>v[i],
 *  or -1, for each i. Equal values are skipped.
 *  \item Time/space $O(n)$.
 *  \end{itemize}
 */
#pragma once

template<class T>
vector<int> nextGreater(const vector<T>& v) {
	vector<int> ans(v.size(), -1), st;
	for (int i = 0; i < (int)v.size(); ++i) {
		while (!st.empty() && v[st.back()] < v[i]) {
			ans[st.back()] = i; st.pop_back();
		}
		st.push_back(i);
	}
	return ans;
}
