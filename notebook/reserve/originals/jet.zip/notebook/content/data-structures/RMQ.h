/**
 * Author: Johan Sannemo, pajenegod
 * License: CC0
 * Source: KACTL; operation generalized.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Static queries on nonempty $[l,r)$; default min.
 *  \item $n<2^{30}$; build/space $O(n\log n)$, query $O(1)$.
 *  \end{itemize}
 */
#pragma once

template<class T> struct STMin {
	T operator()(const T& a, const T& b) const {
		return min(a,b); // associative + idempotent
	}
};

template<class T, class F = STMin<T>> struct RMQ {
	F f;
	vector<vector<T>> jmp;
	RMQ(const vector<T>& v, F op = F())
		: f(op), jmp(1,v) {
		for (int k = 1; (1 << k) <= sz(v); k++) {
			jmp.emplace_back(sz(v) - (1 << k) + 1);
			for (int i = 0; i < sz(jmp[k]); i++)
				jmp[k][i] = f(jmp[k-1][i],
					jmp[k-1][i + (1 << (k-1))]);
		}
	}
	T query(int l, int r) const { // [l,r)
		assert(0 <= l && l < r && r <= sz(jmp[0]));
		int k = __lg(r-l);
		return f(jmp[k][l], jmp[k][r - (1 << k)]);
	}
};
