/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Ordered set: \texttt{order\_of\_key(x)} gives
 *  the count strictly before x under C;
 *  \texttt{find\_by\_order(k)} gives an iterator to the 0-based kth,
 *  or end() if $k\ge size()$.
 *  \item C must be strict. For duplicates, use the
 *  default comparator and pair<T,int> with unique ids.
 *  \item $O(\log n)$ per operation, $O(n)$ space.
 *  \end{itemize}
 * Usage: OST<int> s; s.insert(x);
 *  auto rank = s.order_of_key(x);
 *  auto it = s.find_by_order(k); // check it != s.end()
 */
#pragma once

#include <ext/pb_ds/assoc_container.hpp> /** keep-include */
#include <ext/pb_ds/tree_policy.hpp> /** keep-include */

template<class T, class C = less<T>>
using OST = __gnu_pbds::tree<T,
	__gnu_pbds::null_type, C,
	__gnu_pbds::rb_tree_tag,
	__gnu_pbds::tree_order_statistics_node_update>;
