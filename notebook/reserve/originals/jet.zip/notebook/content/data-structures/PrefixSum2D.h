/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Static sums on $[r_1,r_2)\times[c_1,c_2)$.
 *  Input must have exactly n rows and m columns.
 *  \item Build/space $O((n+1)(m+1))$, query $O(1)$.
 *  Intermediate sums must fit T.
 *  \end{itemize}
 */
#pragma once

template<class T> struct PrefixSum2D {
	int n, m;
	vector<vector<T>> p;
	PrefixSum2D(int rows, int cols,
		const vector<vector<T>>& a)
		: n(rows), m(cols), p(n+1, vector<T>(m+1)) {
		assert(n >= 0 && m >= 0 && sz(a) == n);
		for (int r = 0; r < n; ++r) {
			assert(sz(a[r]) == m);
			for (int c = 0; c < m; ++c)
				p[r+1][c+1] = a[r][c] + p[r][c+1]
					+ p[r+1][c] - p[r][c];
		}
	}
	T query(int r1, int c1, int r2, int c2) const {
		assert(0 <= r1 && r1 <= r2 && r2 <= n);
		assert(0 <= c1 && c1 <= c2 && c2 <= m);
		return p[r2][c2] - p[r1][c2]
			- p[r2][c1] + p[r1][c1];
	}
};
