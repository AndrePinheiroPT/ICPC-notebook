/**
 * Author: Lucian Bicsi
 * Date: 2017-10-31
 * License: CC0
 * Source: folklore
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Point assignment and range maximum on $[l,r)$.
 *   \item Update/query $O(\log n)$; space $O(n)$.
 *   \end{itemize}
 * Status: stress-tested
 */
#pragma once

struct SegTree {
	typedef int T;
	static constexpr T unit = INT_MIN;
	T f(T a, T b) { return max(a, b); } // (any associative fn)
	vector<T> s; int n;
	SegTree(int m = 0, T def = unit) : s(2*m, def), n(m) {}
	void update(int pos, T val) {
		s[pos += n] = val;
		for (pos /= 2; pos >= 1; pos /= 2)
			s[pos] = f(s[pos * 2], s[pos * 2 + 1]);
	}
	T query(int a, int b) { // query [a, b)
		T ra = unit, rb = unit;
		for (a += n, b += n; a < b; a /= 2, b /= 2) {
			if (a % 2) ra = f(ra, s[a++]);
			if (b % 2) rb = f(s[--b], rb);
		}
		return f(ra, rb);
	}
};
