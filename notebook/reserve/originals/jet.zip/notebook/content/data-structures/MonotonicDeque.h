/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item slidingMin(v,k): minimum of each window of
 *  size k, left to right. Requires k>0; empty if k>n.
 *  \item Time $O(n)$; auxiliary space $O(\min(n,k))$.
 *  \end{itemize}
 */
#pragma once

template<class T>
vector<T> slidingMin(const vector<T>& v, int k) {
	assert(k > 0);
	deque<int> dq;
	vector<T> ans;
	for (int i = 0; i < (int)v.size(); ++i) {
		while (!dq.empty() && dq.front() <= i-k)
			dq.pop_front();
		while (!dq.empty() && v[dq.back()] >= v[i])
			dq.pop_back();
		dq.push_back(i);
		if (i >= k-1) ans.push_back(v[dq.front()]);
	}
	return ans;
}
