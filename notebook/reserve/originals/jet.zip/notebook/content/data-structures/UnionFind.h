/**
 * Author: Lukas Polacek
 * Date: 2009-10-26
 * License: CC0
 * Source: folklore
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Disjoint sets on $[0,n)$; join returns whether
 *   two components merged. Path compression, union by size.
 *   \item Amortized $O(\alpha(n))$ per operation;
 *   $O(n)$ construction and space.
 *   \end{itemize}
 */
#pragma once

struct UF {
	vector<int> e;
	UF(int n) : e(n, -1) {}
	bool sameSet(int a, int b) { return find(a) == find(b); }
	int size(int x) { return -e[find(x)]; }
	int find(int x) { return e[x] < 0 ? x : e[x] = find(e[x]); }
	bool join(int a, int b) {
		a = find(a), b = find(b);
		if (a == b) return false;
		if (e[a] > e[b]) swap(a, b);
		e[a] += e[b]; e[b] = a;
		return true;
	}
};
