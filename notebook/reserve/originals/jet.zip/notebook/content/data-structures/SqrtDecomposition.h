/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Point assignment and counts of $a_i<x$ in
 *  $[l,r)$ using sorted blocks; new values are allowed.
 *  Construct from values; set(i,x) assigns a[i]=x;
 *  countLess(l,r,x) returns the count. T is ordered.
 *  \item $B\approx\sqrt n$: build $O(n\log B)$,
 *  set $O(B)$, query $O(B+(n/B)\log B)$, space $O(n)$.
 *  \end{itemize}
 * Usage: SqrtDecomposition<ll> d(a); d.set(i,x);
 *  int count = d.countLess(l,r,x);
 */
#pragma once

template<class T> struct SqrtDecomposition {
	int n, len;
	vector<T> a;
	vector<vector<T>> b;
	SqrtDecomposition(const vector<T>& v = {})
		: n(sz(v)), len(max(1, int(sqrt(n)))), a(v),
		  b((n+len-1)/len) {
		for (int i = 0; i < n; ++i)
			b[i/len].push_back(a[i]);
		for (auto& v1 : b)
			sort(v1.begin(), v1.end());
	}
	void set(int i, T x) {
		assert(0 <= i && i < n);
		auto& v = b[i/len];
		v.erase(lower_bound(v.begin(), v.end(),
			a[i]));
		v.insert(lower_bound(v.begin(), v.end(),
			x), x);
		a[i] = x;
	}
	int countLess(int l, int r, const T& x) const {
		assert(0 <= l && l <= r && r <= n);
		int ans = 0;
		while (l < r) {
			if (l % len == 0 && r-l >= len) {
				const auto& v = b[l/len];
				auto it = lower_bound(v.begin(),
					v.end(), x);
				ans += int(it-v.begin());
				l += len;
			} else {
				ans += a[l] < x;
				++l;
			}
		}
		return ans;
	}
};
