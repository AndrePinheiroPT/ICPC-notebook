/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Compressed 2D additions/sums. Register all
 *  update points in the constructor; query bounds are free.
 *  add(x,y,v) adds v at a registered point, from zero.
 *  \item query(X,Y) sums $x<X,y<Y$; rectangles use
 *  $[x_1,x_2)\times[y_1,y_2)$. Coordinates have type C;
 *  sums and intermediate values must fit T.
 *  \item For m registered points: build $O(m\log^2 m)$,
 *  space $O(m\log m)$, add/query $O(\log^2 m)$.
 *  \end{itemize}
 * Usage: Fenwick2D<ll, ll> f(points); f.add(x,y,v);
 *  ll sum = f.query(x1,y1,x2,y2);
 */
#pragma once
#include "Fenwick.h"

template<class T, class C = int>
struct Fenwick2D {
	vector<C> xs;
	vector<vector<C>> ys;
	vector<Fenwick<T>> ft;
	static int pos(const vector<C>& v, C x) {
		return int(lower_bound(v.begin(), v.end(), x)
			- v.begin());
	}
	Fenwick2D(vector<pair<C,C>> p = {}) {
		sort(p.begin(), p.end());
		p.erase(unique(p.begin(), p.end()), p.end());
		for (auto [x,y] : p) xs.push_back(x);
		xs.erase(unique(xs.begin(), xs.end()),
			xs.end());
		ys.resize(sz(xs));
		for (auto [x,y] : p)
			for (int i = pos(xs,x); i < sz(xs);
				i |= i+1)
				ys[i].push_back(y);
		for (auto& v : ys) {
			sort(v.begin(), v.end());
			v.erase(unique(v.begin(), v.end()),
				v.end());
			ft.emplace_back(sz(v));
		}
	}
	void add(C x, C y, T delta) {
		for (int i = pos(xs,x); i < sz(xs);
				i |= i+1)
			ft[i].add(pos(ys[i],y), delta);
	}
	T query(C x, C y) const {
		T ans{};
		for (int i = pos(xs,x); i; i &= i-1)
			ans += ft[i-1].query(pos(ys[i-1],y));
		return ans;
	}
	T query(C x1, C y1, C x2, C y2) const {
		assert(x1 <= x2 && y1 <= y2);
		return query(x2,y2) - query(x1,y2)
			- query(x2,y1) + query(x1,y1);
	}
};
