#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
const int INF = 1e9;
const long long INFLL = 1e18;
#define sz(x) (int)(x).size()

#ifdef LOCAL
template<class A, class B> ostream& operator<<(ostream& os, const pair<A, B>& p) {
    return os << '(' << p.first << ',' << p.second << ')';
}
template<class T> ostream& operator<<(ostream& os, const vector<T>& v) {
    os << '[';
    for (int i = 0; i < sz(v); i++) os << (i ? "," : "") << v[i];
    return os << ']';
}
#define DEBUG(x) do { cerr << #x << " = " << x << '\n'; } while (0)
#else
#define DEBUG(x) ((void)0)
#endif

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

}
