# jet Notebook Changelog

> Local changes relative to the original KACTL notebook.

## 1. Added DSU

- Added a **Disjoint Set Union (Union-Find)** implementation.

## 2. Standardized shorthand

Removed the following macros and type aliases, expanding all their usages:

| Shorthand | Replacement |
|---|---|
| `rep(i, a, b)` | `for (int i = a; i < b; i++)` |
| `all(x)` | `x.begin(), x.end()` |
| `pii` | `pair<int,int>` |
| `vi` | `vector<int>` |

## 3. Updated `SegmentTree.h`

- Rewrote `update(int pos, T val)` for clarity while preserving its behavior and generality.
- Renamed the query bounds from `[b, e)` to `[a, b)`.

## 4. Updated `RMQ.h`

- Rewrote the sparse table construction for clarity while preserving generic value types and compact per-level storage.
- Replaced `31 - __builtin_clz(...)` with `__lg(...)`.
- Added complete bounds validation to `query(int l, int r)`, preserving the `[l, r)` convention.

## 5. Added `DualSegmentTree.h`

- Added a zero-indexed **Dual Segment Tree** supporting range updates over `[l, r)` and point queries.
- Made the operation configurable through `T`, `f`, and `unit`, requiring `f` to be associative and commutative.
- Added exhaustive and randomized stress tests against a brute-force implementation.