# Capítulo 4 — Numerical

> Registo histórico desta entrega. Para os contratos e alterações posteriores,
> ver [REVISION-ALGORITHMS.md](REVISION-ALGORITHMS.md).

Estado desta entrega: capítulos 1–4 implementados. As etapas anteriores
em `CHAPTERS-01-02.md` e `CHAPTER-03.md` são registos históricos.
Regras: `NOTEBOOK-RULES.md`.

## Conteúdo impresso

- `BinarySearch.h`: first true / last true em `[l,r)`; ausência por r
  ou optional vazio, sem sentinelas que transbordam nos extremos.
- `Bisection.h`: fronteira real de um predicado monotónico, lado true.
- `GoldenSearch.h`: mínimo aproximado de função unimodal contínua.
- `Gauss.h`: sistema real retangular com pivotamento parcial e tolerância.
- `GaussBinary.h`: sistema retangular sobre GF(2), usando bitset.
- `GaussMod.h`: sistema retangular módulo primo, entradas normalizadas.
- `Matrix.h`: produto e potência de matrizes quadradas, com ou sem módulo.
- `NTT.h`: transformada e convolução módulo 998244353, tamanho até 2^23.
- `ModPower.h`: dependência partilhada de GaussMod e NTT; reutilizar no 5.

Os três solvers recebem a matriz aumentada, modificam-na e devolvem rank
ou -1 se incompatível; uma solução fica em x, com variáveis livres zero.
No solver real, rank/compatibilidade dependem de eps e da escala; entradas
e intermediários devem ser finitos. Não garante estabilidade em sistemas
mal condicionados. Os testes usam referências exatas para os casos
adequadamente condicionados, e casos explícitos para o contrato de eps.

Não se imprimem variantes antigas de FFT, inversão, interpolação,
integração ou simplex. Os headers legados ficam no ZIP para não quebrar
capítulos ainda por rever. O formato global não foi alterado.

## Verificação

```sh
ASAN_OPTIONS=detect_leaks=0 RUN_MAX=1 bash doc/scripts/test-chapter-04.sh
```

Requer g++ com GNU++20 e headers Boost para os oráculos exatos.
Se Boost estiver fora dos includes normais, definir BOOST_INCLUDEDIR.

- Integração dos 9 headers com o preâmbulo real de Contest.
- Release e ASan/UBSan com STL debug; LeakSanitizer desligado por ptrace.
- Search/ModPower: 427375 verificações, incluindo extremos inteiros,
  unsigned, precisão real e comparação modular com cpp_int.
- Gauss: 2360 sistemas reais e 19816 modulares; referência racional exata,
  enumeração modular, matrizes vazias, livres e inconsistentes.
- GF(2): 11084 sistemas; 368607 atribuições de referência por força bruta.
- Matrizes: 16877 potências e 132682 entradas verificadas, com tipos
  integrais/reais, moduli grandes e referências de inteiros exatos.
- NTT: 1794 convoluções e 216 transformadas diretas/roundtrip; 1105043
  coeficientes comparados por configuração. Teste máximo adicional em
  release: 9493651 coeficientes no conjunto, incluindo saída com 2^23.

As contagens usam granularidades distintas; não são somadas como casos
independentes. Logs e resultado de layout: `validation/chapter-04*`.
