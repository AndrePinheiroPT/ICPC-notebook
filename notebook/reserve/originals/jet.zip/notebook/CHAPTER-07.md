# Capítulo 7 — Graph

> Registo histórico desta entrega. Para os contratos e alterações posteriores,
> ver [REVISION-ALGORITHMS.md](REVISION-ALGORITHMS.md).

Estado desta entrega: capítulos 1–7 implementados/revistos.
Regras em NOTEBOOK-RULES.md; capítulos 8 em diante continuam por rever.

## Seleção e implementação

- Caminhos mínimos: Dijkstra, 0–1 BFS, Bellman–Ford e Floyd–Warshall.
  Dijkstra e 0–1 BFS aceitam várias fontes; as notas cobrem agrupar
  consultas, inverter arestas, terminar no destino e reconstruir caminhos.
- Kahn e nota de DP em DAG; Kruskal reutiliza o UF original do capítulo 3.
- SCC e DAG de condensação, bridges/articulações, 2-SAT e Hierholzer.
  SCC, lowlink e percursos eulerianos são iterativos.
- Dinic com corte mínimo, fluxo de custo mínimo com potenciais,
  Hopcroft–Karp com vertex cover mínimo e Gale–Shapley.
- Binary lifting, Euler tour de subárvores, LCA, HLD e diâmetro de árvore.
  TreeTour é partilhado por LCA e HLD; LCA reutiliza JumpTable. HLD emite
  intervalos para reutilizar SegTree/LazySegTree, sem duplicar estruturas.
- Notas breves de grafos de estados, capacidades em vértices, tree DP e
  rerooting. BFS/DFS elementares continuam tomados como garantidos.

São 19 headers selecionados. Os headers antigos de Graph continuam no
ZIP, intactos, mas não são impressos. Não se adicionaram variantes como
Gomory–Hu, global min cut, matching geral, link-cut tree ou centroid
decomposition.

## Contratos principais

- Índices públicos em [0,V), intervalos de árvores em [l,r). Cada header
  identifica se recebe grafo dirigido, não dirigido ou árvore.
- Dijkstra: pesos integrais não negativos; distâncias pretendidas < inf.
  Evita overflow na relaxação. 0–1 BFS aceita apenas pesos 0 e 1.
  Ambos devolvem distância à fonte mais próxima, não uma linha por fonte.
- Bellman–Ford: pesos int/ll com sinal; +inf significa inalcançável e
  -inf significa custo sem limite inferior por ciclo negativo alcançável.
  Distâncias finitas devem estar estritamente entre -inf e inf. Usa
  __int128 internamente para não perder ciclos por saturação prematura.
- Floyd: matriz quadrada, mínimo entre arestas paralelas, inf para
  ausência; V*max|peso| < inf. A diagonal é ajustada para permitir caminho
  vazio. Propaga -inf nos pares afetados por ciclos negativos.
- Kahn devolve um prefixo com menos de V elementos se há ciclo.
  Kruskal devolve uma floresta mínima, o peso e os IDs das arestas;
  V menos o número de arestas escolhidas dá o número de componentes.
- SCC: IDs crescem ao longo das arestas da condensação, sem duplicados.
  Lowlink usa IDs de arestas para suportar paralelas e self-loops.
- 2-SAT: literal 2v é v, 2v+1 é a sua negação; xor 1 nega qualquer
  literal. answer só é válido depois de solve devolver true.
- Hierholzer: devolve vértices e IDs de arestas; valida graus, origem
  e cobertura. Falha devolve dois vetores vazios. Sem arestas e com
  origem válida, devolve apenas essa origem.
- Dinic: capacidades integrais não negativas, s diferente de t;
  capacidades e fluxo total cabem em T. flow devolve fluxo adicional.
  Depois da chamada completa, lev >= 0 identifica o lado de s no corte.
  DFS recursiva requer stack suficiente para profundidade O(V).
- MinCostFlow: fluxo adicional limitado por lim, devolvendo fluxo/custo.
  C é inteiro com sinal. Não pode haver ciclo de custo negativo no
  residual, mesmo desconexo; cada chamada reconstrói potenciais. Toda
  a aritmética deve caber nos tipos; fluxo de cada aumento cabe em C,
  custos/distâncias/potenciais têm magnitude inferior ao INF interno.
- Matching: lados [0,n) e [0,m); cover só depois de solve e antes de
  alterar o grafo. DFS do Hopcroft–Karp é recursiva. Gale–Shapley exige
  lados do mesmo tamanho e preferências completas, estritas; o resultado
  é ótimo para os proponentes.
- JumpTable: sucessores podem ser -1; 1 <= lg <= 64 e k < 2^lg.
  TreeTour/LCA/HLD recebem árvore não dirigida, com raiz configurável.
  ancestor devolve -1 quando não existe; dist conta arestas.
- HLD: intervalos disjuntos sem orientação; usar agregados comutativos.
  Em modo edges, cada aresta fica no tin do filho e o LCA é excluído.
  Agregados não comutativos exigem tratamento adicional de direção.
- Diâmetro: pesos não negativos, somas de caminhos cabem em T.
  Árvore vazia devolve (0,-1,-1); com pesos zero os extremos podem coincidir.

## Testes

```sh
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-07.sh
```

GNU++20; sem bibliotecas externas. Compila com warnings tratados como
erros, em release e com ASan/UBSan/STL debug. LeakSanitizer fica desligado
neste ambiente por ptrace. O runner começa pela integração de todos os
headers selecionados dos capítulos 2–7 com o template real de Contest.

Por configuração:

- Caminhos/MST: 5500 grafos, 149316 distâncias, 4000 casos topológicos,
  1200 florestas e 65256 subconjuntos de arestas enumerados. Oráculos
  por enumeração de caminhos/ciclos simples, DP por número de arestas,
  DFS de ciclos e enumeração de florestas. Inclui limites de int/ll/ull,
  fontes repetidas e propagação/saturação de ciclos negativos.
- Conectividade: 5531 SCC, 5760 lowlink, 16461 2-SAT e 20962 Euler,
  além de casos estruturais de 100000 vértices/arestas. Oráculos por
  alcançabilidade, remoção de arestas/vértices, atribuições booleanas
  e percursos por subconjuntos de arestas.
- Fluxos/matching: 1806 Dinic, 957 custo mínimo, 1471 matching/cover,
  281 Gale–Shapley; 34960 pareamentos completos enumerados e 99376
  verificações. Oráculos por cortes, enumeração de fluxos, matching,
  covers e estabilidade. Inclui rerouting residual, chamadas repetidas,
  self-loops, paralelas, componentes desconexas e custos totais grandes.
- Árvores: 1857229 verificações, 401299 saltos, 93117 pares LCA/distância,
  216438 consultas de caminhos e 757 diâmetros. Oráculos por caminhos
  explícitos, subárvores e todos os pares; HLD testado com as duas segment
  trees do capítulo 3, em vértices e arestas. Cadeia de 100000 vértices,
  raiz interna, sucessores cíclicos e saltos de 64 bits incluídos.

As contagens têm granularidades diferentes e não são somadas como casos
independentes. Resultados completos em validation/chapter-07-tests.log.
Revisões independentes não identificaram defeitos funcionais. O estilo
global e todos os conteúdos fora deste capítulo foram preservados.
