# Notebook D — mudanças relativamente a C

Base: `notebookC.zip`, consultando A e as soluções autorizadas de zyndek.
Os arquivos originais e as soluções não foram alterados. Os relatórios antigos
que acompanham o projeto são histórico de B/C; este relatório descreve D.

## Conteúdo e interfaces

| Área | C → D |
|---|---|
| Dijkstra | Agora devolve `(dist,parent)`; distâncias `ll`, fila explícita, entradas antigas ignoradas e soma protegida pelo limite `inf`. Pais só em melhorias estritas. |
| 0–1 BFS | Preserva várias origens; devolve distâncias e pais; remove entradas antigas da deque. |
| Percursos | Novo `Traversal.h`: BFS de uma/várias origens, coloring bipartido de todas as componentes e `restorePath(s,t,parent)`. Inclui deteção de self-loops. |
| Pais e árvores | Raiz/origens com pai `-1`; nós inacessíveis também, distinguindo-os pelas distâncias. Tabelas `jmp[k][v]`. Percursos de árvore continuam iterativos. |
| SCC / 2-SAT | Kosaraju iterativo devolve `comp`; condensação opcional num helper separado, sem arestas repetidas. IDs crescem nas arestas do DAG; `TwoSAT` foi adaptado. |
| Stable matching | Gale–Shapley com fila e `S <= T`, listas completas e estritas. Devolve o parceiro de cada proponente; recetores podem ficar livres. |
| Binary search | `firstTrue` / `lastTrue`, domínio público `[l,r)`, midpoint em 128 bits e `optional<ll>`: `nullopt` quando não existe resposta. Não chama o predicado fora do domínio. |
| Fenwick | Mantém `Fenwick<T>`, `add` e ambas as `query`, incluindo dependência Fenwick2D. Acrescenta `lowerBound(s)` por binary lifting sobre somas prefixo. |
| Matrizes | Troca `Mat` de dimensão fixa por `matMul` / `matPow` sobre vetores, dimensão/módulo em runtime e produtos em 128 bits. Nota de adaptação sem módulo. |
| Gauss modular | Gauss–Jordan com matriz por valor, normalização inicial e vetor `where`; devolve rank, ou `-1` se inconsistente; variáveis livres ficam a zero. |
| Combinações | `fact`, `invfact`, `choose`; preserva primo configurável e multiplicação segura. Binomial exato permanece separado. |
| Trie | Nós dinâmicos, contagem de palavras/prefixos e duplicados; deixa de ter limite fixo de 200005 nós e inserções idempotentes. |
| Double hash | Duas bases aleatórias comuns, potências partilhadas extensíveis, chave com comprimento, concatenação e bytes unsigned. Inteiros arbitrários de 64 bits requerem compressão conjunta prévia. |
| Subset sum | Recupera `bitset`: `dp |= dp << x`, em vez da DP escalar de C. Explica por que cada item é usado apenas uma vez. |

## Decisões preservadas e compromissos

- Bellman–Ford foi mantido integralmente. O seu `prev` não passa a seguir
  automaticamente o contrato de `restorePath`; `-inf` também exige cuidado.
- RMQ continua genérico, mínimo por defeito, e sqrt decomposition mantém
  `countLess` e remoção/inserção no bloco. Segue o compromisso consolidado,
  em vez das primeiras propostas de redução para mínimo / mudança para `<=`.
- A pesquisa binária não replica as antigas sentinelas `(-1,n)` de A:
  a API `[0,n)` cumpre a convenção pedida agora. O domínio tem de caber
  num intervalo semiaberto de extremos `ll`; o extremo direito é excluído.
- Fenwick `lowerBound(s)` exige valores não negativos, devolve `-1` para
  `s <= 0` e `n` se a soma total for insuficiente; este método não permite
  procurar prefixos numa sequência com somas não monótonas.
- Matrizes agora são modulares e quadradas; a adaptação sem módulo é descrita,
  mas não existe um segundo template para ela. Gauss modular exige primo
  até `INT_MAX`. `ModComb` requer limite pré-calculado não superior ao primo.
- Hash permanece probabilístico. Compressão separada de sequências destrói
  comparabilidade: comprimir todos os valores em conjunto. O construtor
  rejeita tipos de 64 bits para evitar truncagem silenciosa.
- `restorePath` recebe a origem explicitamente; em multi-source deve ser a
  raiz da cadeia escolhida. Devolve vazio se a cadeia não chega a essa origem.
- NTT, Miller–Rabin, Pollard–Rho, CHT dinâmico, golden-section search e parser
  completo de `__int128` continuam impressos e nas fontes. As notas explicam
  situações de uso, inputs, outputs e auxiliares, sem afirmar que nunca saem.

## Estrutura e apresentação

Mantêm-se capítulos, ordem, tema Visual Studio Light, três colunas, fonte de
código 9 pt e setup de contest/debugger/shell. Mantêm-se as notas finais de
DP, operações de bits, complexidades e técnicas. A única nova importação de
algoritmos é `Traversal.h`. Capa reduzida ao logo UMinho, sem nomes ou data.
Para aproveitar o espaço, as técnicas finais continuam nas mesmas colunas
sem uma página nova obrigatória; o espaço entre parágrafos foi reduzido.
Não foram removidos algoritmos nem reduzidos fonte, margens ou entrelinha.

## Validação

Os resultados desta execução estão em `validation/notebookD/`; o ponto de
entrada reprodutível é `python3 doc/scripts/test-notebookD.py`.
As baterias derivadas de KACTL e as baterias próprias usam oráculos de força
bruta, implementações independentes, precisão arbitrária e casos estruturais.
Os testes de integração usam o preâmbulo real do template de contest.

Não confundir ficheiros históricos não importados pelo PDF com os headers
ativos: os primeiros foram preservados como reserva de C e não fazem parte
da garantia de cobertura desta revisão. Testes não constituem uma prova de
correção para todo o domínio; os contratos e limites documentados continuam
a aplicar-se, especialmente em geometria numérica e hashing.

### Resultados executados em 27–28 de setembro de 2026

| Bateria | Resultado | Evidência em `validation/notebookD/` |
|---|---|---|
| Contest + Math | PASS release/debug | `logs/test-chapters-01-02.sh.log` |
| Estruturas | PASS release/debug | `ch03.log` |
| Pesquisa e álgebra | PASS release/debug | `ch04.log` |
| Teoria de números | PASS release/debug | `logs/test-chapter-05.sh.log` |
| Combinatória | PASS release/debug | `ch06.log` |
| Grafos | PASS release/debug | `logs/graph-tests.log` |
| Geometria | PASS release/debug | `logs/test-chapter-08.sh.log` |
| Strings e Various | PASS release/debug | `logs/test-chapters-09-10.sh.log` |
| 86 headers isolados e combinados | PASS, preâmbulo real, warnings como erros | `logs/audit-template.py.log` |
| NTT, comprimento máximo `2^23` | PASS release | `logs/ntt-max.log` |

Casos novos incluem limites de inteiros de 64 bits, intervalos vazios,
ausência de resposta, matrizes/primos extremos, pais e caminhos com pesos
zero, SCC/árvores com 100 mil vértices, 2-SAT com 100 mil variáveis, matching
com tamanhos diferentes, trie acima de 250 mil nós e duplicados. Hash foi
também verificado com `-funsigned-char`. Detalhes nos relatórios por área.

Todos os headers ativos têm verificações comportamentais, não apenas
compilação. O stress longo de PBDS não usa `_GLIBCXX_DEBUG` por custo;
integração e testes pequenos usam-no. Capítulos 03/04 ativam warnings mas
não `-Werror`; a auditoria final de todos os headers usa `-Werror`.
Alguns algoritmos preservados, como Dinic e matching bipartido, ainda usam
DFS recursiva; D não promete ausência universal de risco de stack.

LeakSanitizer foi desativado porque o ambiente de execução usa ptrace.
AddressSanitizer, UndefinedBehaviorSanitizer, `LOCAL` e verificações STL
continuam ativos nos modos de debug das baterias. Os 86 headers ativos não
dependem de Boost; os oráculos usam-no, assim como a nota opcional de
aritmética arbitrária com `cpp_int`.

PDF final: **26 páginas**, capa com uma imagem e sem texto, 86 headers
presentes, sem caracteres fora da página. Todas as páginas foram renderizadas
e inspecionadas visualmente. As quebras automáticas de código entre linhas,
colunas e páginas seguem o modelo de C; não foram encontrados cortes ou
sobreposições. Ver `pdf-structure.json` e `pdf-visual-review.json`.
