#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/numerical/GaussBinary.h"
#include "../../content/numerical/Matrix.h"
using boost::multiprecision::cpp_int;

mt19937_64 rng(0xB1042026);
uint64_t systems = 0, assignments = 0, entries = 0, powers = 0;

template<size_t K> bool satisfies(const vector<bitset<K>>& a,
                                 int m, const vi& x) {
	if (sz(x) != m) return false;
	for (int v : x) if (v != 0 && v != 1) return false;
	for (const auto& row : a) {
		int b = 0;
		for (int c = 0; c < m; ++c) b ^= int(row[c])*x[c];
		if (b != int(row[m])) return false;
	}
	return true;
}

// Oracle enumerates all assignments; solution count also determines rank.
template<size_t K> void small(const vector<bitset<K>>& a, int m) {
	int count = 0;
	vi x(m);
	for (int mask = 0; mask < (1 << m); ++mask) {
		for (int j = 0; j < m; ++j) x[j] = (mask >> j)&1;
		count += satisfies(a,m,x); ++assignments;
	}
	auto b = a;
	int rank = gaussBinary(b,m,x);
	if (!count) assert(rank == -1);
	else {
		int want = m;
		for (int v = count; v > 1; v /= 2) --want;
		assert(rank == want);
		assert(satisfies(a,m,x));
		// Returned pivots have their columns eliminated in all other rows.
		vi pivot(m);
		for (int i = 0; i < rank; ++i) {
			int c = 0; while (c < m && !b[i][c]) ++c;
			assert(c < m); pivot[c] = 1;
			for (int j = 0; j < sz(b); ++j)
				assert(bool(b[j][c]) == (i == j));
		}
		for (int c = 0; c < m; ++c)
			if (!pivot[c]) assert(x[c] == 0);
	}
	++systems;
}

void binarySmall() {
	for (int n = 0; n <= 3; ++n) for (int m = 0; m <= 3; ++m)
		for (int mask = 0; mask < (1 << (n*(m+1))); ++mask) {
			vector<bitset<16>> a(n);
			for (int i = 0; i < n; ++i)
				for (int j = 0; j <= m; ++j)
					a[i][j] = (mask >> (i*(m+1)+j))&1;
			small(a,m);
		}
	for (int test = 0; test < 6000; ++test) {
		int n = int(rng()%12), m = int(rng()%9);
		vector<bitset<16>> a(n);
		for (auto& row : a)
			for (int j = 0; j <= m; ++j) row[j] = rng()&1;
		if (n > 1 && test%3 == 0) a[1] = a[0];
		if (n > 1 && test%7 == 0) a[1] = a[0], a[1].flip(m);
		// Bits above the augmented system have no mathematical meaning.
		for (auto& row : a) row[15] = true;
		small(a,m);
	}
	small(vector<bitset<1>>{},0);
	small(vector<bitset<1>>{bitset<1>(0)},0);
	small(vector<bitset<1>>{bitset<1>(1)},0);
}

void binaryWide() {
	for (int m : {1,63,64,65,127,128,129,255,256}) {
		vi want(m);
		for (int& x : want) x = int(rng()&1);
		vector<bitset<257>> a(m);
		// Unit lower triangular matrix: known full rank without Gaussian oracle.
		for (int i = 0; i < m; ++i) {
			a[i][i] = true;
			for (int j = 0; j < i; ++j) a[i][j] = rng()&1;
			for (int j = 0; j <= i; ++j)
				a[i][m] = bool(a[i][m]) ^ (bool(a[i][j]) && want[j]);
		}
		shuffle(a.begin(),a.end(),rng);
		a.push_back(a.front());
		a.push_back(bitset<257>{});
		auto b = a; vi x;
		assert(gaussBinary(b,m,x) == m && x == want);
		assert(satisfies(a,m,x)); ++systems;
		a.back().set(m); b = a;
		assert(gaussBinary(b,m,x) == -1); ++systems;
		// Sparse underdetermined system spans the top and bottom bits.
		a.assign(1,{}); a[0][0] = true; a[0][m-1] = true;
		a[0][m] = true; b = a;
		assert(gaussBinary(b,m,x) == 1);
		assert(satisfies(a,m,x)); ++systems;
	}
}

template<class T>
vector<vector<T>> product(const vector<vector<T>>& a,
                         const vector<vector<T>>& b, T mod) {
	int n = sz(a);
	vector<vector<T>> c(n,vector<T>(n));
	// Independent dot products, including full unsigned 64-bit moduli.
	for (int i = 0; i < n; ++i) for (int j = 0; j < n; ++j) {
		cpp_int v = 0;
		for (int k = 0; k < n; ++k) v += cpp_int(a[i][k])*b[k][j];
		c[i][j] = (v%mod).template convert_to<T>();
	}
	return c;
}

template<class T> void equal(const vector<vector<T>>& a,
                            const vector<vector<T>>& b) {
	assert(a == b); entries += a.size()*a.size();
}

template<class T> void matrices(T mod) {
	for (int n : {0,1,2,3,4}) for (int test = 0; test < 80; ++test) {
		vector<vector<T>> a(n,vector<T>(n)), b = a, id = a;
		for (int i = 0; i < n; ++i) id[i][i] = T(1)%mod;
		for (auto* mat : {&a,&b}) for (auto& row : *mat) for (T& v : row) {
			v = T(rng()%uint64_t(mod));
			if (test%4 == 0) v = mod-1;
		}
		equal(matMul(a,b,mod),product(a,b,mod));
		equal(matMul(a,id,mod),a); equal(matMul(id,a,mod),a);
		auto want = id;
		for (int p = 0; p <= 8; ++p) {
			equal(matPow(a,p,mod),want); ++powers;
			if (p < 8) want = product(want,a,mod);
		}
	}
}

template<class T> void longPowers(T mod) {
	vector<vector<T>> a{{0,1},{1,0}}, id{{1,0},{0,1}};
	for (ll p : {0LL,1LL,2LL,63LL,64LL,LLONG_MAX-1,LLONG_MAX}) {
		equal(matPow(a,p,mod),p&1 ? a : id); ++powers;
	}
}

void transitions() {
	vector<vector<ll>> a{{1,1},{1,0}};
	ll prev = 0, cur = 1;
	for (int k = 0; k <= 1000; ++k) {
		auto b = matPow(a,k,1000000007LL);
		assert(b[0][0] == cur && b[0][1] == prev);
		ll next = (prev+cur)%1000000007; prev = cur; cur = next;
		++powers; entries += 2;
	}
}

int main() {
	binarySmall(); binaryWide();
	for (int mod : {1,2,17,2147483647}) matrices(mod);
	for (ll mod : {1LL,1000000007LL,LLONG_MAX}) matrices(mod);
	matrices(ULLONG_MAX);
	longPowers(2); longPowers(LLONG_MAX); longPowers(ULLONG_MAX);
	transitions();
	cout << "MatrixBinary: " << systems << " GF2 systems, " << assignments
	     << " brute assignments, " << powers << " matrix powers, " << entries
	     << " verified matrix entries\n";
}
