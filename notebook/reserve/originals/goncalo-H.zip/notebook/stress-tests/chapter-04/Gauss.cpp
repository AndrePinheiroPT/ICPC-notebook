#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/numerical/Gauss.h"
#include "../../content/numerical/GaussMod.h"

using Rat = boost::multiprecision::cpp_rational;
mt19937_64 rng(0x47415553535f3236ULL);
unsigned long long checks = 0, realCases = 0, modCases = 0;
void check(bool ok, const char* what) {
	++checks;
	if (!ok) {
		cerr << "FAILED " << what << " at check " << checks << '\n';
		exit(1);
	}
}
int pick(int n) { return int(rng() % n); }

// Exact full-pivot Gauss-Jordan, independent of the
// floating solver's partial-pivot forward elimination.
pair<int,vector<Rat>> exact(const vector<vi>& input, int m) {
	int n = sz(input), r = 0;
	vector<vector<Rat>> a(n,vector<Rat>(m+1));
	for (int i = 0; i < n; ++i)
		for (int j = 0; j <= m; ++j) a[i][j] = input[i][j];
	vi order(m); iota(order.begin(),order.end(),0);
	while (r < n && r < m) {
		int pr = -1, pc = -1;
		for (int j = m-1; j >= r && pr < 0; --j)
			for (int i = n-1; i >= r; --i)
				if (a[i][j] != 0) { pr=i; pc=j; break; }
		if (pr < 0) break;
		swap(a[r],a[pr]);
		for (auto& row : a) swap(row[r],row[pc]);
		swap(order[r],order[pc]);
		Rat q = a[r][r];
		for (int j = 0; j <= m; ++j) a[r][j] /= q;
		for (int i = 0; i < n; ++i) if (i != r) {
			Rat f = a[i][r];
			for (int j = 0; j <= m; ++j) a[i][j] -= f*a[r][j];
		}
		++r;
	}
	vector<Rat> x(m);
	for (int i = r; i < n; ++i)
		if (a[i][m] != 0) return {-1,x};
	for (int i = 0; i < r; ++i) x[order[i]] = a[i][m];
	return {r,x};
}
template<class T>
void residual(const vector<vector<T>>& a, const vector<T>& x,
		long double tol) {
	for (const auto& row : a) {
		long double v = -static_cast<long double>(row.back());
		long double scale = 1+abs(v);
		for (int j = 0; j < sz(x); ++j) {
			long double z = static_cast<long double>(row[j])*x[j];
			v += z; scale += abs(z);
		}
		check(abs(v) <= tol*scale, "real residual");
	}
}
template<class T> void realSmall() {
	long double tol = max(1e-15L,
		2000*static_cast<long double>(numeric_limits<T>::epsilon()));
	for (int run = 0; run < 1000; ++run) {
		++realCases;
		int n = run % 6, m = (run/6) % 6;
		vector<vi> input(n,vi(m+1));
		vi planted(m);
		for (int& z : planted) z = pick(7)-3;
		for (auto& row : input) {
			for (int j = 0; j < m; ++j) row[j] = pick(7)-3;
			if (m && run % 4 == 0) row[0] = 0;
			if (m > 1 && run % 4 == 1) row[1] = row[0];
			if (run % 2) row[m] = pick(7)-3;
			else for (int j = 0; j < m; ++j) row[m] += row[j]*planted[j];
		}
		if (n > 1 && run % 5 == 0) {
			input.back() = input.front();
			if (run % 10 == 0) ++input.back()[m];
		}
		auto [want, sol] = exact(input,m);
		vector<vector<T>> a(n,vector<T>(m+1));
		for (int i = 0; i < n; ++i)
			for (int j = 0; j <= m; ++j) a[i][j] = T(input[i][j]);
		auto original = a;
		vector<T> x{T(999)};
		int got = gauss(a,m,x);
		check(got == want, "real rank vs exact rational");
		check(sz(x) == m, "real output size");
		if (got >= 0) {
			residual(original,x,tol);
			if (got == m) for (int j = 0; j < m; ++j) {
				long double v = sol[j].template convert_to<long double>();
				check(abs(static_cast<long double>(x[j])-v)
					<= tol*(1+abs(v)), "real unique rational solution");
			}
		}
	}
}
template<class T> void realPlanted() {
	long double tol = max(1e-15L,
		2000*static_cast<long double>(numeric_limits<T>::epsilon()));
	for (int run = 0; run < 180; ++run) {
		++realCases;
		int m = run % 19, n = m+run%5;
		vector<T> planted(m);
		for (T& x : planted) x = T(pick(201)-100)/8;
		vector<vector<T>> a(n,vector<T>(m+1));
		for (int i = 0; i < n; ++i) {
			T magnitude{};
			for (int j = 0; j < m; ++j) {
				a[i][j] = T(pick(21)-10);
				magnitude += abs(a[i][j]);
			}
			if (i < m) a[i][i] = magnitude+1;
			for (int j = 0; j < m; ++j) a[i][m] += a[i][j]*planted[j];
		}
		// Strictly diagonally dominant leading square block.
		reverse(a.begin(),a.end());
		auto original = a;
		vector<T> x;
		check(gauss(a,m,x) == m, "real planted full rank");
		residual(original,x,tol);
		for (int j = 0; j < m; ++j)
			check(abs(static_cast<long double>(x[j]-planted[j]))
				<= tol*(1+abs(static_cast<long double>(planted[j]))),
				"real planted solution");
	}
	vector<T> x;
	T delta = T(1e-7L);
	vector<vector<T>> near{{1,1,2},{1,1+delta,2+delta}};
	auto a = near;
	check(gauss(a,2,x,T(1e-6L)) == 1, "real absolute coarse tolerance");
	residual(near,x,1e-6L);
	a = near;
	check(gauss(a,2,x,T(1e-9L)) == 2, "real absolute fine tolerance");
	residual(near,x,1e-9L);
	vector<vector<T>> free{{0,2,4}};
	check(gauss(free,2,x) == 1 && x[0] == 0 && x[1] == 2,
		"real leading free variable");
	vector<vector<T>> bad{{0,T(1e-5L)}};
	check(gauss(bad,1,x,T(1e-6L)) == -1, "real inconsistent zero row");
	a = {{T(1e-20L),T(2e-20L)}};
	check(gauss(a,1,x,T(1e-25L)) == 1 && abs(x[0]-2) < T(1e-10L),
		"real explicit scale-adjusted tolerance");
}
int ipow(int p, int n) {
	int ans = 1;
	while (n--) ans *= p;
	return ans;
}
void modularSmall(const vector<vi>& input, int m, int p) {
	++modCases;
	int count = 0;
	for (int mask = 0; mask < ipow(p,m); ++mask) {
		int v = mask;
		vi x(m);
		for (int& z : x) { z = v%p; v /= p; }
		bool good = true;
		for (const vi& row : input) {
			int s = -row[m];
			for (int j = 0; j < m; ++j) s += row[j]*x[j];
			if (s%p) { good=false; break; }
		}
		count += good;
	}
	int rank = -1;
	if (count) {
		rank = m;
		int ways = count;
		while (ways > 1) {
			check(ways%p == 0, "brute solution count is prime power");
			ways /= p; --rank;
		}
	}
	auto a = input;
	vi x{999};
	check(gaussMod(a,m,x,p) == rank, "modular rank vs brute");
	check(a == input, "modular input preserved");
	check(sz(x) == m, "modular output size");
	if (rank >= 0) {
		for (int z : x) check(0 <= z && z < p, "normalized modular output");
		for (const vi& row : input) {
			ll s = -row[m];
			for (int j = 0; j < m; ++j) s += ll(row[j])*x[j];
			check(s%p == 0, "modular residual");
		}
	}
}
void modularExhaustive() {
	for (int p : {2,3,5})
		for (int n = 0; n <= 2; ++n)
			for (int m = 0; m <= 2; ++m)
				for (int mask = 0; mask < ipow(p,n*(m+1)); ++mask) {
					int v = mask;
					vector<vi> a(n,vi(m+1));
					for (auto& row : a) for (int& z : row) {
						z = v%p; v /= p;
					}
					modularSmall(a,m,p);
				}
	for (int p : {2,3,5}) for (int run = 0; run < 800; ++run) {
		int n = run%5, m = (run/5)%5;
		vector<vi> a(n,vi(m+1));
		for (auto& row : a) for (int& z : row) z = pick(9*p)-4*p;
		if (n > 1 && run%4 == 0) a.back() = a.front();
		if (m > 1 && run%4 == 1)
			for (auto& row : a) row[1] = row[0];
		modularSmall(a,m,p);
	}
}
void modularLarge() {
	const int p = 2147483647;
	for (int m = 0; m <= 20; ++m) {
		++modCases;
		int n = m+2;
		vector<vi> a(n,vi(m+1));
		vi planted(m);
		for (int j = 0; j < m; ++j) planted[j] = p-1-j*123456;
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j)
				a[i][j] = p-(j == i%m ? 1 : 2);
			__int128 b = 0;
			for (int j = 0; j < m; ++j) b += __int128(a[i][j])*planted[j];
			a[i][m] = int(b%p);
		}
		// Leading square block is I-2J, invertible here.
		auto original = a;
		vi x;
		check(gaussMod(a,m,x,p) == m, "largest int prime full rank");
		check(x == planted, "largest int prime solution");
		if (m) {
			a = original;
			a.back() = a.front();
			a.back()[m] = (a.back()[m]+1)%p;
			check(gaussMod(a,m,x,p) == -1, "largest prime inconsistent");
		}
	}
	vi x;
	vector<vi> a{{0,2,4}};
	check(gaussMod(a,2,x,p) == 1 && x == vi({0,2}),
		"modular leading free variable");
	for (int prime : {2,3,5,2147483647}) {
		vector<vi> extrema{{INT_MIN,INT_MAX}};
		auto original = extrema;
		int rank = gaussMod(extrema,1,x,prime);
		ll coef = (ll(INT_MIN)%prime+prime)%prime;
		ll rhs = ll(INT_MAX)%prime;
		check(extrema == original,"extreme input preserved");
		check(rank == (coef ? 1 : rhs ? -1 : 0),"extreme normalized rank");
		if (rank >= 0) check(coef*x[0]%prime == rhs,"extreme residual");
	}
}
int main() {
	realSmall<double>();
	realSmall<long double>();
	realPlanted<double>();
	realPlanted<long double>();
	modularExhaustive();
	modularLarge();
	cout << "Gauss: " << realCases << " real cases, "
		<< modCases << " modular cases, "
		<< checks << " oracle checks passed\n";
}
