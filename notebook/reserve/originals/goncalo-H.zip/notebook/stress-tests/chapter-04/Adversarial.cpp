#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/numerical/Gauss.h"
#include "../../content/numerical/GaussBinary.h"
#include "../../content/numerical/GaussMod.h"
#include "../../content/numerical/Matrix.h"
#include "../../content/numerical/NTT.h"
using boost::multiprecision::cpp_int;
static size_t checks = 0;
static mt19937_64 rng(0x4a110026ULL);
void check(bool b) { ++checks; assert(b); }
void scaledRealSystems() {
    // Binary scaling is exact and leaves the known solution unchanged;
    // explicit eps must scale together with the augmented system.
    for (int e = -400; e <= 400; e += 20) {
        double scale = ldexp(1.,e);
        vector<vector<double>> a{{0,2,-1,7},{3,-1,2,-6},{1,1,1,6}};
        vector<double> known{-2,5,3}, x;
        for (auto& row : a) {
            row[3] = inner_product(row.begin(),row.begin()+3,known.begin(),0.);
            for (double& v : row) v *= scale;
        }
        for (int rotate = 0; rotate < 3; ++rotate) {
            auto b = a;
            check(gauss(b,3,x,scale*1e-12) == 3);
            for (int i = 0; i < 3; ++i) check(abs(x[i]-known[i]) < 1e-10);
            std::rotate(a.begin(),a.begin()+1,a.end());
        }
    }
}
void modularShears() {
    const int p = INT_MAX;
    for (int n = 1; n <= 32; ++n) {
        vector<vi> a(n,vi(n+1)); vi want(n), x;
        for (int i = 0; i < n; ++i) a[i][i] = 1, want[i] = p-1-i;
        // Elementary row additions preserve full rank; no solver oracle.
        for (int t = 0; t < 8*n; ++t) {
            int i = int(rng()%unsigned(n)), j = int(rng()%unsigned(n));
            if (i == j) continue;
            ll f = p-1-ll(rng()%100);
            for (int c = 0; c < n; ++c) a[i][c] = int((a[i][c]+f*a[j][c])%p);
        }
        for (auto& row : a) {
            cpp_int rhs = 0;
            for (int j = 0; j < n; ++j) rhs += cpp_int(row[j])*want[j];
            row[n] = (rhs%p).convert_to<int>();
        }
        a.push_back(a.front()); shuffle(a.begin(),a.end(),rng);
        auto b = a; check(gaussMod(b,n,x,p) == n && x == want);
        a.push_back(a.front()); a.back()[n] = (a.back()[n]+1)%p;
        check(gaussMod(a,n,x,p) == -1);
    }
    for (int m : {63,64,65,127,128,129,511,512}) {
        vector<bitset<513>> a(m); vi want(m), x;
        for (int i = 0; i < m; ++i) want[i] = i%2;
        for (int i = 0; i < m; ++i) {
            a[i][m-1-i] = true; a[i][m] = want[m-1-i];
        }
        for (int i = 1; i < m; ++i) a[i] ^= a[i-1];
        shuffle(a.begin(),a.end(),rng);
        check(gaussBinary(a,m,x) == m && x == want);
    }
}
template<ll P> void jordanPowers() {
    vector<vector<ll>> a{{1,1,0},{0,1,1},{0,0,1}};
    for (ll n : {0LL,1LL,2LL,3LL,2147483647LL,LLONG_MAX-1,LLONG_MAX}) {
        auto b = matPow(a,n,P); cpp_int top = cpp_int(n)*(cpp_int(n)-1)/2;
        for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) {
            ll want = i == j ? 1 : j == i+1 ? n%P : i == 0 && j == 2 ? (top%P).convert_to<ll>() : 0;
            check(b[i][j] == want);
        }
    }
}
void denseConvolution() {
    for (int n : {63,64,65,1023,1024,1025,4095,4096,4097})
        for (int m : {31,32,33,1025}) {
            vi a(n,NTT::mod-1), b(m,NTT::mod-1), c = NTT::conv(a,b);
            check(sz(c) == n+m-1);
            for (int i = 0; i < n+m-1; ++i)
                check(c[i] == min({i+1,n,m,n+m-1-i}));
        }
}
int main() {
    scaledRealSystems(); modularShears();
    jordanPowers<2147483647>(); jordanPowers<9223372036854775783LL>();
    vector<vector<ll>> a{{1,1},{0,1}};
    check(matPow(a,LLONG_MAX,LLONG_MAX)[0][1] == 0);
    denseConvolution();
    cout << "Adversarial Numerical: " << checks << " analytic/exact checks passed\n";
}
