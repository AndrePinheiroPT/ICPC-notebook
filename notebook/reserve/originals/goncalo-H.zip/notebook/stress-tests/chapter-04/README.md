# Stress tests — Numerical

Executar `bash doc/scripts/test-chapter-04.sh` na raiz do notebook.
GNU++17; Boost multiprecision/rational para referências independentes.
`BOOST_INCLUDEDIR` é opcional; `RUN_MAX=1` inclui NTT no limite 2^23.
No ambiente com ptrace: `ASAN_OPTIONS=detect_leaks=0`.

O runner compila release e ASan/UBSan com STL debug e começa por integrar
todos os headers com o template real de Contest. Search usa enumeração,
fronteiras e cpp_int; Gauss usa cpp_rational e enumeração modular;
MatrixBinary usa atribuições booleanas exaustivas, cpp_int e recorrências;
NTT usa convolução quadrática, DFT direta e roundtrips. Sementes fixas
permitem reprodução. A documentação resumida está em `CHAPTER-04.md`.

## Notebook D

- Search.cpp valida firstTrue/lastTrue em [l,r), optional para ausência,
  intervalos vazios, todos falsos/verdadeiros e largura superior a LLONG_MAX.
  Enumeração de pequenos intervalos, fronteiras ll e 40000 amostras largas.
- MatrixBinary.cpp mantém os testes GF2; matrizes dinâmicas são comparadas
  com produtos cpp_int, potências repetidas e Fibonacci. Inclui mod=1,
  LLONG_MAX e ULLONG_MAX, dimensões vazias e expoentes até LLONG_MAX.
- Gauss.cpp verifica preservação da entrada, normalização de entradas
  negativas/extremas, rank por enumeração e resíduos da solução.
- Adversarial.cpp: Gaussian com escalas 2^-400 a 2^400 e eps ajustado,
  sistemas modulares construídos por operações que preservam rank,
  GF2 até 512 bits, potências enormes de blocos de Jordan contra cpp_int
  e convoluções densas com coeficientes analíticos triangulares.
- Resultados: validation/revision-11/ch04.log e ch04-ntt-max.log.

## Notebook F

- A API numérica é preservada, incluindo os domínios int/ll/uint64_t,
  double/long double e bitset<K>. ModPower usa loop while explícito e
  produto de 128 bits uniforme; Gauss tem nomes rank/pivot/factor claros.
- Toda a bateria anterior permanece: testes referenciais independentes,
  limites do domínio e modos release + ASan/UBSan/STL debug.
- NTT no tamanho máximo 2^23 também passou nesta execução.
- Resultado: `validation/notebookF/agent-ch04.log`.
