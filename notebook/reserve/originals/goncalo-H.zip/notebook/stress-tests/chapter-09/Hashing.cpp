#include "ContestPreamble.h"
#include <boost/multiprecision/cpp_int.hpp>
#include "../../content/strings/DoubleHash.h"
using boost::multiprecision::cpp_int;
using DH = DoubleHash;
using H = DH::Key;
static long long cases=0,checks=0,substrings=0,oracles=0;
static void ck(bool ok) {++checks;if(!ok)abort();}

// Arbitrary-precision polynomials: no modular prefix/extraction formula.
static H exact(const vi& a) {
	++oracles;H ans{0,0,sz(a)};
	for(int j=0;j<2;++j) {
		cpp_int value=0;
		for(int x:a) value=value*DH::base[j]+x;
		cpp_int r=value%DH::mod[j];
		ans[j]=r.convert_to<ll>();
	}
	return ans;
}
static void test(const vi& a,bool oracle) {
	++cases;DH h(a);
	ck(sz(h.h)==sz(a)+1 && sz(h.p)==sz(a)+1);
	for(int l=0;l<=sz(a);++l) for(int r=l;r<=sz(a);++r) {
		++substrings;
		vi q(a.begin()+l,a.begin()+r);
		DH fresh(q);H key=h.get(l,r);
		ck(key==fresh.get(0,sz(q)));
		ck(key[2]==r-l);
		if(oracle) ck(key==exact(q));
		for(int m=l;m<=r;++m)
			ck(h.concat(h.get(l,m),h.get(m,r))==key);
	}
	for(int i=0;i<sz(a);++i) {
		vi q=a;q.erase(q.begin()+i);DH removed(q);
		ck(h.concat(h.get(0,i),h.get(i+1,sz(a)))==removed.get(0,sz(q)));
	}
}
static vi compress(const vector<ll>& a,const vector<ll>& all) {
	vi ids;for(ll x:a) ids.push_back(int(lower_bound(all.begin(),all.end(),x)-all.begin()));
	return ids;
}
int main() {
	mt19937_64 rng(0x9102026);
	for(int k=0;k<2;++k) ck(256<=DH::base[k] && DH::base[k]<DH::mod[k]-1);
	ck(DH::base[0]!=DH::base[1]);
	DH baseAliasA(vi{0,int(DH::base[0])}),baseAliasB(vi{1,0});
	ck(baseAliasA.get(0,2)!=baseAliasB.get(0,2));
	for(int n=0;n<=8;++n) for(int mask=0;mask<(1<<n);++mask) {
		vi a(n);for(int i=0;i<n;++i)a[i]=(mask>>i)&1;
		test(a,true);
	}
	for(int t=0;t<600;++t) {
		vi a(rng()%20);
		for(int&x:a) x=int(rng()%1000000007);
		test(a,true);
	}
	test({0,1000000006,1,255,256,999999999},true);
	for(int t=0;t<1000;++t) {
		string s(rng()%60,'\0');vi bytes;
		vector<unsigned char> raw;
		for(char& c:s) {
			c=char(rng()%256);raw.push_back(static_cast<unsigned char>(c));
			bytes.push_back(raw.back());
		}
		DH h(s),g(bytes),v{string_view(s)},u(raw);
		ck(h.get(0,sz(s))==g.get(0,sz(s)));
		ck(h.get(0,sz(s))==v.get(0,sz(s)));
		ck(h.get(0,sz(s))==exact(bytes));
		ck(u.get(0,sz(raw))==exact(bytes));
	}
	string every;for(int i=0;i<256;++i)every+=char(i);
	vi bytes;for(unsigned char c:every)bytes.push_back(c);
	ck(DH(every).get(0,256)==exact(bytes));
	// Length is part of the key, so these cannot alias despite zero residues.
	DH empty(vi{}),zero(vi{0}),zeros(vi{0,0});
	ck(empty.get(0,0)!=zero.get(0,1));
	ck(zeros.get(0,2)!=zero.get(0,1));
	ck(zero.concat(empty.get(0,0),zero.get(0,1))==zero.get(0,1));
	// Full 64-bit values (including old deterministic aliases) are first
	// compressed together, preserving equality without modular reduction.
	vector<ll> x{LLONG_MIN,LLONG_MAX,0,1000000016000000063LL,-1,0};
	vector<ll> y{0,1000000016000000063LL,-1,0};
	vector<ll> all=x;all.insert(all.end(),y.begin(),y.end());
	sort(all.begin(),all.end());all.erase(unique(all.begin(),all.end()),all.end());
	vi cx=compress(x,all),cy=compress(y,all);
	DH hx(cx),hy(cy);
	ck(hx.get(2,6)==hy.get(0,4));
	ck(hy.get(0,1)!=hy.get(1,2));
	ck(hx.get(0,1)!=hx.get(1,2));
	for(int t=0;t<1000;++t) {
		vi a(rng()%40),b(rng()%40);
		for(int&v:a)v=int(rng()%1000000007);
		for(int&v:b)v=int(rng()%1000000007);
		DH ha(a),hb(b);vi joined=a;
		joined.insert(joined.end(),b.begin(),b.end());
		ck(hb.concat(ha.get(0,sz(a)),hb.get(0,sz(b)))==exact(joined));
	}
	// Repeated concatenation uses an explicitly long enough power table.
	DH capacity(string(1<<16,'x'));
	string doubled="ab";H key=DH(doubled).get(0,2);
	for(int i=0;i<15;++i) {
		key=capacity.concat(key,key);doubled+=doubled;
		ck(key==DH(doubled).get(0,sz(doubled)));
	}
	ck(capacity.concat(key,H{})==key && capacity.concat(H{},key)==key);
	vi longInput(100000);for(int&v:longInput)v=int(rng()%1000000007);
	DH large(longInput);
	for(int i=0;i<1000;++i) {
		int l=int(rng()%longInput.size()),r=int(rng()%longInput.size());
		if(l>r)swap(l,r);
		int m=l+(r-l)/2;
		ck(large.concat(large.get(l,m),large.get(m,r))==large.get(l,r));
	}
	cout<<"Hashing: "<<cases<<" sequence cases, "<<substrings
		<<" substrings, "<<oracles<<" independent big-integer oracles, "
		<<checks<<" checks; per-object powers, unsigned bytes, 64-bit joint "
		<<"compression and 100000-symbol case passed\n";
}
