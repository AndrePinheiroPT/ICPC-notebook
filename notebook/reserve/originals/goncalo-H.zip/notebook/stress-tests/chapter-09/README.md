# Stress tests — Strings, notebook D

Na raiz do notebook, executar:

```sh
ASAN_OPTIONS=detect_leaks=0 BOOST_INCLUDEDIR=/path/to/boost/include bash doc/scripts/test-chapters-09-10.sh
```

BOOST_INCLUDEDIR pode ser omitido quando Boost está instalado no sistema.
Boost é usado apenas pelo oráculo independente de Hashing.cpp.
O runner gera ContestPreamble.h a partir do template real e valida integração
com os restantes capítulos. Os testes são GNU++17, release e
ASan/UBSan/STL debug, com -Wall -Wextra -Wshadow -Wconversion -Werror.

## Cobertura atual

- Patterns.cpp: KMP contra matching direto; prefix function e Z contra
  enumeração; Manacher contra todos os substrings; rotação mínima contra
  todas as rotações; Aho contra matching individual em cada fronteira.
  Inclui strings vazias, padrões duplicados, bytes 0/128/255, alphabet 256,
  sobreposições e sequências de inteiros. Casos longos até 200000 símbolos.
- O Trie dinâmico é comparado com multiset após inserções, incluindo
  duplicados e palavras vazias. Verifica contains/count/countPrefix/walk e
  os contadores públicos terminal/pass. Crescimento até 250002 nós testa
  realocações e ultrapassa a antiga capacidade fixa de 200005.
- Suffixes.cpp: ordem de sufixos e LCP contra comparação direta; inclui
  RMQ para pares de sufixos, enumeração ternária até comprimento 8,
  todos os bytes e casos repetidos/periódicos de 200000 bytes.
- Hashing.cpp: calcula separadamente o polinómio completo com cpp_int
  para cada base aleatória, antes de reduzir pelos módulos. Não usa a
  fórmula de prefixos do código como oráculo. Verifica todos os intervalos
  e splits de casos pequenos; concatenação, remoção por concatenação,
  comprimento nas chaves, bytes unsigned, bases comuns entre objetos,
  extensão de potências além do tamanho de qualquer objeto inicial,
  associatividade e caso de 100000 símbolos.
- Valores inteiros de 64 bits, incluindo LLONG_MIN/MAX e o par 0 /
  1000000016000000063 que colidia deterministicamente na implementação C,
  são comprimidos CONJUNTAMENTE para vector<int> antes do hash. O
  construtor rejeita em compilação tipos inteiros maiores que 32 bits;
  IDs negativos ou >=1000000007 violam o contrato e têm assert.
- Adversarial.cpp: propriedades por inversão/bijeção/periodicidade,
  LCP independente com RMQ, associatividade do hash, alphabets binários
  e Trie contra multiset em 5000 operações.

## Validação executada nesta revisão

As quatro suites passaram individualmente em release e
ASan/UBSan + _GLIBCXX_DEBUG + LOCAL. Hashing passou ainda com
-funsigned-char. Resultados por modo:

| Suite | Verificações |
|---|---:|
| Patterns | 1468693 |
| Suffixes | 1714984 |
| Hashing | 549874 |
| Adversarial | 512093 |

Hashing: 1112 sequências, 65810 substrings e 68811 comparações com
polinómios independentes cpp_int. Patterns: 54648 consultas Trie.
Os contadores medem verificações heterogéneas, não provas de correção.
Hash permanece probabilístico; os testes não garantem ausência de colisões.
Relatórios anteriores no ZIP são históricos e descrevem interfaces de C.
