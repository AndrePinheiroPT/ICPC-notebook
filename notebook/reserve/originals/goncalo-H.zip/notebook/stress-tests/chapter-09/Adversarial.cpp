#include "ContestPreamble.h"
#include "../../content/strings/KMP.h"
#include "../../content/strings/ZFunction.h"
#include "../../content/strings/Palindromes.h"
#include "../../content/strings/LeastRotation.h"
#include "../../content/strings/Aho.h"
#include "../../content/strings/AlphabetTrie.h"
#include "../../content/strings/DoubleHash.h"
#include "../../content/strings/Suffixes.h"
#include "../../content/data-structures/RMQ.h"

static mt19937_64 gen(0x20260927abcULL);
static uint64_t checks=0;
void ck(bool ok) { ++checks; if (!ok) abort(); }
int rnd(int n) { return int(gen()%unsigned(n)); }

void sequences() {
 for (int run=0;run<1600;++run) {
  int n=rnd(100),m=rnd(30); string s,p;
  for(int i=0;i<n;++i) s+=char(rnd(5)*63);
  for(int i=0;i<m;++i) p+=char(rnd(5)*63);
  if(run%3==0 && n) p=s.substr(size_t(rnd(n)),size_t(m));
  m=sz(p);
  vi want;
  for(int i=0;i+m<=n;++i) if(s.compare(size_t(i),size_t(m),p)==0) want.push_back(i);
  ck(kmpMatches(s,p)==want);
  string rev=s,rp=p; reverse(rev.begin(),rev.end()); reverse(rp.begin(),rp.end());
  vi mirrored; for(int i:want) mirrored.push_back(n-m-i); reverse(mirrored.begin(),mirrored.end());
  ck(kmpMatches(rev,rp)==mirrored);
  vector<ll> mapped; for(unsigned char c:s) mapped.push_back(LLONG_MIN+ll(c)*1000003);
  ck(prefixFunction(mapped)==prefixFunction(s)); ck(zFunction(mapped)==zFunction(s));
  ck(palindromes(mapped)==palindromes(s)); ck(leastRotation(mapped)==leastRotation(s));
  ck(leastRotation(s+s)==leastRotation(s));
  auto a=palindromes(s),b=palindromes(rev);
  for(int i=0;i<n;++i) { ck(a[0][i]==b[0][n-1-i]); if(i) ck(a[1][i]==b[1][n-i]); }
  Suffixes sf(s); RMQ<int> rmq(sf.lcp);
  for(int q=0;q<80 && n;++q) {
   int x=rnd(n),y=rnd(n),l=0;
   while(x+l<n && y+l<n && s[x+l]==s[y+l]) ++l;
   ck((x==y?n-x:rmq.query(min(sf.rank[x],sf.rank[y]),max(sf.rank[x],sf.rank[y])))==l);
  }
  vi compressed; for(unsigned char c:s) compressed.push_back(c);
  DoubleHash h(compressed),h2(compressed);
  for(int q=0;q<30;++q) {
   int l=rnd(n+1),r=rnd(n+1); if(l>r) swap(l,r);
   int mid=l+rnd(r-l+1); auto left=h.get(l,mid),right=h.get(mid,r);
   ck(h.concat(left,right)==h2.get(l,r));
   vi sub(compressed.begin()+l,compressed.begin()+r); DoubleHash own(sub);
   ck(own.get(0,sz(sub))==h.get(l,r));
   auto tail=h.get(r,n);
   ck(h.concat(h.concat(left,right),tail)==h.concat(left,h.concat(right,tail)));
  }
 }
}
void automata() {
 for(int run=0;run<80;++run) {
  vector<string> words; Aho a(256,0);
  string text;
  for(int i=0;i<300;++i) text+=char(rnd(4)*85);
  for(int i=0;i<90;++i) {
   int l=rnd(301),len=rnd(min(25,301-l)); string s=text.substr(size_t(l),size_t(len));
   if(i%7==0) s.clear();
   words.push_back(s); ck(a.add(s)==i);
  }
  a.build(); int v=0;
  for(int i=0;i<=sz(text);++i) {
   if(i) v=a.go(v,static_cast<unsigned char>(text[i-1]));
   vi expected,actual;
   for(int j=0;j<sz(words);++j) if(sz(words[j])<=i && text.compare(size_t(i-sz(words[j])),words[j].size(),words[j])==0) expected.push_back(j);
   a.report(v,[&](int id){actual.push_back(id);}); sort(actual.begin(),actual.end());
   ck(actual==expected); ck(a.count(v)==sz(expected));
  }
 }
 Trie t; multiset<string> inserted;
 for(int run=0;run<5000;++run) {
  string s(size_t(rnd(25)),'a'); for(char& c:s)c=char('a'+rnd(3));
  if(run%3) {t.insert(s);inserted.insert(s);}
  ck(t.count(s)==(int)inserted.count(s));
  int pref=0; for(const string& w:inserted) if(w.compare(0,s.size(),s)==0)++pref;
  ck(t.countPrefix(s)==pref); ck((t.walk(s)>=0)==(pref!=0 || s.empty()));
 }
}
int main() { sequences(); automata(); cout<<"Strings adversarial: "<<checks<<" checks; reverse/bijection/periodic properties, independent suffix LCP, binary alphabets and trie multiset oracle passed\n"; }
