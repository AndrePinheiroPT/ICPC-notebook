#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_dec_float.hpp>
using namespace std;
using boost::multiprecision::cpp_dec_float_100;
#include "../../content/math/Probability.h"

using Big = cpp_dec_float_100;
size_t checks = 0;

void require(bool ok, const string& what) {
	++checks;
	if (!ok) {
		cerr << "FAIL " << what << '\n';
		exit(1);
	}
}

void closeTo(long double got, long double expected, const string& what,
		long double relative = 3e-14L) {
	bool ok = isfinite(got) &&
		(expected == 0 ? got == 0 : fabsl(got-expected) <= relative*fabsl(expected));
	if (!ok) cerr << setprecision(22) << "got=" << got << " expected=" << expected << '\n';
	require(ok, what);
}

Big highPrecision(long double x) {
	// Preserve binary input exactly; a round-tripping decimal loses relative
	// precision in 1-p when p is the floating-point value just below one.
	int exponent = 0;
	long double fraction = frexpl(x,&exponent);
	Big mantissa = 0;
	for (int bit = 0; bit < numeric_limits<long double>::digits; ++bit) {
		fraction *= 2;
		mantissa *= 2;
		if (fraction >= 1) { mantissa += 1; fraction -= 1; }
	}
	return mantissa*pow(Big(2),exponent-numeric_limits<long double>::digits);
}

Big powWhole(Big base, unsigned long long exponent) {
	Big result = 1;
	while (exponent) {
		if (exponent&1) result *= base;
		base *= base;
		exponent >>= 1;
	}
	return result;
}

void exhaustiveOutcomes() {
	// Enumerate every success/failure sequence; integer weights over 8^n.
	for (int n = 0; n <= 10; ++n) for (int a = 0; a <= 8; ++a) {
		vector<unsigned long long> weights((size_t)n+1);
		unsigned long long denominator = 1;
		for (int i = 0; i < n; ++i) denominator *= 8;
		for (int mask = 0; mask < (1<<n); ++mask) {
			int successes = 0;
			unsigned long long weight = 1;
			for (int i = 0; i < n; ++i) {
				bool hit = (mask>>i)&1;
				if (hit) ++successes;
				weight *= (unsigned)(hit ? a : 8-a);
			}
			weights[successes] += weight;
		}
		auto prob = binomialProb(n, (long double)a/8);
		require(prob.size() == (size_t)n+1, "distribution size");
		for (int k = 0; k <= n; ++k)
			closeTo(prob[k], (long double)weights[k]/denominator, "exhaustive outcome", 0);
	}
}

void combinatorialReference(int n, long double p) {
	auto prob = binomialProb(n,p);
	Big hp = highPrecision(p), coefficient = 1;
	Big smallestNormal = highPrecision(numeric_limits<long double>::min());
	for (int k = 0; k <= n; ++k) {
		Big reference = coefficient * pow(hp,k) * pow(Big(1)-hp,n-k);
		long double expected = reference.convert_to<long double>();
		if (reference >= smallestNormal || reference == 0)
			closeTo(prob[k], expected, "100-digit combinatorial PMF");
		else require(prob[k] >= 0 && prob[k] <= numeric_limits<long double>::min()
			&& isfinite(prob[k]), "underflow tail remains in subnormal range");
		if (k < n) coefficient = coefficient*(n-k)/(k+1);
	}
	long double sum = 0, mean = 0, variance = 0, expectedMean = n*p;
	for (int k = 0; k <= n; ++k) {
		require(isfinite(prob[k]) && prob[k] >= 0 && prob[k] <= 1,
			"valid probability");
		sum += prob[k];
		mean += k*prob[k];
		variance += (k-expectedMean)*(k-expectedMean)*prob[k];
	}
	closeTo(sum,1,"row sums to one");
	closeTo(mean,expectedMean,"binomial mean");
	closeTo(variance,n*p*(1-p),"binomial variance");
	// At-least-one is compared to a direct sum, not 1-prob[0].
	closeTo(atLeastOne(n,p),accumulate(prob.begin()+1,prob.end(),0.0L),
		"at least one versus direct tail");
}

void symmetryAndLargeRow() {
	for (int n : {0,1,2,8,31,128}) for (int a = 0; a <= 8; ++a) {
		long double p = (long double)a/8;
		auto left = binomialProb(n,p), right = binomialProb(n,1-p);
		for (int k = 0; k <= n; ++k)
			closeTo(left[k],right[n-k],"success/failure symmetry");
	}
	auto row = binomialProb(2000,0.5L);
	closeTo(accumulate(row.begin(),row.end(),0.0L),1,"moderate n=2000 row");
	for (int k = 0; k <= 2000; ++k) closeTo(row[k],row[2000-k],"large symmetry");
}

void scalarProbabilities() {
	vector<long double> probabilities{0,1e-40L,1e-20L,1e-9L,0.1L,0.5L,
		0.9L,nextafterl(1,0),1};
	for (long double p : probabilities) {
		Big hp = highPrecision(p);
		for (int n : {0,1,2,10,1000,1000000,INT_MAX}) {
			Big expected = 1-pow(Big(1)-hp,n);
			closeTo(atLeastOne(n,p),expected.convert_to<long double>(),
				"100-digit at-least-one");
		}
		for (int k : {1,2,3,10,1000,1000000,INT_MAX}) {
			Big expected = hp*pow(Big(1)-hp,k-1);
			closeTo(geometricProb(k,p),expected.convert_to<long double>(),
				"100-digit first-success probability");
		}
		closeTo(geometricProb(1,p),p,"first trial");
	}
	// This probability is too small for naive subtraction from 1.
	closeTo(atLeastOne(1000000,1e-200L),1e-194L,"rare success remains nonzero");
	closeTo(geometricProb(1000000,1e-200L),1e-200L,"rare geometric probability");
	Big rare = highPrecision(1e-20L);
	closeTo(atLeastOne(LLONG_MAX,1e-20L),
		(Big(1)-powWhole(Big(1)-rare,LLONG_MAX)).convert_to<long double>(),
		"rare success with 64-bit trial count");
	closeTo(geometricProb(LLONG_MAX,1e-20L),
		(rare*powWhole(Big(1)-rare,LLONG_MAX-1)).convert_to<long double>(),
		"rare first success with 64-bit trial count");
	long double cumulative = 0;
	for (int k = 1; k <= 100; ++k) {
		cumulative += geometricProb(k,0.25L);
		closeTo(cumulative,atLeastOne(k,0.25L),"geometric cumulative identity");
	}
}

int main() {
	auto start = chrono::steady_clock::now();
	exhaustiveOutcomes();
	for (int n : {0,1,2,10,40,128,256})
		for (long double p : {0.0L,1e-30L,1e-6L,0.125L,0.371L,0.5L,
			0.875L,nextafterl(1,0),1.0L}) combinatorialReference(n,p);
	symmetryAndLargeRow();
	scalarProbabilities();
	double seconds = chrono::duration<double>(chrono::steady_clock::now()-start).count();
	cout << "PASS Probability: " << checks << " checks; " << fixed
		<< setprecision(3) << seconds << "s; long double digits="
		<< numeric_limits<long double>::digits << '\n';
}
