#include "ContestPreamble.h"
#include "../../content/math/IntDivision.h"
#include "../../content/math/ModAlign.h"
#include "../../content/math/Int128.h"
#include "../../content/number-theory/ExtGCD.h"
#include "../../content/number-theory/ModInv.h"
#include "../../content/number-theory/GeneralCRT.h"
#include "../../content/number-theory/SPF.h"
#include "../../content/number-theory/TrialDivision.h"
#include "../../content/number-theory/Divisors.h"
#include "../../content/numerical/ModPower.h"
#include "../../content/numerical/Gauss.h"

int main() {
	assert(ceilDiv(17LL,5LL) == 4 && floorDiv(-7LL,3LL) == -3);
	assert(nextMultiple(17LL,5LL) == 20 && nextTerm(17LL,3LL,5LL) == 18);
	assert(gcd(18,30) == 6 && lcm(6,9) == 18);
	ll x,y; ll g = extGcd(6LL,9LL,x,y);
	assert(g == 3 && 6*x+9*y == g);
	set<pair<ll,ll>> brute, parameterized;
	for (int a = 0; a <= 10; ++a) for (int b = 0; b <= 10; ++b)
		if (6*a+9*b == 30) brute.insert({a,b});
	for (ll t = ceilDiv(10LL,3LL); t <= floorDiv(10LL,2LL); ++t)
		parameterized.insert({-10+3*t,10-2*t});
	assert((brute == set<pair<ll,ll>>{{2,2},{5,0}} && parameterized == brute));
	ll residue = -3; residue %= 7; if (residue < 0) residue += 7;
	assert(residue == 4 && modPow(2LL,10,7LL) == 2);
	auto inv = modInv(3,7);
	assert(inv && *inv == 5 && modMul(5LL,*inv,7LL) == 4 && !modInv(2,6));
	auto [r,m] = crtMerge(0,1,2,6);
	tie(r,m) = crtMerge(r,m,5,9);
	assert(r == 14 && m == 18 && nextTerm(20LL,r,m) == 32);
	SPF sieve(101); assert((sieve.factor(60) == vi{2,2,3,5}));
	assert(sieve.p[91] == 7 && sieve.p[97] == 97);
	assert((trialDivision(60LL) == vector<ll>{2,2,3,5}));
	assert((divisors(vector<ll>{2,2,3}) == vector<ll>{1,2,4,3,6,12}));
	for (int n = 1; n <= 500; ++n) {
		auto f = trialDivision(n), ds = divisors(f);
		int tau = 1, sigma = 1, phi = n;
		for (int i = 0; i < sz(f);) {
			int j = i, p = f[i], power = 1, sum = 1;
			while (j < sz(f) && f[j] == p) { ++j; power *= p; sum += power; }
			tau *= j-i+1; sigma *= sum; phi -= phi/p; i = j;
		}
		int count = 0, sum = 0, coprime = 0;
		for (int d = 1; d <= n; ++d) {
			if (n%d == 0) { ++count; sum += d; }
			coprime += gcd(d,n) == 1;
		}
		assert(tau == count && sigma == sum && phi == coprime && sz(ds) == tau);
	}
	assert(3+5+7+9 == 4*3+2*4*3/2);
	assert(i128(LLONG_MAX)*2 > LLONG_MAX);
	for (int n = 1; n <= 12; ++n) {
		int heads = 0, atLeastOne = 0;
		for (unsigned mask = 0; mask < (1U<<n); ++mask) {
			heads += __builtin_popcount(mask); atLeastOne += mask != 0;
		}
		assert(heads == n*(1<<(n-1)));
		assert(atLeastOne == (1<<n)-1);
	}
	// A self-loop has probability .5, target/failure .25 each.
	vector<vector<double>> expected{{.5,-.25,-.25,1},{0,1,0,0},{0,0,1,0}};
	vector<double> solution;
	assert(gauss(expected,3,solution) == 3 && abs(solution[0]-2) < 1e-10);
	vector<vector<double>> hitting{{.5,-.25,-.25,0},{0,1,0,1},{0,0,1,0}};
	assert(gauss(hitting,3,solution) == 3 && abs(solution[0]-.5) < 1e-10);
	vector<vector<double>> geometric{{.25,1}};
	assert(gauss(geometric,1,solution) == 1 && solution[0] == 4);
	assert((1.-.25)/.25 == 3);
	cout << "E Math/NT examples: division, schedules, Diophantine bounds, modular inverse/CRT, "
		<< "500 divisor formulas, enumerated expectations and state equations passed\n";
}
