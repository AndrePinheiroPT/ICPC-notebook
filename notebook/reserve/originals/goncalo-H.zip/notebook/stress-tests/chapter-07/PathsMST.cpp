#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/graph/Dijkstra.h"
#include "../../content/graph/Traversal.h"
#include "../../content/graph/ZeroOneBFS.h"
#include "../../content/graph/BellmanFord.h"
#include "../../content/graph/FloydWarshall.h"
#include "../../content/graph/Kahn.h"
#include "../../content/graph/Kruskal.h"

using E = tuple<int,int,ll>;
const ll oo = 1000000000000000LL;
mt19937_64 rng(0x701f0026);
size_t pathGraphs=0, distances=0, topoGraphs=0, forests=0, subsets=0;

template<class T, class W>
void checkParents(const vector<vector<pair<int,W>>>& g,
		const vector<T>& d, const vi& p, const vi& src, T inf) {
	vi source(sz(g));
	for (int s : src) source[s] = 1;
	assert(sz(p) == sz(g));
	for (int v = 0; v < sz(g); ++v) {
		if (d[v] == inf) { assert(p[v] == -1); continue; }
		if (source[v]) { assert(p[v] == -1 && d[v] == 0); continue; }
		assert(0 <= p[v] && p[v] < sz(g));
		bool witness = false;
		for (auto [u,w] : g[p[v]])
			witness |= u == v && __int128(d[p[v]])+w == d[v];
		assert(witness);
		int root = v, steps = 0;
		while (p[root] >= 0) { root = p[root]; assert(++steps < sz(g)); }
		assert(source[root]);
		auto path = restorePath(root,v,p);
		assert(sz(path) == steps+1 && path.front() == root && path.back() == v);
	}
}

// Enumerate simple cycles and simple paths, independently of relaxation.
vector<vector<ll>> brutePaths(int n, const vector<E>& es) {
	vector<vector<ll>> w(n,vector<ll>(n,oo)), ans=w;
	for (auto [u,v,c] : es) w[u][v]=min(w[u][v],c);
	vector<vi> reach(n,vi(n));
	vi neg(n);
	for (int s=0;s<n;++s) {
		vi q{s}; reach[s][s]=1;
		for (int i=0;i<sz(q);++i) for (int v=0;v<n;++v)
			if (w[q[i]][v]!=oo && !reach[s][v]) { reach[s][v]=1; q.push_back(v); }
		auto cycles=[&](auto&& self,int u,unsigned mask,ll cost)->void {
			for (int v=0;v<n;++v) if(w[u][v]!=oo) {
				if(v==s && cost+w[u][v]<0) neg[s]=1;
				if(!(mask>>v&1U)) self(self,v,mask|(1U<<v),cost+w[u][v]);
			}
		};
		cycles(cycles,s,1U<<s,0);
		auto paths=[&](auto&& self,int u,unsigned mask,ll cost)->void {
			ans[s][u]=min(ans[s][u],cost);
			for (int v=0;v<n;++v) if(w[u][v]!=oo && !(mask>>v&1U))
				self(self,v,mask|(1U<<v),cost+w[u][v]);
		};
		paths(paths,s,1U<<s,0);
	}
	for(int s=0;s<n;++s) for(int t=0;t<n;++t) for(int k=0;k<n;++k)
		if(neg[k] && reach[s][k] && reach[k][t]) ans[s][t]=-oo;
	return ans;
}
ll normalized(ll value, ll inf) {
	return value == inf ? oo : value == -inf ? -oo : value;
}
vector<ll> originalBellman(int n, const vector<E>& edges, int s) {
	vector<BF::Ed> e;
	for (auto [u,v,w] : edges) {
		assert(INT_MIN <= w && w <= INT_MAX);
		e.push_back({u,v,int(w)});
	}
	vector<BF::Node> nodes(n);
	BF::bellmanFord(nodes,e,s);
	for (int i = 1; i < sz(e); ++i) assert(e[i-1].s() <= e[i].s());
	vector<ll> result(n);
	for (int v = 0; v < n; ++v) {
		result[v] = normalized(nodes[v].dist,BF::inf);
		if (nodes[v].dist == BF::inf) assert(nodes[v].prev == -1);
		if (abs(nodes[v].dist) == BF::inf) continue;
		if (v == s) assert(nodes[v].dist == 0 && nodes[v].prev == -1);
		else {
			int p = nodes[v].prev;
			assert(0 <= p && p < n && abs(nodes[p].dist) != BF::inf);
			bool witness = false;
			for (auto [u,to,w] : edges)
				witness |= u == p && to == v && __int128(nodes[p].dist)+w == nodes[v].dist;
			assert(witness);
			int at = v;
			for (int steps = 0; at != s && steps < n; ++steps) {
				assert(0 <= at && at < n); at = nodes[at].prev;
			}
			assert(at == s);
		}
	}
	return result;
}
void checkSigned(int n, const vector<E>& e) {
	auto want = brutePaths(n,e);
	vector<vector<ll>> d(n,vector<ll>(n,FW::inf));
	for (auto [u,v,w] : e) d[u][v] = min(d[u][v],w);
	FW::floydWarshall(d);
	for (int u = 0; u < n; ++u) for (int v = 0; v < n; ++v) {
		assert(normalized(d[u][v],FW::inf) == want[u][v]); ++distances;
	}
	for (int s = 0; s < n; ++s) {
		assert(originalBellman(n,e,s) == want[s]); distances += size_t(n);
	}
	++pathGraphs;
}
void signedPaths() {
	for (int n = 0; n <= 2; ++n) {
		int ways = 1 << (2*n*n);
		for (int code = 0; code < ways; ++code) {
			int copy = code;
			vector<E> e;
			for (int u = 0; u < n; ++u) for (int v = 0; v < n; ++v) {
				int digit = copy%4; copy /= 4;
				if (digit) e.push_back({u,v,digit-2});
			}
			checkSigned(n,e);
		}
	}
	for(int run=0;run<2500;++run) {
		int n=1+int(rng()%7), m=int(rng()%19);
		vector<E> e;
		for(int i=0;i<m;++i) {
			int u=int(rng()%unsigned(n)), v=int(rng()%unsigned(n)), w=int(rng()%17)-7;
			e.push_back({u,v,w});
		}
		checkSigned(n,e);
	}
	vector<E> e{{0,1,INT_MIN},{1,1,-1},{1,2,INT_MAX},
		{0,3,INT_MAX-1},{3,4,-INT_MAX+2},{5,5,-INT_MAX}};
	assert(originalBellman(6,e,0) == vector<ll>({0,-oo,-oo,INT_MAX-1,1,oo}));
	// The original forward/backward edge ordering must propagate long
	// zigzags before its shortened pass limit, for every source labeling.
	for (int n : {1,2,3,4,7,16,65,257}) for (int pattern = 0; pattern < 6; ++pattern) {
		vi order(n); iota(order.begin(),order.end(),0);
		if (pattern == 1) reverse(order.begin(),order.end());
		else if (pattern == 2)
			for (int i = 0; i < n; ++i) order[i] = i%2 ? n-1-i/2 : i/2;
		else if (pattern > 2) shuffle(order.begin(),order.end(),rng);
		int weight = pattern%2 ? INT_MIN+1 : INT_MAX;
		vector<E> path;
		vector<ll> want(n+1,oo);
		for (int i = 0; i < n; ++i) {
			want[order[i]] = ll(i)*weight;
			if (i) path.push_back({order[i-1],order[i],weight});
		}
		path.push_back({n,n,-1}); // Unreachable negative cycle.
		shuffle(path.begin(),path.end(),rng);
		assert(originalBellman(n+1,path,order[0]) == want);
		if (n >= 4) {
			for (auto& edge : path) get<2>(edge) = 1;
			int pivot = n/2;
			path.push_back({order[pivot],order[pivot-1],-2});
			path.push_back({n,n,-1});
			for (int i = 0; i < n; ++i)
				want[order[i]] = i < pivot-1 ? ll(i) : -oo;
			assert(originalBellman(n+1,path,order[0]) == want);
		}
	}
	vector<vector<ll>> empty; FW::floydWarshall(empty); assert(empty.empty());
	// Negative-cycle intermediates grow exponentially without saturation.
	vector<vector<ll>> dense(130,vector<ll>(130,0));
	for(int i=0;i<130;++i) dense[i][i]=-1;
	FW::floydWarshall(dense);
	for(auto& row:dense) for(ll d:row) assert(d == -FW::inf);
	ll bound = (FW::inf-1)/3;
	vector<vector<ll>> dm{{0,bound,FW::inf},{FW::inf,0,bound},{FW::inf,FW::inf,0}};
	FW::floydWarshall(dm);
	assert(dm[0][2] == 2*bound && dm[2][0] == FW::inf);
	dm = {{0,-bound,FW::inf},{FW::inf,0,-bound},{FW::inf,FW::inf,0}};
	FW::floydWarshall(dm);
	assert(dm[0][2] == -2*bound && dm[2][0] == FW::inf);
}

void nonnegativePaths() {
	for(int run=0;run<3000;++run) {
		int n=int(rng()%17), m=n?int(rng()%80):0;
		vector<vector<pair<int,ll>>> g(n);
		vector<vector<pair<int,int>>> b(n);
		vector<E> e;
		for(int i=0;i<m;++i) {
			int u=int(rng()%unsigned(n)), v=int(rng()%unsigned(n));
			ll w=ll(rng()%(run&1?2:25));
			g[u].push_back({v,w}); b[u].push_back({v,int(w)}); e.push_back({u,v,w});
		}
		// Independent synchronous DP on walks of at most n-1 edges.
		auto oracle = [&](const vi& src) {
			vector<ll> want(n,oo);
			for (int s : src) want[s] = 0;
			for (int i = 1; i < n; ++i) {
				auto next = want;
				for (auto [u,v,w] : e) if (want[u] != oo)
					next[v] = min(next[v],want[u]+w);
				want.swap(next);
			}
			return want;
		};
		if (n) {
			int s = int(rng()%unsigned(n));
			auto want = oracle({s});
			auto [d,p] = dijkstra(g,s,oo);
			assert(d == want); checkParents(g,d,p,{s},oo);
			auto di = dijkstra(g,s,1000000).first;
			for (int v = 0; v < n; ++v) assert(di[v] == (want[v] == oo ? 1000000 : want[v]));
		}
		if(run&1) {
			vi src;
			if (n) {
				int count = int(rng()%unsigned(n+2));
				for (int i = 0; i < count; ++i) src.push_back(int(rng()%unsigned(n)));
			}
			auto want = oracle(src);
			auto [db,p]=zeroOneBfs(b,src);
			checkParents(b,db,p,src,INT_MAX);
			for(int v=0;v<n;++v) assert(db[v]==(want[v]==oo?INT_MAX:want[v]));
		}
		distances+=size_t(n)*2; ++pathGraphs;
	}
	vector<vector<pair<int,ll>>> h(3);
	h[0]={{1,LLONG_MAX-1}}; h[1]={{1,LLONG_MAX},{2,0}};
	assert(dijkstra(h,0,LLONG_MAX).first==vector<ll>({0,LLONG_MAX-1,LLONG_MAX-1}));
	vector<vector<pair<int,ll>>> stale{{{1,100},{1,50},{2,1}},{{3,1}},{{1,1}},{{3,0}}, {}};
	assert(dijkstra(stale,0).first == vector<ll>({0,2,1,3,LLONG_MAX/4}));
	assert(restorePath(0,0,dijkstra(stale,0).second) == vi{0});
	assert(restorePath(0,4,dijkstra(stale,0).second).empty());
}

void topological() {
	for(int run=0;run<4000;++run) {
		int n=int(rng()%21);
		vector<vi> g(n);
		if(n) for(int i=0;i<int(rng()%70);++i) {
			int u=int(rng()%unsigned(n)),v=int(rng()%unsigned(n));
			if((run&1) && u>=v) continue;
			g[u].push_back(v);
		}
		vi color(n); bool cycle=false;
		auto dfs=[&](auto&& self,int u)->void {
			color[u]=1;
			for(int v:g[u]) { if(color[v]==1) cycle=true; if(!color[v]) self(self,v); }
			color[u]=2;
		};
		for(int v=0;v<n;++v) if(!color[v]) dfs(dfs,v);
		auto q=kahn(g); vi pos(n,-1);
		for(int i=0;i<sz(q);++i) {assert(pos[q[i]]==-1);pos[q[i]]=i;}
		assert((sz(q)!=n)==cycle);
		for(int u=0;u<n;++u) for(int v:g[u]) if(pos[v]>=0)
			assert(pos[u]>=0 && pos[u]<pos[v]);
		++topoGraphs;
	}
	vector<vi> chain(100000);
	for(int i=1;i<sz(chain);++i) chain[i-1].push_back(i);
	auto order=kahn(chain);
	for(int i=0;i<sz(chain);++i) assert(order[i]==i);
}

int components(int n,const vector<E>& e,unsigned mask) {
	vector<vi> g(n);
	for(int i=0;i<sz(e);++i) if(mask>>i&1U) {
		auto [u,v,w]=e[i]; g[u].push_back(v); g[v].push_back(u);
	}
	vi seen(n); int c=0;
	for(int s=0;s<n;++s) if(!seen[s]) {
		++c; vi q{s}; seen[s]=1;
		for(int i=0;i<sz(q);++i) for(int v:g[q[i]]) if(!seen[v]) {seen[v]=1;q.push_back(v);}
	}
	return c;
}
void checkForest(int n, const vector<E>& e) {
	int m = sz(e), c=components(n,e,(1U<<m)-1), need=n-c;
	ll best=oo;
	for(unsigned mask=0;mask<(1U<<m);++mask) if(__builtin_popcount(mask)==need) {
		++subsets;
		if(components(n,e,mask)!=c) continue;
		ll cost=0; for(int i=0;i<m;++i) if(mask>>i&1U) cost+=get<2>(e[i]);
		best=min(best,cost);
	}
	auto [cost,ids]=kruskal(n,e);
	assert(cost==best && sz(ids)==need);
	unsigned mask=0; ll sum=0;
	for(int i:ids) {assert(!(mask>>i&1U));mask|=1U<<i;sum+=get<2>(e[i]);}
	assert(components(n,e,mask)==c && sum==cost);
	++forests;
}
void spanningForests() {
	for(int run=0;run<1200;++run) {
		int n=int(rng()%8), m=n?int(rng()%13):0;
		vector<E> e;
		for(int i=0;i<m;++i) e.push_back({int(rng()%unsigned(n)),int(rng()%unsigned(n)),ll(rng()%21)-10});
		checkForest(n,e);
	}
}

void exhaustiveAndAdversarial() {
	// All 3-vertex digraphs with each edge absent, -1 or +1, including loops.
	// Independent enumeration distinguishes unreachable/finite/-infinite paths.
	for (int code = 0; code < 19683; ++code) {
		vector<E> e; int copy = code;
		for (int u = 0; u < 3; ++u) for (int v = 0; v < 3; ++v) {
			int digit = copy%3; copy /= 3;
			if (digit) e.push_back({u,v,digit == 1 ? -1 : 1});
		}
		checkSigned(3,e);
	}
	// Every simple 4-vertex digraph: Kahn removes exactly vertices with no
	// cycle among their ancestors (permutations serve as an independent oracle).
	for (unsigned mask = 0; mask < (1U<<16); ++mask) {
		vector<vi> g(4); vi pos(4,-1), perm{0,1,2,3};
		for (int u = 0; u < 4; ++u) for (int v = 0; v < 4; ++v)
			if (mask >> (4*u+v) & 1U) g[u].push_back(v);
		auto q = kahn(g);
		for (int i = 0; i < sz(q); ++i) { assert(pos[q[i]] == -1); pos[q[i]] = i; }
		bool exists = false;
		do {
			vi at(4); for (int i = 0; i < 4; ++i) at[perm[i]] = i;
			bool ok = true;
			for (int u = 0; u < 4; ++u) for (int v : g[u]) ok &= at[u] < at[v];
			exists |= ok;
		} while (next_permutation(perm.begin(),perm.end()));
		assert((sz(q) == 4) == exists);
		for (int u = 0; u < 4; ++u) for (int v : g[u])
			if (pos[v] >= 0) assert(pos[u] >= 0 && pos[u] < pos[v]);
		++topoGraphs;
	}
	// All choices of absent/negative/positive edge on K4, including forests.
	for (int code = 0; code < 729; ++code) {
		vector<E> e; int copy = code;
		for (int u = 0; u < 4; ++u) for (int v = u+1; v < 4; ++v) {
			int digit = copy%3; copy /= 3;
			if (digit) e.push_back({u,v,digit == 1 ? -7 : 11});
		}
		checkForest(4,e);
	}
	// A dense heap with decreasing parallel weights, many stale entries and
	// zero-weight cycles. A 0-chain has exact distance 0 to all but the isolate.
	constexpr int n = 160;
	vector<vector<pair<int,ll>>> g(n+1);
	vector<vector<pair<int,int>>> z(n+1);
	for (int u = 0; u < n; ++u) for (int v = 0; v < n; ++v) {
		g[u].push_back({v,1000000-u-v});
		z[u].push_back({v,1});
	}
	for (int u = 0; u+1 < n; ++u) {
		g[u].push_back({u+1,0}); z[u].push_back({u+1,0});
	}
	for (int w = 3000; w >= 0; --w) g[0].push_back({n-1,w});
	auto d = dijkstra(g,0).first; auto b = zeroOneBfs(z,{0,0}).first;
	for (int u = 0; u < n; ++u) assert(d[u] == 0 && b[u] == 0);
	assert(d[n] == LLONG_MAX/4 && b[n] == INT_MAX);
	assert(zeroOneBfs(z,{}).first == vi(n+1,INT_MAX));
	distances += 2*size_t(n+1); pathGraphs += 2;
	// Finite answers immediately below custom infinity, including ll overflow.
	for (ll inf : {2LL,3LL,1LL<<62,LLONG_MAX}) {
		vector<vector<pair<int,ll>>> h(4);
		h[0]={{1,inf-1},{2,inf}}; h[1]={{2,inf-1},{3,0}};
		auto [dist,p] = dijkstra(h,0,inf);
		assert(dist == vector<ll>({0,inf-1,inf,inf-1}));
		checkParents(h,dist,p,{0},inf);
	}
}

void traversals() {
	assert(bfs({},{}).first.empty());
	assert(zeroOneBfs({},{}).first.empty());
	assert(bipartite({}).first);
	for (int n = 0; n <= 4; ++n) {
		int edges = n*(n+1)/2;
		for (unsigned mask = 0; mask < (1U<<edges); ++mask) {
			vector<vi> g(n);
			vector<vector<pair<int,int>>> weighted(n);
			int bit = 0;
			for (int u = 0; u < n; ++u) for (int v = u; v < n; ++v,++bit)
				if (mask>>bit&1U) {
					g[u].push_back(v); g[v].push_back(u);
					weighted[u].push_back({v,1}); weighted[v].push_back({u,1});
				}
			bool possible = false;
			for (unsigned colors = 0; colors < (1U<<n); ++colors) {
				bool ok = true;
				for (int u = 0; u < n; ++u) for (int v : g[u])
					ok &= ((colors>>u&1U) != (colors>>v&1U));
				possible |= ok;
			}
			auto [ok,color] = bipartite(g); assert(ok == possible);
			if (ok) for (int u = 0; u < n; ++u) for (int v : g[u])
				assert(color[u] != color[v]);
			// All source subsets; independent all-pairs Floyd oracle.
			vector<vi> all(n,vi(n,100));
			for (int u = 0; u < n; ++u) {
				for (int v : g[u]) all[u][v] = 1;
				all[u][u] = 0;
			}
			for (int k = 0; k < n; ++k) for (int u = 0; u < n; ++u)
				for (int v = 0; v < n; ++v) all[u][v] = min(all[u][v],all[u][k]+all[k][v]);
			for (unsigned sources = 0; sources < (1U<<n); ++sources) {
				vi src; for (int v = 0; v < n; ++v) if (sources>>v&1U) src.push_back(v);
				if (!src.empty()) src.push_back(src[0]);
				auto [d,p] = bfs(g,src); checkParents(weighted,d,p,src,-1);
				for (int v = 0; v < n; ++v) {
					int want = 100; for (int s : src) want = min(want,all[s][v]);
					assert(d[v] == (want == 100 ? -1 : want));
				}
			}
		}
	}
	vector<vi> chain(100000);
	for (int v = 1; v < sz(chain); ++v) chain[v-1].push_back(v), chain[v].push_back(v-1);
	auto [d,p] = bfs(chain,{0});
	assert(d.back() == sz(chain)-1 && sz(restorePath(0,sz(chain)-1,p)) == sz(chain));
	assert(bipartite(chain).first);
}

int main() {
	signedPaths(); nonnegativePaths(); topological(); spanningForests();
	exhaustiveAndAdversarial(); traversals();
	cout<<"PathsMST: "<<pathGraphs<<" path graphs, "<<distances<<" distances, "
	    <<topoGraphs<<" topological graphs, "<<forests<<" forests, "<<subsets<<" brute subsets passed\n";
}
