# Stress tests — Graph

Na raiz do notebook: bash doc/scripts/test-chapter-07.sh.
GNU++17, Boost.Multiprecision para a integração com capítulos anteriores. Num ambiente com ptrace:
ASAN_OPTIONS=detect_leaks=0 bash doc/scripts/test-chapter-07.sh.

O runner compila e executa release e ASan/UBSan/STL debug com -Werror.
Integration.inc usa o preâmbulo real de Contest e todos os headers
selecionados dos capítulos 2–7. Testa também dependências partilhadas.

- PathsMST.cpp: caminhos mínimos, ciclos negativos, topologias e MST.
  Oráculos de caminhos/ciclos simples, DP por quantidade de arestas,
  DFS e enumeração de subconjuntos; limites aritméticos e multigrafos.
  Dijkstra usa origem única e testa entradas antigas da heap, paralelas,
  pesos zero e proteção de overflow; valida todos os pais e os caminhos
  reconstruídos. BFS e bipartição cobrem exaustivamente grafos até quatro
  vértices (incluindo loops) e todos os conjuntos de origens, mais uma
  cadeia de 100000 vértices. Bellman--Ford e Floyd--Warshall
  usam os corpos originais em BF/FW, com sentinelas distintas. Há
  enumeração exaustiva de grafos ponderados até dois vértices,
  regressões em caminhos ziguezague e verificação dos predecessores
  finitos do Bellman--Ford e da sua ordenação especial das arestas.
- Connectivity.cpp: SCC/condensação por alcançabilidade; lowlink por
  remoção; SAT por atribuições; Euler por percursos exaustivos. Casos
  vazios, paralelas e self-loops. Lowlink/Euler mantêm casos profundos
  de 100000 vértices; SCC iterativo usa cadeias/ciclos/estrelas de
  100000 vértices; 2-SAT usa 100000 variáveis na cadeia de implicações.
- FlowMatching.cpp: cortes, fluxos enumerados, matchings/covers e
  estabilidade. Testa capacidades residuais, chamadas repetidas,
  cancelamento por reversas, custos negativos e lados vazios. Stable matching
  cobre também S<T, com enumeração de todos os matchings injetivos pequenos
  para verificar estabilidade e optimalidade para os proponentes.
- Trees.cpp: caminhos por busca independente, subárvores, sucessores
  e diâmetros por todos os pares. HLD com SegTree/LazySegTree reais,
  valores nos vértices/arestas, raiz arbitrária e cadeia de 100000 vértices.
  Regressões dos anexos verificam a acumulação inversa dos tamanhos de
  subárvore e o retorno final do LCA, incluindo raiz não zero e -1.

Sementes fixas; sem dependência das macros all/rep. Ver CHAPTER-07.md
para contratos e contagens. Tests assumem inputs dentro dos contratos:
por exemplo, árvores válidas e ausência de ciclos negativos no MCMF.

## Revisão 11 — cobertura adicional

- Enumeração completa de 19683 grafos dirigidos de três vértices com
  pesos ausentes/-1/+1; 65536 grafos dirigidos de quatro vértices para
  SCC e Kahn; 729 florestas ponderadas e 729 multigrafos para lowlink.
- Todos os multiconjuntos de três cláusulas em três variáveis;
  6561 sequências de quatro arestas para Euler, todos os inícios e
  ambas as orientações. Oráculos de remoção, atribuições e percursos.
- Todas as 19683 atribuições de capacidades 0/1/2 em K3 dirigido;
  729 redes de custo reduzido não negativo; todos os 65536 grafos
  bipartidos 4x4 e todos os 46656 perfis de preferências 3+3.
- Todos os Prüfer codes até cinco vértices, para todas as raízes;
  todos os 625 grafos funcionais parciais de quatro vértices.
- Limites LLONG_MAX/ULLONG_MAX, reversas após acrescentar capacidade,
  caminho alternante de 1000 vértices, heaps com muitas entradas antigas
  e contagens de saltos na fronteira dos 64 bits.

Resultados e contratos: `validation/revision-11/graph-review.md`.
Log integral de release e ASan/UBSan/STL debug:
`validation/revision-11/ch07.log`.

## Notebook F

- DinicFlow e MinCostFlow deixam de receber parâmetros de tipo: capacidades
  e custos usam `ll`; testa-se LLONG_MAX (ULLONG_MAX continua nos saltos).
- HLD devolve intervalos em `path(u,v,edges)`; os mesmos oráculos verificam
  cobertura, ausência de repetição e quantidade logarítmica de intervalos.
- Hopcroft–Karp deixa de usar um vértice fictício para o estado livre.
  Mantêm-se todos os 65536 grafos 4x4 e o caminho alternante longo.
- Logs/contratos atuais: `validation/notebookF/agent-graphs.md` e
  `validation/notebookF/logs/test-chapter-07.sh.log`.
