#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/graph/StrongComponents.h"
#include "../../content/graph/Lowlink.h"
#include "../../content/graph/TwoSAT.h"
#include "../../content/graph/Hierholzer.h"

using Edges = vector<pair<int,int>>;
mt19937 rng(0x51cc2a7U);
long long sccCases = 0, lowCases = 0;
long long satCases = 0, eulerCases = 0;
int rnd(int n) {
	assert(n > 0);
	return int(rng() % unsigned(n));
}

// Fixture adapter keeps the existing independent oracle unchanged.
struct SCC {
	vi comp;
	vector<vi> dag;
	SCC(const vector<vi>& g) : comp(kosaraju(g)), dag(condensation(g,comp)) {}
};

void checkSCC(const vector<vi>& g) {
	++sccCases;
	int n = sz(g);
	vector<vi> reach(n,vi(n));
	for (int v = 0; v < n; ++v) {
		reach[v][v] = 1;
		for (int u : g[v]) reach[v][u] = 1;
	}
	for (int k = 0; k < n; ++k)
		for (int u = 0; u < n; ++u)
			for (int v = 0; v < n; ++v)
				reach[u][v] |= reach[u][k] && reach[k][v];
	SCC s(g);
	assert(sz(s.comp) == n);
	int c = sz(s.dag);
	vi used(c);
	set<pair<int,int>> expected, actual;
	for (int u = 0; u < n; ++u) {
		assert(0 <= s.comp[u] && s.comp[u] < c);
		used[s.comp[u]] = 1;
		for (int v = 0; v < n; ++v)
			assert((s.comp[u] == s.comp[v]) ==
				bool(reach[u][v] && reach[v][u]));
		for (int v : g[u]) if (s.comp[u] != s.comp[v])
			expected.insert({s.comp[u],s.comp[v]});
	}
	assert(accumulate(used.begin(),used.end(),0) == c);
	for (int u = 0; u < c; ++u) for (int v : s.dag[u]) {
		assert(u < v && v < c);
		assert(actual.insert({u,v}).second);
	}
	assert(actual == expected);
}

int components(int n, const Edges& e,
		int skipEdge = -1, int skipVertex = -1) {
	vector<vi> g(n);
	for (int i = 0; i < sz(e); ++i) {
		auto [u,v] = e[i];
		if (i == skipEdge || u == skipVertex ||
			v == skipVertex) continue;
		g[u].push_back(v); g[v].push_back(u);
	}
	vi seen(n), st;
	int result = 0;
	for (int s = 0; s < n; ++s) {
		if (s == skipVertex || seen[s]) continue;
		++result; seen[s] = 1; st.push_back(s);
		while (!st.empty()) {
			int v = st.back(); st.pop_back();
			for (int u : g[v]) if (!seen[u]) {
				seen[u] = 1; st.push_back(u);
			}
		}
	}
	return result;
}

void checkLow(int n, const Edges& e) {
	++lowCases;
	Lowlink l(n,e);
	assert(sz(l.cut) == n);
	vi bridge(sz(e));
	for (int id : l.bridges) {
		assert(0 <= id && id < sz(e));
		assert(!bridge[id]); bridge[id] = 1;
	}
	int base = components(n,e);
	for (int i = 0; i < sz(e); ++i)
		assert(bool(bridge[i]) == (components(n,e,i) > base));
	for (int v = 0; v < n; ++v) {
		assert(l.cut[v] == 0 || l.cut[v] == 1);
		assert(bool(l.cut[v]) == (components(n,e,-1,v) > base));
	}
}

bool value(int literal, int mask) {
	return bool(((mask >> (literal/2)) & 1) ^ (literal&1));
}
bool bruteSAT(int n, const Edges& clauses) {
	for (int mask = 0; mask < (1 << n); ++mask) {
		bool ok = true;
		for (auto [a,b] : clauses)
			ok &= value(a,mask) || value(b,mask);
		if (ok) return true;
	}
	return false;
}
void checkSATResult(TwoSAT& t, int n, const Edges& clauses) {
	++satCases;
	bool expected = bruteSAT(n,clauses), actual = t.solve();
	assert(actual == expected);
	if (!actual) return;
	assert(sz(t.answer) == n);
	int mask = 0;
	for (int v = 0; v < n; ++v) {
		assert(t.answer[v] == 0 || t.answer[v] == 1);
		mask |= t.answer[v] << v;
	}
	for (auto [a,b] : clauses)
		assert(value(a,mask) || value(b,mask));
}
void checkSAT(int n, Edges clauses, bool extend = false) {
	TwoSAT t(n);
	for (auto [a,b] : clauses) t.either(a,b);
	checkSATResult(t,n,clauses);
	checkSATResult(t,n,clauses);
	if (extend && n) {
		int a = rnd(2*n);
		clauses.push_back({a,a}); t.either(a,a);
		checkSATResult(t,n,clauses);
	}
}

bool bruteEuler(int n, const Edges& e, int src, bool directed) {
	if (src < 0 || src >= n) return false;
	int full = (1 << sz(e))-1;
	vector<vi> memo(n,vi(full+1,-1));
	function<bool(int,int)> dfs = [&](int v, int mask) {
		if (mask == full) return true;
		int& result = memo[v][mask];
		if (result != -1) return bool(result);
		result = 0;
		for (int i = 0; i < sz(e); ++i) {
			if (mask & (1 << i)) continue;
			auto [a,b] = e[i];
			int u = -1;
			if (v == a) u = b;
			else if (!directed && v == b) u = a;
			if (u >= 0 && dfs(u,mask | (1 << i))) {
				result = 1; return true;
			}
		}
		return false;
	};
	return dfs(src,0);
}

void validateEuler(const pair<vi,vi>& result, int n,
		const Edges& e, int src, bool directed) {
	const auto& [path,ids] = result;
	assert(sz(path) == sz(e)+1 && sz(ids) == sz(e));
	assert(path.front() == src);
	vi seen(sz(e));
	for (int v : path) assert(0 <= v && v < n);
	for (int i = 0; i < sz(ids); ++i) {
		int id = ids[i];
		assert(0 <= id && id < sz(e) && !seen[id]);
		seen[id] = 1;
		auto [a,b] = e[id];
		bool forward = path[i] == a && path[i+1] == b;
		bool backward = path[i] == b && path[i+1] == a;
		assert(forward || (!directed && backward));
	}
}
void checkEuler(int n, const Edges& e, int src, bool directed) {
	++eulerCases;
	bool expected = bruteEuler(n,e,src,directed);
	auto result = eulerTrail(n,e,src,directed);
	assert(!result.first.empty() == expected);
	if (expected) validateEuler(result,n,e,src,directed);
	else assert(result.second.empty());
}

void smallTests() {
	for (int n = 0; n <= 3; ++n) {
		for (int mask = 0; mask < (1 << (n*n)); ++mask) {
			vector<vi> g(n);
			for (int u = 0; u < n; ++u)
				for (int v = 0; v < n; ++v)
					if (mask & (1 << (u*n+v))) g[u].push_back(v);
			checkSCC(g);
		}
		Edges possible;
		for (int u = 0; u < n; ++u)
			for (int v = u; v < n; ++v) possible.push_back({u,v});
		int ways = 1;
		for (int i = 0; i < sz(possible); ++i) ways *= 3;
		for (int mask = 0; mask < ways; ++mask) {
			Edges e;
			int copy = mask;
			for (auto edge : possible) {
				for (int count = copy%3; count--;)
					e.push_back(edge);
				copy /= 3;
			}
			checkLow(n,e);
		}
	}
	for (int n = 0; n <= 2; ++n) {
		Edges possible;
		for (int a = 0; a < 2*n; ++a)
			for (int b = a; b < 2*n; ++b) possible.push_back({a,b});
		for (int mask = 0; mask < (1 << sz(possible)); ++mask) {
			Edges clauses;
			for (int i = 0; i < sz(possible); ++i)
				if (mask & (1 << i)) clauses.push_back(possible[i]);
			checkSAT(n,clauses);
		}
	}
	for (int n = 0; n <= 3; ++n) {
		int maxEdges = n < 3 ? 4 : 3;
		int ways = 1;
		for (int m = 0; m <= maxEdges; ++m) {
			for (int mask = 0; mask < ways; ++mask) {
				Edges e;
				int copy = mask;
				for (int i = 0; i < m; ++i) {
					int edge = copy % (n*n); copy /= n*n;
					e.push_back({edge/n,edge%n});
				}
				for (int src = -1; src <= n; ++src)
					for (bool directed : {false,true})
						checkEuler(n,e,src,directed);
			}
			ways *= n*n;
		}
	}
	for (int run = 0; run < 5000; ++run) {
		int n = rnd(9), m = n ? rnd(31) : 0;
		Edges e;
		vector<vi> g(n);
		for (int i = 0; i < m; ++i) {
			int u = rnd(n), v = rnd(n);
			g[u].push_back(v); e.push_back({u,v});
		}
		checkSCC(g); checkLow(n,e);
		n = rnd(8); m = n ? rnd(31) : 0;
		Edges clauses;
		for (int i = 0; i < m; ++i)
			clauses.push_back({rnd(2*n),rnd(2*n)});
		checkSAT(n,clauses,true);
		n = rnd(7); m = n ? rnd(10) : 0;
		e.clear();
		for (int i = 0; i < m; ++i)
			e.push_back({rnd(n),rnd(n)});
		for (bool directed : {false,true})
			checkEuler(n,e,rnd(n+2)-1,directed);
	}
}

void largeTests() {
	constexpr int n = 100000;
	vector<vi> g(n);
	Edges e;
	for (int v = 1; v < n; ++v) {
		g[v-1] = {v,v}; e.push_back({v-1,v});
	}

	{
		Lowlink l(n,e);
		assert(sz(l.bridges) == n-1);
		vi ids = l.bridges;
		sort(ids.begin(),ids.end());
		for (int i = 0; i < n-1; ++i) assert(ids[i] == i);
		for (int v = 0; v < n; ++v)
			assert(bool(l.cut[v]) == (v > 0 && v+1 < n));
	}
	for (bool directed : {false,true}) {
		auto result = eulerTrail(n,e,0,directed);
		validateEuler(result,n,e,0,directed);
		assert(eulerTrail(n,e,1,directed).first.empty());
	}
	g.back() = {0,0}; e.push_back({n-1,0});
	{
		Lowlink l(n,e);
		assert(l.bridges.empty());
		for (int cut : l.cut) assert(!cut);
	}
	for (bool directed : {false,true}) {
		auto result = eulerTrail(n,e,n/2,directed);
		validateEuler(result,n,e,n/2,directed);
	}
	{
		// Iterative SCC must handle deep implication chains without call stack growth.
		constexpr int m = 100000;
		TwoSAT t(m);
		t.either(0,0);
		for (int v = 1; v < m; ++v)
			t.either(2*(v-1)+1,2*v);
		assert(t.solve());
		for (int x : t.answer) assert(x == 1);
		t.either(2*(m-1)+1,2*(m-1)+1);
		assert(!t.solve());
	}
	{
		Edges loops(n,{0,0});
		for (bool directed : {false,true}) {
			auto result = eulerTrail(1,loops,0,directed);
			validateEuler(result,1,loops,0,directed);
		}
		Lowlink l(1,loops);
		assert(l.bridges.empty() && l.cut == vi{0});
	}
}

void iterativeSCCCases() {
	// Deep chains/cycles now exercise explicit stacks on the heap.
	const int n = 100000;
	vector<vi> g(n);
	for (int v = 1; v < n; ++v) g[v-1] = {v,v};
	SCC chain(g);
	assert(sz(chain.dag) == n);
	for (int v = 0; v < n; ++v) {
		assert(chain.comp[v] == v);
		assert(chain.dag[v] == (v+1 < n ? vi{v+1} : vi{}));
	}
	g.back() = {0,0};
	SCC cycle(g);
	assert(cycle.dag == vector<vi>(1));
	for (int c : cycle.comp) assert(c == 0);
	// Large breadth tests allocation/linear condensation without deep recursion.
	g.assign(100000,{});
	for (int v = 1; v < sz(g); ++v) g[0].insert(g[0].end(),{v,v});
	SCC star(g);
	assert(sz(star.dag) == sz(g));
	assert(star.comp[0] == 0 && sz(star.dag[0]) == sz(g)-1);
	set<int> labels(star.comp.begin(),star.comp.end());
	assert(sz(labels) == sz(g));
	set<int> out(star.dag[0].begin(),star.dag[0].end());
	assert(sz(out) == sz(g)-1 && !out.count(0));
	for (int c = 1; c < sz(g); ++c) assert(star.dag[c].empty());
}

void forestRootRegressions() {
	// Different DFS roots: two children, one child, isolated, and loop-only.
	Edges e{{0,1},{0,2},{3,4},{4,5},{7,7}};
	checkLow(8,e);
	Lowlink b(8,e);
	assert(b.cut == vi({1,0,0,0,1,0,0,0}));
	sort(b.bridges.begin(),b.bridges.end());
	assert(b.bridges == vi({0,1,2,3}));
	// A parallel edge must not be confused with a DFS root/parent edge.
	e.push_back({0,1});
	checkLow(8,e);
	b = Lowlink(8,e);
	sort(b.bridges.begin(),b.bridges.end());
	assert(b.cut == vi({1,0,0,0,1,0,0,0}));
	assert(b.bridges == vi({1,2,3}));
}

void exhaustiveExtensions() {
	// All simple 4-vertex directed graphs; self-loops are included.
	for (unsigned mask = 0; mask < (1U<<16); ++mask) {
		vector<vi> g(4);
		for (int u = 0; u < 4; ++u) for (int v = 0; v < 4; ++v)
			if (mask >> (4*u+v) & 1U) g[u].push_back(v);
		checkSCC(g);
	}
	// All undirected 4-vertex multigraphs with 0, 1 or 2 copies per edge.
	// Every case also has loops, which must never create bridges/cut vertices.
	for (int code = 0; code < 729; ++code) {
		Edges e{{0,0},{1,1},{2,2},{3,3}}; int copy = code;
		for (int u = 0; u < 4; ++u) for (int v = u+1; v < 4; ++v) {
			int count = copy%3; copy /= 3;
			while (count--) e.push_back({u,v});
		}
		checkLow(4,e);
	}
	// Every multiset of three clauses on three variables; brute assignments
	// verify repeated literals, tautologies, forcing and contradictory units.
	Edges choices;
	for (int a = 0; a < 6; ++a) for (int b = a; b < 6; ++b)
		choices.push_back({a,b});
	for (int a = 0; a < sz(choices); ++a)
		for (int b = a; b < sz(choices); ++b)
			for (int c = b; c < sz(choices); ++c)
				checkSAT(3,{choices[a],choices[b],choices[c]});
	// Extend edge-sequence enumeration to 4 edges on 3 vertices, all starts.
	for (int code = 0; code < 6561; ++code) {
		Edges e; int copy = code;
		for (int i = 0; i < 4; ++i) {
			int k = copy%9; copy /= 9; e.push_back({k/3,k%3});
		}
		for (int src = 0; src < 3; ++src) for (bool directed : {false,true})
			checkEuler(3,e,src,directed);
	}
}

int main() {
	smallTests();
	forestRootRegressions();
	exhaustiveExtensions();
	largeTests(); iterativeSCCCases();
	cout << "Connectivity verified: SCC=" << sccCases
		<< ", lowlink=" << lowCases << ", 2SAT=" << satCases
		<< ", Euler=" << eulerCases
		<< "; SCC: 100000-vertex chain/cycle/star; "
		<< "2SAT: 100000-variable implication chain; "
		<< "lowlink/Euler: 100000-vertex/edge structural cases\n";
}
