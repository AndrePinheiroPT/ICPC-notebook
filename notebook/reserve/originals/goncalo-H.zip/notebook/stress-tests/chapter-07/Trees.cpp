#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/graph/JumpTable.h"
#include "../../content/graph/TreeTour.h"
#include "../../content/graph/TreeLCA.h"
#include "../../content/graph/HeavyLight.h"
#include "../../content/graph/TreeDiameter.h"
#include "../../content/data-structures/SegmentTree.h"
#include "../../content/data-structures/LazySegTree.h"

static mt19937_64 rng(0x7AEE2026);
static uint64_t checks = 0, jumps = 0, lcas = 0, paths = 0, diameters = 0;
static int rnd(int n) { return int(rng()%unsigned(n)); }
static void check(bool ok) { ++checks; assert(ok); }

// Independent successor oracle: enumerate the orbit once, then reduce in its cycle.
int walk(const vi& to, int v, ull k) {
	vi seen(sz(to),-1), path;
	while (v >= 0 && seen[v] < 0) {
		seen[v] = sz(path); path.push_back(v); v = to[v];
	}
	if (k < ull(sz(path))) return path[size_t(k)];
	if (v < 0) return -1;
	ull begin = ull(seen[v]), len = ull(sz(path))-begin;
	return path[size_t(begin+(k-begin)%len)];
}

void testJumps() {
	for (int test = 0; test < 260; ++test) {
		int n = test < 4 ? test : rnd(41);
		vi to(n);
		for (int& v : to) v = rnd(n+1)-1;
		if (test == 3) to = {1,2,0};
		for (int lg : {1,2,3,5,8,16,32,63,64}) {
			JumpTable jt(to,lg);
			ull limit = lg == 64 ? ULLONG_MAX : (1ULL << lg)-1;
			vector<ull> ks{0,1,limit,limit/2,1ULL << (lg-1),rng()&limit};
			for (int v = -1; v < n; ++v) for (ull k : ks) {
				check(jt.jump(v,k) == walk(to,v,k)); ++jumps;
			}
		}
	}
	JumpTable cycle(vi{1,2,0},64);
	check(cycle.jump(0,1ULL << 63) == 2);
	check(cycle.jump(0,ULLONG_MAX) == 0);
	jumps += 2;
}

struct Oracle {
	int n, root;
	vector<vi> d, prev;
	vi par;
	vector<vi> sub;
	Oracle(const vector<vi>& g, int r)
		: n(sz(g)), root(r), d(n,vi(n,-1)), prev(n,vi(n,-1)),
		  par(n,-1), sub(n,vi(n)) {
		for (int s = 0; s < n; ++s) {
			queue<int> q; q.push(s); d[s][s] = 0;
			while (!q.empty()) {
				int v = q.front(); q.pop();
				for (int u : g[v]) if (d[s][u] < 0) {
					d[s][u] = d[s][v]+1;
					prev[s][u] = v; q.push(u);
				}
			}
		}
		if (n) par = prev[root];
		for (int v = 0; v < n; ++v)
			for (int u = v; u >= 0; u = par[u]) sub[u][v] = 1;
	}
	int lca(int a, int b) const {
		vi seen(n);
		for (int u = a; u >= 0; u = par[u]) seen[u] = 1;
		while (!seen[b]) b = par[b];
		return b;
	}
	vi path(int a, int b, bool edges) const {
		vi p{b};
		while (p.back() != a) p.push_back(prev[a][p.back()]);
		reverse(p.begin(),p.end());
		if (!edges) return p;
		vi result;
		for (int i = 1; i < sz(p); ++i)
			result.push_back(par[p[i]] == p[i-1] ? p[i] : p[i-1]);
		return result;
	}
};

template<class Tour> void verifyTour(const Tour& t, const Oracle& o) {
	check(sz(t.ord) == o.n && t.par == o.par);
	vi used(o.n);
	for (int v : t.ord) { check(0 <= v && v < o.n); ++used[v]; }
	for (int v = 0; v < o.n; ++v) {
		check(used[v] == 1);
		check(0 <= t.tin[v] && t.tin[v] < t.tout[v] && t.tout[v] <= o.n);
		check(t.ord[t.tin[v]] == v && t.dep[v] == o.d[o.root][v]);
		for (int u = 0; u < o.n; ++u)
			check((t.tin[v] <= t.tin[u] && t.tin[u] < t.tout[v]) == bool(o.sub[v][u]));
	}
}

void testLCA(const TreeLCA& t, const Oracle& o) {
	for (int a = 0; a < o.n; ++a) {
		int at = a;
		for (int k = 0; k <= o.n+1; ++k) {
			check(t.ancestor(a,ull(k)) == at); ++jumps;
			if (at >= 0) at = o.par[at];
		}
		check(t.ancestor(a,1ULL << 63) == -1);
		check(t.ancestor(a,ULLONG_MAX) == -1); jumps += 2;
		for (int b = 0; b < o.n; ++b) {
			check(t.lca(a,b) == o.lca(a,b));
			check(t.dist(a,b) == o.d[a][b]); ++lcas;
		}
	}
}

void verifyPath(const HeavyLight& h, const Oracle& o, int u, int v, bool edges) {
	vi want = o.path(u,v,edges), got;
	int calls = 0;
	for (auto [l,r] : h.path(u,v,edges)) {
		check(0 <= l && l < r && r <= o.n); ++calls;
		for (int i = l; i < r; ++i) got.push_back(h.ord[i]);
	}
	sort(want.begin(),want.end()); sort(got.begin(),got.end());
	check(got == want);
	check(calls <= 2*(32-__builtin_clz(unsigned(o.n)))+1);
	++paths;
}

void testHLD(const HeavyLight& h, const Oracle& o) {
	if (!o.n) return;
	for (int v = 0; v < o.n; ++v) {
		check(o.sub[h.head[v]][v]);
		if (o.par[v] >= 0 && h.head[v] == h.head[o.par[v]])
			check(h.tin[v] == h.tin[o.par[v]]+1);
	}
	vector<ll> val(o.n), edge(o.n), byPos(o.n), byEdge(o.n);
	SegTree maxV(o.n), maxE(o.n);
	for (int v = 0; v < o.n; ++v) {
		val[v] = rnd(21)-10;
		edge[v] = v == o.root ? 0 : rnd(21)-10;
		byPos[h.tin[v]] = val[v]; byEdge[h.tin[v]] = edge[v];
		maxV.update(h.tin[v],int(val[v])); maxE.update(h.tin[v],int(edge[v]));
	}
	LazySegTree<ll> sumV(byPos), sumE(byEdge);
	for (int a = 0; a < o.n; ++a) for (int b = 0; b < o.n; ++b) {
		verifyPath(h,o,a,b,false); verifyPath(h,o,a,b,true);
	}
	for (int it = 0; it < 100; ++it) {
		int u = rnd(o.n), v = rnd(o.n); bool edges = bool(rnd(2));
		ll delta = rnd(31)-15;
		auto& values = edges ? edge : val;
		auto& sums = edges ? sumE : sumV;
		auto& maxima = edges ? maxE : maxV;
		for (auto [l,r] : h.path(u,v,edges)) sums.add(l,r,delta);
		for (int x : o.path(u,v,edges)) {
			values[x] += delta;
			maxima.update(h.tin[x],int(values[x]));
		}
		for (bool edgeMode : {false,true}) {
			ll wantSum = 0, gotSum = 0; int wantMax = INT_MIN, gotMax = INT_MIN;
			const auto& vs = edgeMode ? edge : val;
			for (int x : o.path(u,v,edgeMode)) {
				wantSum += vs[x]; wantMax = max(wantMax,int(vs[x]));
			}
			for (auto [l,r] : h.path(u,v,edgeMode)) {
				gotSum += (edgeMode ? sumE : sumV).query(l,r);
				gotMax = max(gotMax,(edgeMode ? maxE : maxV).query(l,r));
			}
			check(gotSum == wantSum && gotMax == wantMax); ++paths;
		}
		ll subSum = 0;
		for (int x = 0; x < o.n; ++x) if (o.sub[u][x]) subSum += val[x];
		check(sumV.query(h.tin[u],h.tout[u]) == subSum);
	}
}

template<class T> void diameter(const vector<vector<pair<int,T>>>& g) {
	int n = sz(g);
	auto [got,a,b] = treeDiameter(g);
	if (!n) { check(got == T{} && a == -1 && b == -1); ++diameters; return; }
	const T inf = numeric_limits<T>::max()/4;
	vector<vector<T>> d(n,vector<T>(n,inf));
	for (int u = 0; u < n; ++u) {
		d[u][u] = 0;
		for (auto [v,w] : g[u]) d[u][v] = w;
	}
	// Independent all-pairs Floyd-Warshall; valid because weights are nonnegative.
	for (int k = 0; k < n; ++k) for (int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
			if (d[i][k] != inf && d[k][j] != inf)
				d[i][j] = min(d[i][j],T(d[i][k]+d[k][j]));
	T want = 0;
	for (const auto& row : d) for (T x : row) want = max(want,x);
	check(0 <= a && a < n && 0 <= b && b < n);
	check(got == want && got == d[a][b]); ++diameters;
}

void testTree(vector<vi> g, int root, bool zeros) {
	for (auto& v : g) shuffle(v.begin(),v.end(),rng);
	Oracle o(g,root);
	TreeTour tour(g,root); TreeLCA lca(g,root); HeavyLight h(g,root);
	verifyTour(tour,o); verifyTour(lca,o); verifyTour(h,o);
	testLCA(lca,o); testHLD(h,o);
	vector<vector<pair<int,int>>> unit(sz(g));
	vector<vector<pair<int,ll>>> wg(sz(g));
	vector<vector<pair<int,long double>>> real(sz(g));
	for (int v = 0; v < sz(g); ++v) for (int u : g[v]) if (v < u) {
		ll w = zeros ? 0 : rnd(11);
		unit[v].push_back({u,1}); unit[u].push_back({v,1});
		wg[v].push_back({u,w*1000000000000LL});
		wg[u].push_back({v,w*1000000000000LL});
		real[v].push_back({u,static_cast<long double>(w)/2});
		real[u].push_back({v,static_cast<long double>(w)/2});
	}
	diameter(unit); diameter(wg); diameter(real);
}

void deepChain() {
	const int n = 100000, root = n/2;
	vector<vi> g(n);
	vector<vector<pair<int,ll>>> wg(n);
	for (int i = 1; i < n; ++i) {
		g[i-1].push_back(i); g[i].push_back(i-1);
		wg[i-1].push_back({i,1}); wg[i].push_back({i-1,1});
	}
	TreeLCA t(g,root); HeavyLight h(g,root);
	for (int v = 0; v < n; ++v) {
		int size = v == root ? n : (v < root ? v+1 : n-v);
		check(t.tout[v]-t.tin[v] == size && h.tout[v]-h.tin[v] == size);
		check(t.ord[t.tin[v]] == v && h.ord[h.tin[v]] == v);
	}
	for (int i = 0; i < 10000; ++i) {
		int a = rnd(n), b = rnd(n), depth = abs(a-root);
		check(t.lca(a,b) == clamp(root,min(a,b),max(a,b)));
		check(t.dist(a,b) == abs(a-b)); ++lcas;
		ull k = i%2 ? ull(rnd(n+1)) : rng();
		int want = k > ull(depth) ? -1 : a+(a < root ? int(k) : -int(k));
		check(t.ancestor(a,k) == want); ++jumps;
	}
	vector<ll> vertex(n,1), edge(n,1);
	edge[h.tin[root]] = 0;
	LazySegTree<ll> v(vertex), e(edge);
	for (auto [l,r] : h.path(0,n-1)) v.add(l,r,2);
	for (auto [l,r] : h.path(0,n-1,true)) e.add(l,r,3);
	ll sv = 0, se = 0;
	for (auto [l,r] : h.path(0,n-1)) sv += v.query(l,r);
	for (auto [l,r] : h.path(0,n-1,true)) se += e.query(l,r);
	check(sv == 3LL*n && se == 4LL*(n-1)); paths += 4;
	for (int i = 0; i < n; i += 137) {
		int calls = 0;
		calls = sz(h.path(i,i,true));
		check(calls == 0);
	}
	auto [len,a,b] = treeDiameter(wg);
	check(len == n-1 && abs(a-b) == n-1); ++diameters;
}

void exhaustiveTreesAndOrbits() {
	// Prüfer sequences enumerate every labelled tree on 2..5 vertices.
	// Test every root; all-pairs BFS remains the independent LCA/HLD oracle.
	for (int n = 2; n <= 5; ++n) {
		int ways = 1; for (int i = 0; i < n-2; ++i) ways *= n;
		for (int code = 0; code < ways; ++code) {
			vi seq(n-2), deg(n,1); int copy = code;
			for (int& v : seq) { v = copy%n; copy /= n; ++deg[v]; }
			vector<vi> g(n);
			for (int v : seq) {
				int u = int(find(deg.begin(),deg.end(),1)-deg.begin());
				g[u].push_back(v); g[v].push_back(u); --deg[u]; --deg[v];
			}
			vi leaves;
			for (int v = 0; v < n; ++v) if (deg[v] == 1) leaves.push_back(v);
			g[leaves[0]].push_back(leaves[1]); g[leaves[1]].push_back(leaves[0]);
			for (int root = 0; root < n; ++root) testTree(g,root,code%7 == 0);
		}
	}
	// Every partial functional graph on 4 vertices, at 64-bit jump boundaries.
	for (int code = 0; code < 625; ++code) {
		vi to(4); int copy = code;
		for (int& v : to) { v = copy%5-1; copy /= 5; }
		JumpTable jt(to,64);
		for (int v = -1; v < 4; ++v)
			for (ull k : {0ULL,1ULL,2ULL,3ULL,4ULL,15ULL,1ULL<<63,ULLONG_MAX}) {
				check(jt.jump(v,k) == walk(to,v,k)); ++jumps;
			}
	}
	// Large representable path sums, also exercising zero-weight ties.
	vector<vector<pair<int,ll>>> big(4);
	for (auto [u,v,w] : vector<tuple<int,int,ll>>{{0,1,0},{1,2,LLONG_MAX-3},{1,3,3}}) {
		big[u].push_back({v,w}); big[v].push_back({u,w});
	}
	auto [d,a,b] = treeDiameter(big);
	check(d == LLONG_MAX && ((a == 2 && b == 3) || (a == 3 && b == 2)));
	++diameters;
}

void attachmentRegressions() {
	check(TreeLCA::levels(0) == 1);
	check(TreeLCA::levels(1) == 1);
	check(TreeLCA::levels(2) == 2);
	check(TreeLCA::levels(3) == 3);
	check(TreeLCA::levels(INT_MAX) == 32);
	// The supplied Euler snippet ended during the reverse size pass;
	// this branched, nonzero-root tree checks every completed subtree interval.
	vector<vi> g(7);
	for (auto [u,v] : vector<pair<int,int>>{{4,1},{4,6},{1,0},{1,3},{3,2},{6,5}})
		g[u].push_back(v), g[v].push_back(u);
	TreeTour t(g,4);
	check(t.ord == vi({4,6,5,1,3,2,0}));
	check(t.tin == vi({6,3,5,4,0,2,1}));
	check(t.tout == vi({7,7,6,6,7,3,3}));
	check(t.par == vi({1,4,3,1,-1,6,4}));
	check(t.dep == vi({2,1,3,2,0,2,1}));
	// Both queries require the repaired final return tbl[0][a].
	TreeLCA lc(g,4);
	check(lc.lca(0,2) == 1); check(lc.lca(0,5) == 4);
	check(lc.jt.jmp[0][4] == -1);
	for (ull k = 0; k <= 4; ++k)
		check(lc.ancestor(2,k) == vi({2,3,1,4,-1})[k]);
	check(lc.ancestor(4,0) == 4);
	check(lc.ancestor(4,1) == -1);
	check(lc.ancestor(2,ULLONG_MAX) == -1);
	check(lc.dist(0,5) == 4);
	TreeLCA empty({});
	check(empty.ord.empty() && empty.par.empty());
}

int main() {
	attachmentRegressions();
	testJumps(); testTree({},0,true); testTree(vector<vi>(1),0,true);
	for (int n : {2,3,8,17,40}) {
		vector<vi> chain(n), star(n);
		for (int i = 1; i < n; ++i) {
			chain[i].push_back(i-1); chain[i-1].push_back(i);
			star[i].push_back(0); star[0].push_back(i);
		}
		for (int r : {0,n/2,n-1}) {
			testTree(chain,r,false); testTree(star,r,true);
		}
	}
	for (int i = 0; i < 220; ++i) {
		int n = rnd(31)+1;
		vector<vi> g(n);
		for (int v = 1; v < n; ++v) {
			int p = rnd(v); g[p].push_back(v); g[v].push_back(p);
		}
		testTree(g,rnd(n),i%7 == 0);
	}
	exhaustiveTreesAndOrbits();
	deepChain();
	cout << "Trees: " << checks << " verified assertions, " << jumps
	     << " successor/ancestor jumps, " << lcas << " LCA/distance pairs, "
	     << paths << " path checks, " << diameters
	     << " diameter checks; iterative 100000-vertex chain passed\n";
}
