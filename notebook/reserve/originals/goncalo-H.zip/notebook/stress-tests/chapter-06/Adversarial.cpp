#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/combinatorial/Binomial.h"
#include "../../content/combinatorial/ModComb.h"
#include "../../content/combinatorial/PermCycles.h"
using boost::multiprecision::cpp_int;
static size_t checks = 0;
static mt19937 rng(0x6a110026);
void check(bool b) { ++checks; assert(b); }
void largeExact() {
    // Independent factorial quotients, rather than the cancellation
    // recurrence used by binom, on several thousand-bit results.
    vector<cpp_int> fact(1501,1);
    for (int i = 1; i <= 1500; ++i) fact[i] = fact[i-1]*i;
    for (int t = 0; t < 600; ++t) {
        int n = int(rng()%1501), k = int(rng()%unsigned(n+1));
        cpp_int want = fact[n]/(fact[k]*fact[n-k]);
        check(binom<cpp_int>(n,k) == want);
    }
}
void wilsonRows() {
    // C(p-1,k)=(-1)^k and C(p-2,k)=(-1)^k(k+1) modulo p.
    // These algebraic oracles avoid factorials and modular powering.
    for (int p : {2,3,5,17,101,1009,10007,65537}) {
        ModComb<int> c(p,p);
        check(c.fact[p-1] == p-1 && c.invfact[p-1] == p-1);
        for (int k = 0; k < p; ++k) {
            check(c.choose(p-1,k) == (k%2 ? p-1 : 1));
            if (k <= p-2) check(c.choose(p-2,k) == (k%2 ? p-k-1 : k+1));
        }
    }
}
void relabelledCycles() {
    for (int n : {0,1,2,127,128,129,100003,200003}) {
        vi p(n), rename(n), inverse(n), want;
        iota(rename.begin(),rename.end(),0); shuffle(rename.begin(),rename.end(),rng);
        int at = 0;
        while (at < n) {
            int len = min(n-at,1+int(rng()%127)); want.push_back(len);
            for (int j = 0; j < len; ++j) p[rename[at+j]] = rename[at+(j+1)%len];
            at += len;
        }
        for (int i = 0; i < n; ++i) inverse[p[i]] = i;
        auto got = cycleLengths(p), inv = cycleLengths(inverse);
        sort(want.begin(),want.end()); sort(got.begin(),got.end()); sort(inv.begin(),inv.end());
        check(got == want && inv == want);
    }
}
int main() {
    largeExact(); wilsonRows(); relabelledCycles();
    cout << "Adversarial Combinatorial: " << checks << " exact/analytic checks passed\n";
}
