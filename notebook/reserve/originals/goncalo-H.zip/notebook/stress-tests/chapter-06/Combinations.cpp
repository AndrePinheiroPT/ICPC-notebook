#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/combinatorial/Binomial.h"
#include "../../content/combinatorial/ModComb.h"
using boost::multiprecision::cpp_int;

mt19937_64 rng(0x434f4d425f323036ULL);
unsigned long long checks = 0, exactCases = 0, modCases = 0, permutations = 0;
void check(bool ok, const char* what) {
	++checks;
	if (!ok) {
		cerr << "FAILED " << what << " at check " << checks << '\n';
		exit(1);
	}
}

// Pascal uses only addition; no factorials or multiplicative binomial formula.
vector<vector<cpp_int>> pascal(int limit) {
	vector<vector<cpp_int>> p(limit);
	for (int n = 0; n < limit; ++n) {
		p[n].assign(n+1,1);
		for (int k = 1; k < n; ++k) p[n][k] = p[n-1][k-1]+p[n-1][k];
	}
	return p;
}
template<class T>
void exactIfFits(ll n, ll k, const cpp_int& want) {
	if (want > numeric_limits<T>::max()) return;
	check(cpp_int(binom<T>(n,k)) == want, "fixed-width exact binomial");
	++exactCases;
}
void exactSmall(const vector<vector<cpp_int>>& rows) {
	for (int n = 0; n < sz(rows); ++n) {
		for (int k = 0; k <= n; ++k) {
			const cpp_int& want = rows[n][k];
			check(binom<cpp_int>(n,k) == want, "big integer vs Pascal");
			++exactCases;
			exactIfFits<int>(n,k,want);
			exactIfFits<ll>(n,k,want);
			exactIfFits<ull>(n,k,want);
		}
		for (ll k : {-1LL,LLONG_MIN,ll(n)+1,LLONG_MAX}) {
			check(binom(n,k) == 0, "invalid exact k");
			check(binom<cpp_int>(n,k) == 0, "invalid big-integer k");
		}
	}
	check(binom(66,33) == 7219428434016265740LL, "signed cancellation boundary");
	check(binom<ull>(67,33) == 14226520737620288370ULL,
		"unsigned cancellation boundary");
	check(binom<int>(33,16) == 1166803110, "int cancellation boundary");
}

// Different oracle for huge n: accumulate the whole falling product,
// then divide by k!, using arbitrary precision for both.
cpp_int falling(ll n, int k) {
	cpp_int a = 1, b = 1;
	for (int i = 0; i < k; ++i) { a *= n-i; b *= i+1; }
	return a/b;
}
void largeArguments() {
	vector<ll> ns{0,1,2,33,66,67,INT_MAX,4294967296LL,
		4294967297LL,LLONG_MAX-1,LLONG_MAX};
	for (int run = 0; run < 300; ++run)
		ns.push_back(ll(rng() >> 1));
	for (ll n : ns) {
		for (int k = 0; k <= 20 && k <= n; ++k) {
			cpp_int want = falling(n,k);
			check(binom<cpp_int>(n,k) == want, "large n exact oracle");
			check(binom<cpp_int>(n,n-k) == want, "large n symmetry");
			exactCases += 2;
			exactIfFits<int>(n,k,want);
			exactIfFits<ll>(n,k,want);
			exactIfFits<ull>(n,k,want);
		}
		check(binom<int>(n,0) == 1 && binom<int>(n,n) == 1,
			"large n trivial coefficients fit int");
		check(binom(n,-1) == 0 && binom(n,LLONG_MIN) == 0, "large n negative k");
	}
	check(binom(LLONG_MAX,1) == LLONG_MAX, "largest signed n");
	check(binom(LLONG_MAX,LLONG_MAX-1) == LLONG_MAX, "largest n symmetric");
	check(binom(4294967296LL,2) == 9223372034707292160LL,
		"divide before product avoids signed overflow");
}
template<class T>
void modular(T prime, const vector<vector<cpp_int>>& rows) {
	vector<int> limits{1,2,3,17,101,sz(rows)};
	if (prime <= T(sz(rows))) limits.push_back(int(prime));
	sort(limits.begin(),limits.end());
	limits.erase(unique(limits.begin(),limits.end()),limits.end());
	for (int lim : limits) {
		if (T(lim) > prime) continue;
		ModComb<T> c(lim,prime);
		check(c.p == prime && sz(c.fact) == lim && sz(c.invfact) == lim, "ModComb dimensions");
		cpp_int factorial = 1, p = prime;
		for (int n = 0; n < lim; ++n) {
			if (n) factorial *= n;
			check(cpp_int(c.fact[n]) == factorial%p, "factorial exact oracle");
			check((cpp_int(c.fact[n])*c.invfact[n])%p == 1, "inverse factorial identity");
			for (int k = 0; k <= n; ++k) {
				check(cpp_int(c.choose(n,k)) == rows[n][k]%p, "modular Pascal oracle");
				++modCases;
			}
			for (ll k : {-1LL,LLONG_MIN,ll(n)+1,LLONG_MAX})
				check(c.choose(n,k) == 0, "invalid modular k");
		}
	}
}
void multisetCounts() {
	ModComb<int> c(10,11);
	for (int n = 0; n <= 9; ++n)
		for (int a = 0; a <= n; ++a)
			for (int b = 0; b <= n-a; ++b) {
				vector<int> word(a,0);
				word.insert(word.end(),b,1);
				word.insert(word.end(),n-a-b,2);
				ll count = 0;
				do { ++count; ++permutations; } while (next_permutation(word.begin(),word.end()));
				ll want = binom(n,a)*binom(n-a,b);
				check(want == count, "multinomial via distinct permutations");
				check(ll(c.choose(n,a))*c.choose(n-a,b)%11 == count%11,
					"modular multinomial permutations");
			}
}
int main() {
	auto rows = pascal(201);
	exactSmall(rows); largeArguments(); multisetCounts();
	for (int p : {2,3,5,17,101,1009,2147483647}) modular(p,rows);
	for (ll p : {2LL,17LL,1000000007LL,9223372036854775783LL}) modular(p,rows);
	// Large-prime fixtures have exact certificates in chapter-05/PrimeFactor.cpp.
	for (ull p : {2ULL,17ULL,1000000007ULL,18446744073709551557ULL}) modular(p,rows);
	modular<uint32_t>(2147483647U,rows);
	modular<uint64_t>(18446744073709551557ULL,rows);
	cout << "Combinations: " << exactCases << " exact cases, "
		<< modCases << " modular cases, " << permutations << " distinct permutations, "
		<< checks << " independent checks passed\n";
}
