#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
using namespace std;
using ll = long long;
#include "../../content/numerical/ModPower.h"
using boost::multiprecision::cpp_int;

static size_t checks = 0;
template<class T> void test(T a, T b, T m, ull e) {
	cpp_int x = a, y = b, z = m;
	x %= z; if (x < 0) x += z;
	y %= z; if (y < 0) y += z;
	T aa = x.convert_to<T>(), bb = y.convert_to<T>();
	assert(cpp_int(modMul(aa,bb,m)) == x*y % z);
	cpp_int expected = boost::multiprecision::powm(x,cpp_int(e),z);
	assert(cpp_int(modPow(a,e,m)) == expected);
	checks += 2;
}

int main() {
	for (int m = 1; m <= 40; ++m)
		for (int a = -2*m; a <= 2*m; ++a)
			for (int e = 0; e <= 16; ++e)
				test(a, m-a, m, ull(e));
	vector<ll> s = {LLONG_MIN,LLONG_MIN+1,-2,-1,0,1,2,LLONG_MAX-1,LLONG_MAX};
	vector<ull> u = {0,1,2,3,1ULL<<32,(1ULL<<63)-1,1ULL<<63,ULLONG_MAX-58,ULLONG_MAX-1,ULLONG_MAX};
	vector<ull> ex = {0,1,2,3,63,64,65,1ULL<<63,ULLONG_MAX};
	for (ll m : {1LL,2LL,3LL,1000000007LL,LLONG_MAX-1,LLONG_MAX})
		for (ll a : s) for (ll b : s) for (ull e : ex) test(a,b,m,e);
	for (ull m : u) if (m)
		for (ull a : u) for (ull b : u) for (ull e : ex) test(a,b,m,e);
	mt19937_64 rng(0x352f03029ULL);
	for (int it = 0; it < 10000; ++it) {
		ull m = rng() | 1ULL, a = rng(), b = rng(), e = rng();
		test(a,b,m,e);
		ll sm = ll(rng() >> 1) | 1;
		ll sa = ll(rng() >> 1), sb = ll(rng() >> 1);
		if (it & 1) sa = -sa;
		if (it & 2) sb = -sb;
		test(sa,sb,sm,e);
		test(uint32_t(a),uint32_t(b),uint32_t(m),e);
		test(uint64_t(a),uint64_t(b),uint64_t(m),e);
	}
	cout << "Modular: " << checks << " exact arithmetic checks passed\n";
}
