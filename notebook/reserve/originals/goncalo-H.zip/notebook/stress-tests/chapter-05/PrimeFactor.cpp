#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/miller_rabin.hpp>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/number-theory/Prime64.h"
#include "../../content/number-theory/Factor64.h"
using boost::multiprecision::cpp_int;

static mt19937_64 rng(0x8d614c239a75ULL);
static uint64_t primeCases = 0, factorCases = 0, factorsChecked = 0;

void require(bool b, const char* what) {
	if (!b) { cerr << "FAILED PrimeFactor: " << what << '\n'; abort(); }
}
bool trialPrime(ull n) {
	if (n < 2 || n%2 == 0) return n == 2;
	for (ull p = 3; p <= n/p; p += 2) if (n%p == 0) return false;
	return true;
}
vector<ull> trialFactors(ull n) {
	vector<ull> f;
	for (ull p = 2; p <= n/p; ++p)
		while (n%p == 0) { f.push_back(p); n /= p; }
	if (n > 1) f.push_back(n);
	return f;
}
void primality(ull n, bool want) {
	if (isPrime64(n) != want) {
		cerr << "Primality mismatch at " << n << ", expected " << want << '\n';
		abort();
	}
	++primeCases;
}
void factorization(ull n, vector<ull> want) {
	sort(want.begin(), want.end());
	vector<ull> got = factor64(n);
	if (got != want) {
		cerr << "Factorization mismatch at " << n << "; got:";
		for (ull p : got) cerr << ' ' << p;
		cerr << "; expected:";
		for (ull p : want) cerr << ' ' << p;
		cerr << '\n'; abort();
	}
	cpp_int product = 1;
	for (ull p : got) product *= p;
	require(product == cpp_int(n), "exact cpp_int reconstruction");
	++factorCases; factorsChecked += got.size();
}

// Independent Lucas/Pocklington certificates: fully factor p-1 into
// trial-verified primes; verify the witness with cpp_int, never modPow
// or isPrime64. These are exact certificates, not probable-prime results.
void certify(ull p, ull witness, const vector<ull>& f) {
	cpp_int product = 1;
	for (ull q : f) { require(trialPrime(q), "certificate factor prime"); product *= q; }
	require(product == cpp_int(p)-1, "certificate factorization of p-1");
	cpp_int n = p, a = witness;
	require(boost::multiprecision::powm(a, cpp_int(p-1), n) == 1,
	        "certificate Fermat equality");
	for (ull q : set<ull>(f.begin(), f.end())) {
		cpp_int x = boost::multiprecision::powm(a, cpp_int((p-1)/q), n);
		x = (x+n-1)%n;
		require(gcd(x.convert_to<ull>(), p) == 1, "certificate gcd condition");
	}
	primality(p, true);
	factorization(p, {p});
}

int main() {
	auto start = chrono::steady_clock::now();
	constexpr int limit = 250000;
	vector<bool> prime(limit+1, true);
	prime[0] = prime[1] = false;
	for (int p = 2; p*p <= limit; ++p) if (prime[p])
		for (int n = p*p; n <= limit; n += p) prime[n] = false;
	for (int n = 0; n <= limit; ++n) primality(ull(n), prime[n]);
	for (ull n = 1; n <= 20000; ++n) factorization(n, trialFactors(n));
	for (int i = 0; i < 1500; ++i) {
		ull n = rng()%1000000000ULL+1;
		auto f = trialFactors(n);
		primality(n, f.size() == 1);
		factorization(n, f);
	}
	// Known Carmichael/strong pseudoprimes and unsigned/signed endpoints.
	vector<pair<ull,vector<ull>>> composite{
		{341, {11,31}}, {561, {3,11,17}}, {1105, {5,13,17}},
		{1729, {7,13,19}}, {2465, {5,17,29}}, {2821, {7,13,31}},
		{6601, {7,23,41}}, {3215031751ULL, {151,751,28351}},
		{341550071728321ULL, {10670053,32010157}},
		{3825123056546413051ULL, {149491,747451,34233211}},
		{18446744073709551615ULL, {3,5,17,257,641,65537,6700417}},
		{18446744073709551614ULL, {2,7,7,73,127,337,92737,649657}},
		{9223372036854775807ULL, {7,7,73,127,337,92737,649657}},
		{124376107291ULL, {352523,352817}}
	};
	for (auto [n,f] : composite) {
		cpp_int product = 1;
		for (ull p : f) { require(trialPrime(p), "composite fixture factors"); product *= p; }
		require(product == n, "composite fixture product");
		primality(n, false); factorization(n, f);
		ull d = rho64(n);
		require(d > 1 && d < n && n%d == 0, "rho proper divisor");
	}
	certify(18446744073709551557ULL, 2,
	        {2,2,11,137,547,5594472617641ULL});
	certify(9223372036854775783ULL, 3,
	        {2,3,3,3,3,17,23,319279,456065899});
	certify(2305843009213693951ULL, 37,
	        {2,3,3,5,5,7,11,13,31,41,61,151,331,1321});
	vector<ull> big{4294967291ULL,4294967279ULL,4294967231ULL,
	                2147483647ULL,1000000007ULL,1000000009ULL};
	for (ull p : big) { require(trialPrime(p), "32-bit prime fixture"); primality(p, true); }
	for (size_t i = 0; i < big.size(); ++i) for (size_t j = i; j < big.size(); ++j) {
		cpp_int product = cpp_int(big[i])*big[j];
		require(product <= numeric_limits<ull>::max(), "semiprime fits uint64");
		ull n = product.convert_to<ull>();
		primality(n, false); factorization(n, {big[i],big[j]});
	}
	vector<ull> small{2,3,5,7,11,97,65537};
	for (ull p : small) {
		cpp_int product = 1;
		vector<ull> f;
		while (product*p <= numeric_limits<ull>::max()) {
			product *= p; f.push_back(p);
			factorization(product.convert_to<ull>(), f);
		}
	}
	vector<ull> pool = small;
	pool.insert(pool.end(), big.begin(), big.end());
	for (int i = 0; i < 250; ++i) {
		cpp_int product = 1;
		vector<ull> f;
		for (int j = 0; j < 10; ++j) {
			ull p = pool[size_t(rng()%pool.size())];
			if (product*p > numeric_limits<ull>::max()) break;
			product *= p; f.push_back(p);
		}
		factorization(product.convert_to<ull>(), f);
	}
	// Extra cross-check with independently implemented arithmetic/witnesses.
	// Unlike the exact certificates above, this oracle is probabilistic.
	mt19937 boostRng(713971);
	for (int i = 0; i < 200; ++i) {
		ull n = rng();
		bool probable = boost::multiprecision::miller_rabin_test(cpp_int(n), 48, boostRng);
		primality(n, probable);
	}
	double seconds = chrono::duration<double>(chrono::steady_clock::now()-start).count();
	cout << "PrimeFactor: " << primeCases << " primality cases, " << factorCases
	     << " exact factorizations, " << factorsChecked << " factors compared; "
	     << fixed << setprecision(3) << seconds << " s.\n";
}
