#include "ContestPreamble.h"
#include "../../content/various/MonotonicStack.h"
#include "../../content/various/MonotonicDeque.h"

size_t arrays = 0, checks = 0;
template<class T> void check(const vector<T>& a) {
	const auto saved = a;
	int n = sz(a);
	for (bool right : {false,true}) {
		auto got = nearestSmaller(a,right);
		assert(sz(got) == n);
		for (int i = 0; i < n; ++i) {
			int want = right ? n : -1;
			for (int j = i+(right ? 1 : -1); j >= 0 && j < n;
					j += right ? 1 : -1)
				if (a[j] < a[i]) { want = j; break; }
			assert(got[i] == want); ++checks;
		}
	}
	for (int k = 1; k <= n+2; ++k) {
		auto got = slidingMin(a,k);
		assert(sz(got) == max(0,n-k+1));
		for (int l = 0; l+k <= n; ++l) {
			int want = l;
			for (int i = l+1; i < l+k; ++i)
				if (a[i] <= a[want]) want = i;
			assert(got[l] == want); ++checks;
		}
	}
	assert(a == saved); ++arrays;
}

int main() {
	assert((nearestSmaller(vi{2,2,1}) == vi{-1,-1,-1}));
	assert((nearestSmaller(vi{2,2,1},true) == vi{2,2,3}));
	assert((slidingMin(vi{3,1,1,2},2) == vi{1,2,2}));
	for (int n = 0, ways = 1; n <= 8; ++n, ways *= 3)
		for (int mask = 0; mask < ways; ++mask) {
			vi a(n); int x = mask;
			for (int& v : a) { v = x%3-1; x /= 3; }
			check(a);
		}
	mt19937_64 rng(0xE20260928ULL);
	for (int run = 0; run < 4000; ++run) {
		vector<ll> a(rng()%41);
		for (ll& x : a) {
			auto pick = rng()%20;
			x = pick == 0 ? LLONG_MIN : pick == 1 ? LLONG_MAX : ll(rng()%31)-15;
		}
		check(a);
	}
	check(vector<double>{-1.,2.,2.,0.,-1.});
	check(vector<string>{"b","a","a","c"});
	constexpr int n = 200000;
	for (int mode = 0; mode < 3; ++mode) {
		vi a(n);
		for (int i = 0; i < n; ++i) a[i] = mode == 0 ? i : mode == 1 ? n-i : 7;
		auto left = nearestSmaller(a), right = nearestSmaller(a,true);
		for (int i = 0; i < n; ++i) {
			assert(left[i] == (mode == 0 ? i-1 : -1));
			assert(right[i] == (mode == 1 ? i+1 : n));
			checks += 2;
		}
		for (int k : {1,17,10000,n,n+1,INT_MAX}) {
			auto got = slidingMin(a,k);
			assert(sz(got) == max(0,n-k+1));
			for (int l = 0; l < sz(got); ++l) {
				assert(got[l] == (mode == 0 ? l : l+k-1)); ++checks;
			}
		}
	}
	cout << "Monotonic: " << arrays << " exhaustive/random arrays, " << checks
		<< " oracle/structural checks; empty, duplicates, extremes, k>n and 200000 elements passed\n";
}
