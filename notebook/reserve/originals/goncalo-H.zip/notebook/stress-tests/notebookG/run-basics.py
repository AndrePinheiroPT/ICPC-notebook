#!/usr/bin/env python3
"""Exercise G's array helpers and the exact printed STL listings."""
from pathlib import Path
import json
import os
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PREAMBLE, sep, _ = (ROOT / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep
env = os.environ.copy()
env.setdefault('ASAN_OPTIONS', 'detect_leaks=0')
with tempfile.TemporaryDirectory(prefix='notebookG-basics-') as temp:
    work = Path(temp)
    blocks = re.findall(r'\\begin\{lstlisting\}(?:\[[^\]]*\])?(.*?)\\end\{lstlisting\}',
                        (ROOT / 'content/contest/STLGuide.tex').read_text(), re.S)
    assert len(blocks) == 4
    stl = work / 'STLGuide.cpp'
    stl.write_text(PREAMBLE + '\nint main() {\n' + '\n'.join(blocks) + r'''
assert((items == vector<pair<ll,int>>{{9,1},{9,3},{7,2}}));
assert(first == 1 && past == 3 && found);
assert(cost == 1 && id == 7 && pq.top() == make_pair(4LL,2));
assert(freq.size() == 2 && freq.at(4) == 2 && freq.at(-1) == 1 && !has7);
assert(s == set<int>({2,5}) && bag == multiset<int>({2,5}));
// Also exercise the documented absent-value and one-copy boundaries.
assert(lower_bound(a.begin(),a.end(),10) == a.end());
assert(upper_bound(a.begin(),a.end(),1) == a.begin());
if (auto it = bag.find(99); it != bag.end()) bag.erase(it);
assert(bag.size() == 2);
bag.insert(2); bag.erase(2); assert(bag == multiset<int>({5}));
cout << "PASS exact STLGuide listings and boundary checks\n";
}
''')
    sources = [HERE / f'{name}.cpp' for name in
               ('ArrayBasics', 'TwoPointers', 'CoordinateCompression')] + [stl]
    for mode, flags in (
        ('release', ['-O2']),
        ('asan-ubsan', ['-O1', '-g', '-fsanitize=address,undefined',
                        '-fno-sanitize-recover=all', '-fno-omit-frame-pointer', '-no-pie'])):
        for source in sources:
            binary = work / (source.stem + '-' + mode)
            subprocess.run(['g++', '-std=gnu++17', '-Wall', '-Wextra', '-Werror',
                            *flags, str(source), '-o', str(binary)], check=True)
            print(f'{mode}: {source.stem}', flush=True)
            subprocess.run([str(binary)], check=True, env=env)
    mains = json.loads((HERE / 'basics-instantiations.json').read_text())
    for header, main in mains.items():
        source = work / 'isolated.cpp'
        source.write_text(PREAMBLE + '\n#include ' + json.dumps(str(ROOT/header)) + '\n' + main)
        binary = work / 'isolated'
        subprocess.run(['g++', '-std=gnu++17', '-O1', '-Wall', '-Wextra', '-Werror',
                        str(source), '-o', str(binary)], check=True)
        subprocess.run([str(binary)], check=True)
        subprocess.run(['g++', '-std=gnu++17', '-DLOCAL', '-Wall', '-Wextra', '-Werror',
                        '-fsyntax-only', str(source)], check=True)
        print(f'PASS isolated Contest preamble + LOCAL: {header}', flush=True)
