#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/various/TwoPointers.h"

unsigned long long checks = 0;
void check(bool ok) { ++checks; if (!ok) abort(); }
template<class T> pair<int,int> bruteDistinct(const vector<T>& a,int k) {
	pair<int,int> best{0,0};
	for (int l = 0; l < sz(a); ++l) {
		set<T> used;
		for (int r = l; r < sz(a); ++r) {
			used.insert(a[r]);
			if (sz(used) <= k && r+1-l > best.second-best.first)
				best = {l,r+1};
		}
	}
	return best;
}
pair<int,int> bruteSum(const vector<ll>& a,ll limit) {
	pair<int,int> best{0,0};
	for (int l = 0; l < sz(a); ++l) {
		__int128 sum = 0;
		for (int r = l; r < sz(a); ++r) {
			sum += a[r];
			if (sum <= limit && r+1-l > best.second-best.first)
				best = {l,r+1};
		}
	}
	return best;
}
int main() {
	for (int n = 0; n <= 7; ++n) {
		int choices = 1;
		for (int i = 0; i < n; ++i) choices *= 3;
		for (int mask = 0; mask < choices; ++mask) {
			int x = mask;
			vi a(n);
			for (int& v : a) { v = x%3-1; x /= 3; }
			for (int k = 0; k <= 4; ++k)
				check(longestKDistinct(a,k) == bruteDistinct(a,k));
			vector<ll> nonnegative(a.begin(),a.end());
			for (ll& v : nonnegative) ++v;
			for (ll limit = 0; limit <= 9; ++limit)
				check(longestSumAtMost(nonnegative,limit) == bruteSum(nonnegative,limit));
		}
	}
	mt19937 rng(749237);
	for (int run = 0; run < 3000; ++run) {
		int n = rng()%41, k = rng()%12;
		vector<ll> a(n);
		for (ll& x : a) x = ll(rng()%19)-9;
		check(longestKDistinct(a,k) == bruteDistinct(a,k));
		for (ll& x : a) x += 9;
		ll limit = rng()%151;
		check(longestSumAtMost(a,limit) == bruteSum(a,limit));
	}
	vector<string> words{"red","blue","red","green"};
	check(longestKDistinct(words,2) == make_pair(0,3));
	for (const vector<ll>& a : vector<vector<ll>>{{LLONG_MAX},{0,LLONG_MAX,0},{0,0,0},{5,6}})
		for (ll limit : {0LL,4LL,LLONG_MAX})
			check(longestSumAtMost(a,limit) == bruteSum(a,limit));
	cout << "PASS TwoPointers: " << checks << " checks\n";
}
