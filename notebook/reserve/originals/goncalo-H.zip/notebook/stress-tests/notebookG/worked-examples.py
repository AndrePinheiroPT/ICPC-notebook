#!/usr/bin/env python3
"""Test four worked algorithms and compile the literal Usage printed in their header."""

import argparse
import os
from pathlib import Path
import re
import subprocess
import tempfile


def printed_usage(header):
    lines = []
    found = False
    for raw in header.read_text().split("*/", 1)[0].splitlines():
        line = re.sub(r"^\s*\* ?", "", raw)
        if not found:
            if line.startswith("Usage:"):
                found = True
                lines.append(line[len("Usage:"):].lstrip())
        elif re.match(r"^[A-Za-z][A-Za-z ]*:", line):
            break
        else:
            lines.append(line)
    if not found:
        raise RuntimeError("WorkedExamples.h has no Usage metadata")
    return "\n".join(lines).rstrip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sanitize", action="store_true")
    parser.add_argument("--compiler", default="g++")
    parser.add_argument("--emit", type=Path, help="Save the extracted Usage translation unit")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    header = root / "content/various/WorkedExamples.h"
    code = """#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
"""
    code += f'#include "{header.as_posix()}"\nint main() {{\n'
    code += printed_usage(header)
    code += """
    if (pairs != 3 || starts != 3 || hours != 7 || !possible) {
        cerr << "Printed WorkedExamples Usage failed\\n";
        return 1;
    }
    cout << "WorkedExamples Usage: 4/4 exact printed examples OK\\n";
}
"""
    if args.emit:
        args.emit.write_text(code)
    flags = ["-std=c++17", "-Wall", "-Wextra", "-Wshadow", "-Wconversion", "-Werror"]
    if args.sanitize:
        flags += ["-O1", "-g", "-D_GLIBCXX_DEBUG", "-fsanitize=address,undefined",
                  "-fno-omit-frame-pointer", "-fno-pie", "-no-pie"]
    else:
        flags += ["-O2"]
    env = os.environ.copy()
    if args.sanitize:
        env.setdefault("ASAN_OPTIONS", "detect_leaks=0")
        env.setdefault("UBSAN_OPTIONS", "halt_on_error=1")
    with tempfile.TemporaryDirectory(prefix="notebookG-worked-") as temporary:
        usage_source = Path(temporary) / "usage.cpp"
        usage_source.write_text(code)
        sources = [root / "stress-tests/notebookG/WorkedExamples.cpp", usage_source]
        for index, source in enumerate(sources):
            executable = Path(temporary) / f"test-{index}"
            subprocess.run([args.compiler, *flags, str(source), "-o", str(executable)], check=True)
            subprocess.run([str(executable)], check=True, env=env)


if __name__ == "__main__":
    main()
