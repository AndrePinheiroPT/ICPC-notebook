#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/various/WorkedExamples.h"

static array<long long,4> cases{};
static mt19937_64 rng(2026093007ULL);

void require(bool ok, const char* why) {
	if (!ok) { cerr << why << '\n'; abort(); }
}

void checkPairs(const vector<ll>& a) {
	ll want = 0;
	for (int i = 0; i < sz(a); ++i)
		for (int j = i+1; j < sz(a); ++j) want += a[i] == a[j];
	require(equalKeyPairs(a) == want, "equal pairs versus every index pair");
	++cases[0];
}

void testPairs() {
	for (int n = 0; n <= 9; ++n) {
		int count = 1;
		for (int i = 0; i < n; ++i) count *= 3;
		for (int mask = 0; mask < count; ++mask) {
			vector<ll> a(n);
			int x = mask;
			for (ll& v : a) { v = array<ll,3>{-2,0,5}[x%3]; x /= 3; }
			checkPairs(a);
		}
	}
	checkPairs({LLONG_MIN,LLONG_MAX,LLONG_MIN,0,LLONG_MAX});
	for (int trial = 0; trial < 2000; ++trial) {
		vector<ll> a(size_t(rng()%40));
		for (ll& v : a) v = array<ll,5>{LLONG_MIN,-1,0,7,LLONG_MAX}[rng()%5];
		checkPairs(a);
	}
	// A count exceeding INT_MAX, without a quadratic reference at this size.
	require(equalKeyPairs(vector<ll>(100000,LLONG_MAX)) == 4999950000LL,
		"pair count must use 64 bits");
}

void checkWindows(const string& s, int k, char wanted, int need) {
	int want = 0;
	for (int start = 0; start < sz(s); ++start) {
		int count = 0;
		for (int j = 0; j < k; ++j) count += s[(start+j)%sz(s)] == wanted;
		want += count >= need;
	}
	require(countCircularWindows(s,k,wanted,need) == want,
		"circular windows versus independent per-start scan");
	++cases[1];
}

string binaryWord(int n, int mask) {
	string s(n,'a');
	for (int i = 0; i < n; ++i) if (mask >> i & 1) s[i] = 'b';
	return s;
}

void testWindows() {
	// Empty input is outside the contract (1 <= k <= n).
	for (int n = 1; n <= 8; ++n) for (int mask = 0; mask < (1<<n); ++mask) {
		string s = binaryWord(n,mask);
		for (int k = 1; k <= n; ++k) for (int need = 0; need <= n+1; ++need)
			for (char wanted : string("abx")) checkWindows(s,k,wanted,need);
	}
	checkWindows("a",1,'a',INT_MAX);
	checkWindows("##..",2,'#',1);
	for (int trial = 0; trial < 2000; ++trial) {
		int n = 1+int(rng()%80);
		string s(n,'a');
		for (char& c : s) c = string("ab#")[rng()%3];
		checkWindows(s,1+int(rng()%unsigned(n)),string("ab#x")[rng()%4],
			int(rng()%unsigned(n+3)));
	}
}

ll coveredOracle(const vector<pair<ll,ll>>& intervals) {
	// Atomize the line at all endpoints; test each atomic segment against
	// every original interval. No interval merging or sweep-state recurrence.
	vector<ll> points;
	for (auto [l,r] : intervals) { points.push_back(l); points.push_back(r); }
	sort(points.begin(),points.end());
	points.erase(unique(points.begin(),points.end()),points.end());
	__int128 answer = 0;
	for (int i = 1; i < sz(points); ++i) {
		bool covered = false;
		for (auto [l,r] : intervals)
			covered |= l <= points[i-1] && points[i] <= r;
		if (covered) answer += (__int128)points[i]-points[i-1];
	}
	require(answer <= LLONG_MAX, "oracle union exceeds contract bound");
	return ll(answer);
}

void checkCovered(const vector<pair<ll,ll>>& intervals) {
	require(coveredTime(intervals) == coveredOracle(intervals),
		"covered time versus endpoint atomization");
	++cases[2];
}

void testCovered() {
	vector<pair<ll,ll>> choices;
	for (ll l = 0; l <= 4; ++l) for (ll r = l; r <= 4; ++r)
		choices.push_back({l,r});
	for (int n = 0; n <= 4; ++n) {
		int count = 1;
		for (int i = 0; i < n; ++i) count *= sz(choices);
		for (int mask = 0; mask < count; ++mask) {
			vector<pair<ll,ll>> a(n);
			int x = mask;
			for (auto& interval : a) { interval = choices[x%sz(choices)]; x /= sz(choices); }
			checkCovered(a);
		}
	}
	checkCovered({{0,1},{LLONG_MAX-1,LLONG_MAX}}); // old total+right overflows
	checkCovered({{0,LLONG_MAX-1},{LLONG_MAX,LLONG_MAX}});
	checkCovered({{0,LLONG_MAX}});
	checkCovered({{LLONG_MAX,LLONG_MAX}});
	checkCovered({{0,LLONG_MAX},{0,LLONG_MAX},{1,2}});
	array<ll,7> edge{0,1,2,LLONG_MAX/2,LLONG_MAX-2,LLONG_MAX-1,LLONG_MAX};
	for (int trial = 0; trial < 4000; ++trial) {
		vector<pair<ll,ll>> a(size_t(rng()%15));
		for (auto& [l,r] : a) {
			if (trial%2) { l = edge[rng()%edge.size()]; r = edge[rng()%edge.size()]; }
			else { l = ll(rng() >> 1); r = ll(rng() >> 1); }
			if (l > r) swap(l,r);
		}
		checkCovered(a);
	}
}

bool splitOracle(const string& s, const vector<string>& dictionary) {
	if (s.empty()) return true;
	set<string> words(dictionary.begin(),dictionary.end());
	// Try every placement of cuts between characters, independently of trie/DP.
	for (unsigned mask = 0; mask < (1U << (sz(s)-1)); ++mask) {
		int first = 0;
		bool good = true;
		for (int past = 1; past <= sz(s); ++past)
			if (past == sz(s) || (mask >> (past-1) & 1U)) {
				if (!words.count(s.substr(size_t(first),size_t(past-first)))) {
					good = false; break;
				}
				first = past;
			}
		if (good) return true;
	}
	return false;
}

void checkWords(const string& s, const vector<string>& dictionary) {
	Trie trie;
	for (const auto& word : dictionary) trie.insert(word);
	require(splitIntoWords(s,trie) == splitOracle(s,dictionary),
		"word splitting versus every cut pattern");
	++cases[3];
}

void testWords() {
	vector<string> pool{"a","b","aa","ab","ba","bb"};
	for (int selected = 0; selected < (1<<sz(pool)); ++selected) {
		vector<string> words;
		for (int i = 0; i < sz(pool); ++i) if (selected >> i & 1)
			words.push_back(pool[i]);
		if (selected%2) words.push_back("");
		if (selected%3 && !words.empty()) words.push_back(words[0]);
		for (int n = 0; n <= 8; ++n)
			for (int mask = 0; mask < (1<<n); ++mask)
				checkWords(binaryWord(n,mask),words);
	}
	checkWords("abc",{"a","ab","bc"}); // longest-first greedy trap
	checkWords("abcd",{"ab","abc","cd"});
	checkWords("aaaa",{"aa","aa",""}); // reusable word + duplicate
	checkWords("",{}); checkWords("",{""}); checkWords("a",{"",""});
	checkWords("azzzz",{"az","z"});
	for (int trial = 0; trial < 1000; ++trial) {
		vector<string> words(size_t(rng()%10));
		for (string& word : words) {
			word.resize(size_t(rng()%6));
			for (char& c : word) c = char('a'+rng()%3);
		}
		string s(size_t(rng()%13),'a');
		for (char& c : s) c = char('a'+rng()%3);
		checkWords(s,words);
	}
	Trie empty;
	require(!splitIntoWords(string(100000,'a'),empty), "empty dictionary at large n");
	Trie longWord; longWord.insert(string(1000,'a'));
	require(splitIntoWords(string(2000,'a'),longWord), "reuse a long word");
	require(!splitIntoWords(string(1999,'a')+'b',longWord), "long unmatched suffix");
}

int main() {
	testPairs(); testWindows(); testCovered(); testWords();
	cout << "WorkedExamples differential cases: pairs=" << cases[0]
		<< " windows=" << cases[1] << " intervals=" << cases[2]
		<< " word-break=" << cases[3] << "; boundaries OK\n";
}
