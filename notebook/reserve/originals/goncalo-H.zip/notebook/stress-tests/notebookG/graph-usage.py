#!/usr/bin/env python3
"""Compile and run the exact Usage metadata printed for every active graph header."""

import argparse
import os
from pathlib import Path
import re
import subprocess
import tempfile


CHECKS = {
    "Traversal.h": """
    require(dist == vi({0,1,0}), "nearest sources");
    require(parent[0] == -1 && parent[2] == -1, "source parents");
    require(ok && color == vi({0,1,0}), "bipartition");
    require(route == vi({0,1}), "route from selected depot");
""",
    "GridBFS.h": """
    require(d[0*3+2] == 2 && d[1*3+1] == -1, "grid distances");
    require(p[0] == -1 && p[8] == -1, "grid source parents");
""",
    "Dijkstra.h": """
    require(dist == vector<ll>({0,7}), "minimum fares");
    require(restorePath(0,1,parent) == vi({0,1}), "fare route");
""",
    "ZeroOneBFS.h": """
    require(dist == vi({0,0,0}) && tickets == 0, "free route");
    require(parent[2] == 1, "free detour through vertex 1");
""",
    "BellmanFord.h": """
    require(answer == 2 && nodes[2].prev == 1, "rebated fare");
""",
    "FloydWarshall.h": """
    require(cost == 2 && m[2][0] == FW::inf, "all-pairs fares");
    require(m[0][0] == 0 && m[1][1] == 0 && m[2][2] == 0, "diagonal");
""",
    "Kahn.h": """
    require(possible && order == vi({0,1,2}), "installation order");
    require(cycle, "cyclic requirements");
""",
    "Kruskal.h": """
    require(connected && cost == 6 && ids == vi({1,0}), "minimum cable cost");
""",
    "StrongComponents.h": """
    require(comp == vi({0,0,1,1}) && same, "return-trip groups");
    require(dag == vector<vi>({{1},{}}), "collapsed one-way road");
""",
    "Lowlink.h": """
    require(b.bridges == vi({3}), "critical road ID");
    require(b.cut == vi({0,1,0,0}), "critical town");
""",
    "TwoSAT.h": """
    require(ok && sat.answer == vi({1,0}), "backup selection");
""",
    "Hierholzer.h": """
    require(v == vi({0,1,2}) && ids == vi({0,1}), "road inspection trail");
""",
    "DinicFlow.h": """
    require(sent == 3, "pipe bottleneck");
    require(f.flow(0,2) == 0, "incremental second flow");
""",
    "MinCostFlow.h": """
    require(sent == 2 && cost == 8, "shipping bill");
""",
    "JumpTable.h": """
    require(u == 2, "five shuttle rides");
""",
    "TreeTour.h": """
    require(first == 1 && past == 4, "team interval");
    require(team == vi({1,3,2}), "team members");
""",
    "TreeLCA.h": """
    require(c == 1 && d == 2 && up == 0, "manager and distance queries");
    require(t.ancestor(2,3) == -1, "absent ancestor");
""",
    "TreeDiameter.h": """
    require(length == 6 && a == 2 && b == 0, "farthest towns");
""",
}


def usage(path):
    """Preserve all printed C++ lines, stopping at the next metadata field."""
    comment = path.read_text().split("*/", 1)[0]
    lines = []
    found = False
    for raw in comment.splitlines():
        line = re.sub(r"^\s*\* ?", "", raw)
        if not found:
            if line.startswith("Usage:"):
                found = True
                lines.append(line[len("Usage:"):].lstrip())
        elif re.match(r"^[A-Za-z][A-Za-z ]*:", line):
            break
        else:
            lines.append(line)
    if not found:
        raise RuntimeError(f"Missing Usage metadata: {path}")
    while lines and not lines[-1].strip():
        lines.pop()
    if not 3 <= len(lines) <= 6:
        raise RuntimeError(f"Expected 3-6 Usage lines: {path.name} has {len(lines)}")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sanitize", action="store_true")
    parser.add_argument("--compiler", default="g++")
    parser.add_argument("--emit", type=Path, help="Also save the generated C++ for inspection")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    graph = root / "content/graph"
    selected = re.findall(r"\\kactlimport\{([^}]+\.h)\}", (graph / "chapter.tex").read_text())
    if len(selected) != len(set(selected)) or set(selected) != set(CHECKS):
        raise RuntimeError("Graph Usage coverage differs from active chapter imports: "
                           f"untested={set(selected)-set(CHECKS)}, inactive={set(CHECKS)-set(selected)}")
    code = """#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
void require(bool ok, const char* label) {
    if (!ok) { cerr << label << '\\n'; abort(); }
}
"""
    for name in selected:
        code += f'#include "{(graph/name).as_posix()}"\n'
    calls = []
    for name in selected:
        function = "example_" + Path(name).stem
        code += f"\nvoid {function}() {{\n"
        code += usage(graph / name) + "\n" + CHECKS[name] + "}\n"
        calls.append(f"    {function}();")
    code += "\nint main() {\n" + "\n".join(calls)
    code += f'\n    cout << "Graph Usage: {len(selected)}/{len(selected)} printed examples OK\\n";\n}}\n'
    if args.emit:
        args.emit.write_text(code)
    flags = ["-std=c++17", "-Wall", "-Wextra", "-Wshadow", "-Werror"]
    if args.sanitize:
        flags += ["-O1", "-g", "-D_GLIBCXX_DEBUG", "-fsanitize=address,undefined",
                  "-fno-omit-frame-pointer", "-fno-pie", "-no-pie"]
    else:
        flags += ["-O2", "-DNDEBUG"]
    with tempfile.TemporaryDirectory(prefix="notebookG-graph-usage-") as temporary:
        source = Path(temporary) / "examples.cpp"
        executable = Path(temporary) / "examples"
        source.write_text(code)
        subprocess.run([args.compiler, *flags, str(source), "-o", str(executable)], check=True)
        env = os.environ.copy()
        if args.sanitize:
            env.setdefault("ASAN_OPTIONS", "detect_leaks=0")
        subprocess.run([str(executable)], check=True, env=env)
    print("Covered: " + ", ".join(selected))


if __name__ == "__main__":
    main()
