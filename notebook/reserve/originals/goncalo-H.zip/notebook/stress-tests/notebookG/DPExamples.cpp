#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) int((x).size())
#include "../../content/various/DPExamples.h"

static uint64_t checks=0;
static uint64_t arrayCases=0,itemCases=0,coinCases=0,stringCases=0,gridCases=0;
static mt19937_64 rng(0xD026E7ULL);
void ck(bool value,const char* label) {
	++checks;
	if(!value) {cerr<<"FAIL "<<label<<'\n';exit(1);}
}

void arrayCase(const vector<ll>& a) {
	ll linear=LLONG_MIN,circular=LLONG_MIN;
	for(int start=0;start<sz(a);++start) {
		ll sum=0;
		for(int len=1;len<=sz(a);++len) {
			sum+=a[(start+len-1)%sz(a)];
			circular=max(circular,sum);
			if(start+len<=sz(a)) linear=max(linear,sum);
		}
	}
	ck(maxSubarray(a)==pair<ll,ll>{linear,circular},"Kadane vs every interval");
	++arrayCases;
}
void testArrays() {
	for(int n=1;n<=8;++n) {
		int count=1;for(int i=0;i<n;++i)count*=3;
		for(int code=0;code<count;++code) {
			int x=code;vector<ll>a(n);
			for(ll&v:a) {v=array<ll,3>{-3,0,4}[x%3];x/=3;}
			arrayCase(a);
		}
	}
	arrayCase({-4000000000000000LL,7,-4000000000000000LL});
	arrayCase({5000000000000000LL,-8000000000000000LL,6000000000000000LL});
	arrayCase({LLONG_MIN});arrayCase({LLONG_MAX});
}

void itemCase(const vi& w,const vector<ll>& v,int limit) {
	vector<ll>want(limit+1);
	for(unsigned mask=0;mask<(1U<<sz(w));++mask) {
		ll weight=0,value=0;
		for(int i=0;i<sz(w);++i) if(mask>>i&1U) weight+=w[i],value+=v[i];
		for(int cap=0;cap<=limit;++cap) if(weight<=cap)want[cap]=max(want[cap],value);
	}
	for(int cap=0;cap<=limit;++cap)
		ck(knapsack01(w,v,cap)==want[cap],"0/1 knapsack vs all item subsets");
	++itemCases;
}
void testItems() {
	for(int n=0;n<=5;++n) {
		int count=1;for(int i=0;i<n;++i)count*=6;
		for(int code=0;code<count;++code) {
			int x=code;vi w(n);vector<ll>v(n);
			for(int i=0;i<n;++i) {w[i]=(x%6)/2;v[i]=(x%2)?3:-2;x/=6;}
			itemCase(w,v,7);
		}
	}
	for(int it=0;it<150;++it) {
		int n=int(rng()%12);vi w(n);vector<ll>v(n);
		for(int i=0;i<n;++i)w[i]=int(rng()%10),v[i]=ll(rng()%61)-20;
		itemCase(w,v,25);
	}
	itemCase({INT_MAX,0,2},{1000000000000LL,5,2000000000000LL},3);
}

// Oracle enumerates multiplicities for each denomination, not table transitions.
pair<ll,int> coinOracle(const vi& c,int at,int remaining,int used=0) {
	if(at==sz(c)) return remaining==0?pair<ll,int>{1,used}:pair<ll,int>{0,INT_MAX};
	ll count=0;int fewest=INT_MAX;
	for(int q=0;q*c[at]<=remaining;++q) {
		auto [ways,best]=coinOracle(c,at+1,remaining-q*c[at],used+q);
		count+=ways;fewest=min(fewest,best);
	}
	return {count,fewest};
}
ll orderedOracle(const vi& coins,int remaining) {
	if(!remaining)return 1;
	ll count=0;
	for(int c:coins)if(c<=remaining)count+=orderedOracle(coins,remaining-c);
	return count;
}
int orderedFromNotes(const vi& coins,int S,int mod) {
	vi dp(S+1);dp[0]=1%mod;
	for(int s=1;s<=S;++s)for(int c:coins)if(c<=s)
		dp[s]=int((dp[s]+ll(dp[s-c]))%mod);
	return dp[S];
}
void testCoins() {
	for(int mask=0;mask<(1<<6);++mask) {
		vi c;for(int i=0;i<6;++i)if(mask>>i&1)c.push_back(i+1);
		for(int s=0;s<=18;++s) {
			auto [ways,best]=coinOracle(c,0,s);
			ck(minCoins(c,s)==(best==INT_MAX?-1:best),"minimum coins vs multiplicities");
			for(int mod:{1,2,7,97,1000000007,INT_MAX})
				ck(coinWays(c,s,mod)==ways%mod,"coin combinations vs multiplicities");
			reverse(c.begin(),c.end());
			ck(coinWays(c,s)==ways,"coin order does not change combinations");
			if(s<=10)ck(orderedFromNotes(c,s,97)==orderedOracle(c,s)%97,"ordered loop variant");
			++coinCases;
		}
	}
	ck(minCoins({4,4,7},8)==2,"duplicate denominations harmless for minimum");
	ck(coinWays({INT_MAX},3)==0,"coin greater than target");
	// Larger counts exercise residues near INT_MAX; exact wide 2D table oracle.
	vi coins{1,2,3,4,5,6,7,8,9,10};
	vector<vector<__int128_t>> exact(coins.size()+1,vector<__int128_t>(301));
	exact[0][0]=1;
	for(int i=1;i<=sz(coins);++i)for(int s=0;s<=300;++s)
		for(int q=0;q*coins[i-1]<=s;++q)exact[i][s]+=exact[i-1][s-q*coins[i-1]];
	for(int mod:{1,2,1000000007,INT_MAX})
		ck(coinWays(coins,300,mod)==int(exact.back()[300]%mod),"wide count / full int modulus");
}

bool isSubsequence(const string& a,const string& b) {
	int i=0;for(char c:b)if(i<sz(a)&&a[i]==c)++i;return i==sz(a);
}
int lcsOracle(const string& a,const string& b) {
	int best=0;
	for(unsigned mask=0;mask<(1U<<sz(a));++mask) {
		string sub;for(int i=0;i<sz(a);++i)if(mask>>i&1U)sub+=a[i];
		if(isSubsequence(sub,b))best=max(best,sz(sub));
	}
	return best;
}
void testStrings() {
	vector<string> strings;
	for(int n=0;n<=6;++n)for(int mask=0;mask<(1<<n);++mask) {
		string s(n,'a');for(int i=0;i<n;++i)if(mask>>i&1)s[i]='b';strings.push_back(s);
	}
	for(const string&a:strings)for(const string&b:strings) {
		ck(lcsLength(a,b)==lcsOracle(a,b),"LCS vs all subsequences");
		++stringCases;
	}
	ck(lcsLength("","abc")==0 && lcsLength("abc","")==0,"empty LCS arguments");
	ck(lcsLength(string("\0x\0",3),string("\0\0",2))==2,"LCS embedded null bytes");
}

ll gridOracle(const vector<string>& g,int r=0,int c=0) {
	if(g.empty()||g[0].empty()||r==sz(g)||c==sz(g[0])||g[r][c]=='#')return 0;
	if(r==sz(g)-1&&c==sz(g[0])-1)return 1;
	return gridOracle(g,r+1,c)+gridOracle(g,r,c+1);
}
void testGrids() {
	for(int n=1;n<=3;++n)for(int m=1;m<=4;++m)
		for(int mask=0;mask<(1<<(n*m));++mask) {
			vector<string>g(n,string(m,'.'));
			for(int i=0;i<n*m;++i)if(mask>>i&1)g[i/m][i%m]='#';
			ll want=gridOracle(g);
			for(int mod:{1,2,7,1000000007,INT_MAX})
				ck(gridPaths(g,mod)==want%mod,"grid paths vs every route");
			++gridCases;
		}
	ck(gridPaths({})==0 && gridPaths({"",""})==0,"empty grids");
	// Independent binomial for open grid; exercises int-modulus additions.
	vector<string>g(18,string(18,'.'));
	__int128_t ways=1;for(int i=1;i<=17;++i)ways=ways*(17+i)/i;
	for(int mod:{1,2,1000000007,INT_MAX})
		ck(gridPaths(g,mod)==int(ways%mod),"open grid vs binomial coefficient");
}
int main() {
	testArrays();testItems();testCoins();testStrings();testGrids();
	cout<<"DPExamples: "<<arrayCases<<" arrays, "<<itemCases<<" item sets, "
	    <<coinCases<<" coin targets, "<<stringCases<<" string pairs, "
	    <<gridCases<<" obstacle grids; "<<checks<<" checks passed.\n";
}
