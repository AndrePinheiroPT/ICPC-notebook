#!/usr/bin/env python3
"""Execute the literal C++ listings printed in GraphGuide.tex."""
from pathlib import Path
import re, subprocess, tempfile, os
root=Path(__file__).resolve().parents[2]
blocks=re.findall(r'\\begin\{lstlisting\}(?:\[[^\]]*\])?\s*\n(.*?)\\end\{lstlisting\}',(root/'content/graph/GraphGuide.tex').read_text(),re.S)
assert len(blocks)==2
checks=['assert(d==vector<ll>({0,5,7}) && p==vi({-1,0,1}) && d[2]+fee[0]==10);','assert(sent==1 && chosen==1 && f.lev[0]>=0 && f.lev[3]<0);']
pre=(root/'content/contest/template.cpp').read_text().split('int main() {')[0]
pre+='\n#include "content/graph/Dijkstra.h"\n#include "content/graph/DinicFlow.h"\n'
source=pre+'int main() {\n'+''.join('{\n'+b+'\n'+c+'\n}\n' for b,c in zip(blocks,checks))+'}\n'
env=dict(os.environ);env.setdefault('ASAN_OPTIONS','detect_leaks=0')
with tempfile.TemporaryDirectory(prefix='notebook-g-graphguide-') as tmp:
 p=Path(tmp);(p/'test.cpp').write_text(source)
 for mode,flags in [('release',['-O2']),('sanitize',['-O1','-g','-DLOCAL','-D_GLIBCXX_DEBUG','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'])]:
  subprocess.run(['g++','-std=gnu++17','-Wall','-Wextra','-Werror','-I',str(root),*flags,str(p/'test.cpp'),'-o',str(p/'run')],check=True)
  subprocess.run([str(p/'run')],env=env,check=True)
  print('PASS',mode,'2 exact GraphGuide listings',flush=True)
