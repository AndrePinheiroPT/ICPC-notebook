#!/usr/bin/env python3
"""Compile and execute the exact Usage metadata printed for Various."""
from pathlib import Path
import re,json,tempfile,subprocess,os,hashlib
root=Path(__file__).resolve().parents[2]
checks={
'CoordinateCompression.h':'assert(values==vi({10,50}) && rank==vi({1,0,1}));',
'TwoPointers.h':'assert(l==0 && r==3 && (w==pair<int,int>(0,2)));',
'Subsequence.h':'assert(removed==2 && ids.size()==3 && weak.size()==4); vi values;for(int id:ids)values.push_back(height[id]);assert(values==vi({1,2,4}));',
'SubsetBits.h':'assert(ten && !five && possible[0] && possible[3] && possible[7]);',
'SOS.h':'assert(count==2 && recipe[2]==0 && recipe[7]==2);',
'MonotonicStack.h':'assert(left==vi({-1,-1,1,1}) && right==vi({1,4,4,4}));',
'MonotonicDeque.h':'assert(at==vi({1,3,3}) && minimum==vi({2,1,1}));',
'CoverIntervals.h':'assert(count==2 && chosen && *chosen==vi({1,2}));',
'Histogram.h':'assert(area==8 && l==2 && r==4);',
'GregorianDays.h':'assert(elapsed==2 && inclusive==3);',
'DPExamples.h':'assert(linear==6 && circular==11 && best==9 && few==2 && ways==2 && common==2 && paths==3);'}
pre=(root/'content/contest/template.cpp').read_text().split('int main() {')[0]
includes=''; snippets=''; records=[]
for header,check in checks.items():
 p=root/'content/various'/header;s=p.read_text();block=s.split('/**',1)[1].split('*/',1)[0]
 lines=[re.sub(r'^\s*\* ?', '',line) for line in block.splitlines()]
 start=next(i for i,line in enumerate(lines) if line.startswith('Usage:'))
 usage=lines[start][len('Usage:'):]+ '\n'+'\n'.join(lines[start+1:])
 # The optional later Time metadata belongs to prose, not C++.
 usage=re.split(r'\n(?:Time|Memory|Status|Source|License):',usage)[0]
 includes+='#include '+json.dumps(str(p))+'\n'
 snippets+='\n{\n'+usage+'\n'+check+'\n}\n'
 records.append({'header':str(p.relative_to(root)),'usage_sha256':hashlib.sha256(usage.encode()).hexdigest()})
env=dict(os.environ);env.setdefault('ASAN_OPTIONS','detect_leaks=0')
with tempfile.TemporaryDirectory(prefix='notebookG-various-usage-') as temp:
 p=Path(temp);src=p/'examples.cpp';src.write_text(pre+includes+'\nint main(){\n'+snippets+'\n}\n')
 for mode,flags in [('release',['-O2']),('sanitize',['-O1','-g','-DLOCAL','-D_GLIBCXX_DEBUG','-fsanitize=address,undefined','-fno-omit-frame-pointer','-no-pie'])]:
  exe=p/mode
  subprocess.run(['g++','-std=gnu++17','-Wall','-Wextra','-Wconversion','-Werror',*flags,str(src),'-o',str(exe)],check=True)
  subprocess.run([str(exe)],env=env,check=True)
  print('PASS',mode,': all 11 Various header examples (15 functions exercised)',flush=True)
out=root/'validation/notebookG/various-usage.json';out.write_text(json.dumps({'all_passed':True,'examples':records},indent=2)+'\n')
