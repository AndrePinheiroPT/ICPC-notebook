#!/usr/bin/env python3
"""Extract and execute AppliedExamples.tex's exact twelve listings."""
from pathlib import Path
import json
import os
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
PRE, sep, _ = (ROOT / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep
DOCUMENT = ROOT / 'content/various/AppliedExamples.tex'
BLOCKS = re.findall(r'\\begin\{lstlisting\}(.*?)\\end\{lstlisting\}',
                    DOCUMENT.read_text(), re.S)
assert len(BLOCKS) == 12
CASES = [
    ('inversions', ['various/CoordinateCompression.h', 'data-structures/Fenwick.h'],
     '3\n', r'''
assert(answer == 3);
for (int n = 0; n <= 7; ++n) {
    int limit = 1;
    for (int i = 0; i < n; ++i) limit *= 3;
    for (int code = 0; code < limit; ++code) {
        vector<ll> test(n); int value = code;
        for (ll& x : test) { x = value%3-1; value /= 3; }
        ll brute = 0;
        for (int i = 0; i < n; ++i)
            for (int j = i+1; j < n; ++j) brute += test[i] > test[j];
        assert(countInversions(test) == brute);
    }
}
'''),
    ('subtree-payroll', ['graph/TreeTour.h', 'data-structures/Fenwick.h'],
     '100 115\n', r'''
assert(teamPay(1) == salary[1]+salary[3]+salary[4]);
assert(teamPay(0) == accumulate(salary.begin(),salary.end(),0LL));
assert(teamPay(4) == 45);
setPay(4,45); assert(teamPay(1) == 115);
setPay(1,0); assert(teamPay(1) == salary[3]+salary[4]);
setPay(3,70); assert(teamPay(1) == 115 && teamPay(0) == 255);
'''),
    ('dag-paths', ['graph/Kahn.h'], '3\n', r'''
function<ll(int)> brute = [&](int u) -> ll {
    if (u == target) return 1;
    ll result = 0;
    for (int v : g[u]) result += brute(v);
    return result;
};
assert(brute(start) == 3);
'''),
    ('rectangle-updates-and-sums',
     ['data-structures/Difference2D.h', 'data-structures/PrefixSum2D.h'],
     '12\n24\n', r'''
vector<vector<ll>> brute(n,vector<ll>(m));
for (auto [r1,c1,r2,c2,x] : updates)
    for (int r = r1; r < r2; ++r)
        for (int c = c1; c < c2; ++c) brute[r][c] += x;
assert(finalGrid == brute);
for (int r1 = 0; r1 <= n; ++r1)
    for (int r2 = r1; r2 <= n; ++r2)
        for (int c1 = 0; c1 <= m; ++c1)
            for (int c2 = c1; c2 <= m; ++c2) {
                ll expected = 0;
                for (int r = r1; r < r2; ++r)
                    for (int c = c1; c < c2; ++c) expected += brute[r][c];
                assert(sums.query(r1,c1,r2,c2) == expected);
            }
'''),
    ('nearest-station-route', ['graph/Traversal.h'], '1\n3 4\n', r'''
assert(dist == vi({0,1,2,1,0,-1}));
assert(route == vi({3,4}));
assert(sz(route)-1 == dist[target]);
assert(find(stations.begin(),stations.end(),route.back()) != stations.end());
for (int i = 1; i < sz(route); ++i)
    assert(find(g[route[i-1]].begin(),g[route[i-1]].end(),route[i])
           != g[route[i-1]].end());
'''),
    ('teams-with-experienced-member', ['combinatorial/ModComb.h'], '31\n', r'''
ll brute = 0;
for (unsigned mask = 0; mask < (1U<<7); ++mask)
    if (__builtin_popcount(mask) == 3 && (mask&7U)) ++brute;
assert(all == 35 && none == 4 && ways == brute && ways == 31);
'''),
    ('two-state-expectation', ['numerical/Gauss.h'], '4.000000 3.000000\n', r'''
assert(rank == 2 && abs(expected[0]-4) < 1e-12L && abs(expected[1]-3) < 1e-12L);
assert(abs(expected[0]-(1+expected[1])) < 1e-12L);
assert(abs(expected[1]-(1+0.5L*expected[0])) < 1e-12L);
'''),
    ('distance-to-polyline', ['geometry/Projection2.h'], '2.000000\n', r'''
assert(abs(best-2) < 1e-12L);
// The horizontal segment ends before x=6; the vertical projection is internal.
assert(abs(segDist(road[0],road[1],house)-sqrtl(8)) < 1e-12L);
assert(abs(segDist(road[1],road[2],house)-2) < 1e-12L);
'''),
    ('whole-string-period', ['strings/KMP.h'], '3\n', r'''
int brute = n;
for (int length = 1; length <= n; ++length) if (n%length == 0) {
    bool same = true;
    for (int i = 0; i < n; ++i) same &= s[i] == s[i%length];
    if (same) { brute = length; break; }
}
assert(period == brute && period == 3);
'''),
    ('edit-distance-two-rows', [], '3\n', r'''
assert(edits == 3);
for (auto [a,b,expected] : vector<tuple<string,string,int>>{
    {"","",0}, {"","abc",3}, {"abc","",3}, {"abc","ac",1},
    {"same","same",0}, {"a","b",1}, {"ab","ba",2}, {"aaa","a",2}
}) {
    assert(editDistance(a,b) == expected);
    assert(editDistance(b,a) == expected);
}
// Explore all edits with breadth-first search, independently of the DP.
vector<string> words{""};
for (int length = 1; length <= 3; ++length)
    for (int mask = 0; mask < (1<<length); ++mask) {
        string s(length,'a');
        for (int i = 0; i < length; ++i) if (mask&(1<<i)) s[i] = 'b';
        words.push_back(s);
    }
for (const string& source : words) {
    map<string,int> distance{{source,0}};
    queue<string> todo; todo.push(source);
    while (!todo.empty()) {
        string s = todo.front(); todo.pop();
        auto add = [&](const string& next) {
            if (sz(next) <= 3 && !distance.count(next)) {
                distance[next] = distance[s]+1;
                todo.push(next);
            }
        };
        for (int i = 0; i < sz(s); ++i) {
            add(s.substr(0,i)+s.substr(i+1));
            string next = s; next[i] = (s[i] == 'a' ? 'b' : 'a'); add(next);
        }
        for (int i = 0; i <= sz(s); ++i)
            for (char c : string("ab")) add(s.substr(0,i)+c+s.substr(i));
    }
    for (const string& target : words)
        assert(editDistance(source,target) == distance.at(target));
}
'''),
    ('endpoint-game', [], '3 8\n', r'''
assert(difference == 3 && firstScore == 8);
int checked = 0;
for (int n = 0; n <= 7; ++n) {
    int limit = 1;
    for (int i = 0; i < n; ++i) limit *= 3;
    for (int code = 0; code < limit; ++code) {
        vector<ll> test(n); int value = code;
        const ll choices[] = {-2,0,3};
        for (ll& x : test) { x = choices[value%3]; value /= 3; }
        // Enumerate choices using both absolute scores, without DP differences.
        function<pair<ll,ll>(int,int,bool)> brute = [&](int l, int r, bool first) {
            if (l == r) return pair<ll,ll>{0,0};
            auto left = brute(l+1,r,!first), right = brute(l,r-1,!first);
            if (first) {
                left.first += test[l]; right.first += test[r-1];
                return left.first >= right.first ? left : right;
            }
            left.second += test[l]; right.second += test[r-1];
            return left.second >= right.second ? left : right;
        };
        auto [first,second] = brute(0,n,true);
        assert(endpointGame(test) == make_pair(first-second,first));
        ++checked;
    }
}
assert(checked == 3280);
'''),
    ('meeting-rooms', [], '2\n', r'''
assert(rooms == 2);
assert(minRooms({}) == 0);
assert(minRooms({{1,2},{2,3}}) == 1);
assert(minRooms({{1,3},{1,3},{1,3}}) == 3);
vector<pair<ll,ll>> choices;
for (ll l = -1; l < 2; ++l)
    for (ll r = l+1; r <= 2; ++r) choices.push_back({l,r});
int checked = 0;
vector<pair<ll,ll>> test;
function<void(int,int)> generate = [&](int left, int lower) {
    if (left) {
        for (int i = lower; i < sz(choices); ++i) {
            test.push_back(choices[i]); generate(left-1,i); test.pop_back();
        }
        return;
    }
    // Enumerate room assignments and reject every overlapping pair.
    int n = sz(test), best = n+1;
    vi room(n);
    function<void(int,int)> assign = [&](int i, int used) {
        if (used >= best) return;
        if (i == n) { best = used; return; }
        for (int r = 0; r <= used; ++r) {
            bool valid = true;
            for (int j = 0; j < i; ++j) if (room[j] == r)
                valid &= max(test[i].first,test[j].first)
                         >= min(test[i].second,test[j].second);
            if (valid) { room[i] = r; assign(i+1,max(used,r+1)); }
        }
    };
    assign(0,0);
    assert(minRooms(test) == best);
    auto reversed = test; reverse(reversed.begin(),reversed.end());
    assert(minRooms(reversed) == best);
    ++checked;
};
for (int n = 0; n <= 6; ++n) generate(n,0);
assert(checked == 924);
'''),
]

env = os.environ.copy()
env.setdefault('ASAN_OPTIONS', 'detect_leaks=0')
with tempfile.TemporaryDirectory(prefix='notebookG-applied-') as temp:
    work = Path(temp)
    for index, (name, headers, expected, checks) in enumerate(CASES):
        block = BLOCKS[index].strip('\n') + '\n'
        assert len(block.splitlines()) <= (12 if 5 <= index < 9 else 20), (name, len(block.splitlines()))
        include = ''.join('#include ' + json.dumps(str(ROOT/'content'/h)) + '\n'
                          for h in headers)
        variants = [('printed', block, expected, checks)]
        if name == 'dag-paths':
            cyclic = block.replace('auto order = kahn(g);',
                                   'g[3].push_back(0);\nauto order = kahn(g);')
            variants.append(('cycle', cyclic, 'cycle\n', ''))
        if name == 'nearest-station-route':
            variants.append(('unreachable', block.replace('int target = 3;', 'int target = 5;'),
                             '-1\n\n', 'assert(route.empty() && dist[target] == -1);'))
            variants.append(('already-at-station', block.replace('int target = 3;', 'int target = 0;'),
                             '0\n0\n', 'assert(route == vi({0}));'))
        if name == 'whole-string-period':
            variants.append(('non-tiling-border', block.replace('"abcabcabc"', '"ababa"'),
                             '5\n', 'assert(period == 5);'))
        for variant, code, output, extra in variants:
            source = work / 'example.cpp'
            source.write_text(PRE + '\n' + include + '\nint main() {\n'
                              + code + extra + '\n}\n')
            for mode, flags in (
                ('release', ['-O2']),
                ('ASan/UBSan', ['-O1', '-g', '-fsanitize=address,undefined',
                               '-fno-sanitize-recover=all', '-fno-omit-frame-pointer', '-no-pie']),
                ('LOCAL', ['-O2', '-DLOCAL'])):
                binary = work / 'example'
                subprocess.run(['g++', '-std=gnu++17', '-Wall', '-Wextra', '-Werror',
                                *flags, str(source), '-o', str(binary)], check=True)
                result = subprocess.run([str(binary)], check=True, env=env,
                                        capture_output=True, text=True)
                assert result.stdout == output, (name, variant, mode, result.stdout, output)
            print(f'PASS release + ASan/UBSan + LOCAL: {name} ({variant})', flush=True)
print('PASS all twelve exact printed integrations and four boundary variants', flush=True)
