#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/data-structures/ArrayBasics.h"

unsigned long long checks = 0;
void check(bool ok) { ++checks; if (!ok) abort(); }
template<class T> void testPrefix(const vector<T>& a) {
	auto p = prefixSums(a);
	check(p.size() == a.size()+1 && p[0] == 0);
	for (int l = 0; l <= sz(a); ++l) {
		__int128 sum = 0;
		for (int r = l; r <= sz(a); ++r) {
			check(sum >= LLONG_MIN && sum <= LLONG_MAX);
			check(rangeSum(p,l,r) == ll(sum));
			if (r < sz(a)) sum += a[r];
		}
	}
}
int main() {
	testPrefix(vi{});
	testPrefix(vector<ll>{LLONG_MIN,LLONG_MAX});
	testPrefix(vector<ll>{LLONG_MAX,-LLONG_MAX,LLONG_MAX});
	for (int n = 0; n <= 7; ++n) {
		int choices = 1;
		for (int i = 0; i < n; ++i) choices *= 5;
		for (int mask = 0; mask < choices; ++mask) {
			int x = mask;
			vi a(n);
			for (int& v : a) { v = x%5-2; x /= 5; }
			testPrefix(a);
		}
	}
	mt19937 rng(384573);
	for (int run = 0; run < 2000; ++run) {
		int n = rng()%41;
		vector<ll> d(n+1), want(n);
		for (int q = 0; q < 100; ++q) {
			int l = rng()%(n+1), r = rng()%(n+1);
			if (l > r) swap(l,r);
			ll x = ll(rng()%2001)-1000;
			addRange(d,l,r,x);
			for (int i = l; i < r; ++i) want[i] += x;
			if (q%7 == 0 || q == 99) {
				auto saved = d;
				check(finishDiff(d) == want && d == saved);
			}
		}
	}
	vector<ll> d(3);
	addRange(d,0,2,LLONG_MAX);
	check(finishDiff(d) == vector<ll>({LLONG_MAX,LLONG_MAX}));
	addRange(d,1,1,LLONG_MIN); // empty: must not overflow
	check(finishDiff(d) == vector<ll>({LLONG_MAX,LLONG_MAX}));
	addRange(d,0,2,-LLONG_MAX);
	check(finishDiff(d) == vector<ll>({0,0}));
	cout << "PASS ArrayBasics: " << checks << " checks\n";
}
