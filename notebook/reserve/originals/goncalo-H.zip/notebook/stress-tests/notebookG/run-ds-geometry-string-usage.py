#!/usr/bin/env python3
"""Compile the exact printed Usage examples for 18 retained G headers.

The source examples are extracted, never duplicated here. Expected outputs
are checked independently with arithmetic/geometry and literal sequences.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
PRE, sep, _ = (ROOT / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep
CHECKS = {
    'data-structures/ArrayBasics.h': r'''
assert(p == vector<ll>({0,4,2,9}));
assert(total == (-2+7));
assert(a == vector<ll>({0,5,5}));
''',
    'data-structures/UnionFind.h': r'''
assert(connected && groupSize == 3 && !separate);
assert(!roads.join(0,2) && roads.size(3) == 1);
''',
    'data-structures/Fenwick.h': r'''
assert(payroll == 20+5+30);
assert(at == 1 && f.query(1) < 35 && f.query(2) >= 35);
''',
    'data-structures/SegmentTree.h': r'''
assert(best == max({6,9,8}));
assert(s.query(0,1) == 4 && s.query(2,2) == INT_MIN);
''',
    'data-structures/LazySegTree.h': r'''
assert(payroll == (20+5)+(30+5)+40);
assert(s.query(0,4) == 110 && s.query(0,1) == 10);
''',
    'data-structures/RMQ.h': r'''
assert(height == 1 && index == 1);
assert(rmq.query(2,4) == make_pair(1,2));
''',
    'data-structures/PrefixSum2D.h': r'''
assert(total == crops[0][1]+crops[0][2]+crops[1][1]+crops[1][2]);
assert(total == 16 && p.query(0,0,2,3) == 21);
''',
    'data-structures/Difference2D.h': r'''
assert(a == vector<vector<ll>>({{0,5,5},{2,7,5}}));
for (int r = 0; r < 2; ++r)
    for (int c = 0; c < 3; ++c)
        assert(a[r][c] == (c>=1 ? 5 : 0)+(r==1 && c<2 ? 2 : 0));
''',
    'geometry/Point.h': r'''
assert(step.x == 3 && step.y == 4);
assert(squared == 3*3+4*4 && abs(length-5.0) < 1e-12);
''',
    'geometry/Predicates.h': r'''
assert(turn == 1 && gate && !beyond);
assert(side(b,a,p) == -1);
''',
    'geometry/lineIntersection.h': r'''
assert(kind == 1);
assert(abs(p.x-1.5L) < 1e-12L && abs(p.y-1.5L) < 1e-12L);
assert(abs(p.x-p.y) < 1e-12L && abs(p.x+p.y-3) < 1e-12L);
''',
    'geometry/LineSegInter.h': r'''
assert(points.size() == 2);
assert(points[0] == P2(2,0) && points[1] == P2(4,0));
''',
    'geometry/Projection2.h': r'''
assert(foot == P2(6,0) && mirror == P2(6,-3));
assert(abs(toLine-3) < 1e-12L);
assert(abs(toBank-sqrtl(2*2+3*3)) < 1e-12L);
''',
    'geometry/PolyArea.h': r'''
assert(twice == 2*(3*2) && abs(area-6) < 1e-12L);
reverse(plot.begin(),plot.end());
assert(polyArea2(plot) == -12);
''',
    'strings/KMP.h': r'''
assert(pos == vi({0,2}) && pi == vi({0,0,1}));
vi brute;
for (int i = 0; i+sz(pattern) <= sz(text); ++i)
    if (text.substr(size_t(i),pattern.size()) == pattern) brute.push_back(i);
assert(pos == brute);
''',
    'strings/ZFunction.h': r'''
assert(z == vi({0,1,0,0,3,1,0}) && repeated == 3);
for (int i = 1; i < sz(s); ++i) {
    int want = 0;
    while (i+want < sz(s) && s[want] == s[i+want]) ++want;
    assert(z[i] == want);
}
''',
    'strings/DoubleHash.h': r'''
assert(same && erased[2] == 2);
string plain = "abc";
plain.erase(1,1);
assert(plain == "ac");
DoubleHash direct(plain);
assert(erased == direct.get(0,sz(plain)));
''',
    'strings/AlphabetTrie.h': r'''
assert(copies == 2 && pref == 3 && !exact);
assert(t.countPrefix("") == 3 && t.count("car") == 1);
assert(t.countPrefix("cab") == 0);
''',
}


def exact_usage(path):
    """The Usage metadata ends at the next metadata key or comment end."""
    metadata = path.read_text().split('*/', 1)[0]
    found = False
    lines = []
    for raw in metadata.splitlines():
        line = re.sub(r'^\s*\* ?', '', raw)
        if not found:
            if line.startswith('Usage:'):
                found = True
                lines.append(line[len('Usage:'):].lstrip())
        elif re.match(r'[A-Za-z][A-Za-z ]*:', line):
            break
        else:
            lines.append(line)
    assert found and lines, f'No Usage in {path}'
    return '\n'.join(lines).rstrip() + '\n'


env = os.environ.copy()
env.setdefault('ASAN_OPTIONS', 'detect_leaks=0')
with tempfile.TemporaryDirectory(prefix='notebookG-printed-usage-') as temp:
    work = Path(temp)
    for relative, checks in CHECKS.items():
        header = ROOT / 'content' / relative
        usage = exact_usage(header)
        assert 3 <= len(usage.splitlines()) <= 6, (relative, usage)
        source = work / 'example.cpp'
        source.write_text(PRE + '\n#include ' + json.dumps(str(header))
                          + '\nint main() {\n' + usage + checks + '\n}\n')
        for mode, flags in (
            ('release', ['-O2']),
            ('ASan/UBSan', ['-O1', '-g', '-fsanitize=address,undefined',
                           '-fno-sanitize-recover=all', '-fno-omit-frame-pointer', '-no-pie'])):
            binary = work / 'example'
            subprocess.run(['g++', '-std=gnu++17', '-Wall', '-Wextra', '-Werror',
                            *flags, str(source), '-o', str(binary)], check=True)
            subprocess.run([str(binary)], check=True, env=env)
        subprocess.run(['g++', '-std=gnu++17', '-Wall', '-Wextra', '-Werror',
                        '-DLOCAL', '-fsyntax-only', str(source)], check=True)
        digest = hashlib.sha256(usage.encode()).hexdigest()[:12]
        print(f'PASS release + ASan/UBSan + LOCAL: {relative} '
              f'({len(usage.splitlines())} exact Usage lines; {digest})', flush=True)
print(f'PASS all {len(CHECKS)} exact printed Usage examples', flush=True)
