#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/various/CoordinateCompression.h"

unsigned long long checks = 0;
void check(bool ok) { ++checks; if (!ok) abort(); }
template<class T> void test(const vector<T>& a) {
	auto saved = a;
	auto [values,rank] = compressCoordinates(a);
	set<T> distinct(a.begin(),a.end());
	check(values == vector<T>(distinct.begin(),distinct.end()));
	check(rank.size() == a.size() && a == saved);
	for (int i = 0; i < sz(a); ++i) {
		check(0 <= rank[i] && rank[i] < sz(values));
		check(values[rank[i]] == a[i]);
		for (int j = 0; j < sz(a); ++j) {
			check((a[i] < a[j]) == (rank[i] < rank[j]));
			check((a[i] == a[j]) == (rank[i] == rank[j]));
		}
	}
}
int main() {
	test(vi{});
	test(vi{50,10,50});
	test(vector<ll>{LLONG_MAX,0,LLONG_MIN,LLONG_MAX,LLONG_MIN});
	test(vector<string>{"z","a","z","ab"});
	test(vector<double>{-0.0,0.0,1.5,-2.25});
	mt19937_64 rng(194831);
	for (int run = 0; run < 5000; ++run) {
		vector<ll> a(rng()%51);
		for (ll& x : a) x = ll(rng()%101)-50;
		test(a);
	}
	cout << "PASS CoordinateCompression: " << checks << " checks\n";
}
