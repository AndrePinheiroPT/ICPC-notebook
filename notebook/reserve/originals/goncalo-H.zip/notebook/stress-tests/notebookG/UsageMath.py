#!/usr/bin/env python3
"""Extract, compile and execute the actual printed math Usage examples."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "validation/notebookG/math-usage"
HEADERS = [
    "math/IntDivision.h", "math/ModAlign.h", "math/Int128.h",
    "numerical/BinarySearch.h", "numerical/SearchExample.h",
    "numerical/Bisection.h", "numerical/Gauss.h", "numerical/ModPower.h",
    "numerical/GaussMod.h", "number-theory/ModInv.h", "number-theory/SPF.h",
    "number-theory/TrialDivision.h", "number-theory/Divisors.h",
    "combinatorial/Binomial.h", "combinatorial/ModComb.h",
    "combinatorial/PermCycles.h",
]


def usage(text):
    metadata = re.match(r"/\*\*(.*?)\*/", text, re.S).group(1)
    lines, active = [], False
    for raw in metadata.splitlines():
        line = re.sub(r"^\s*\* ?", "", raw)
        field = re.match(r"([A-Z][A-Za-z ]+):\s*(.*)", line)
        if field:
            if active:
                break
            if field.group(1) == "Usage":
                active = True
                lines.append(field.group(2))
        elif active:
            lines.append(line)
    while lines and not lines[-1].strip():
        lines.pop()
    assert active and 3 <= len(lines) <= 6
    return "\n".join(lines)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    template = ROOT / "content/contest/template.cpp"
    preamble, delimiter, _ = template.read_text().partition("int main() {")
    assert delimiter, "Actual contest preamble not found"
    files, examples = {}, {}
    for header in HEADERS:
        path = ROOT / "content" / header
        text = path.read_text()
        snippet = usage(text)
        assert re.search(r"\bassert\s*\(", snippet), header
        examples[header] = snippet
        files["content/" + header] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "body_sha256": hashlib.sha256(text.split("*/", 1)[1].encode()).hexdigest(),
            "usage_lines": len(snippet.splitlines()),
            "assertions": len(re.findall(r"\bassert\s*\(", snippet)),
        }
    source = OUT / "math-usage-extracted.cpp"
    code = preamble + "\n"
    for header in HEADERS:
        code += "#include " + json.dumps(str(ROOT / "content" / header)) + "\n"
    for i, header in enumerate(HEADERS):
        # Strip only metadata markers: no rewritten/copied example code.
        code += f"\nvoid demo{i}() {{\n" + examples[header] + "\n}\n"
    code += "\nint main() {\n"
    for i, header in enumerate(HEADERS):
        code += f"demo{i}(); cout << " + json.dumps("PASS " + header + "\n") + ";\n"
    code += 'cout << "All 16 exact Usage examples passed.\\n";\n}\n'
    source.write_text(code)
    common = [
        "g++", "-std=gnu++17", "-Wall", "-Wextra", "-Wshadow",
        "-Wconversion", "-Werror",
    ]
    commands, results = [], {}
    for mode, flags in [
        ("release", ["-O2"]),
        ("sanitized", [
            "-O1", "-g", "-fno-omit-frame-pointer", "-fno-pie", "-no-pie",
            "-fsanitize=address,undefined", "-D_GLIBCXX_DEBUG",
        ]),
    ]:
        binary = OUT / ("math-usage-" + mode)
        command = common + flags + [str(source), "-o", str(binary)]
        subprocess.run(command, check=True)
        commands.append(command)
        env = dict(os.environ, ASAN_OPTIONS="detect_leaks=0",
                   UBSAN_OPTIONS="halt_on_error=1")
        result = subprocess.run([str(binary)], text=True, capture_output=True, env=env)
        (OUT / (mode + ".log")).write_text(result.stdout + result.stderr)
        print(mode + ":\n" + result.stdout, end="", flush=True)
        if result.stderr:
            print(result.stderr, flush=True)
        result.check_returncode()
        results[mode] = {"exit_code": result.returncode, "stdout": result.stdout}
    command = common + ["-DLOCAL", "-fsyntax-only", str(source)]
    subprocess.run(command, check=True)
    commands.append(command)
    report = {
        "status": "passed", "headers": len(HEADERS),
        "runner": "python3 stress-tests/notebookG/UsageMath.py",
        "compiler": subprocess.check_output(["g++", "--version"], text=True).splitlines()[0],
        "template_sha256": hashlib.sha256(template.read_bytes()).hexdigest(),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "files": files, "commands": commands, "results": results,
        "local_debug_preamble": "syntax check passed",
        "sanitizer_environment": {"ASAN_OPTIONS": "detect_leaks=0", "UBSAN_OPTIONS": "halt_on_error=1"},
    }
    (OUT / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    print("PASS actual contest preamble with LOCAL; results.json written", flush=True)


if __name__ == "__main__":
    main()
