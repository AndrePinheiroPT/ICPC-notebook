#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()

#include "../../content/graph/GridBFS.h"
#include "../../content/graph/Traversal.h"
#include "../../content/graph/Dijkstra.h"
#include "../../content/graph/ZeroOneBFS.h"
#include "../../content/graph/DinicFlow.h"
#include "../../content/graph/MinCostFlow.h"
#include "../../content/graph/TwoSAT.h"
#include "../../content/graph/Hierholzer.h"

void require(bool ok, const char* why) {
	if (!ok) { cerr << why << '\n'; abort(); }
}

long long cases = 0;
void checkGrid(const vector<string>& a,
		const vector<pair<int,int>>& src, char wall = '#') {
	++cases;
	int R = sz(a), C = sz(a[0]), n = R*C;
	vector<vi> g(n);
	// Independent construction: each right/down pair adds both arcs.
	for (int r = 0; r < R; ++r) for (int c = 0; c < C; ++c) {
		if (a[r][c] == wall) continue;
		int v = r*C+c;
		if (r+1 < R && a[r+1][c] != wall) {
			g[v].push_back(v+C); g[v+C].push_back(v);
		}
		if (c+1 < C && a[r][c+1] != wall) {
			g[v].push_back(v+1); g[v+1].push_back(v);
		}
	}
	vi sources, isSource(n);
	for (auto [r,c] : src) {
		sources.push_back(r*C+c); isSource[r*C+c] = 1;
	}
	auto before = a;
	auto [dist,parent] = gridBfs(a,src,wall);
	auto expected = bfs(g,sources).first;
	require(dist == expected, "grid distances differ from adjacency BFS");
	require(a == before, "grid input mutated");
	require(sz(parent) == n, "parent size");
	for (int v = 0; v < n; ++v) {
		if (dist[v] < 0 || isSource[v]) {
			require(parent[v] == -1, "source/unreachable parent");
		} else {
			int p = parent[v];
			require(0 <= p && p < n, "parent out of range");
			require(abs(p/C-v/C)+abs(p%C-v%C) == 1,
				"parent is not orthogonally adjacent");
			require(dist[p]+1 == dist[v], "parent distance");
			require(a[p/C][p%C] != wall, "parent is wall");
		}
		if (a[v/C][v%C] == wall)
			require(dist[v] == -1, "wall reached");
	}
}

void examples() {
	// Verbatim API examples printed in the headers and guide.
	{
		vector<string> a{"...",".#.","..."};
		auto [d,p] = gridBfs(a,{{0,0},{2,2}});
		require(d[0*3+2] == 2 && d[1*3+1] == -1, "grid example");
		int root = 2;
		while (p[root] >= 0) root = p[root];
		auto path = restorePath(root,2,p);
		require(sz(path) == 3 && path.back() == 2, "grid route");
	}
	{
		vector<vi> g{{1},{0,2},{1}};
		auto [dist,parent] = bfs(g,{0,2});
		auto [ok,color] = bipartite(g);
		require(dist == vi({0,1,0}) && parent[0] == -1,
			"BFS example");
		require(ok && color[0] != color[1], "bipartite example");
	}
	{
		vector<vector<pair<int,ll>>> g(2);
		g[0].push_back({1,7});
		auto [dist,parent] = dijkstra(g,0);
		require(dist == vector<ll>({0,7}) &&
			restorePath(0,1,parent) == vi({0,1}), "Dijkstra example");
	}
	{
		vector<ll> fee{3,5,2};
		vector<vector<pair<int,ll>>> g(3);
		g[0].push_back({1,fee[1]});
		g[1].push_back({2,fee[2]});
		auto [d,p] = dijkstra(g,0);
		require(d[2] == 7 && d[2]+fee[0] == 10 && p[2] == 1,
			"vertex fees example");
	}
	{
		vector<vector<pair<int,int>>> g(2);
		g[0].push_back({1,0});
		auto [dist,parent] = zeroOneBfs(g,{0});
		require(dist == vi({0,0}) && parent[1] == 0, "0-1 example");
	}
	{
		DinicFlow f(3);
		f.add(0,1,5); f.add(1,2,3);
		ll sent = f.flow(0,2);
		require(sent == 3 && f.flow(0,2) == 0, "Dinic example");
	}
	{
		DinicFlow f(4); // 0=s, 1=worker, 2=job, 3=t
		f.add(0,1,2);
		int id = sz(f.g[1]);
		f.add(1,2,1); f.add(2,3,1);
		ll sent = f.flow(0,3);
		ll chosen = 1-f.g[1][id].cap;
		require(sent == 1 && chosen == 1, "assignment example");
	}
	{
		MinCostFlow f(3);
		f.add(0,1,2,3); f.add(1,2,2,1);
		auto [sent,cost] = f.flow(0,2,2);
		require(sent == 2 && cost == 8, "min-cost example");
	}
	{
		TwoSAT sat(2);
		sat.either(0,2); sat.either(1,3);
		sat.either(0,0);
		bool ok = sat.solve();
		require(ok && sat.answer == vi({1,0}), "2-SAT example");
	}
	{
		vector<pair<int,int>> e{{0,1},{1,2}};
		auto [v,ids] = eulerTrail(3,e,0,false);
		require(v == vi({0,1,2}) && ids == vi({0,1}), "Euler example");
	}
	// Every documented clause recipe, checked against its truth table.
	for (int rule = 0; rule < 6; ++rule)
		for (int x = 0; x < 2; ++x) for (int y = 0; y < 2; ++y) {
			TwoSAT sat(2); int a = 0, b = 2;
			if (rule == 0) sat.either(a,b); // at least one
			if (rule == 1) sat.either(a^1,b^1); // not both
			if (rule == 2) { // exactly one
				sat.either(a,b); sat.either(a^1,b^1);
			}
			if (rule == 3) sat.either(a^1,b); // implication
			if (rule == 4) { // same truth value
				sat.either(a^1,b); sat.either(b^1,a);
			}
			if (rule == 5) sat.either(a,a); // force a
			sat.either(a^(!x),a^(!x));
			sat.either(b^(!y),b^(!y));
			bool want[] = {bool(x||y), !(x&&y), x!=y,
				bool(!x||y), x==y, bool(x)};
			require(sat.solve() == want[rule], "clause recipe");
		}
}

int main() {
	examples();
	// Each cell independently wall / free / source: all masks and source
	// subsets on all positive rectangles through 3x3, including no sources.
	for (int R = 1; R <= 3; ++R) for (int C = 1; C <= 3; ++C) {
		int total = 1;
		for (int i = 0; i < R*C; ++i) total *= 3;
		for (int mask = 0; mask < total; ++mask) {
			vector<string> a(R,string(C,'.'));
			vector<pair<int,int>> src;
			int x = mask;
			for (int v = 0; v < R*C; ++v, x /= 3) {
				if (x%3 == 0) a[v/C][v%C] = '#';
				if (x%3 == 2) src.push_back({v/C,v%C});
			}
			checkGrid(a,src);
		}
	}
	mt19937 rng(730091);
	for (int test = 0; test < 2000; ++test) {
		int R = 1+int(rng()%25), C = 1+int(rng()%25);
		vector<string> a(R,string(C,'.'));
		vector<pair<int,int>> src;
		for (int r = 0; r < R; ++r) for (int c = 0; c < C; ++c) {
			if (rng()%4 == 0) a[r][c] = 'X';
			else if (rng()%7 == 0) {
				a[r][c] = 'S'; src.push_back({r,c});
				if (rng()%2) src.push_back({r,c});
			}
		}
		checkGrid(a,src,'X');
	}
	checkGrid({string(100000,'.')},{{0,0}});
	checkGrid(vector<string>(100000,"."),{{99999,0},{99999,0}});
	cout << "GridBFS: " << cases << " differential cases; API examples OK\n";
}
