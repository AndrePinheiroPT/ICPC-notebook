#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/numerical/SearchExample.h"
#include "../../content/number-theory/ModInv.h"
#include "../../content/numerical/Gauss.h"
#include "../../content/numerical/GaussMod.h"
#include "../../content/geometry/Projection2.h"
#include "../../content/strings/DoubleHash.h"
#include "../../content/various/SOS.h"

int main() {
    long long cases = 0;
    for (int n=1;n<=7;++n) {
        int total=1; for(int i=0;i<n;++i) total*=3;
        for(int state=0;state<total;++state) {
            int s=state; vector<ll> a(n);
            for(ll& x:a) {x=s%3;s/=3;}
            vector<ll> best(n+1,LLONG_MAX);
            for(int mask=0;mask<(1<<(n-1));++mask) {
                ll mx=0,sum=a[0]; int groups=1;
                for(int i=1;i<n;++i) {
                    if(mask&(1<<(i-1))) {mx=max(mx,sum);sum=0;++groups;}
                    sum+=a[i];
                }
                best[groups]=min(best[groups],max(mx,sum));
            }
            for(int k=1;k<=n;++k) {
                if(k>1) best[k]=min(best[k],best[k-1]);
                assert(minGroupCapacity(a,k)==best[k]);++cases;
            }
            assert(minGroupCapacity(a,n+2)==*max_element(a.begin(),a.end()));
        }
    }
    assert(minGroupCapacity({2,1,3,2},2)==5);
    assert(minGroupCapacity({LLONG_MAX-1},1)==LLONG_MAX-1);
    assert(minGroupCapacity({LLONG_MAX/2,LLONG_MAX/2},1)==LLONG_MAX-1);
    assert(minGroupCapacity({0,0},3)==0);
    for(ll m=2;m<=150;++m) for(ll a=-200;a<=200;++a) {
        auto inv=modInv(a,m); ll brute=-1;
        for(ll x=0;x<m;++x) if(((a*x)%m+m)%m==1) {brute=x;break;}
        assert(inv.has_value()==(brute!=-1));
        if(inv) assert(*inv==brute);
        ++cases;
    }
    mt19937_64 rng(5731);
    for(int i=0;i<50000;++i) {
        ll m=ll(rng()>>1); if(m<2) m=2;
        ll a=ll(rng());
        auto inv=modInv(a,m);ll residue=a%m;if(residue<0) residue+=m;
        assert(inv.has_value()==(gcd(residue,m)==1));
        if(inv) assert(*inv>=0 && *inv<m && (__int128)residue*(*inv)%m==1);
        ++cases;
    }
    for(ll a:{LLONG_MIN,LLONG_MAX,-1LL,0LL,1LL}) {
        auto inv=modInv(a,LLONG_MAX); ll v=a%LLONG_MAX;if(v<0)v+=LLONG_MAX;
        assert(inv.has_value()==(gcd(v,LLONG_MAX)==1));
        if(inv) assert((__int128)v*(*inv)%LLONG_MAX==1);
    }
    vector<vector<long double>> eq{{0.5L,1.L}};vector<long double>x;
    assert(gauss(eq,1,x)==1 && fabsl(x[0]-2)<1e-12L);
    vector<vi> mod{{1,1,1,0}};vi y;
    assert(gaussMod(mod,3,y,3)==1);int solutions=0;
    for(int a=0;a<3;++a)for(int b=0;b<3;++b)for(int c=0;c<3;++c)
        solutions+=(a+b+c)%3==0;
    assert(solutions==9);
    P2 a(0,0),b(2,0),p(1,3);
    assert(fabsl(segDist(a,b,p)-3)<1e-12L);
    DoubleHash h("abc"), expected("ac");
    assert(h.concat(h.get(0,1),h.get(2,3))==expected.get(0,2));
    vi recipes(8);recipes[1]=recipes[3]=1;sos(recipes);
    assert(recipes[3]==2 && recipes[2]==0 && recipes[7]==2);
    cout << "Search, independent inverse checks and printed examples: " << cases << " cases passed\n";
}
