#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
mkdir -p validation/notebookG/dp
g++ -std=c++17 -Wall -Wextra -Wshadow -Wconversion -Werror -O2 \
  stress-tests/notebookG/DPExamples.cpp -o validation/notebookG/dp/dp-release
validation/notebookG/dp/dp-release | tee validation/notebookG/dp/release.log
g++ -std=c++17 -Wall -Wextra -Wshadow -Wconversion -Werror -O1 -g \
  -fno-omit-frame-pointer -fno-pie -no-pie \
  -fsanitize=address,undefined -D_GLIBCXX_DEBUG \
  stress-tests/notebookG/DPExamples.cpp -o validation/notebookG/dp/dp-sanitized
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1 \
  validation/notebookG/dp/dp-sanitized | tee validation/notebookG/dp/sanitized.log
