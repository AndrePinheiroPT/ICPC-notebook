#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
#define sz(x) (int)(x).size()
#include "../../content/data-structures/UnionFind.h"
#include "../../content/data-structures/DynamicConnectivity.h"
#include "../../content/data-structures/Fenwick.h"
#include "../../content/data-structures/Fenwick2D.h"
#include "../../content/data-structures/SegmentTree.h"
#include "../../content/data-structures/LazySegTree.h"
#include "../../content/data-structures/RMQ.h"
#include "../../content/data-structures/OrderedSet.h"
#include "../../content/data-structures/SqrtDecomposition.h"
#include "../../content/data-structures/PrefixSum2D.h"
#include "../../content/data-structures/Difference2D.h"
static size_t checks = 0;
static mt19937_64 rng(0x3a110026ULL);
void check(bool b) { ++checks; assert(b); }

void balancedUnions() {
    constexpr int n = 1 << 15;
    UF uf(n); RollbackUF rb(n);
    vi snapshots;
    // Balanced unions produce the largest permissible UF tree depth.
    for (int width = 1; width < n; width *= 2) {
        snapshots.push_back(rb.time());
        for (int i = 0; i < n; i += 2*width) {
            check(uf.join(i,i+width)); check(rb.join(i,i+width));
        }
        for (int i = 0; i < n; ++i) {
            check(uf.size(i) == 2*width && rb.size(i) == 2*width);
            check(uf.sameSet(i,i/(2*width)*(2*width)));
        }
    }
    for (int width = n/2; width; width /= 2) {
        rb.rollback(snapshots.back()); snapshots.pop_back();
        for (int i = 0; i < n; ++i) {
            check(rb.size(i) == width);
            check(rb.find(i) == rb.find(i/width*width));
            if (i+width < n) check(rb.find(i) != rb.find(i+width));
        }
    }
}
void lifetimes() {
    // Exhaust all two-edge lifetimes, including empty intervals and every
    // power-of-two segment-tree boundary; truth is Boolean connectivity.
    for (int q = 0; q <= 7; ++q)
        for (int a = 0; a <= q; ++a) for (int b = a; b <= q; ++b)
            for (int c = 0; c <= q; ++c) for (int d = c; d <= q; ++d) {
                DynamicConnectivity dc(3,q);
                dc.add(a,b,0,1); dc.add(c,d,1,2);
                dc.add(a,b,1,0); // Separate active copy of the same edge.
                dc.add(0,q,1,1);
                for (int repeat = 0; repeat < 2; ++repeat) {
                    int seen = 0;
                    dc.run([&](int t, RollbackUF& u) {
                        bool x = a <= t && t < b, y = c <= t && t < d;
                        check((u.find(0) == u.find(2)) == (x && y));
                        check(u.size(1) == 1+int(x)+int(y)); ++seen;
                    });
                    check(seen == q && dc.uf.time() == 0);
                }
            }
}
void arrays() {
    for (int n : {1,2,3,31,32,33,127,128,129,511,512,513}) {
        vector<ll> a(n); vector<pair<int,int>> p(n);
        for (int i = 0; i < n; ++i) {
            a[i] = (i%3-1)*1000000000000LL; p[i] = {i,n-i};
        }
        Fenwick<ll> ft(n); LazySegTree<ll> lazy(a);
        SqrtDecomposition<ll> sq(a); RMQ<ll> rmq(a); RMQ<pair<int,int>> indexed(p);
        SegTree seg(n); OST<pair<ll,int>> os;
        for (int i = 0; i < n; ++i) {
            ft.add(i,a[i]); seg.update(i,int(a[i]/1000000000000LL));
            // Long PBDS stress has a separate suite; keep STL-debug
            // validation bounded here (its insertion checks are cubic).
            if (n <= 33) os.insert({a[i],i});
        }
        for (int t = 0; t < 700; ++t) {
            int l = int(rng()%unsigned(n)), r = l+1+int(rng()%unsigned(n-l));
            check(rmq.query(l,r) == *min_element(a.begin()+l,a.begin()+r));
            check(indexed.query(l,r) == *min_element(p.begin()+l,p.begin()+r));
            check(ft.query(l,r) == accumulate(a.begin()+l,a.begin()+r,0LL));
            check(seg.query(l,r) == *max_element(a.begin()+l,a.begin()+r)/1000000000000LL);
            ll x = (t%3-1)*1000000000000LL;
            check(sq.countLess(l,r,x) == count_if(a.begin()+l,a.begin()+r,[&](ll v) { return v < x; }));
            if (n <= 33) check(os.order_of_key({x,-1}) == size_t(count_if(a.begin(),a.end(),[&](ll v) { return v < x; })));
        }
        // Compare chained lazy updates to an independent flat vector.
        for (int width = 1; width <= n; width *= 2) {
            for (int l = 0; l < n; l += width) {
                int r = min(n,l+width); ll v = ll(l%7-3)*10000000000LL;
                lazy.add(l,r,v); for (int i = l; i < r; ++i) a[i] += v;
            }
        }
        for (int l = 0; l <= n; ++l)
            check(lazy.query(l,n) == accumulate(a.begin()+l,a.end(),0LL));
    }
}
void denseAndCompressed() {
    for (int n = 0; n <= 7; ++n) for (int m = 0; m <= 7; ++m) {
        vector<vector<ll>> a(n,vector<ll>(m)); Difference2D<ll> d(n,m);
        for (int i = 0; i < n; ++i) for (int j = 0; j < m; ++j) {
            ll v = ((i+j)%3-1)*(LLONG_MAX/4096);
            d.add(i,j,n,m,v);
            for (int r = i; r < n; ++r) for (int c = j; c < m; ++c) a[r][c] += v;
        }
        check(d.values() == a); PrefixSum2D<ll> p(n,m,a);
        for (int r1 = 0; r1 <= n; ++r1) for (int r2 = r1; r2 <= n; ++r2)
            for (int c1 = 0; c1 <= m; ++c1) for (int c2 = c1; c2 <= m; ++c2) {
                ll want = 0;
                for (int r = r1; r < r2; ++r) for (int c = c1; c < c2; ++c) want += a[r][c];
                check(p.query(r1,c1,r2,c2) == want);
            }
    }
    vector<ll> xs{LLONG_MIN,LLONG_MIN+1,-1,0,1,LLONG_MAX-1,LLONG_MAX};
    vector<pair<ll,ll>> points;
    for (ll x : xs) for (ll y : xs) points.push_back({x,y}), points.push_back({x,y});
    Fenwick2D<ll,ll> f(points); map<pair<ll,ll>,ll> a;
    for (auto pt : points) { f.add(pt.first,pt.second,17); a[pt] += 17; }
    for (ll x : xs) for (ll y : xs) {
        ll want = 0;
        for (auto [pt,v] : a) if (pt.first < x && pt.second < y) want += v;
        check(f.query(x,y) == want);
    }
}
int main() {
    balancedUnions(); lifetimes(); arrays(); denseAndCompressed();
    cout << "Adversarial DS: " << checks << " independent boundary checks passed\n";
}
