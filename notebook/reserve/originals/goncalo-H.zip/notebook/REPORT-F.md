# Notebook F — alterações relativamente ao E

Base: `notebookE.zip` fornecido pelo utilizador. Objetivo: conseguir reconhecer,
chamar e adaptar os algoritmos com menos sintaxe genérica e menos passos
escondidos, sem trocar os algoritmos por versões mais lentas.

## O que mudou

| Área | Alterações principais |
|---|---|
| Todos os 88 headers ativos | Descrição com situação de uso, formato e ordem dos argumentos, resultados/sentinelas e significado de estruturas/auxiliares; exemplos concretos e complexidade. |
| Introdução | Guia de dependências, `ll`/`vi`, templates ainda necessários, inferência automática, `auto [x,y]`, `optional`, callbacks/lambdas e asserts. |
| Estruturas | RMQ de mínimo sem operação genérica; SegTree de máximo sem helper `f`; UF/rollback em passos explícitos; Fenwick2D com o mesmo lowbit nas duas dimensões; LazySegTree com `sum`/`lazy`. |
| Numérico | Potência modular com `while` e produto seguro uniforme; Gauss com nomes como `rank`, `pivot`, `factor` e ciclos explícitos; auxiliares da pesquisa contínua explicados. |
| Math/Number theory | Divisões floor/ceil, alinhamento modular, Euclides estendido, SPF/trial division e Miller–Rabin escritos em passos mais diretos; preservada a segurança aritmética. |
| Combinatória | Utilização de factorial/binomial/multinomial, inclusão-exclusão e Catalan mais concreta; documentação corrigida para `fact`/`invfact`. |
| Grafos | Dinic e min-cost flow sem parâmetros de tipo; HLD devolve intervalos; Hopcroft–Karp sem vértice fictício/sentinela; representação de arestas, resíduos, pais, componentes e estados explicada. |
| Strings | Aho sem classe template; hash com construtores explícitos; Manacher separado em ciclos ímpar/par; suffix array com ranks intermédios nomeados. |
| Geometria | Recursão tipada em closest pair/união de retângulos; classificação de interseções explícita; distinção entre coordenadas inteiras/reais e significado dos resultados. |
| Various | LIS com binary search explícita; SOS com máscaras menor/maior; Floyd cycle em três fases; convex hull trick com iteradores e remoções separados em passos; pequenos casos de histogram/interval cover desdobrados. |
| Notas de DP | Objetivos, inputs, significado dos estados e localização da resposta; explicação de `tight`, `started`, `mex` e condições das otimizações. |
| Capa | Logo, UMinho e Gonçalo Faria por baixo. |

A stack/deque monótonas mantêm as implementações de E. Também foram mantidos
o corpo de Bellman–Ford, SCC/percursos de árvores iterativos, subset sum com
bitset, todos os algoritmos avançados e a ordem dos 88 imports.
Foram alterados 40 corpos de implementação; 48 mantêm o código de E.
Os detalhes e hashes por ficheiro estão em `validation/notebookF/preservation.json`.

## Compromissos das interfaces mais simples

- **RMQ:** continua `RMQ<T>` e `query(l,r)`, agora só mínimo. Retirar `F` e o
  argumento da operação elimina a personalização por callback; mínimo de pares
  ainda permite devolver valor e índice. Mesmos custos de construção/consulta.
- **SegTree:** continua máximo sobre `int` (editar `T`/`unit` para `ll`). Para
  uma operação não comutativa, não basta substituir `max`: são necessários
  acumuladores ordenados à esquerda/direita. A operação implementada não mudou.
- **Flows:** `DinicFlow f(n)` e `MinCostFlow f(n)` usam `ll`. Conservam fluxo,
  custo, resíduos e corte mínimo, mas deixam de aceitar parâmetros de tipos
  alternativos; em particular, deixam de cobrir capacidades até ULLONG_MAX.
  Os totais/intermédios têm de respeitar os limites `ll`/`INF` documentados.
- **HLD:** `for (auto [l,r] : h.path(u,v)) ...` substitui o callback. Mesma
  decomposição e tempo `O(log n)`; materializa `O(log n)` intervalos por chamada.
  Os intervalos já não tinham ordem útil para operações não comutativas em E.
- **Aho:** `Aho a` para a-z; `Aho a(256,0)` para bytes. Alfabeto configurado
  no construtor, não em `<...>`. Mantém IDs, duplicados, padrões vazios e
  resultados; vetores por nó e callback tipado acrescentam constantes de
  alocação/chamada, sem alterar a complexidade assintótica.
- **DoubleHash:** aceita diretamente strings/string_view, `vector<int>` e
  `vector<unsigned char>`. Outros contentores integrais precisam de conversão.
  Mantém comprimento, concatenação e bases aleatórias comuns. Valores de 64 bits
  continuam a exigir compressão conjunta, sem truncar. O construtor de bytes
  usa temporariamente um vetor de inteiros: mais memória constante, ainda `O(n)`.
- **ModPower:** produto sempre em 128 bits, em vez de escolher o tipo por
  metaprogramação. Mantém os domínios signed/unsigned de 64 bits e complexidade;
  pode ter uma constante maior para módulos pequenos.
- **Geometria recursiva:** `std::function` substitui a lambda que recebe a si
  própria; tem custo constante de chamada indireta, com a mesma profundidade
  `O(log n)` e complexidade do algoritmo.

Não se eliminaram todos os templates: `Point<T>` distingue inteiros de reais;
Fenwick e somas podem precisar de `ll`; algoritmos de sequências aceitam strings
ou vetores. Nestes casos, os exemplos mostram chamadas normais ou o único tipo
necessário, em vez de descartar capacidades úteis.

## Validação

As nove baterias atuais passaram: capítulos 01–02, 03, 04, 05, 06, 07, 08,
09–10 e auditoria do template. Foram adaptados os testes das APIs alteradas;
os oráculos independentes e casos extremos foram conservados.

- Compilação GNU++17 com avisos tratados como erros nas baterias aplicáveis.
- Release e debug com AddressSanitizer, UndefinedBehaviorSanitizer e STL debug.
- Testes diferenciais, aleatórios, exaustivos para instâncias pequenas,
  integração entre algoritmos e casos limite dos tipos suportados.
- 88 headers compilados isoladamente, instanciados, com `LOCAL` e em conjunto.
- NTT testada também no comprimento máximo suportado `2^23`.
- Repetição direcionada de Fenwick2D e, após a última simplificação, LineHull
  contra consultas por força bruta, em release e debug conforme os logs.
- LeakSanitizer desativado porque o ambiente usa ptrace; ASan/UBSan ativos.

Resultados, comandos, limites e hashes em `validation/notebookF/`. As fontes
históricas não importadas não fazem parte da promessa de cobertura de F.
Testes aumentam a confiança; não constituem prova de correção para todo input.
Alterações finais só de texto podem mudar o hash do header sem mudar o código
já testado; `final-coverage.json` distingue esta situação dos testes finais
específicos de LineHull.

## PDF e reprodução

O PDF tem **26 páginas: capa + 25 de conteúdo**. Mantidos os capítulos,
três colunas, cores e fonte de 9 pt. Para acomodar as explicações, o espaçamento
entre linhas passou de 10,5 para 9,5 pt; Math/Number theory já usavam 9,5.
Verificação final
de páginas, capa, presença dos 88 headers e limites físicos em
`validation/notebookF/pdf-structure.json`; revisão visual das 26 páginas registada em `visual-review.json`.

O preprocessor de LaTeX foi corrigido para aceitar `BF::...` como código,
escapar caracteres especiais nos exemplos e permitir uma lambda `[&]` no
início da linha seguinte. Não altera os algoritmos.

Comandos atuais e dependências: `README.md`. Relatórios D/E e relatórios
antigos de capítulos ficam no pacote como histórico, identificados como tal.
