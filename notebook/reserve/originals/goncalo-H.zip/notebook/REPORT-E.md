# Notebook E — alterações face a D

## Resultado

- 26 páginas físicas: capa apenas com o logo UMinho + 25 de conteúdo.
- Mesmo formato A4 horizontal, três colunas, tema Visual Studio Light e
  tamanho de código de 9 pt. A estrutura de pastas e os capítulos de D mantêm-se.
- 88 headers ativos: os 86 anteriores + stack e deque monótonas.
- Nenhuma implementação anterior foi alterada: a comparação com o ZIP de D
  confirmou igualdade byte a byte do código após o comentário inicial dos
  222 headers existentes, incluindo os de reserva.
- As fontes de Contest, Data structures, Numerical, Combinatorial, Graph,
  Geometry, Strings e Appendix, e o estilo global, são idênticos a D.
  Em Various, o conteúdo anterior é idêntico após retirar a nova secção.

## Matemática e teoria de números

As notas passaram a ligar a ferramenta à forma como aparece num enunciado,
com exemplos e explicação dos inputs, resultados e condições. O idioma do
notebook continua a ser o inglês, como em D.

| Tema | O que ficou mais direto |
|---|---|
| Divisão e alinhamento | Número de caixas com `ceilDiv`; diferença entre floor e divisão C++; próximo múltiplo ou horário periódico. |
| Somas e séries | Distinguir aumento constante de multiplicação constante; parâmetros num exemplo; soma em `[l,r)` por diferença de prefixos; domínio das séries. |
| Overflow | Promoção antes das operações e escolha entre 64, 128 bits e `cpp_int`. |
| Probabilidade | “Pelo menos um” pelo complementar, condição/Bayes e independência. |
| Esperança | Pontuação média, contagens por indicadores, tentativas até ao sucesso, custo por estado e como montar as equações para Gauss. |
| GCD/LCM e diofantinas | Dividir em partes iguais, simplificar razões, períodos, existência de solução inteira e limites de `t`, com exemplo de quantidades não negativas. |
| Modular | Normalizar restos, escolher produto/potência, dividir por inverso e reconhecer quando esse inverso não existe. |
| CRT | Juntar horários/restos, interpretar `(r,M)`, detetar incompatibilidade/overflow e encontrar a primeira solução após um limite. |
| Primos e fatores | Escolher SPF, divisão experimental, Miller–Rabin ou Pollard–Rho conforme a pergunta; fatores com multiplicidade versus divisores. |
| Divisores | Interpretar número/soma de divisores e totiente; exemplo `12 = 2² × 3`. |

Ficheiros: `content/math/chapter.tex`, `content/number-theory/chapter.tex`
e os comentários de utilização de IntDivision, ModAlign, ModInv, SPF,
TrialDivision, Prime64, Factor64 e Divisors. Corpos de código preservados.

Para cumprir as 26 páginas sem cortar conteúdo existente, estes dois
capítulos usam espaçamento local mais compacto: texto e código de 9 pt
com entrelinha local de 9,5 pt, fórmulas mais compactas e a opção de
supressão de linhas vazias nas listagens. Os restantes capítulos mantêm
os estilos de D; o código continua a usar 9 pt/10,5 pt fora destes dois.
Não foi retirado nenhum algoritmo, fórmula, setup de contest ou nota final.

## Novos templates — Various, secção 10.2 (página impressa 23)

| Ficheiro/API | Contrato |
|---|---|
| `MonotonicStack.h` — `nearestSmaller(a, right=false)` | Índice do vizinho estritamente menor mais próximo: à esquerda por defeito ou à direita. Ausência: `-1` à esquerda, `n` à direita. O(n) tempo/espaço. |
| `MonotonicDeque.h` — `slidingMin(a,k)` | Índice do mínimo de cada janela `[l,l+k)`; obter valor com `a[ans[l]]`. `k>0`; vazio se `k>n`. Empates escolhem o mais à direita. O(n) tempo, O(min(n,k)) auxiliar além da saída. |

Ambos são templates de tipo, usam os aliases do template de Contest,
aceitam entrada vazia e não alteram o vetor de entrada. As notas explicam
os candidatos guardados, comparações estritas/não estritas, adaptação a
máximos e desempates. Não duplicam a implementação de histograma de D.

## Validação executada

Baterias de regressão de D reexecutadas para todos os capítulos, com os
novos testes integrados. Todas as nove etapas terminaram com código 0:

| Runner | Resultado | Duração |
|---|---|---|
| `audit-template.py` | PASS | 127.55 s |
| `test-chapter-03.sh` | PASS | 93.05 s |
| `test-chapter-04.sh` | PASS | 64.97 s |
| `test-chapter-05.sh` | PASS | 54.17 s |
| `test-chapter-06.sh` | PASS | 38.79 s |
| `test-chapter-07.sh` | PASS | 153.02 s |
| `test-chapter-08.sh` | PASS | 96.18 s |
| `test-chapters-01-02.sh` | PASS | 53.16 s |
| `test-chapters-09-10.sh` | PASS | 120.54 s |

- Modos release e debug com `LOCAL`, `_GLIBCXX_DEBUG`, AddressSanitizer
  e UndefinedBehaviorSanitizer. `RUN_MAX=1` nas baterias que o utilizam.
- Novas estruturas: 13 843 vetores exaustivos/aleatórios e 4 746 296
  verificações por modo, usando busca direta como oráculo e propriedades
  dos casos grandes. Inclui vazios, duplicados, todos iguais, ordem crescente
  e decrescente, extremos de `long long`, outros tipos, `k>n`, `k=INT_MAX`
  e vetores de 200 000 elementos.
- Novos exemplos de Math/NT executados: divisão, horários, limites diofantinos,
  inverso/CRT, funções de divisores para n=1..500 comparadas com enumeração,
  probabilidades/esperanças enumeradas e sistemas de equações de estados.
- 88 headers compilados e instanciados individualmente com o preâmbulo real
  de Contest, verificados também com `LOCAL`, e compilados em conjunto.
- PDF reconstruído em duas passagens, 26 páginas verificadas, capa com uma
  imagem e sem texto, todos os 88 headers presentes e zero caracteres fora
  dos limites definidos. Revisão visual das 26 páginas renderizadas.
- Comparação automatizada com D: todos os 822 ficheiros originais mantidos;
  código anterior intacto e alterações de conteúdo limitadas ao âmbito acima.

Os logs, comandos, versões, códigos de saída e hashes estão em
`validation/notebookE/`. `summary.json` identifica o código final;
`preservation.json` regista a comparação com D e `pdf-structure.json` o PDF.
Depois dos testes de execução, os ajustes foram apenas de comentários e
paginação; os corpos dos algoritmos não mudaram.

Limites: testes não constituem prova formal para todas as entradas. Os
ficheiros de reserva não importados foram preservados, mas não são
apresentados como cobertos pela bateria dos 88 headers ativos.
LeakSanitizer foi desativado por incompatibilidade com ptrace; ASan e UBSan
permaneceram ativos. Os relatórios de revisões anteriores são histórico.

## Reproduzir

```bash
python3 doc/scripts/test-notebookE.py
make kactl
python3 doc/scripts/verify-pdf.py
python3 doc/scripts/verify-from-D.py /caminho/notebookD.zip
```

Requisitos: GNU++17/g++, Bash, Python 3, Boost (ou `BOOST_INCLUDEDIR`),
LaTeX e Node.js. A verificação do PDF usa `pypdf` e `pdfplumber`.
O ZIP inclui o PDF, fontes, testes, logs e este relatório; não inclui
binários de teste nem a pasta temporária de compilação `build/`.
