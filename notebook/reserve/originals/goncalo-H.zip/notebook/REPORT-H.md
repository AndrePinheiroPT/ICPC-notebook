# G → H

A revisão muda a apresentação e a página de reconhecimento. O catálogo, as implementações e todos os exemplos executáveis do ZIP G foram preservados.

## Junto de cada algoritmo e estrutura

Os 64 nomes têm uma frase que diz, em termos simples, para que serve o bloco. Por exemplo, Dijkstra encontra caminhos mínimos com custos não negativos; Fenwick combina alterações pontuais com somas de intervalos; Kosaraju agrupa vértices que se alcançam mutuamente. O DAG de SCCs continua a ser construído separadamente por `condensation`.

Os mini-enunciados e descrições foram simplificados, retirando repetição. Foram mantidos argumentos, retornos, condições, sentinelas, limites, complexidades e contexto dos auxiliares. Incluindo os novos resumos, o texto total desses blocos diminuiu cerca de 8%; não foi acrescentada uma camada de explicação longa.

## Página 26: Techniques (A)

A secção foi reescrita para ficar aberta ao lado dos enunciados e ocupa exclusivamente a última página. As pistas começam por interpretar o pedido, conferir limites e procurar simulação, contagens, fórmulas, invariantes ou um estado suficiente. Só depois encaminham para DP, grafos, estruturas de intervalos, strings, geometria ou álgebra quando as condições se aplicam.

Cada bloco tem uma pergunta de reconhecimento e palavras-chave destacadas. O guia distingue, por exemplo, decidir por uma fórmula de pesquisar uma resposta monotónica; simular preferências de resolver matching; contar todos os percursos de procurar apenas o mais curto; e detectar um invariante de provar que ele é suficiente.

A auditoria cruzou os 41 enunciados dos cinco TST. Há 27 correspondências diretas com uma observação/procedimento, 12 pontos de partida úteis que ainda exigem trabalho próprio e 2 casos onde a pista é apenas geral. Isto mede ajuda de reconhecimento, não soluções completas nem cobertura por templates. A classificação resulta de análise dos enunciados, não de uma certificação por editoriais oficiais. O resumo agregado acompanha o ZIP; a matriz por problema ficou fora para não revelar o TST 2025.

Também foram corrigidos símbolos de comparação e bit shifts que o texto das notas de DP imprimia com glifos errados, e a associação dos nomes no cabeçalho à página onde começam. São correções de apresentação.

## Preservação e testes

- Corpos dos 64 headers e respectivos `Usage` comparados byte a byte com o ZIP G.
- Catálogo ativo, exemplos de aplicação, template, debugger, convenções e código preservados.
- Reexecutadas as 19 baterias de regressão, incluindo os testes por força bruta e os exemplos extraídos do próprio texto impresso.
- Verificadas compilação isolada/instanciada, `LOCAL`, inclusão conjunta, release e sanitizers onde aplicáveis.
- Verificados os 64 resumos no PDF, capa, ausência de texto cortado, 26 páginas e isolamento de Techniques (A) na página física 26.
- Mantidos 9 pt, três colunas e o tema de cores. Revisão visual após a compilação final.

Resultados e hashes atuais: `validation/notebookH/`. Comandos de reprodução em `README.md`. As baterias verificam os casos cobertos; os contratos de entrada de cada implementação continuam a aplicar-se.
