# Notebook G — guia prático para o TST

G parte do ZIP F fornecido. A seleção privilegia técnicas que se reconhecem e usam diretamente durante o solve. A margem libertada foi usada para mini-enunciados, chamadas concretas, resultados esperados e pequenas implementações; manteve-se o espaçamento compacto.

**PDF final: 26 páginas — capa + 25 páginas de conteúdo; 64 headers ativos e 12 aplicações completas curtas.**

## O que mudou

- **88 → 64 headers ativos:** retirados 31 do catálogo impresso e adicionados 7 blocos práticos. A lista exata está em `validation/notebookG/preservation.json`.
- Mantidos explicitamente **trie, Dinic, min-cost flow, 2-SAT, Euler e lazy segment tree**. Gauss, Gauss modular e SOS mantêm exemplos concretos como reservas.
- **Todos os 64 headers ativos têm exemplo executável**, acompanhado de contexto sobre o pedido, os argumentos e o resultado. Os testes extraem as próprias linhas `Usage` impressas.
- Novos blocos: prefixos/diferenças 1D; compressão de coordenadas; duas janelas com two pointers; BFS em grelha; binary search aplicado a repartir uma sequência; seis implementações de DP; quatro padrões curtos completos.
- DP passou a explicar **estado, base, transição, ordem e resposta**: máximo subarray linear/circular, mochila, moedas, LCS/substring/edit distance, caminhos em grelha, jogo dos extremos e subconjuntos com último vértice.
- Os quatro padrões completos mostram pares com a mesma chave, janelas circulares, união de intervalos e segmentação de palavras com trie.
- Guias de utilização: seleção de estruturas por operação, STL, modelação de estados/grafos, equações e distinções entre distâncias, pais e estados impossíveis.
- Flows têm mais contexto sobre construção da rede, capacidade/custo, limite de unidades, arestas residuais, recuperação das escolhas e corte mínimo. 2-SAT explica a tradução das condições e Euler as condições de partida.
- Exemplos que combinam blocos: contar inversões, salários de uma subárvore, contar caminhos num DAG, aplicar retângulos e consultar a grelha final, encontrar uma estação próxima e reconstruir a rota. Há ainda quatro integrações para combinações com restrições, equações de expectativa, distância a uma estrada e período de uma string. Completam o guia a distância de edição, o jogo de retirar um extremo e a atribuição do mínimo de salas a reuniões.
- Os exemplos não identificam provas e não foram derivados especificamente do TST2025.

## O que saiu do impresso

| Grupo | Conteúdo retirado |
|---|---|
| Estruturas | DSU com rollback, conectividade dinâmica offline, Fenwick 2D, ordered set e sqrt decomposition |
| Numérico | Golden search, Gauss binário, matrizes e NTT |
| Teoria dos números | ExtGCD autónomo, CRT geral, Miller–Rabin e Pollard–Rho |
| Grafos | Matching bipartido autónomo, stable matching e heavy-light |
| Geometria | Hull e derivados, point-in-polygon/convex, círculos, enclosing circle, nearest pair e união de retângulos |
| Strings | Aho–Corasick, suffix array, Manacher e rotação mínima |
| Outros | Floyd para ciclos de funções e CHT dinâmico |

Também foram reduzidas notas avançadas de DP, séries e Catalan. Os cortes são escolhas de prioridade para este guia, não afirmações de impossibilidade numa prova futura. As fontes históricas continuam no ZIP para manter as regressões e a estrutura do projeto, mas não aparecem no PDF nem no catálogo ativo.

## Código e convenções preservados

Dos 57 headers herdados que continuam ativos, **56 têm o corpo byte a byte igual ao F**. Só `ModInv.h` teve o corpo alterado: passou a conter o Euclides estendido necessário à sua implementação, sem depender de um bloco retirado do impresso. A interface continua a devolver `optional`, normaliza entradas negativas e usa `__int128` nos coeficientes.

Mantidos o template, debugger, setup de contest, cores, três colunas e fonte de 9 pt. Índices 0-based, intervalos `[l,r)`, prefixos com `n+1` posições, `jmp[k][v]` e pai da raiz `-1`. A capa mantém logo, UMinho e Gonçalo Faria. Foram corrigidos pequenos problemas de paginação para não sobrepor títulos nem separar desnecessariamente os nomes dos headers do seu conteúdo.

## Validação

- Reexecutadas as baterias de regressão por capítulo que acompanham o notebook/KACTL.
- Testes independentes por força bruta, exaustivos ou aleatórios para os novos helpers e exemplos: arrays, janelas, compressão, DP, grelhas, pesquisa binária, inverso modular e padrões completos.
- Exemplos `Usage` e listings dos guias extraídos dos ficheiros impressos, compilados e executados com resultados esperados verificados.
- Compilação isolada e instanciada dos 64 headers com o preâmbulo real do contest; compilação com `LOCAL` e conjunta para detetar dependências e colisões.
- Testes de correção em release e com ASan/UBSan e verificações da STL, quando aplicável. LeakSanitizer desativado no ambiente de execução; a NTT retirada não fez o ensaio máximo opcional (`RUN_MAX=0`).
- PDF reconstruído e revisto visualmente; conferidos capa, paginação, presença dos headers e limites da página.

Resultados efetivos, comandos, durações e hashes ficam em `validation/notebookG/`. Os testes detetam regressões nos casos cobertos; os contratos e limites de cada algoritmo continuam a ter de ser respeitados.

## Reproduzir

```sh
make kactl
python3 doc/scripts/test-notebookG.py
python3 doc/scripts/verify-pdf-g.py
```

A construção requer LaTeX, Python 3 e Node.js; os testes requerem g++ e headers Boost para os oráculos históricos de precisão arbitrária. `NODE` e `BOOST_INCLUDEDIR` permitem indicar instalações fora do PATH/local padrão. A verificação estrutural do PDF requer `pypdf` e `pdfplumber`. Consulte `README.md` para pormenores.
