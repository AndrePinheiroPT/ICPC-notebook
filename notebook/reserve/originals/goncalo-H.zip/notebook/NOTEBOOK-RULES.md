# Regras atuais — notebook H revisto final

- Explicações impressas em português de Portugal, com acentuação correta; nomes de APIs e termos técnicos podem ficar em inglês.
- Preservar contratos, fórmulas, complexidades, exemplos e todas as implementações exceto o DoubleHash, simplificado por pedido explícito.
- DoubleHash: duas bases fixas distintas; h/p locais; get e concat O(1), construção O(n); concat usa potências do objeto e exige comprimento direito <= input construído. A igualdade de hashes pode colidir.
- Manter probabilidades e o guia final em tópicos; não acrescentar algoritmos.
- Técnicas (A) ocupa exclusivamente a página física 26, com sinais em negrito e ações curtas.
- Corpo de 9 pt; guia de 10 pt, títulos de 11 pt; três colunas, cores e capa UMinho/Gonçalo Faria.
- 26 páginas no total. Preservar 0-based, [l,r), prefixos n+1, jmp[k][v], pai da raiz -1.
- Não exportar soluções nem mappings do TST 2025.
- Reexecutar as 20 baterias, comparar tokens executáveis e exemplos com a revisão anterior e rever a renderização final.
