# Notebook H revisto — últimos ajustes

## Português de Portugal

Passaram para PT-PT os resumos junto aos nomes, as explicações das funções, mini-enunciados, comentários explicativos dos exemplos, guias de uso, matemática e a página final. Acentos preservados no texto e no código. Nomes das funções, variáveis, parâmetros, literais de exemplo e termos técnicos não foram traduzidos. Os rótulos impressos passam a Uso, Tempo e Memória; os nomes internos dos metadados ficam iguais para o parser.

Foi acrescentado suporte de caracteres acentuados nos listings e usada a fonte Latin Modern, da mesma família visual do texto anterior, em T1. Mantêm-se cores, estrutura de três colunas e os tamanhos de letra. O entrelinhamento do corpo foi ajustado em 1% para manter as 26 páginas; a página final mantém o seu espaçamento.

## DoubleHash

O código passou de **47 para 34 linhas**:

- `h` guarda prefixos e `p` guarda potências, ambos no objeto, calculados diretamente no construtor.
- Saíram a lambda de bases aleatórias, a cache global e os helpers `powers`/`append`.
- Duas bases fixas distintas; mantêm-se dois módulos e o comprimento na chave.
- `get(l,r)` mantém intervalos `[l,r)` e custo O(1). Construção e espaço O(n).
- A concatenação usa `h.concat(x,y)`, em O(1). O comprimento de y tem de caber nas potências de h, ou seja, não exceder o comprimento do input usado para construir h. Existe assert. Para concatenar chaves maiores, é preciso construir um objeto com input suficientemente longo.
- Strings mantêm bytes sem sinal; inteiros usam IDs com compressão conjunta quando necessário.

As bases fixas tornam o código mais simples e os resultados reproduzíveis, mas permitem colisões preparadas para essas bases. O texto explica que hashing não garante igualdade exata. Cada objeto guarda agora as próprias potências, em vez de partilhar a tabela global; a concatenação já não a expande automaticamente. Os exemplos e testes usam a nova chamada.

## Preservação e formato

A revisão anterior já tinha as probabilidades e o checklist final; ambos permanecem, agora traduzidos. Catálogo de **65 headers**. Capa e tema preservados. **26 páginas**: capa + 25 de conteúdo, com Técnicas (A) apenas na última. O texto principal mantém 9 pt; o guia, 10 pt e títulos de 11 pt.

Comparação automática com o ZIP entregue antes deste tweak: **64 corpos C++ e 64 Usage mantêm os mesmos tokens executáveis**, removendo apenas comentários; o único header alterado funcionalmente é DoubleHash. Os **19 listings TeX**, template de contest e comandos Bash também mantêm o código. Os imports e os algoritmos selecionados permanecem iguais.

## Validação

- **20/20 baterias atuais passaram**, incluindo regressões, exemplos extraídos do texto, release e ASan/UBSan/STL debug quando aplicável.
- Compilação dos 65 headers isolados, com LOCAL e em conjunto: PASS.
- DoubleHash: **549 876 verificações**, incluindo 65 810 substrings e 68 811 oráculos independentes de inteiros arbitrariamente grandes. Inclui bytes 0–255, vazios/zeros, compressão conjunta, concatenação com potências locais e caso de 100 000 símbolos.
- Probabilidades: 12 762 verificações por modo, além do Usage literal.
- PDF: contagem de páginas, catálogo, resumos, margens e exclusividade do guia verificados; páginas finais inspecionadas visualmente.

Logs e provas desta revisão: `validation/notebookH-revisto/`. As validações anteriores mantêm-se como histórico. Testes finitos não constituem uma prova universal nem eliminam colisões de hash.
