#!/usr/bin/env python3
"""Run the notebook G regression suite and keep reproducible logs/exit codes."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, platform, subprocess, time

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('--only', nargs='*', help='Runner names, e.g. test-chapter-03.sh')
args = parser.parse_args()
names = args.only or [
    'test-chapters-01-02.sh', 'test-chapter-03.sh', 'test-chapter-04.sh',
    'test-chapter-05.sh', 'test-chapter-06.sh', 'test-chapter-07.sh',
    'test-chapter-08.sh', 'test-chapters-09-10.sh', 'test-g-search.sh',
    'test-g-basics.sh', 'test-g-dp.sh', 'test-g-grid.sh', 'audit-template-g.py',
    'test-g-usage-math.sh', 'test-g-usage-graph.sh',
    'test-g-usage-various.sh', 'test-g-usage-ds-geometry-strings.sh',
    'test-g-worked.sh', 'test-g-applied.sh']
out = root / 'validation/notebookG'
(out / 'logs').mkdir(parents=True, exist_ok=True)
env = dict(os.environ)
# LeakSanitizer cannot run under ptrace; ASan and UBSan remain enabled.
env.setdefault('ASAN_OPTIONS', 'detect_leaks=0')
env.setdefault('RUN_MAX', '0')
if env.get('BOOST_INCLUDEDIR'):
    env['CPATH'] = env['BOOST_INCLUDEDIR'] + (':' + env['CPATH'] if env.get('CPATH') else '')
def update_summary(record):
    """Merge one result; --only must not discard earlier suite evidence."""
    path = out / 'test-summary.json'
    summary = json.loads(path.read_text()) if path.exists() else {}
    rows = {row['runner']: row for row in summary.get('runners', [])}
    name = record['runner']
    compact = {key: record[key] for key in
               ('runner', 'utc', 'seconds', 'exit_code', 'command', 'compiler')}
    if name in rows:
        summary.setdefault('history', []).append(rows[name])
    rows[name] = compact
    summary['runners'] = list(rows.values())
    summary['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary['all_passed'] = all(row['exit_code'] == 0 for row in rows.values())
    summary['result_semantics'] = (
        'Latest recorded result for each runner; --only preserves unselected '
        'results. Replaced records remain in history.')
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(summary, indent=2)+chr(10))
    temporary.replace(path)


failed = False
for name in names:
    command = ['python3' if name.endswith('.py') else 'bash', str(root / 'doc/scripts' / name)]
    start = time.monotonic()
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('RUN', name, flush=True)
    sources = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
               for folder in ('content', 'stress-tests', 'doc/scripts')
               for p in sorted((root / folder).rglob('*'))
               if p.is_file() and p.suffix in ('.h', '.cpp', '.inc', '.sh', '.py', '.tex', '.txt')}
    with (out / 'logs' / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    record = {'runner': name, 'utc': stamp, 'seconds': round(time.monotonic()-start, 2),
              'exit_code': result.returncode, 'command': command,
              'compiler': subprocess.check_output(['g++', '--version'], text=True).splitlines()[0],
              'platform': platform.platform(), 'ASAN_OPTIONS': env['ASAN_OPTIONS'],
              'RUN_MAX': env['RUN_MAX'], 'source_sha256': sources}
    (out / (name + '.json')).write_text(json.dumps(record, indent=2)+'\n')
    update_summary(record)
    print(('PASS' if result.returncode == 0 else 'FAIL'), name, record['seconds'], 's', flush=True)
    failed |= result.returncode != 0
raise SystemExit(int(failed))
