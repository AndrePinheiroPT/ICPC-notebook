#!/usr/bin/env python3
"""Verify Notebook F scope and bind its final source inventory to test evidence.

This is read-only for notebook sources. It writes verification JSON under
validation/notebookF. Full-file hashes and implementation-only hashes are
reported separately: a historical whole-file SHA cannot reveal its old body.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('archive', nargs='?', default='/home/zyndek/NOTEBOOKS/notebookE.zip')
args = parser.parse_args()
archive = Path(args.archive)
out = root / 'validation/notebookF'
chapters = ('math', 'data-structures', 'numerical', 'number-theory',
            'combinatorial', 'graph', 'geometry', 'strings', 'various')
runner_for = dict(zip(chapters, (
    'test-chapters-01-02.sh', 'test-chapter-03.sh', 'test-chapter-04.sh',
    'test-chapter-05.sh', 'test-chapter-06.sh', 'test-chapter-07.sh',
    'test-chapter-08.sh', 'test-chapters-09-10.sh', 'test-chapters-09-10.sh')))
runner_names = list(dict.fromkeys(runner_for.values())) + ['audit-template.py']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def split_header(data):
    """Remove only the initial /** metadata block, preserving the exact body."""
    match = re.match(rb'\s*/\*\*.*?\*/', data, re.S)
    assert match, 'Expected initial header documentation block'
    return data[:match.end()], data[match.end():]

def description(data):
    metadata, _ = split_header(data)
    match = re.search(rb'\* Description:(.*)', metadata, re.S)
    assert match, 'Missing Description field'
    return match.group(1)

def generated(name):
    parts = PurePosixPath(name).parts
    return ('build' in parts or '__pycache__' in parts
            or name.startswith('content/tex/vscode-theme/cache/')
            or name == 'header.tmp'
            or Path(name).suffix in {'.aux', '.toc', '.out', '.log', '.pyc', '.synctex'})

active = []
old_files = {}
ignored_generated = []
with zipfile.ZipFile(archive) as source:
    for entry in source.infolist():
        if entry.is_dir():
            continue
        assert entry.filename.startswith('notebook/'), entry.filename
        name = entry.filename[len('notebook/'):]
        assert '..' not in PurePosixPath(name).parts
        old_files[name] = source.read(entry)
        if generated(name):
            ignored_generated.append(name)
        else:
            assert (root / name).is_file(), f'Original E file missing: {name}'
    for chapter in chapters:
        name = f'content/{chapter}/chapter.tex'
        before = re.findall(rb'\\kactlimport\{([^}]+\.h)\}', old_files[name])
        after = re.findall(rb'\\kactlimport\{([^}]+\.h)\}', (root/name).read_bytes())
        assert before == after, f'Header import membership/order changed: {name}'
        active.extend(f'content/{chapter}/{h.decode()}' for h in after)
assert len(active) == len(set(active)) == 88
active_set = set(active)

inactive = []
for name, before in old_files.items():
    if name.startswith('content/') and name.endswith('.h') and name not in active_set:
        after = (root / name).read_bytes()
        # Some inactive legacy snippets lack metadata. For those compare all bytes.
        strip = lambda data: split_header(data)[1] if re.match(rb'\s*/\*\*', data) else data
        assert strip(before) == strip(after), f'Inactive code changed: {name}'
        inactive.append(name)

inventory = []
for name in active:
    before, after = old_files[name], (root/name).read_bytes()
    old_meta, old_body = split_header(before)
    new_meta, new_body = split_header(after)
    assert description(before) != description(after), f'Description not revised: {name}'
    inventory.append({
        'header': name,
        'implementation_changed': old_body != new_body,
        'metadata_comment_changed': old_meta != new_meta,
        'description_revised': True,
        'E_file_sha256': sha(before), 'F_file_sha256': sha(after),
        'E_implementation_sha256': sha(old_body), 'F_implementation_sha256': sha(new_body),
        'E_metadata_sha256': sha(old_meta), 'F_metadata_sha256': sha(new_meta),
    })

# Inspect only current printed sources and current integration/smoke fixtures.
current_text = [(name, (root/name).read_text()) for name in active]
current_text += [(f'content/{c}/chapter.tex', (root/f'content/{c}/chapter.tex').read_text())
                 for c in ('contest', *chapters, 'appendix')]
current_text += [(str(p.relative_to(root)), p.read_text())
                 for p in sorted(out.glob('*-instantiations.json'))]
current_text += [(str(p.relative_to(root)), p.read_text())
                 for p in sorted((root/'stress-tests').glob('chapter-*/Integration.inc'))]
stale_patterns = {
    'removed concrete-flow/Aho template parameters': r'\b(?:DinicFlow|MinCostFlow|Aho)\s*<',
    'removed RMQ operation functor': r'\bSTMin\b|\bRMQ\s*<\s*(?:ll|int|T)\s*,',
    'removed callback-style HLD example': r'\.path\([^\n;]*\[\s*&?\s*\]',
}
for location, text in current_text:
    for label, pattern in stale_patterns.items():
        assert not re.search(pattern, text), f'Stale current API ({label}): {location}'

runner_evidence = {}
for name in runner_names:
    path = out / (name + '.json')
    record = json.loads(path.read_text())
    assert record['runner'] == name and record['exit_code'] == 0, f'Runner failed: {name}'
    log = root / record.get('log', f'validation/notebookF/logs/{name}.log')
    assert log.is_file() and log.stat().st_size, f'No runner log: {name}'
    if 'log_sha256' in record:
        assert sha(log.read_bytes()) == record['log_sha256'], f'Changed test log: {name}'
    runner_evidence[name] = {
        'record': str(path.relative_to(root)), 'record_sha256': sha(path.read_bytes()),
        'exit_code': 0, 'log': str(log.relative_to(root)), 'log_sha256': sha(log.read_bytes()),
        'command': record['command'], 'compiler': record.get('compiler'),
    }
assert len(runner_evidence) == 9

line_record_path = out/'linehull-targeted.json'
line = json.loads(line_record_path.read_text())
assert line['exit_code'] == 0
line_log = root / line['log']
assert line_log.is_file() and line_log.stat().st_size
assert line['sha256']['content/various/LineHull.h'] == sha((root/'content/various/LineHull.h').read_bytes()), \
    'Final LineHull differs from the targeted-tested source'

fenwick_record = json.loads((out/'test-chapter-03.sh.json').read_text())
fenwick = fenwick_record['final_fenwick2d_recheck']
assert fenwick['exit_code'] == 0 and fenwick['result'] == 'PASS'
assert sha((root/fenwick['log']).read_bytes()) == fenwick['log_sha256']
review_path = out/'independent-api-inventory.json'
review = {entry['header']: entry for entry in json.loads(review_path.read_text())['headers']}
coverage = []
for item in inventory:
    name = item['header']
    runner = runner_for[name.split('/')[1]]
    record = json.loads((out/(runner+'.json')).read_text())
    whole_file = record.get('source_sha256', {}).get(name)
    implementation = record.get('implementation_sha256_verified_after_execution', {}).get(name)
    review_matches = review[name]['F_implementation_sha256'] == item['F_implementation_sha256']
    evidence = {
        'header': name, 'primary_runner': runner,
        'final_implementation_sha256': item['F_implementation_sha256'],
        'final_file_sha256': item['F_file_sha256'],
        'runner_recorded_file_sha256': whole_file,
        'runner_file_byte_match': whole_file == item['F_file_sha256'] if whole_file else None,
        'post_execution_implementation_hash_match': implementation == item['F_implementation_sha256']
            if implementation else None,
        'independent_review_snapshot_implementation_match': review_matches,
        'combined_compile_audit': 'audit-template.py',
    }
    if name == 'content/various/LineHull.h':
        evidence['final_source_evidence'] = 'targeted final LineHull file hash, release + ASan/UBSan; earlier whole-notebook audit predates this local helper rewrite'
        evidence['targeted_record'] = str(line_record_path.relative_to(root))
    elif name == 'content/strings/Aho.h' and not review_matches:
        # The last PDF fix only wraps a constructor declaration before a token.
        formatting = json.loads((out/'aho-linebreak.json').read_text())
        current = (root/name).read_bytes()
        unwrapped = current.replace(b"explicit Aho(int alphabet = 26,\n\t\tint first = 'a')",
                                    b"explicit Aho(int alphabet = 26, int first = 'a')")
        assert sha(current) == formatting['after_sha256']
        assert sha(unwrapped) == formatting['before_sha256']
        assert sha(split_header(unwrapped)[1]) == review[name]['F_implementation_sha256']
        evidence['final_source_evidence'] = 'same independently reviewed implementation after reversing the recorded whitespace-only constructor line wrap'
        evidence['formatting_record'] = 'validation/notebookF/aho-linebreak.json'
    elif implementation:
        assert implementation == item['F_implementation_sha256'], f'Untested implementation delta: {name}'
        evidence['final_source_evidence'] = 'implementation hash explicitly recorded after successful direct runner; header prose may have changed afterwards'
    elif whole_file == item['F_file_sha256']:
        evidence['final_source_evidence'] = 'runner whole-file source SHA equals the final file'
    else:
        assert review_matches, f'Unreviewed post-run implementation delta: {name}'
        evidence['final_source_evidence'] = 'final body equals independent review snapshot; full-file hash differs after documentation edits, so old runner body is not cryptographically recoverable from its full-file SHA alone'
    if name == 'content/data-structures/Fenwick2D.h':
        evidence['targeted_release_recheck'] = fenwick['log']
    coverage.append(evidence)

preservation = {
    'source_archive': str(archive), 'source_archive_sha256': sha(archive.read_bytes()),
    'original_E_file_paths': len(old_files),
    'required_original_E_files_retained': len(old_files) - len(ignored_generated),
    'generated_paths_excluded_from_retention_assertion': sorted(ignored_generated),
    'all_original_E_paths_present_in_this_workspace': all((root/n).is_file() for n in old_files),
    'active_header_count': 88, 'active_header_import_order_unchanged': True,
    'inactive_header_implementations_unchanged': len(inactive),
    'all_active_descriptions_revised': True,
    'implementation_changed_count': sum(x['implementation_changed'] for x in inventory),
    'metadata_comment_changed_count': sum(x['metadata_comment_changed'] for x in inventory),
    'stale_current_api_matches': [], 'headers': inventory,
}
(out/'preservation.json').write_text(json.dumps(preservation, indent=2)+'\n')
final = {
    'scope': 'Final active implementations, successful chapter runners and targeted follow-ups; no claim of exhaustive correctness.',
    'header_count': 88, 'successful_runner_count': 9,
    'implementation_hash_definition': 'Exact bytes after the initial /** metadata comment, including subsequent code comments and whitespace.',
    'evidence_limit': 'A saved full-file SHA cannot reveal a previous implementation body. For documentation-only drift, the independent-review implementation snapshot and explicit audit trail are reported, not falsely treated as a byte-identical runner snapshot.',
    'runner_records': runner_evidence,
    'targeted_followups': {
        'LineHull': {'record': str(line_record_path.relative_to(root)), 'exit_code': 0,
                     'log': line['log'], 'log_sha256': sha(line_log.read_bytes()),
                     'final_source_file_sha256': line['sha256']['content/various/LineHull.h']},
        'Fenwick2D': fenwick,
    },
    'independent_review_snapshot': str(review_path.relative_to(root)),
    'independent_review_snapshot_sha256': sha(review_path.read_bytes()),
    'coverage': coverage,
}
(out/'final-coverage.json').write_text(json.dumps(final, indent=2)+'\n')
print(json.dumps({k: v for k, v in preservation.items() if k not in ('headers', 'generated_paths_excluded_from_retention_assertion')}, indent=2))
print('PASS: nine successful runner records and both targeted follow-ups linked in final-coverage.json')
