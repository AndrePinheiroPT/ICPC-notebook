#!/usr/bin/env python3
"""Compile/run each selected header using only the actual Contest preamble.
The small mains instantiate templates, so dependent-name lookup is checked.
Full correctness and sanitizers belong to the chapter stress-test runners.
"""
from pathlib import Path
import json, re, subprocess, tempfile

root = Path(__file__).resolve().parents[2]
pre, sep, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep
chapters = ('math','data-structures','numerical','number-theory','combinatorial','graph','geometry','strings','various')
headers = [f'content/{c}/{h}' for c in chapters for h in re.findall(
    r'\\kactlimport\{([^}]+\.h)\}', (root/'content'/c/'chapter.tex').read_text())]
smokes = json.loads((root/'validation/notebookG/instantiations.json').read_text())
assert set(headers) == set(smokes), (set(headers)-set(smokes),set(smokes)-set(headers))

with tempfile.TemporaryDirectory(prefix='notebook-template-') as temp:
    tmp = Path(temp)
    for header in headers:
        source=tmp/'single.cpp'; binary=tmp/'single'
        source.write_text(pre+'\n#include '+json.dumps(str(root/header))+'\n'+smokes[header])
        args=['g++','-std=gnu++17','-O1','-Wall','-Wextra','-Werror',str(source)]
        subprocess.run(args+['-o',str(binary)],check=True)
        subprocess.run([str(binary)],check=True)
        subprocess.run(args+['-DLOCAL','-fsyntax-only'],check=True)
        print(f'PASS isolated + instantiated + LOCAL: {header}',flush=True)
    # Detect namespace/macro collisions between otherwise independent headers.
    source=tmp/'all.cpp'
    source.write_text(pre+'\n'+''.join('#include '+json.dumps(str(root/h))+'\n' for h in headers)+'int main() {}\n')
    subprocess.run(['g++','-std=gnu++17','-Wall','-Wextra','-Werror','-fsyntax-only',str(source)],check=True)
    print(f'PASS combined: {len(headers)} headers; no extra template macros or aliases',flush=True)
