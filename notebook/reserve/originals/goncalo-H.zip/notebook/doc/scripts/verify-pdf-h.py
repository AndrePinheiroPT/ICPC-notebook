#!/usr/bin/env python3
"""H: 26 physical pages; recognition guide alone on the final page."""
from pathlib import Path
import hashlib,json,re,unicodedata
import pdfplumber
from pypdf import PdfReader
root=Path(__file__).resolve().parents[2];pdf=root/'kactl.pdf';reader=PdfReader(pdf)
assert len(reader.pages)==26,f'Expected26pages, got{len(reader.pages)}'
texts=[p.extract_text() or '' for p in reader.pages]
assert texts[0].strip()=='UMinho\nGonçalo Faria'
assert len(reader.pages[0].images)==1
assert all('Techniques (A)' not in t for t in texts[:-1])
assert 'Techniques (A)' in texts[-1]
headers=[];summaries=[]
for chapter in (root/'content').glob('*/chapter.tex'):
 for name in re.findall(r'\\kactlimport\{([^}]+\.h)\}',chapter.read_text()):
  headers.append(name)
  s=(chapter.parent/name).read_text()
  summaries.append(s.split(' * Summary:',1)[1].split('\n',1)[0].strip())
assert len(headers)==64
def normalize(text):
 return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',text).replace('’',"'").replace('‘',"'"))
body=' '.join(texts[1:-1]);normalized=normalize(body)
for name,summary in zip(headers,summaries):
 assert name in body,name
 assert normalize(summary) in normalized,summary
 assert name not in texts[-1],f'Algorithm code leaked to appendix: {name}'
guide=(root/'content/appendix/Recognition.tex').read_text()
headings=re.findall(r'\\noindent\\textbf\{([^}]+)\}',guide)
assert len(headings)==18,len(headings)
last=normalize(texts[-1])
for title in headings:
 assert title in last,title
 assert all(title not in t for t in texts[:-1]),title
outside=[]
with pdfplumber.open(pdf) as doc:
 for i,p in enumerate(doc.pages):
  for c in p.chars:
   if c['x0']<10 or c['x1']>p.width-10 or c['top']<1 or c['bottom']>p.height-7:outside.append((i+1,c['text']))
assert not outside,outside[:20]
result={'pages':26,'content_pages':25,'recognition_physical_page':26,'recognition_headings':len(headings),'recognition_exclusive_to_final_page':True,'active_headers_present':len(headers),'summaries_present':len(summaries),'cover_images':1,'out_of_bounds_characters':0,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
(root/'validation/notebookH/pdf-structure.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
