#!/usr/bin/env python3
"""Check that the original H content is preserved outside the requested edits."""
from pathlib import Path
import hashlib, json, re, sys, zipfile

root = Path(__file__).resolve().parents[2]
base = Path(sys.argv[1])
with zipfile.ZipFile(base) as archive:
    old = {n[len('notebook/'):]: archive.read(n) for n in archive.namelist()
           if n.startswith('notebook/') and not n.endswith('/')}
allowed = {'content/kactl.tex', 'content/appendix/Recognition.tex', 'content/math/chapter.tex'}
checked = []
for name, data in old.items():
    if name.startswith('content/') and name not in allowed:
        assert (root / name).read_bytes() == data, name
        checked.append(name)
headers = []
for name, data in old.items():
    if name.startswith('content/') and name.endswith('/chapter.tex'):
        headers += [str(Path(name).parent / h) for h in
                    re.findall(r'\\kactlimport\{([^}]+\.h)\}', data.decode())]
assert len(headers) == 64
for name in headers:
    assert (root / name).read_bytes() == old[name], name
new = set()
for chapter in (root / 'content').glob('*/chapter.tex'):
    for h in re.findall(r'\\kactlimport\{([^}]+\.h)\}', chapter.read_text()):
        new.add(str((chapter.parent / h).relative_to(root)))
assert new == set(headers) | {'content/math/Probability.h'}
math = (root / 'content/math/chapter.tex').read_text()
assert math.replace('\\kactlimport{Probability.h}\n\n', '') == old['content/math/chapter.tex'].decode()
result = dict(base_zip_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),
              original_active_headers_unchanged=64, active_headers=65,
              other_unchanged_content_files=len(checked),
              changed_original_content=sorted(allowed),
              new_content=['content/math/Probability.h'],
              contest_setup_and_template_unchanged=True,
              math_existing_text_unchanged=True)
(root / 'validation/notebookH-revisto/preservation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
