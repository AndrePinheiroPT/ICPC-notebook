#!/usr/bin/env bash
set -euo pipefail
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-ch07.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
python3 - "$root" "$tmp/integration.cpp" <<'PY'
from pathlib import Path
import re, sys
root = Path(sys.argv[1])
preamble, sep, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert sep, 'Contest template main not found'
imports = []
for chapter in ('math','data-structures','numerical','number-theory','combinatorial','graph'):
    text = (root / 'content' / chapter / 'chapter.tex').read_text()
    for name in re.findall(r'\\kactlimport\{([^}]+\.h)\}', text):
        imports.append(f'#include "content/{chapter}/{name}"\n')
# Preserve historical regression fixtures after the print catalogue cuts.
# The separate G template audit checks only the selected printable headers.
import json
old = json.loads((root / 'validation/notebookG/original-imports.json').read_text())
used = {line.split('/')[1] for line in imports}
for chapter in used:
    for header in old['content/' + chapter + '/chapter.tex']:
        line = '#include "content/' + chapter + '/' + header + '"\n'
        if line not in imports: imports.append(line)
fixture = (root / 'stress-tests/chapter-07/Integration.inc').read_text()
Path(sys.argv[2]).write_text(preamble + ''.join(imports) + fixture)
PY
for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion -Werror)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -DLOCAL -D_GLIBCXX_DEBUG
      -fsanitize=address,undefined -fno-omit-frame-pointer)
  fi
  echo "$mode: integration with actual Contest template and chapters 2-7"
  g++ "${flags[@]}" -I "$root" "$tmp/integration.cpp" -o "$tmp/integration-$mode"
  "$tmp/integration-$mode"
  for name in PathsMST Connectivity FlowMatching Trees; do
    echo "$mode: $name"
    g++ "${flags[@]}" "$root/stress-tests/chapter-07/$name.cpp" -o "$tmp/$name-$mode"
    "$tmp/$name-$mode"
  done
done
