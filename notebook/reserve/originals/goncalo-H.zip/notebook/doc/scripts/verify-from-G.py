#!/usr/bin/env python3
"""Prove H keeps the selected code, interfaces, Usage and chapter catalogue."""
from pathlib import Path
import hashlib,json,re,sys,zipfile
root=Path(__file__).resolve().parents[2]
base=Path(sys.argv[1]);z=zipfile.ZipFile(base)
old={n[len('notebook/'):]:z.read(n) for n in z.namelist() if n.startswith('notebook/') and not n.endswith('/')}
headers=[]
for c in (root/'content').glob('*/chapter.tex'):
 if c.parent.name!='appendix':assert c.read_bytes()==old[str(c.relative_to(root))],c
 for h in re.findall(r'\\kactlimport\{([^}]+\.h)\}',c.read_text()):headers.append(c.parent/h)
rows=[]
def prose(s,start):
 s=s.split(start,1)[1].split(' * Usage:',1)[0]
 s=re.sub(r'^\s*\*\s?', '',s,flags=re.M)
 s=s.replace('Description:', '')
 return len(s.split())
for p in headers:
 rel=str(p.relative_to(root));b=old[rel].decode();a=p.read_text()
 assert b.split('#pragma once',1)[1]==a.split('#pragma once',1)[1],rel
 assert b.split(' * Usage:',1)[1]==a.split(' * Usage:',1)[1],rel
 summary=a.split(' * Summary:',1)[1].split('\n',1)[0].strip()
 assert 3<=len(summary.split())<=10,(rel,summary)
 rows.append({'header':rel,'summary':summary,'original_description_words':prose(b,' * Description:'),'summary_and_description_words':prose(a,' * Summary:'),'body_and_usage_unchanged':True,'body_sha256':hashlib.sha256(a.split('#pragma once',1)[1].encode()).hexdigest()})
assert len(rows)==64
# Additional printed example sources are outside .h files and must also stay exact.
texexamples=[str(p.relative_to(root)) for p in (root/'content').rglob('*.tex') if r'\begin{lstlisting}' in p.read_text() and '/tex/' not in str(p)]
for rel in texexamples:
 if rel!='content/appendix/Recognition.tex':assert (root/rel).read_bytes()==old[rel],rel
assert (root/'content/contest/template.cpp').read_bytes()==old['content/contest/template.cpp']
before=sum(r['original_description_words'] for r in rows);after=sum(r['summary_and_description_words'] for r in rows)
assert after<=before,(before,after)
result={'base_zip_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'active_headers':64,'all_bodies_and_usage_unchanged':True,'active_catalogue_unchanged':True,'additional_printed_examples_unchanged':True,'contest_template_unchanged':True,'description_words_before':before,'summary_and_description_words_after':after,'percent_reduction':round((before-after)*100/before,2),'headers':rows}
out=root/'validation/notebookH';out.mkdir(parents=True,exist_ok=True)
(out/'preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: 64 bodies and Usage, catalogue, printed listings and contest template unchanged')
print('Descriptions + new summaries:',before,'->',after,'words')
