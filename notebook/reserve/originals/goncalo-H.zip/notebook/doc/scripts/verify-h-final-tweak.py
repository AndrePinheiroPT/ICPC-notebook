#!/usr/bin/env python3
"""Verify the PT-PT revision changes executable code only in DoubleHash."""
from pathlib import Path
import hashlib,json,re,sys,zipfile
root=Path(__file__).resolve().parents[2]
base=Path(sys.argv[1])
with zipfile.ZipFile(base) as z:
 old={n[len('notebook/'):]:z.read(n).decode('utf-8') for n in z.namelist()
      if n.startswith('notebook/content/') and n.endswith(('.h','.cpp','.tex','.sh'))}
# Keep literals intact, discard only comments and whitespace. Remaining token
# sequences detect changes to operators, bounds, types, identifiers and strings.
lex=re.compile(r'("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')|(/\*[\s\S]*?\*/|//[^\n]*)|(\s+)|(\w+|[^\s])')
def tokens(source):
 return [m.group(0) for m in lex.finditer(source) if m.group(1) or m.group(4)]
def usage(source):
 match=re.search(r'^ \* Usage:(.*?)(?=^ \* [A-Z][A-Za-z]+:|^ \*/)',source,re.M|re.S)
 if not match:return []
 return tokens(re.sub(r'^ \* ?', '',match.group(1),flags=re.M))
headers=[]
for c in (root/'content').glob('*/chapter.tex'):
 headers.extend(str((c.parent/h).relative_to(root)) for h in re.findall(r'\\kactlimport\{([^}]+\.h)\}',c.read_text()))
assert len(headers)==65
unchanged=[]
for name in headers:
 before=old[name];after=(root/name).read_text()
 if name!='content/strings/DoubleHash.h':
  assert tokens(before.split('#pragma once',1)[1])==tokens(after.split('#pragma once',1)[1]),name
  assert usage(before)==usage(after),name+' Usage'
  unchanged.append(name)
 assert before.split(' * Summary:',1)[1].split('\n',1)[0]!=after.split(' * Summary:',1)[1].split('\n',1)[0],name+' summary untranslated'
assert len(unchanged)==64
listings=0
for name,before in old.items():
 if name.endswith('.tex') and '/tex/' not in name:
  after=(root/name).read_text()
  a=re.findall(r'\\begin\{lstlisting\}(?:\[[^\]]*\])?(.*?)\\end\{lstlisting\}',before,re.S)
  b=re.findall(r'\\begin\{lstlisting\}(?:\[[^\]]*\])?(.*?)\\end\{lstlisting\}',after,re.S)
  assert len(a)==len(b),name
  for x,y in zip(a,b):assert tokens(x)==tokens(y),name
  listings+=len(a)
assert (root/'content/contest/template.cpp').read_text()==old['content/contest/template.cpp']
# Bash configuration differs only in its leading explanatory comment.
assert (root/'content/contest/config.sh').read_text().splitlines()[1:]==old['content/contest/config.sh'].splitlines()[1:]
result={'base_zip_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'active_headers':65,'translated_summaries':65,'unchanged_algorithm_token_sequences':64,
 'unchanged_usage_token_sequences':64,'intentional_executable_change':'content/strings/DoubleHash.h',
 'unchanged_tex_code_listings':listings,'contest_template_unchanged':True,'contest_bash_commands_unchanged':True}
(root/'validation/notebookH-revisto/preservation-final-tweak.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
