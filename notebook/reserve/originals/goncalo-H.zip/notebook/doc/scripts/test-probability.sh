#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-probability.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
export UBSAN_OPTIONS="halt_on_error=1"

# Compile the literal printed Usage with the current contest preamble.
python3 - "$root" "$tmp/usage.cpp" <<'PY'
from pathlib import Path
import json
import re
import sys
root, output = Path(sys.argv[1]), Path(sys.argv[2])
header = root / 'content/math/Probability.h'
metadata = re.match(r'/\*\*(.*?)\*/', header.read_text(), re.S).group(1)
lines, active = [], False
for raw in metadata.splitlines():
    line = re.sub(r'^\s*\* ?', '', raw)
    field = re.match(r'([A-Z][A-Za-z ]+):\s*(.*)', line)
    if field:
        if active:
            break
        if field.group(1) == 'Usage':
            active = True
            lines.append(field.group(2))
    elif active:
        lines.append(line)
assert active and 'assert(' in '\n'.join(lines)
preamble, marker, _ = (root / 'content/contest/template.cpp').read_text().partition('int main() {')
assert marker
output.write_text(preamble + '\n#include ' + json.dumps(str(header)) +
                  '\nint main() {\n' + '\n'.join(lines) +
                  '\ncout << "PASS literal Probability.h Usage\\n";\n}\n')
print(f'Extracted {len(lines)} literal Usage lines from Probability.h', flush=True)
PY

extra=()
if [[ -n "${BOOST_INCLUDEDIR:-}" ]]; then extra+=(-isystem "$BOOST_INCLUDEDIR"); fi
for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion -Werror)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -DLOCAL -D_GLIBCXX_DEBUG -fsanitize=address,undefined
      -fno-omit-frame-pointer -fno-pie -no-pie)
  fi
  echo "$mode"
  g++ "${flags[@]}" "${extra[@]}" "$root/stress-tests/math/Probability.cpp" -o "$tmp/test"
  "$tmp/test"
  g++ "${flags[@]}" "$tmp/usage.cpp" -o "$tmp/usage"
  "$tmp/usage"
done
