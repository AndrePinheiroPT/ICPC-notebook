#!/usr/bin/env python3
"""Verify revised H's printed catalogue and the exclusive final checklist page."""
from pathlib import Path
import hashlib, json, re, unicodedata
import pdfplumber
from pypdf import PdfReader

root = Path(__file__).resolve().parents[2]
pdf = root / 'kactl.pdf'
reader = PdfReader(pdf)
assert len(reader.pages) == 26, len(reader.pages)
texts = [p.extract_text() or '' for p in reader.pages]
assert texts[0].strip() == 'UMinho\nGonçalo Faria'
assert len(reader.pages[0].images) == 1
assert all('Técnicas (A)' not in t for t in texts[:-1])
assert 'Técnicas (A)' in texts[-1]

def normalize(text):
    text = unicodedata.normalize('NFKC', text).replace('’', "'").replace('‘', "'")
    return re.sub(r'\s+', ' ', text)

headers, summaries = [], []
for chapter in (root / 'content').glob('*/chapter.tex'):
    for name in re.findall(r'\\kactlimport\{([^}]+\.h)\}', chapter.read_text()):
        headers.append(name)
        source = (chapter.parent / name).read_text()
        summaries.append(source.split(' * Summary:', 1)[1].split('\n', 1)[0].strip())
assert len(headers) == 65
body = ' '.join(texts[1:-1])
for name, summary in zip(headers, summaries):
    assert name in body, name
    assert normalize(summary) in normalize(body), summary
    assert name not in texts[-1], name
probability_pages = [i+1 for i,t in enumerate(texts) if 'Probability.h' in t or 'binomialProb' in t or 'geometricProb' in t]
assert probability_pages and all(2 <= i <= 25 for i in probability_pages)
for function in ('binomialProb', 'atLeastOne', 'geometricProb'):
    assert function in body, function

guide = (root / 'content/appendix/Recognition.tex').read_text()
headings = re.findall(r'\\recgroup\{([^}]+)\}', guide)
signals = re.findall(r'\\rec\{([^}]+)\}', guide)
assert len(headings) == 12
assert len(signals) == 64
last = normalize(texts[-1])
for phrase in headings + signals:
    assert normalize(phrase) in last, phrase
outside = []
with pdfplumber.open(pdf) as doc:
    for i, page in enumerate(doc.pages):
        for char in page.chars:
            if char['x0'] < 10 or char['x1'] > page.width - 10 or char['top'] < 1 or char['bottom'] > page.height - 7:
                outside.append((i + 1, char['text']))
    # Checklist text is intentionally larger than the 9 pt body.
    sizes = [c['size'] for c in doc.pages[-1].chars if c['text'].isalpha()]
    assert sum(9.8 < size < 10.1 for size in sizes) / len(sizes) > 0.75
assert not outside, outside[:20]
result = dict(pages=26, content_pages=25, recognition_physical_page=26,
              recognition_headings=len(headings), recognition_bullets=len(signals),
              recognition_exclusive_to_final_page=True, active_headers_present=len(headers),
              summaries_present=len(summaries), probability_physical_pages=probability_pages,
              cover_images=1, out_of_bounds_characters=0,
              sha256=hashlib.sha256(pdf.read_bytes()).hexdigest())
(root / 'validation/notebookH-revisto/pdf-structure.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
