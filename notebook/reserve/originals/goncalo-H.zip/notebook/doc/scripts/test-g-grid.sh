#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-g-grid.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Werror)
  if [[ "$mode" == release ]]; then flags+=(-O2); else
    flags+=(-O1 -g -D_GLIBCXX_DEBUG -fsanitize=address,undefined -fno-omit-frame-pointer)
  fi
  g++ "${flags[@]}" "$root/stress-tests/notebookG/GridBFS.cpp" -o "$tmp/test"
  echo "$mode"
  "$tmp/test"
done
