#!/usr/bin/env python3
"""Compare selected G headers with an original notebookF.zip (argument)."""
from pathlib import Path
import sys, zipfile, hashlib, json, re
root=Path(__file__).resolve().parents[2]
base=Path(sys.argv[1])
with zipfile.ZipFile(base) as z:
 prefix=next(n[:-len('content/kactl.tex')] for n in z.namelist() if n.endswith('content/kactl.tex'))
 old=set()
 for n in z.namelist():
  if n.endswith('/chapter.tex') and n.startswith(prefix+'content/'):
   for h in re.findall(r'\\kactlimport\{([^}]+\.h)\}',z.read(n).decode()):
    old.add(str(Path(n[len(prefix):]).parent/h))
 current={str(p.parent.relative_to(root)/h) for p in (root/'content').glob('*/chapter.tex') for h in re.findall(r'\\kactlimport\{([^}]+\.h)\}',p.read_text())}
 def body(s): return s.split('#pragma once',1)[1]
 retained=[]
 for h in sorted(old&current):
  code=body((root/h).read_text()); same=code==body(z.read(prefix+h).decode())
  retained.append({'header':h,'body_unchanged_from_F':same,'body_sha256':hashlib.sha256(code.encode()).hexdigest()})
 changed=[x['header'] for x in retained if not x['body_unchanged_from_F']]
 assert changed==['content/number-theory/ModInv.h'],changed
 assert (root/'content/contest/template.cpp').read_bytes()==z.read(prefix+'content/contest/template.cpp')
 for h in current:
  for inc in re.findall(r'^#include "([^"]+)"',(root/h).read_text(),re.M):
   dep=(root/h).parent/inc
   assert str(dep.resolve().relative_to(root.resolve())) in current,(h,inc)
 result={'base_zip_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'old_count':len(old),'active_count':len(current),'removed':sorted(old-current),'added':sorted(current-old),'retained':retained,'all_local_dependencies_printed':True,'contest_template_unchanged':True}
 (root/'validation/notebookG/preservation.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(old),'->',len(current),'headers;',len(old-current),'cuts;',len(current-old),'added;',len(retained)-len(changed),'retained bodies unchanged')
