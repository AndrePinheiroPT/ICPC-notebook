#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
python3 stress-tests/notebookG/UsageMath.py
