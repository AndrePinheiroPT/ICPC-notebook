#!/usr/bin/env bash
set -euo pipefail
export ASAN_OPTIONS="${ASAN_OPTIONS:-detect_leaks=0}"
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/notebook-tests.XXXXXX")
trap 'rm -rf -- "$tmp"' EXIT

extra=()
if [[ -n "${BOOST_INCLUDEDIR:-}" ]]; then
  extra+=(-isystem "$BOOST_INCLUDEDIR")
fi

bash "$root/stress-tests/contest/run.sh"

# Compile the actual Contest preamble together with all new Math headers.
python3 - "$root" "$tmp/integration.cpp" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
s = (root / 'content/contest/template.cpp').read_text()
preamble, sep, _ = s.partition('int main() {')
assert sep, 'Contest template main not found'
Path(sys.argv[2]).with_name('ContestPreamble.h').write_text(preamble)
fixture = (root / 'stress-tests/math/Integration.inc').read_text()
Path(sys.argv[2]).write_text(preamble + fixture)
PY

for mode in release debug; do
  flags=(-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion -Werror)
  if [[ "$mode" == release ]]; then
    flags+=(-O2)
  else
    flags+=(-O1 -g -DLOCAL -D_GLIBCXX_DEBUG
      -fsanitize=address,undefined -fno-omit-frame-pointer)
  fi
  g++ "${flags[@]}" "${extra[@]}" -I "$root" \
    "$tmp/integration.cpp" -o "$tmp/integration-$mode"
  "$tmp/integration-$mode"
  for name in IntDivision ModAlign Int128 Adversarial UsageExamples; do
    echo "$mode: $name"
    g++ "${flags[@]}" "${extra[@]}" -I "$tmp" \
      "$root/stress-tests/math/$name.cpp" -o "$tmp/$name-$mode"
    "$tmp/$name-$mode"
  done
done
