#!/usr/bin/env python3
"""Notebook G structural check; rendered pages also require visual review."""
from pathlib import Path
import hashlib, json, re
import pdfplumber
from pypdf import PdfReader

root = Path(__file__).resolve().parents[2]
pdf = root / 'kactl.pdf'
reader = PdfReader(pdf)
assert 2 <= len(reader.pages) <= 26, 'Maximum: cover plus 25 content pages'
cover_text = reader.pages[0].extract_text().strip()
assert 'UMinho' in cover_text and 'Gonçalo Faria' in cover_text, cover_text
assert len(reader.pages[0].images) == 1, 'Cover must contain only the logo image'
text = '\n'.join(p.extract_text() for p in reader.pages[1:])
headers = [h for c in (root / 'content').glob('*/chapter.tex')
           for h in re.findall(r'\\kactlimport\{([^}]+\.h)\}', c.read_text())]
missing = [h for h in headers if h not in text]
assert not missing, missing
outside = []
with pdfplumber.open(pdf) as pages:
    for i, page in enumerate(pages.pages):
        for c in page.chars:
            if c['x0'] < 10 or c['x1'] > page.width-10 or c['top'] < 1 or c['bottom'] > page.height-7:
                outside.append((i+1,c['text'],c['x0'],c['top']))
assert not outside, outside[:20]
result = {'pages':len(reader.pages), 'cover_text':cover_text, 'cover_images':1,
          'active_headers_present':len(headers), 'out_of_bounds_characters':0,
          'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
dest = root / 'validation/notebookG/pdf-structure.json'
dest.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
