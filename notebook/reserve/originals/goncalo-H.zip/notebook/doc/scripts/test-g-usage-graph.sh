#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
python3 stress-tests/notebookG/graph-usage.py
python3 stress-tests/notebookG/graph-usage.py --sanitize
python3 stress-tests/notebookG/test-graph-guide.py
