#!/usr/bin/env python3
"""Verify E's scope against the supplied, unmodified notebookD.zip."""
from pathlib import Path
import hashlib, json, re, sys, zipfile

root = Path(__file__).resolve().parents[2]
archive = Path(sys.argv[1])
allowed = {
    'content/math/chapter.tex', 'content/number-theory/chapter.tex',
    'content/various/chapter.tex',
    'content/math/IntDivision.h', 'content/math/ModAlign.h',
    'content/number-theory/ModInv.h', 'content/number-theory/SPF.h',
    'content/number-theory/TrialDivision.h', 'content/number-theory/Divisors.h',
    'content/number-theory/Prime64.h', 'content/number-theory/Factor64.h',
}
new_headers = {'content/various/MonotonicStack.h', 'content/various/MonotonicDeque.h'}
def code(data):
    return data.split(b'*/', 1)[1] if data.lstrip().startswith(b'/**') else data

changed, old_paths, old_headers, active = [], set(), 0, 0
with zipfile.ZipFile(archive) as z:
    for entry in z.infolist():
        if entry.is_dir():
            continue
        name = entry.filename.removeprefix('notebook/')
        old_paths.add(name)
        path = root / name
        assert path.is_file(), f'D file missing: {name}'
        before, after = z.read(entry), path.read_bytes()
        if name.startswith('content/') and before != after:
            changed.append(name)
            assert name in allowed, f'Unexpected content change: {name}'
        if name.startswith('content/') and name.endswith('.h'):
            old_headers += 1
            assert code(before) == code(after), f'Changed implementation: {name}'
        if name.startswith('content/') and name.endswith('/chapter.tex'):
            active += len(re.findall(rb'\\kactlimport\{[^}]+\.h\}', before))
    old_various = z.read('notebook/content/various/chapter.tex').decode()
    new_various = (root/'content/various/chapter.tex').read_text()
    insertion = '\\section{Monotonic stack and deque}\n\\kactlimport{MonotonicStack.h}\n\\kactlimport{MonotonicDeque.h}\n\n'
    assert new_various.replace(insertion, '', 1) == old_various
added = {str(p.relative_to(root)) for p in (root/'content').rglob('*')
         if p.is_file() and str(p.relative_to(root)) not in old_paths
         and '__pycache__' not in p.parts
         and 'content/tex/vscode-theme/cache/' not in str(p.relative_to(root))}
assert added == new_headers, added
current_active = sum(len(re.findall(r'\\kactlimport\{[^}]+\.h\}', p.read_text()))
                     for p in (root/'content').glob('*/chapter.tex'))
assert current_active == active+2 == 88
result = {
    'source_archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'all_D_file_paths_retained': len(old_paths),
    'preexisting_header_implementations_byte_identical': old_headers,
    'D_active_headers_preserved': active,
    'E_active_headers': current_active,
    'changed_content_files': sorted(changed), 'added_content_files': sorted(added),
    'global_theme_and_other_chapters_byte_identical': True,
    'various_old_content_preserved_except_insertion': True,
}
(root/'validation/notebookE/preservation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
