/**
 * Author: jet notebook
 * Summary: Contar escolhas em que a ordem não importa.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Escolher 3 de 8 alunos: 56 equipas; a ordem não importa.
 *  binom(n,k) devolve a contagem exata para k de n objetos distintos.
 *  Os objetos são distintos mesmo que tenham valores iguais.
 *  \item n>=0; k fora de [0,n] dá 0. Resultado ll por omissão;
 *  binom<cpp\_int>(n,k) permite respostas enormes. O resultado tem de caber
 *  em T; cancela denominadores antes de multiplicar.
 *  \item $O(r\log(n+1))$, r=min(k,n-k); inteiros grandes custam mais.
 *  \end{itemize}
 * Usage: ll teams = binom(8,3);
 *  assert(teams == 56);
 *  assert(binom(8,0) == 1 && binom(8,9) == 0);
 */
#pragma once

template<class T = ll> T binom(ll n, ll k) {
	assert(n >= 0);
	if (k < 0 || k > n) return T(0);
	k = min(k, n-k);
	T ans = 1;
	for (ll i = 1; i <= k; ++i) {
		ll a = n-k+i, b = i, g = gcd(a,b);
		a /= g; b /= g;
		ans = T(ans / b * a);
	}
	return ans;
}
