/**
 * Author: jet notebook
 * Summary: Encontrar ciclos numa permutação.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Repetir \{1,2,0,4,3\} repõe tudo após lcm(3,2)=6 aplicações.
 *  Os ciclos também determinam trocas/paridade.
 *  \item Passa uma permutação p de [0,n), onde i vai para p[i].
 *  Devolve tamanhos dos ciclos disjuntos, sem ordem garantida; ponto fixo
 *  vale 1. p vazio dá vazio. Um ciclo contém posições que rodam entre si.
 *  \item Visita cada índice uma vez: tempo/espaço O(n).
 *  \end{itemize}
 * Usage: vi p{1,2,0,4,3};
 *  auto len = cycleLengths(p);
 *  ll period = 1;
 *  for (int k : len) period = lcm(period,ll(k));
 *  assert(period == 6);
 *  assert(sz(p)-sz(len) == 3); // mínimo de trocas quaisquer
 */
#pragma once

vi cycleLengths(const vi& p) {
	vi len, vis(sz(p));
	for (int i = 0; i < sz(p); ++i) if (!vis[i]) {
		int j = i, k = 0;
		do {
			vis[j] = 1; ++k;
			j = p[j];
		} while (j != i);
		len.push_back(k);
	}
	return len;
}
