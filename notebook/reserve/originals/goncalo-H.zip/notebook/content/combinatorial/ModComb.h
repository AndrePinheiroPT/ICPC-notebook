/**
 * Author: jet notebook
 * Summary: Contar muitas combinações módulo um primo.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Muitas consultas de equipas com até 100 alunos.
 *  Pré-calcula uma vez; p.ex. escolher 3 de 100 módulo um primo.
 *  \item Constrói com lim,prime: $0\le n<lim$, $1\le lim\le prime$.
 *  choose(n,k) devolve a contagem módulo p; k inválido dá 0. p tem de ser primo.
 *  \item fact[i] guarda i!, invfact[i] o inverso, ambos módulo p.
 *  Reutiliza o objeto. O tipo do módulo (inteiro até 64 bits) é inferido de prime.
 *  \item Construção O(lim+log p), espaço O(lim); consulta O(1).
 *  \end{itemize}
 * Usage: ModComb c(101,1000000007LL);
 *  ll ways = c.choose(100,3);
 *  assert(ways == 161700);
 *  assert(c.choose(5,2) == 10); // reutiliza o pré-processamento
 */
#pragma once
#include "../numerical/ModPower.h"

template<class T = ll> struct ModComb {
	T p;
	vector<T> fact, invfact;
	ModComb(int lim, T prime)
		: p(prime), fact(lim), invfact(lim) {
		assert(p >= 2 && 1 <= lim && T(lim) <= p);
		fact[0] = 1;
		for (int i = 1; i < lim; ++i)
			fact[i] = modMul(fact[i-1], T(i), p);
		invfact[lim-1] = modPow(fact[lim-1], ull(p-2), p);
		for (int i = lim-1; i > 0; --i)
			invfact[i-1] = modMul(invfact[i], T(i), p);
	}
	T choose(ll n, ll k) const {
		assert(0 <= n && n < sz(fact));
		if (k < 0 || k > n) return T(0);
		T ans = modMul(fact[n], invfact[k], p);
		return modMul(ans, invfact[n-k], p);
	}
};
