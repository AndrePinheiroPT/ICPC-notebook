/**
 * Author: jet notebook
 * Summary: Resolver equações lineares módulo um primo.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Módulo 7, $2x+y=5$, $x-y=1$ dão x=2,y=1.
 *  Aqui a aritmética modular é exata.
 *  \item Passa a,m,x,p, com p PRIMO e $2\le p\le$ INT\_MAX.
 *  Linhas com m coeficientes e termo independente. Copia a, normaliza
 *  entradas int e guarda uma solução x em $[0,p)$.
 *  \item Devolve rank: -1 impossível, m única; restantes variáveis livres a zero.
 *  where[c] indica a linha pivot, -1 se livre. Inverte o pivot para ficar 1
 *  e elimina-o das outras linhas.
 *  \item Tempo $O(nm\min(n,m)+\min(n,m)\log p)$; cópia ocupa $O(nm)$.
 *  \end{itemize}
 * Usage: vector<vi> a{{2,1,5},{1,-1,1}};
 *  vi x;
 *  int rank = gaussMod(a,2,x,7);
 *  assert(rank == 2 && (x == vi{2,1}));
 */
#pragma once
#include "ModPower.h"

int gaussMod(vector<vector<int>> a, int m,
		vector<int>& x, int p) {
	assert(m >= 0 && p >= 2);
	int n = sz(a), rank = 0;
	vi where(m,-1);
	x.assign(m, 0);
	for (auto& row : a) {
		assert(sz(row) == m+1);
		for (int& v : row) {
			v %= p;
			if (v < 0) v += p;
		}
	}
	for (int c = 0; c < m && rank < n; ++c) {
		int pivot = rank;
		while (pivot < n && !a[pivot][c]) ++pivot;
		if (pivot == n) continue;
		swap(a[rank], a[pivot]);
		where[c] = rank;
		ll inv = modPow(a[rank][c], p-2, p);
		for (int j = c; j <= m; ++j)
			a[rank][j] = int(a[rank][j] * inv % p);
		for (int i = 0; i < n; ++i) if (i != rank) {
			int factor = a[i][c];
			a[i][c] = 0;
			for (int j = c+1; j <= m; ++j)
				a[i][j] = int((a[i][j]
					- ll(factor)*a[rank][j]%p + p)%p);
		}
		++rank;
	}
	for (int i = rank; i < n; ++i)
		if (a[i][m]) return -1;
	for (int c = 0; c < m; ++c)
		if (where[c] != -1) x[c] = a[where[c]][m];
	return rank;
}
