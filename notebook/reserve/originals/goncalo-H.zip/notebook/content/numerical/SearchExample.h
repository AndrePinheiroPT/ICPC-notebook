/**
 * Author: Team reference
 * Summary: Minimizar a maior soma de grupos consecutivos.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Divide tamanhos não negativos a em até k grupos
 *  consecutivos não vazios. Para \{2,1,3,2\}, k=2, os grupos
 *  \{2,1\} e \{3,2\} dão 5.
 *  \item Passa a não vazio, k>=1, total(a)<LLONG\_MAX.
 *  Devolve a maior soma ótima, sem os limites dos grupos.
 *  \item check(cap) preenche grupos de forma greedy; aumentar a capacidade
 *  nunca exige mais grupos. Limite direito total+1 inclui total.
 *  \item Tempo $O(n\log(total-max(a)+2))$, espaço extra $O(1)$.
 *  \end{itemize}
 * Usage: vector<ll> jobs{2,1,3,2};
 *  ll cap = minGroupCapacity(jobs,2);
 *  assert(cap == 5); // [2,1] e [3,2]
 */
#pragma once
#include "BinarySearch.h"

ll minGroupCapacity(const vector<ll>& a, int k) {
	assert(!a.empty() && k >= 1);
	ll lo = 0, total = 0;
	for (ll x : a) {
		assert(x >= 0 && x < LLONG_MAX-total);
		lo = max(lo,x); total += x;
	}
	auto check = [&](ll cap) {
		int groups = 1;
		ll sum = 0;
		for (ll x : a) {
			if (x > cap-sum) {
				++groups; sum = x;
			} else sum += x;
		}
		return groups <= k;
	};
	return *firstTrue(lo,total+1,check);
}
