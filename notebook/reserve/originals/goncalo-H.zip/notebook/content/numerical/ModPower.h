/**
 * Author: Noam527; jet notebook (genérico, aritmética segura)
 * Summary: Calcular potências e produtos módulo um número.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Contar strings binárias de tamanho 10 módulo 7: $2^{10}\bmod7=2$.
 *  Também serve para inversos com módulo primo. O módulo guarda o resto,
 *  não o número grande completo.
 *  \item modPow(b,e,m) devolve $b^e\bmod m$; e>=0, m>0, b com sinal
 *  pode ser negativo. modMul(a,b,m) multiplica resíduos $0\le a,b<m$
 *  e devolve um valor em $[0,m)$.
 *  \item T inteiro até 64 bits; b,m do mesmo tipo. Produtos usam 128 bits.
 *  Produto $O(1)$, potência $O(\log(e+1))$; espaço $O(1)$.
 *  \end{itemize}
 * Usage: int n = 10;
 *  ll ways = modPow(2LL,n,7LL);
 *  assert(ways == 2);
 *  assert(modMul(5LL,6LL,7LL) == 2);
 */
#pragma once

using ull = unsigned long long;

template<class T> T modMul(T a, T b, T m) {
	return T((__uint128_t)a * b % m);
}
template<class T> T modPow(T b, ull e, T m) {
	T ans = 1 % m;
	b %= m;
	if (b < 0) b += m;
	while (e > 0) {
		if (e & 1) ans = modMul(ans,b,m);
		b = modMul(b,b,m);
		e /= 2;
	}
	return ans;
}
