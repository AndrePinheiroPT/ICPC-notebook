/**
 * Author: jet notebook
 * Summary: Aproximar o menor valor real válido.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Um quadrado precisa de área pelo menos 2: encontrar o lado $\sqrt 2$.
 *  Aumentar o lado mantém a condição válida.
 *  \item Passa reais finitos l<r, com f(l)=false e f(r)=true.
 *  f só pode mudar de false para true. Devolve uma aproximação do limite
 *  pelo lado true, não o valor de f. Os extremos aproximam-se.
 *  \item T é real; k>=0 iterações. $O(k)$ chamadas, espaço $O(1)$.
 *  A largura reduz para metade até a precisão impedir o avanço.
 *  \end{itemize}
 * Usage: double side = bisect(0.,2.,[](double t) {
 *      return t*t >= 2; });
 *  assert(side*side >= 2);
 *  assert(abs(side-sqrt(2.)) < 1e-12);
 */
#pragma once

template<class T, class F>
T bisect(T l, T r, F f, int k = 100) {
	static_assert(is_floating_point_v<T>);
	assert(l < r && k >= 0);
	while (k--) {
		T m = l < 0 && r > 0 ? (l+r)/2
			: l+(r-l)/2;
		if (m == l || m == r) break;
		if (f(m)) r = m;
		else l = m;
	}
	return r;
}
