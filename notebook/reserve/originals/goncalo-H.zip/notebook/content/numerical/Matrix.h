/**
 * Author: zyndek; adapted for the notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use a small state-transition matrix to skip
 *  many steps of a recurrence or count walks of length e.
 *  Pass square n*n matrices of residues in $[0,mod)$.
 *  matMul(a,b,mod) returns their product; matPow(a,e,mod)
 *  returns $a^e$ (identity for e=0). Inputs stay unchanged.
 *  \item Integer T up to 64 bits, mod>=1, e>=0;
 *  128-bit products prevent overflow. For ordinary
 *  arithmetic remove reductions; all arithmetic must fit T.
 *  \item Product $O(n^3)$, power $O(n^3\log(e+1))$;
 *  extra space $O(n^2)$.
 *  \end{itemize}
 * Usage: vector<vector<ll>> a{{1,1},{1,0}};
 *  auto b = matPow(a,k,1000000007LL); // b[0][1]=F_k
 */
#pragma once

template<class T>
vector<vector<T>> matMul(const vector<vector<T>>& a,
		const vector<vector<T>>& b, T mod) {
	static_assert(is_integral_v<T> && sizeof(T) <= 8);
	assert(mod >= 1 && sz(a) == sz(b));
	int n = sz(a);
	for (int i = 0; i < n; ++i) {
		assert(sz(a[i]) == n && sz(b[i]) == n);
		for (int j = 0; j < n; ++j) {
			assert(a[i][j] >= 0 && a[i][j] < mod);
			assert(b[i][j] >= 0 && b[i][j] < mod);
		}
	}
	vector<vector<T>> c(n,vector<T>(n));
	for (int i = 0; i < n; ++i)
		for (int k = 0; k < n; ++k)
			for (int j = 0; j < n; ++j)
				c[i][j] = T((c[i][j] + (__uint128_t)
					a[i][k]*b[k][j]) % mod);
	return c;
}
template<class T>
vector<vector<T>> matPow(vector<vector<T>> a,
		ll e, T mod) {
	assert(e >= 0 && mod >= 1);
	int n = sz(a);
	vector<vector<T>> r(n,vector<T>(n));
	for (int i = 0; i < n; ++i) r[i][i] = T(1)%mod;
	while (e) {
		if (e&1) r = matMul(r,a,mod);
		e /= 2;
		if (e) a = matMul(a,a,mod);
	}
	return r;
}
