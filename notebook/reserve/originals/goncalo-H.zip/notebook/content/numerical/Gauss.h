/**
 * Author: jet notebook
 * Summary: Resolver equações lineares com números reais.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Preços com $2x+y=5$, $x-y=1$: obter x=2,y=1.
 *  Cada linha tem m coeficientes e termo independente, p.ex. \{2,1,5\}.
 *  Cada coluna é uma incógnita, na ordem de x.
 *  \item Passa a,m,x para equações reais lineares (p.ex. esperanças).
 *  Altera a; guarda uma solução aproximada em x. Devolve rank:
 *  -1 impossível, m única; senão, variáveis livres a zero.
 *  \item pivot escolhe um coeficiente grande; elimina e resolve de trás
 *  para a frente. T real, entradas/intermédios finitos; eps>0 é tolerância
 *  absoluta, pelo que a escala importa.
 *  \item Tempo $O(nm\min(n,m))$, espaço extra $O(m)$.
 *  \end{itemize}
 * Usage: vector<vector<double>> a{{2,1,5},{1,-1,1}};
 *  vector<double> x;
 *  int rank = gauss(a,2,x);
 *  assert(rank == 2);
 *  assert(abs(x[0]-2) < 1e-9 && abs(x[1]-1) < 1e-9);
 */
#pragma once

template<class T>
int gauss(vector<vector<T>>& a, int m,
		vector<T>& x, T eps = T(1e-12L)) {
	static_assert(is_floating_point_v<T>);
	assert(m >= 0 && eps > 0);
	int n = sz(a), rank = 0;
	vi col;
	x.assign(m, T{});
	for (auto& row : a) assert(sz(row) == m+1);
	for (int c = 0; c < m && rank < n; ++c) {
		int pivot = rank;
		for (int i = rank+1; i < n; ++i)
			if (abs(a[i][c]) > abs(a[pivot][c])) pivot = i;
		if (abs(a[pivot][c]) <= eps) continue;
		swap(a[rank], a[pivot]);
		for (int i = rank+1; i < n; ++i) {
			T factor = a[i][c] / a[rank][c];
			a[i][c] = 0;
			for (int j = c+1; j <= m; ++j)
				a[i][j] -= factor * a[rank][j];
		}
		col.push_back(c);
		++rank;
	}
	for (int i = rank; i < n; ++i)
		if (abs(a[i][m]) > eps) return -1;
	for (int i = rank-1; i >= 0; --i) {
		int c = col[i];
		T value = a[i][m];
		for (int j = c+1; j < m; ++j)
			value -= a[i][j] * x[j];
		x[c] = value / a[i][c];
	}
	return rank;
}
