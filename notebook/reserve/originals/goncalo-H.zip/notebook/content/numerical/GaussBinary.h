/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use for equations made of XORs, e.g. switches
 *  or parity. a[i][j]=1 means equation i uses variable j;
 *  a[i][m] is its required RHS bit. Pass rows a,m,x;
 *  choose bitset<K> with K>m. a is modified.
 *  \item Returns rank: -1 impossible, m unique;
 *  otherwise x is one 0/1 solution with free variables 0.
 *  col records pivot variables; XOR eliminates a variable.
 *  \item Time $O(nm\lceil K/w\rceil)$ for word size w;
 *  extra space $O(m+K/w)$, besides the bitset rows.
 *  \end{itemize}
 * Usage: vector<bitset<501>> a(n); vi x;
 *  int rank = gaussBinary(a,m,x); // fill a first
 */
#pragma once

template<size_t K>
int gaussBinary(vector<bitset<K>>& a, int m, vi& x) {
	assert(0 <= m && size_t(m) < K);
	int n = sz(a), rank = 0;
	vi col;
	x.assign(m,0);
	for (int c = 0; c < m && rank < n; ++c) {
		int pivot = rank;
		while (pivot < n && !a[pivot][c]) ++pivot;
		if (pivot == n) continue;
		swap(a[pivot],a[rank]);
		for (int i = 0; i < n; ++i)
			if (i != rank && a[i][c]) a[i] ^= a[rank];
		col.push_back(c); ++rank;
	}
	for (int i = rank; i < n; ++i)
		if (a[i][m]) return -1;
	for (int i = 0; i < rank; ++i) x[col[i]] = a[i][m];
	return rank;
}
