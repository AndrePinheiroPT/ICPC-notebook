/**
 * Author: zyndek; adaptado ao notebook
 * Summary: Encontrar o primeiro ou último inteiro válido.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Máquinas produzem uma peça a cada 2 e 3 minutos.
 *  O primeiro instante em $[0,11)$ com 5 peças é 6.
 *  \item Passa os candidatos $[l,r)$ e check(x), que testa se x serve.
 *  firstTrue exige false seguido de true; lastTrue, true seguido de false.
 *  \item Devolve optional: testa if(ans), depois lê *ans.
 *  nullopt indica ausência, incluindo l==r. check só recebe candidatos válidos.
 *  O ponto médio usa 128 bits para evitar overflow de ll; F é o tipo da função.
 *  \item $O(\log(r-l+1))$ chamadas a check, espaço $O(1)$.
 *  \end{itemize}
 * Usage: auto fits = [](ll t) { return t/2+t/3 >= 5; };
 *  auto ans = firstTrue(0,11,fits);
 *  assert(ans && *ans == 6);
 *  assert(!firstTrue(0,6,fits)); // sem resposta em [0,6)
 *  auto last = lastTrue(0,11,[](ll x) { return x/2+x/3 <= 4; });
 *  assert(last && *last == 5);
 */
#pragma once

template<class F>
optional<ll> firstTrue(ll l, ll r, F check) {
	assert(l <= r);
	ll end = r;
	while (l < r) {
		ll m = ll((__int128)l + ((__int128)r-l)/2);
		if (check(m)) r = m;
		else l = m+1;
	}
	if (l == end) return nullopt;
	return l;
}
template<class F>
optional<ll> lastTrue(ll l, ll r, F check) {
	assert(l <= r);
	ll begin = l;
	while (l < r) {
		ll m = ll((__int128)l + ((__int128)r-l)/2);
		if (check(m)) l = m+1;
		else r = m;
	}
	if (l == begin) return nullopt;
	return l-1;
}
