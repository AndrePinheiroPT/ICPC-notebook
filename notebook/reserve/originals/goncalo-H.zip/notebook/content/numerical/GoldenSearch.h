/**
 * Author: jet notebook, based on KACTL
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use to minimize a real function which falls
 *  then rises on $[l,r]$; no flat parts except at minima.
 *  Pass endpoints and f(x); result is x, not f(x).
 *  Golden search reuses evaluations when f is expensive.
 *  between(t) safely picks a point inside the interval.
 *  \item Floating T; finite endpoints/values, l<=r,
 *  k>=0. $O(k)$ calls, $O(1)$ space; width shrinks by
 *  $((\sqrt5-1)/2)^k$, limited by floating-point precision.
 *  \end{itemize}
 * Usage: double x = gss(-5.,5.,[](double t) {
 *    return (t-2)*(t-2); }); // x near 2
 */
#pragma once

template<class T, class F>
T gss(T l, T r, F f, int k = 100) {
	static_assert(is_floating_point_v<T>);
	assert(l <= r && k >= 0);
	T ratio = (sqrt(T(5))-1)/2;
	auto between = [&](T t) {
		return l < 0 && r > 0 ? l*(1-t)+r*t
			: l+(r-l)*t;
	};
	T x = between(1-ratio), y = between(ratio);
	T fx = f(x), fy = f(y);
	while (k--) {
		if (!(l < x && x < y && y < r)) break;
		if (fx < fy) {
			r = y; y = x; fy = fx;
			x = between(1-ratio); fx = f(x);
		} else {
			l = x; x = y; fx = fy;
			y = between(ratio); fy = f(y);
		}
	}
	return l < 0 && r > 0 ? (l+r)/2 : l+(r-l)/2;
}
