/**
 * Author: jet notebook
 * Summary: Encontrar arestas e vértices críticos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: triângulo 0,1,2 com estrada extra 1--3.
 *   Que falhas de uma estrada/cidade o desligam?
 *   \item Entrada: n vértices, arestas não dirigidas e[i]=(u,v).
 *   bridges contém IDs críticos; cut[v]=1 marca um vértice
 *   cuja remoção divide a sua componente.
 *   Aceita lacetes e arestas paralelas.
 *   \item tin é o instante de visita; low é a visita mais antiga
 *   alcançável descendo na árvore DFS e usando até uma aresta de retorno.
 *   pe é o ID da aresta-pai; raízes têm pai -1.
 *   DFS iterativo; tempo e espaço $O(n+m)$.
 *   \end{itemize}
 * Usage: vector<pair<int,int>> edges{
 *       {0,1},{1,2},{2,0},{1,3}};
 *   Lowlink b(4,edges);
 *   // b.bridges={3}; b.cut={0,1,0,0}
 */
#pragma once

struct Lowlink {
	vi bridges, cut;
	Lowlink(int n, const vector<pair<int,int>>& e)
		: cut(n) {
		vector<vector<pair<int,int>>> g(n);
		for (int i = 0; i < sz(e); ++i) {
			auto [u,v] = e[i];
			g[u].push_back({v,i});
			g[v].push_back({u,i});
		}
		vi tin(n,-1), low(n), par(n,-1), pe(n,-1);
		vi it(n), child(n), st;
		int timer = 0;
		for (int s = 0; s < n; ++s) if (tin[s] < 0) {
			tin[s] = low[s] = timer++;
			st.push_back(s);
			while (!st.empty()) {
				int v = st.back();
				if (it[v] < sz(g[v])) {
					auto [u,id] = g[v][it[v]++];
					if (id == pe[v]) continue;
					if (tin[u] < 0) {
						par[u] = v; pe[u] = id; ++child[v];
						tin[u] = low[u] = timer++;
						st.push_back(u);
					} else low[v] = min(low[v],tin[u]);
				} else {
					st.pop_back();
					int p = par[v];
					if (p < 0) cut[v] = child[v] > 1;
					else {
						low[p] = min(low[p],low[v]);
						if (low[v] > tin[p])
							bridges.push_back(pe[v]);
						if (par[p] >= 0 && low[v] >= tin[p])
							cut[p] = 1;
					}
				}
			}
		}
	}
};
