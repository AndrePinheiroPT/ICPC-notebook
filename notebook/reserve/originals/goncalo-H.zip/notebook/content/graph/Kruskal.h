/**
 * Author: jet notebook
 * Summary: Ligar vértices com custo total mínimo
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: cabos 0--1, 1--2, 0--2 custam 4,2,9.
 *   Ligar os três locais pelo menor custo.
 *   \item n vértices; e[i]=(u,v,peso) é uma aresta não dirigida.
 *   Devolve (cost,ids); IDs das arestas escolhidas indexam e.
 *   \item Entrada desconexa dá uma árvore por componente;
 *   número de componentes = n-ids.size(). Aceita pesos negativos.
 *   T é inferido dos pesos; somas devem caber em T.
 *   Tempo $O(V+E\log(E+1))$, espaço $O(V+E)$.
 *   \end{itemize}
 * Usage: vector<tuple<int,int,ll>> edges{
 *       {0,1,4},{1,2,2},{0,2,9}};
 *   auto [cost,ids] = kruskal(3,edges); // 6; IDs {1,0}
 *   bool connected = sz(ids)==2; // n-1 arestas escolhidas
 */
#pragma once
#include "../data-structures/UnionFind.h"

template<class T>
pair<T,vi> kruskal(int n,
		const vector<tuple<int,int,T>>& e) {
	vi ord(sz(e)), ids;
	iota(ord.begin(),ord.end(),0);
	sort(ord.begin(),ord.end(),[&](int a,int b) {
		return get<2>(e[a]) < get<2>(e[b]);
	});
	UF uf(n);
	T cost = 0;
	for (int i : ord) {
		auto [u,v,w] = e[i];
		if (uf.join(u,v)) {
			cost += w; ids.push_back(i);
		}
	}
	return {cost,ids};
}
