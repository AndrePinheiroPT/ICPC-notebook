/**
 * Author: jet notebook
 * Summary: Percorrer cada aresta uma única vez
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: inspecionar 0--1 e 1--2 uma vez desde 0.
 *   Devolver cidades e IDs das estradas por ordem.
 *   \item IDs $[0,n)$; e[i]=(u,v) é a aresta i.
 *   Passar cada aresta não dirigida UMA vez; directed=true se dirigida.
 *   Vértices podem repetir: não é caminho mínimo
 *   nem uma visita a cada vértice.
 *   \item Devolve (vertices,edgeIDs) por ordem do percurso:
 *   m+1 vértices e m IDs. Par vazio: impossível desde src;
 *   sem arestas: (\{src\},\{\}). Não altera a entrada.
 *   Aceita lacetes/paralelas; n=0 falha.
 *   \item Escolher src pelas regras de graus do guia;
 *   circuito não vazio começa num vértice com aresta.
 *   used evita repetições; st constrói o percurso.
 *   O total de arestas verifica a conexão.
 *   Tempo/espaço $O(n+m)$; iterativo.
 *   \end{itemize}
 * Usage: vector<pair<int,int>> e{{0,1},{1,2}};
 *   auto [v,ids] = eulerTrail(3,e,0,false);
 *   // v={0,1,2}, ids={0,1}
 */
#pragma once

pair<vi,vi> eulerTrail(int n,
		const vector<pair<int,int>>& e,
		int src, bool directed) {
	if (src < 0 || src >= n) return {};
	vector<vector<pair<int,int>>> g(n);
	vi deg(n);
	for (int i = 0; i < sz(e); ++i) {
		auto [u,v] = e[i];
		g[u].push_back({v,i}); ++deg[u];
		if (directed) --deg[v];
		else g[v].push_back({u,i}), ++deg[v];
	}
	int pos = 0, neg = 0;
	for (int v = 0; v < n; ++v) {
		if (directed) {
			if (deg[v] == 1 && v == src) ++pos;
			else if (deg[v] == -1) ++neg;
			else if (deg[v]) return {};
		} else pos += deg[v]&1;
	}
	if (directed && pos != neg) return {};
	if (!directed && pos &&
			(pos != 2 || !(deg[src]&1))) return {};
	vi it(n), used(sz(e)), path, ids;
	vector<pair<int,int>> st{{src,-1}};
	while (!st.empty()) {
		auto [v,id] = st.back();
		while (it[v] < sz(g[v]) &&
				used[g[v][it[v]].second]) ++it[v];
		if (it[v] == sz(g[v])) {
			path.push_back(v);
			if (id >= 0) ids.push_back(id);
			st.pop_back();
		} else {
			auto [u,k] = g[v][it[v]++];
			used[k] = 1; st.push_back({u,k});
		}
	}
	if (sz(ids) != sz(e)) return {};
	reverse(path.begin(),path.end());
	reverse(ids.begin(),ids.end());
	return {move(path),move(ids)};
}
