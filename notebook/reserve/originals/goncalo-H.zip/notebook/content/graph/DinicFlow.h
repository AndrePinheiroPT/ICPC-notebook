/**
 * Author: jet notebook
 * Summary: Enviar fluxo máximo com capacidades limitadas
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: tubos 0 para 1 e 1 para 2 suportam 5 e 3 unidades.
 *   Quanto chega a 2?
 *   \item Vértices $[0,n)$; s fornece, t recebe.
 *   add(u,v,cap) é dirigido; cap limita unidades, não distância.
 *   flow(s,t) devolve unidades adicionais, não os caminhos.
 *   \item Altera g: cap passa a capacidade restante;
 *   rev indexa a aresta inversa em g[to], que desfaz escolhas anteriores.
 *   add cria-a automaticamente. Numa aresta original guardada,
 *   fluxo líquido = capacidade original C menos cap restante.
 *   \item Após flow, lev[v]>=0 marca o lado de s num corte mínimo.
 *   lev é o nível BFS; it[u] é a próxima aresta a tentar no DFS.
 *   Chamadas repetidas continuam a rede residual;
 *   reconstruir para casos independentes.
 *   \item IDs válidos, $s\ne t$, capacidades >=0, total cabe em ll.
 *   Tempo $O(V^2E)$, espaço $O(V+E)$; profundidade DFS $O(V)$.
 *   \end{itemize}
 * Usage: DinicFlow f(3);
 *   f.add(0,1,5); f.add(1,2,3);
 *   ll sent = f.flow(0,2); // 3; segunda chamada envia 0
 */
#pragma once

struct DinicFlow {
	struct Edge { int to, rev; ll cap; };
	vector<vector<Edge>> g;
	vi lev, it;
	DinicFlow(int n) : g(n), lev(n), it(n) {}
	void add(int u, int v, ll cap) {
		assert(cap >= 0);
		int a = sz(g[u]), b = sz(g[v]);
		g[u].push_back({v,b+(u==v),cap});
		g[v].push_back({u,a,0});
	}
	bool bfs(int s, int t) {
		fill(lev.begin(), lev.end(), -1);
		queue<int> q;
		q.push(s); lev[s] = 0;
		while (!q.empty()) {
			int u = q.front(); q.pop();
			for (auto e : g[u])
				if (e.cap > 0 && lev[e.to] < 0) {
					lev[e.to] = lev[u]+1;
					q.push(e.to);
				}
		}
		return lev[t] >= 0;
	}
	ll dfs(int u, int t, ll f) {
		if (u == t) return f;
		for (int& i = it[u]; i < sz(g[u]); ++i) {
			auto& e = g[u][i];
			if (e.cap <= 0 || lev[e.to] != lev[u]+1)
				continue;
			ll sent = dfs(e.to, t, min(f,e.cap));
			if (sent > 0) {
				e.cap -= sent; g[e.to][e.rev].cap += sent;
				return sent;
			}
		}
		return 0;
	}
	ll flow(int s, int t) {
		assert(0 <= s && s < sz(g));
		assert(0 <= t && t < sz(g) && s != t);
		ll ans = 0;
		while (bfs(s,t)) {
			fill(it.begin(), it.end(), 0);
			while (ll sent = dfs(s,t,
					LLONG_MAX)) ans += sent;
		}
		return ans;
	}
};
