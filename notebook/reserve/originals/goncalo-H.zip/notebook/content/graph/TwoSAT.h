/**
 * Author: jet notebook
 * Summary: Encontrar escolhas binárias válidas
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: exatamente uma máquina de reserva deve ligar;
 *   a máquina 0 é obrigatória. Encontrar uma escolha válida.
 *   \item TwoSAT(n); variáveis $[0,n)$, literais $[0,2n)$.
 *   Literal 2*v é verdadeiro, 2*v+1 é falso.
 *   Negar com xor 1, não com menos unário.
 *   Cada restrição deve ser um OR de até dois literais.
 *   \item either(a,b) exige a OR b; either(a,a) força a.
 *   Adiciona not-a -> b e not-b -> a ao grafo de implicações g.
 *   solve() devolve false se impossível; só após true ler answer[v] (0/1).
 *   É uma solução, não uma contagem nem o máximo de verdadeiros.
 *   Adicionar cláusulas e voltar a resolver recalcula a resposta.
 *   \item Literal e negação na mesma SCC indicam contradição.
 *   Cláusulas de 3+ literais não são suportadas;
 *   ver restrições comuns no guia.
 *   \item solve: tempo/espaço $O(n+m)$, m cláusulas;
 *   cada either custa $O(1)$ amortizado.
 *   \end{itemize}
 * Usage: TwoSAT sat(2); // variáveis 0 e 1
 *   sat.either(0,2); sat.either(1,3); // exatamente uma
 *   sat.either(0,0); // forçar variável 0 a true
 *   bool ok = sat.solve(); // true; answer = {1,0}
 */
#pragma once
#include "StrongComponents.h"

struct TwoSAT {
	vector<vi> g;
	vi answer;
	TwoSAT(int n) : g(2*n) {}
	void either(int a, int b) {
		g[a^1].push_back(b);
		g[b^1].push_back(a);
	}
	bool solve() {
		vi comp = kosaraju(g);
		answer.resize(sz(g)/2);
		for (int v = 0; v < sz(answer); ++v) {
			int a = comp[2*v], b = comp[2*v+1];
			if (a == b) return false;
			answer[v] = a > b;
		}
		return true;
	}
};
