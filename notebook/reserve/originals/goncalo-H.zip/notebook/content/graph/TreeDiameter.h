/**
 * Author: jet notebook
 * Summary: Encontrar o par de vértices mais afastados
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: estradas $0-1-2$ têm comprimentos 4 e 2.
 *   Encontrar as cidades mais afastadas e a sua distância.
 *   \item g[u] contém (v,peso) numa árvore não dirigida.
 *   Pesos não negativos; usar 1 em arestas sem peso.
 *   \item Devolve (length,a,b), com extremos a,b.
 *   Entrada vazia dá (0,-1,-1); extremos podem coincidir.
 *   far(s) encontra o vértice mais afastado; repetir a partir dele.
 *   \item T é inferido dos pesos; somas de caminhos cabem em T.
 *   Tempo e espaço $O(n)$; sem DFS recursivo.
 *   \end{itemize}
 * Usage: vector<vector<pair<int,ll>>> g{
 *       {{1,4}},{{0,4},{2,2}},{{1,2}}};
 *   auto [length,a,b] = treeDiameter(g); // 6, 2, 0
 */
#pragma once

template<class T>
tuple<T,int,int> treeDiameter(
		const vector<vector<pair<int,T>>>& g) {
	int n = sz(g);
	if (!n) return {T{},-1,-1};
	auto far = [&](int s) {
		vector<T> d(n);
		vi par(n,-1), q{s};
		int best = s;
		for (int i = 0; i < sz(q); ++i) {
			int v = q[i];
			if (d[v] > d[best]) best = v;
			for (auto [u,w] : g[v]) if (u != par[v]) {
				par[u] = v; d[u] = d[v]+w;
				q.push_back(u);
			}
		}
		return pair{best,d[best]};
	};
	int a = far(0).first;
	auto [b,d] = far(a);
	return {d,a,b};
}
