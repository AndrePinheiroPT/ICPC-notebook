/**
 * Author: jet notebook
 * Summary: Enviar unidades ao menor custo com capacidades
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: enviar duas caixas por troços de preço 3 e 1
 *   por caixa, ambos de capacidade 2. Minimizar a conta.
 *   \item add(u,v,cap,cost): aresta dirigida, máximo cap unidades,
 *   custo por unidade cost. s fornece, t recebe.
 *   flow(s,t,lim) maximiza unidades adicionais até lim,
 *   depois minimiza o custo. Devolve (sent,totalCost);
 *   para exatamente k unidades, passar k e verificar sent==k.
 *   \item Altera capacidades residuais em g. rev indexa a aresta
 *   inversa em g[to], com custo oposto. Chamadas repetidas
 *   continuam a rede; resultados são incrementais.
 *   h ajusta custos de Dijkstra; pv[v]/pe[v] guardam
 *   vértice/índice da aresta anterior. Cada chamada refaz h.
 *   Aceita arestas negativas; nenhum ciclo residual negativo é permitido.
 *   \item IDs $[0,n)$ válidos, $s\ne t$, lim>=0;
 *   capacidades inteiras >=0, somas/produtos cabem em ll.
 *   Custos/distâncias/potenciais têm módulo <INF.
 *   Tempo $O(V+VE+A(E+V)\log(V+E+1))$, A aumentações;
 *   espaço $O(V+E)$.
 *   \end{itemize}
 * Usage: MinCostFlow f(3);
 *   f.add(0,1,2,3); f.add(1,2,2,1);
 *   auto [sent,cost] = f.flow(0,2,2); // (2,8)
 */
#pragma once

struct MinCostFlow {
	struct Edge { int to, rev; ll cap, cost; };
	const ll INF = LLONG_MAX/4;
	vector<vector<Edge>> g;
	MinCostFlow(int n) : g(n) {}
	void add(int u, int v, ll cap, ll cost) {
		assert(cap >= 0 && -INF < cost && cost < INF);
		int a = sz(g[u]), b = sz(g[v]);
		g[u].push_back({v,b+(u==v),cap,cost});
		g[v].push_back({u,a,0,-cost});
	}
	pair<ll,ll> flow(int s, int t,
		ll lim = LLONG_MAX) {
		int n = sz(g);
		assert(0 <= s && s < n && 0 <= t && t < n);
		assert(s != t && lim >= 0);
		vector<ll> h(n), d(n);
		vi pv(n,-1), pe(n,-1);
		for (int k = 0; k < n; ++k) {
			bool change = false;
			for (int u = 0; u < n; ++u)
				for (auto e : g[u]) if (e.cap > 0)
					if (h[u]+e.cost < h[e.to]) {
						h[e.to] = h[u]+e.cost;
						change = true;
					}
			if (!change) break;
			assert(k+1 < n); // Sem ciclo negativo.
		}
		ll sent = 0, totalCost = 0;
		while (sent < lim) {
			fill(d.begin(), d.end(), INF);
			priority_queue<pair<ll,int>,
				vector<pair<ll,int>>,
				greater<pair<ll,int>>> q;
			d[s] = 0; q.push({0,s});
			while (!q.empty()) {
				auto [du,u] = q.top(); q.pop();
				if (du != d[u]) continue;
				for (int i = 0; i < sz(g[u]); ++i) {
					auto e = g[u][i];
					if (e.cap <= 0) continue;
					ll reduced = du+e.cost+h[u]-h[e.to];
					if (reduced < d[e.to]) {
						d[e.to] = reduced;
						pv[e.to] = u; pe[e.to] = i;
						q.push({reduced,e.to});
					}
				}
			}
			if (d[t] == INF) break;
			for (int v = 0; v < n; ++v)
				if (d[v] < INF) h[v] += d[v];
			ll amount = lim-sent;
			for (int v = t; v != s; v = pv[v])
				amount = min(amount,g[pv[v]][pe[v]].cap);
			for (int v = t; v != s; v = pv[v]) {
				auto& e = g[pv[v]][pe[v]];
				e.cap -= amount;
				g[v][e.rev].cap += amount;
			}
			sent += amount; totalCost += amount*(h[t]-h[s]);
		}
		return {sent,totalCost};
	}
};
