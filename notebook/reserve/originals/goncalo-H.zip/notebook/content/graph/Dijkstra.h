/**
 * Author: jet notebook
 * Summary: Caminhos mínimos com custos não negativos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: estrada 0 para 1 custa 7.
 *   Calcular custos mínimos a partir de 0.
 *   \item vector<vector<pair<int,ll>>> g(n);
 *   g[u].push\_back(\{v,w\}) cria u -> v de custo w>=0.
 *   Adicionar o inverso se bidirecional. IDs $[0,n)$;
 *   s é a origem. Não altera a entrada.
 *   \item Devolve (dist,parent): dist[v] é o custo mínimo;
 *   inf indica inalcançável. parent[v] é o vértice anterior,
 *   -1 na origem/inalcançáveis. Custos finitos devem ser <inf;
 *   custos >=inf são tratados como inalcançáveis.
 *   A origem custa 0; somar a sua taxa à parte.
 *   Ver no guia como pôr taxas de entrada nas arestas.
 *   \item Heap de (distância,vértice); ignora entradas desatualizadas.
 *   Tempo $O((V+E)\log(V+E+1))$, espaço extra $O(V+E)$.
 *   \end{itemize}
 * Usage: vector<vector<pair<int,ll>>> g(2);
 *   g[0].push_back({1,7});
 *   auto [dist,parent] = dijkstra(g,0); // {0,7}
 *   // restorePath(0,1,parent) de Traversal.h
 */
#pragma once

pair<vector<ll>,vi> dijkstra(
		const vector<vector<pair<int,ll>>>& g,
		int s,
		ll inf = LLONG_MAX/4) {
	assert(0 <= s && s < sz(g) && inf > 0);
	vector<ll> dist(sz(g),inf);
	vi parent(sz(g),-1);
	using P = pair<ll,int>;
	priority_queue<P,vector<P>,greater<P>> pq;
	dist[s] = 0; pq.push({0,s});
	while (!pq.empty()) {
		auto [du,u] = pq.top(); pq.pop();
		if (du != dist[u]) continue;
		for (auto [v,w] : g[u]) {
			assert(w >= 0);
			if (w >= inf-du) continue;
			ll nd = du+w;
			if (nd < dist[v]) {
				dist[v] = nd; parent[v] = u;
				pq.push({nd,v});
			}
		}
	}
	return {dist,parent};
}
