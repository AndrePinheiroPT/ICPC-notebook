/**
 * Author: jet notebook
 * Summary: Encontrar ancestrais comuns e distâncias
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: 0 chefia 1, que chefia 2 e 3.
 *   Encontrar o chefe comum mais próximo e a distância entre ambos.
 *   \item g é uma árvore não dirigida; root define os pais.
 *   lca(a,b) é o ancestral comum mais próximo; dist(a,b) conta arestas.
 *   ancestor(v,k) é o k-ésimo pai, ou -1 se ausente.
 *   \item TreeTour fornece par/dep/tin/tout/ord; jt guarda saltos.
 *   Subir o vértice mais fundo, depois ambos.
 *   Construção vazia permitida; consultas exigem vértices válidos.
 *   Construção/espaço $O(n\log n)$; consultas $O(\log n)$.
 *   \end{itemize}
 * Usage: vector<vi> g{{1},{0,2,3},{1},{1}};
 *   TreeLCA t(g,0);
 *   int c=t.lca(2,3), d=t.dist(2,3); // 1, 2 arestas
 *   int up=t.ancestor(2,2); // 0; três passos dão -1
 */
#pragma once
#include "TreeTour.h"
#include "JumpTable.h"

struct TreeLCA : TreeTour {
	JumpTable jt;
	static int levels(int n) {
		int d = 1;
		for (ll on = 1; on < n; on *= 2) ++d;
		return d;
	}
	TreeLCA(const vector<vi>& g, int root = 0)
		: TreeTour(g,root), jt(par,levels(sz(g))) {}
	int ancestor(int v, ull k) const {
		return k > ull(dep[v]) ? -1 : jt.jump(v,k);
	}
	int lca(int a, int b) const {
		if (dep[a] < dep[b]) swap(a,b);
		a = jt.jump(a,ull(dep[a]-dep[b]));
		if (a == b) return a;
		for (int i = sz(jt.jmp); i--;) {
			int c = jt.jmp[i][a], d = jt.jmp[i][b];
			if (c != d) a = c, b = d;
		}
		return jt.jmp[0][a];
	}
	int dist(int a, int b) const {
		int c = lca(a,b);
		return (dep[a]-dep[c])+(dep[b]-dep[c]);
	}
};
