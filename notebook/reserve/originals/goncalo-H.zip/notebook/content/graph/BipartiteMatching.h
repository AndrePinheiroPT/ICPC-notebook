/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Pair as many left/right items as possible,
 *   using each once. Construct with n left, m right;
 *   add(u,v) allows left u to pair with right v.
 *   \item solve() returns number of pairs; l[u] and r[v]
 *   are their partners (-1 if free). cover() then returns
 *   left/right IDs touching all edges, using fewest vertices.
 *   Call cover after solve without changing the graph.
 *   \item BFS finds shortest chains that rearrange pairs;
 *   DFS uses those chains. Matching $O((V+E)\sqrt V)$,
 *   cover $O(V+E)$; space $O(V+E)$, DFS depth $O(V)$.
 *   \end{itemize}
 * Usage: BipartiteMatching b(n,m); b.add(u,v);
 *   int count = b.solve(); auto [a,c] = b.cover();
 */
#pragma once

struct BipartiteMatching {
	int n, m, shortest = 0;
	vector<vi> g;
	vi l, r, d;
	BipartiteMatching(int a, int b)
		: n(a), m(b), g(a), l(a,-1), r(b,-1),
		  d(a) {}
	void add(int u, int v) { g[u].push_back(v); }
	bool bfs() {
		fill(d.begin(), d.end(), -1);
		shortest = n+1;
		queue<int> q;
		for (int u = 0; u < n; ++u) if (l[u] < 0)
			d[u] = 0, q.push(u);
		while (!q.empty()) {
			int u = q.front(); q.pop();
			if (d[u] >= shortest) continue;
			for (int v : g[u]) {
				int w = r[v];
				if (w < 0) shortest = d[u]+1;
				else if (d[w] < 0) {
					d[w] = d[u]+1; q.push(w);
				}
			}
		}
		return shortest <= n;
	}
	bool dfs(int u) {
		for (int v : g[u]) {
			int w = r[v];
			if (w < 0 ? d[u]+1 == shortest
					: d[w] == d[u]+1 && dfs(w)) {
				l[u] = v; r[v] = u; return true;
			}
		}
		d[u] = -1;
		return false;
	}
	int solve() {
		fill(l.begin(), l.end(), -1);
		fill(r.begin(), r.end(), -1);
		int ans = 0;
		while (bfs()) for (int u = 0; u < n; ++u)
			if (l[u] < 0 && dfs(u)) ++ans;
		return ans;
	}
	pair<vi,vi> cover() const {
		vi a(n), b(m);
		queue<int> q;
		for (int u = 0; u < n; ++u) if (l[u] < 0)
			a[u] = 1, q.push(u);
		while (!q.empty()) {
			int u = q.front(); q.pop();
			for (int v : g[u])
				if (l[u] != v && !b[v]) {
					b[v] = 1;
					int w = r[v];
					if (w >= 0 && !a[w])
						a[w] = 1, q.push(w);
				}
		}
		pair<vi,vi> ans;
		for (int u = 0; u < n; ++u)
			if (!a[u]) ans.first.push_back(u);
		for (int v = 0; v < m; ++v)
			if (b[v]) ans.second.push_back(v);
		return ans;
	}
};
