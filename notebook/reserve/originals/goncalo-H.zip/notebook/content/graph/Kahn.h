/**
 * Author: jet notebook, based on KACTL
 * Summary: Ordenar tarefas após os seus pré-requisitos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: instalar 0 e 1 antes de 2.
 *   Exigir 2 antes de 0 cria um ciclo e impede uma ordem completa.
 *   \item Para u antes de v, pôr v em g[u].
 *   kahn(g) devolve IDs numa ordem válida;
 *   menos de V indica ciclo: não existe ordem completa.
 *   \item in[v] conta pré-requisitos por terminar.
 *   Tempo $O(V+E)$, espaço extra $O(V)$.
 *   \end{itemize}
 * Usage: vector<vi> g{{2},{2},{}};
 *   auto order = kahn(g); // {0,1,2}
 *   bool possible = sz(order)==sz(g); // true
 *   g[2].push_back(0); // agora 0 e 2 dependem um do outro
 *   auto loop = kahn(g);
 *   bool cycle = sz(loop)<sz(g); // true
 */
#pragma once

vi kahn(const vector<vi>& g) {
	vi in(sz(g)), q;
	for (auto& adj : g) for (int v : adj) ++in[v];
	for (int v = 0; v < sz(g); ++v)
		if (!in[v]) q.push_back(v);
	for (int i = 0; i < sz(q); ++i)
		for (int v : g[q[i]]) if (!--in[v])
			q.push_back(v);
	return q;
}
