/**
 * Author: jet notebook
 * Summary: Agrupar vértices mutuamente alcançáveis
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: dois pares de cidades permitem ida e volta,
 *   ligados por uma estrada de sentido único. Agrupar cada par.
 *   \item g[u] contém vizinhos de saída. kosaraju(g) devolve
 *   comp[v], ID do grupo de v; num grupo todos se alcançam.
 *   \item condensation(g,comp) constrói à parte o grafo dos grupos,
 *   sem arestas duplicadas. É acíclico; todas as arestas vão
 *   de IDs menores para maiores.
 *   \item DFS guarda a ordem de fim; depois percorre arestas inversas.
 *   Ambas as passagens usam stacks, seguras em cadeias longas.
 *   Cada função usa tempo e espaço $O(V+E)$.
 *   \end{itemize}
 * Usage: vector<vi> g{{1},{0,2},{3},{2}};
 *   auto comp = kosaraju(g); // {0,0,1,1}
 *   auto dag = condensation(g,comp); // {{1},{}}
 *   bool same = comp[0]==comp[1]; // true
 */
#pragma once

vi kosaraju(const vector<vi>& g) {
	int n = sz(g), count = 0;
	vector<vi> rev(n);
	for (int v = 0; v < n; ++v)
		for (int u : g[v]) rev[u].push_back(v);
	vi seen(n), next(n), order, comp(n,-1), st;
	for (int s = 0; s < n; ++s) if (!seen[s]) {
		seen[s] = 1; st.push_back(s);
		while (!st.empty()) {
			int v = st.back();
			if (next[v] == sz(g[v])) {
				order.push_back(v); st.pop_back();
			} else {
				int u = g[v][next[v]++];
				if (!seen[u]) seen[u] = 1, st.push_back(u);
			}
		}
	}
	for (int i = n; i--;) {
		int s = order[i];
		if (comp[s] >= 0) continue;
		comp[s] = count; st.push_back(s);
		while (!st.empty()) {
			int v = st.back(); st.pop_back();
			for (int u : rev[v]) if (comp[u] < 0) {
				comp[u] = count; st.push_back(u);
			}
		}
		++count;
	}
	return comp;
}
vector<vi> condensation(const vector<vi>& g,
		const vi& comp) {
	int count = 0;
	for (int c : comp) count = max(count,c+1);
	vector<vi> groups(count), dag(count);
	for (int v = 0; v < sz(g); ++v)
		groups[comp[v]].push_back(v);
	vi mark(count,-1);
	for (int c = 0; c < count; ++c)
		for (int v : groups[c]) for (int u : g[v]) {
			int d = comp[u];
			if (d != c && mark[d] != c) {
				mark[d] = c; dag[c].push_back(d);
			}
		}
	return dag;
}
