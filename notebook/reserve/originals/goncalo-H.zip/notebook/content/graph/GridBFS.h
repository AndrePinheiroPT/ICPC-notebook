/**
 * Author: jet notebook
 * Summary: Menos movimentos numa grelha
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: grelha $3\times3$ com parede central.
 *   Equipas em cantos opostos: distância à mais próxima?
 *   \item Grelha de caracteres; wall bloqueia, restantes células livres.
 *   Só movimentos ortogonais. Origens (linha,coluna) começam em 0,
 *   dentro da grelha e livres; várias origens dão a mais próxima.
 *   \item Devolve (dist,parent) lineares, indexados por r*C+c;
 *   descodificar com id/C e id\%C. dist=-1 em paredes/inalcançáveis;
 *   parent=-1 nas origens/inalcançáveis.
 *   Seguir os pais e inverter para obter um caminho.
 *   \item Grelha retangular não vazia; linhas com comprimento
 *   positivo, R*C<=INT\_MAX. Origens vazias permitidas; repetidas
 *   ignoradas. Não altera a entrada. Tempo $O(RC+|src|)$, espaço $O(RC)$.
 *   \end{itemize}
 * Usage: vector<string> a{"...",".#.","..."};
 *   auto [d,p] = gridBfs(a,{{0,0},{2,2}});
 *   // d[0*3+2]=2; d[1*3+1]=-1 (parede)
 */
#pragma once

pair<vi,vi> gridBfs(const vector<string>& a,
		const vector<pair<int,int>>& src,
		char wall = '#') {
	assert(!a.empty());
	int R = sz(a), C = sz(a[0]);
	assert(C > 0 && (ll)R*C <= INT_MAX);
	for (int r = 0; r < R; ++r) assert(sz(a[r]) == C);
	vi dist(R*C,-1), parent(R*C,-1), q;
	for (auto [r,c] : src) {
		assert(0 <= r && r < R && 0 <= c && c < C);
		assert(a[r][c] != wall);
		int v = r*C+c;
		if (dist[v] < 0) dist[v] = 0, q.push_back(v);
	}
	const int dr[4] = {-1,1,0,0};
	const int dc[4] = {0,0,-1,1};
	for (int i = 0; i < sz(q); ++i) {
		int v = q[i], r = v/C, c = v%C;
		for (int k = 0; k < 4; ++k) {
			int nr = r+dr[k], nc = c+dc[k];
			if (nr < 0 || nr >= R || nc < 0 || nc >= C)
				continue;
			int u = nr*C+nc;
			if (a[nr][nc] == wall || dist[u] >= 0) continue;
			dist[u] = dist[v]+1; parent[u] = v;
			q.push_back(u);
		}
	}
	return {dist,parent};
}
