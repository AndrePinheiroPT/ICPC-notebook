/**
 * Author: jet notebook
 * Summary: Caminhos mínimos com custos 0 ou 1
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: 0 para 2 custa um bilhete; via 1 é grátis.
 *   Minimizar bilhetes, não movimentos.
 *   \item g[u] contém (v,peso), com pesos apenas 0 ou 1;
 *   vector<vector<pair<int,int>>> g(n). Adjacência dirigida,
 *   IDs $[0,n)$; adicionar ambos os sentidos se necessário.
 *   src=\{s\} ou várias origens, todas com custo inicial 0.
 *   \item Devolve (dist,parent) desde a origem mais próxima;
 *   INT\_MAX indica inalcançável. parent=-1 nas origens/inalcançáveis.
 *   Várias origens minimizam custos, não somam distâncias.
 *   Não altera a entrada; BFS normal falha se o custo do percurso
 *   diferir do número de arestas.
 *   \item Deque: custo 0 entra à frente, 1 atrás;
 *   ignora distâncias desatualizadas. Tempo $O(|src|+V+E)$,
 *   espaço extra $O(V+E)$.
 *   \end{itemize}
 * Usage: vector<vector<pair<int,int>>> g(3);
 *   g[0]={{1,0},{2,1}}; g[1]={{2,0}};
 *   auto [dist,parent] = zeroOneBfs(g,{0}); // {0,0,0}
 *   int tickets = dist[2]; // 0, pelo vértice 1
 */
#pragma once

pair<vi,vi> zeroOneBfs(
		const vector<vector<pair<int,int>>>& g,
		const vi& src) {
	vi d(sz(g),INT_MAX), parent(sz(g),-1);
	deque<pair<int,int>> q;
	for (int s : src) {
		assert(0 <= s && s < sz(g));
		if (d[s] != 0) {
			d[s] = 0; q.push_back({0,s});
		}
	}
	while (!q.empty()) {
		auto [dv,v] = q.front(); q.pop_front();
		if (dv != d[v]) continue;
		for (auto [u,w] : g[v]) {
			assert(w == 0 || w == 1);
			if (dv+w >= d[u]) continue;
			d[u] = dv+w; parent[u] = v;
			if (w) q.push_back({d[u],u});
			else q.push_front({d[u],u});
		}
	}
	return {d,parent};
}
