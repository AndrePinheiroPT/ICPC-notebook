/**
 * Author: Team reference
 * Summary: Caminhos mínimos e coloração bipartida
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: depósitos nas pontas de $0-1-2$. Calcular
 *   distâncias ao mais próximo e dois grupos sem arestas internas.
 *   \item Arestas de custo unitário; IDs $[0,n)$. vector<vi> g(n);
 *   g[u].push\_back(v) cria u -> v; adicionar ambos os sentidos
 *   se não dirigido. bfs(g,src) devolve (dist,parent), sem alterar g.
 *   src=\{s\} ou várias origens: distância à mais próxima,
 *   não um percurso que passe por todas.
 *   \item dist=-1: inalcançável; parent=-1 nas origens e
 *   inalcançáveis. q é a fila de descoberta. src vazio não
 *   alcança nada; origens repetidas são permitidas.
 *   \item restorePath(s,t,parent) devolve vértices s..t,
 *   ou vazio se a cadeia não chegar a s. Com várias origens,
 *   seguir os pais até -1 identifica a origem de t.
 *   Exige IDs válidos e pais sem ciclos.
 *   \item bipartite(g) verifica todas as componentes não dirigidas;
 *   devolve (ok,color). Se ok, color[v] é 0/1; lacetes falham.
 *   Percursos $O(V+E+|src|)$, caminho $O(V)$; espaço $O(V)$.
 *   \end{itemize}
 * Usage: vector<vi> g{{1},{0,2},{1}};
 *   auto [dist,parent] = bfs(g,{0,2}); // {0,1,0}
 *   auto [ok,color] = bipartite(g); // true
 *   vi route = restorePath(0,1,parent); // {0,1}
 */
#pragma once

pair<vi,vi> bfs(const vector<vi>& g, const vi& src) {
	vi dist(sz(g),-1), parent(sz(g),-1), q;
	for (int s : src) {
		assert(0 <= s && s < sz(g));
		if (dist[s] < 0) dist[s] = 0, q.push_back(s);
	}
	for (int i = 0; i < sz(q); ++i) {
		int v = q[i];
		for (int u : g[v]) if (dist[u] < 0) {
			dist[u] = dist[v]+1; parent[u] = v;
			q.push_back(u);
		}
	}
	return {dist,parent};
}
vi restorePath(int s, int t, const vi& parent) {
	assert(0 <= s && s < sz(parent));
	assert(0 <= t && t < sz(parent));
	vi path;
	for (int v = t; v >= 0; v = parent[v]) {
		path.push_back(v);
		if (v == s) {
			reverse(path.begin(),path.end());
			return path;
		}
	}
	return {};
}
pair<bool,vi> bipartite(const vector<vi>& g) {
	vi color(sz(g),-1), q;
	for (int s = 0; s < sz(g); ++s) {
		if (color[s] >= 0) continue;
		color[s] = 0; q = {s};
		for (int i = 0; i < sz(q); ++i) {
			int v = q[i];
			for (int u : g[v]) {
				if (color[u] < 0) {
					color[u] = color[v]^1; q.push_back(u);
				} else if (color[u] == color[v])
					return {false,color};
			}
		}
	}
	return {true,color};
}
