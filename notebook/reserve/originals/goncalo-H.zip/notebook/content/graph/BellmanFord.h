/**
 * Author: Simon Lindholm
 * Date: 2015-02-23
 * License: CC0
 * Source: http://en.wikipedia.org/wiki/Bellman-Ford_algorithm
 * Summary: Caminhos mínimos com arestas negativas
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: 0 para 1 custa 4; 1 para 2 reembolsa 2.
 *   Calcular o menor custo total.
 *   \item Criar novo vector<BF::Node> nodes(V);
 *   arestas BF::Ed\{from,to,intWeight\}.
 *   Chamar bellmanFord(nodes,edges,s) com origem válida.
 *   \item Ler nodes[v].dist e .prev (vértice anterior).
 *   BF::inf: inalcançável; -inf: um ciclo negativo alcançável
 *   permite baixar este custo sem limite.
 *   Ordena edges; prev só serve para distâncias finitas.
 *   \item Somas finitas em $(-inf,inf)$;
 *   basta $V(E+1)\max|w|<inf$, inf=LLONG\_MAX.
 *   Tempo $O(V(E+1)+E\log(E+1))$, espaço extra $O(\log(E+1))$.
 *   \end{itemize}
 * Usage: vector<BF::Node> nodes(3);
 *   vector<BF::Ed> edges{{0,1,4},{1,2,-2}};
 *   BF::bellmanFord(nodes,edges,0);
 *   ll answer = nodes[2].dist; // 2; prev = 1
 * Status: Testado em kattis:shortestpath3
 */
#pragma once

namespace BF {
const ll inf = LLONG_MAX;
struct Ed {
	int a, b, w, s() {
		return a < b ? a : -a;
	}
};
struct Node { ll dist = inf; int prev = -1; };

void bellmanFord(vector<Node>& nodes,
		vector<Ed>& eds, int s) {
	nodes[s].dist = 0;
	sort(eds.begin(), eds.end(), [](Ed a, Ed b) {
		return a.s() < b.s();
	});

	int lim = sz(nodes) / 2 + 2;
	// /3+100 com vértices baralhados
	for (int i = 0; i < lim; i++)
		for (Ed ed : eds) {
			Node cur = nodes[ed.a],
				&dest = nodes[ed.b];
			if (abs(cur.dist) == inf) continue;
			ll d = cur.dist + ed.w;
			if (d < dest.dist) {
				dest.prev = ed.a;
				dest.dist = (i < lim-1 ? d : -inf);
			}
		}
	for (int i = 0; i < lim; i++)
		for (Ed e : eds) {
			if (nodes[e.a].dist == -inf)
				nodes[e.b].dist = -inf;
		}
}
} // namespace BF
