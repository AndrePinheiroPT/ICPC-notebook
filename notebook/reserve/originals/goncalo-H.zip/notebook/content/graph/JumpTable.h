/**
 * Author: jet notebook
 * Summary: Destino após muitos passos fixos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: paragens repetem $0\to1\to2\to0$.
 *   Onde estamos após cinco viagens desde 0?
 *   \item next[v] é o sucessor, -1 se ausente.
 *   jump(v,k) devolve o destino após k passos;
 *   ao ficar ausente, permanece -1.
 *   \item jmp[k][v] guarda o sucessor após $2^k$ passos.
 *   Escolher $1\le lg\le64$ com passos $<2^{lg}$;
 *   lg=64 suporta todas as contagens unsigned de 64 bits.
 *   Construção/espaço $O(n\,lg)$; cada jump $O(lg)$.
 *   \end{itemize}
 * Usage: vi next{1,2,0};
 *   JumpTable t(next,64);
 *   int u = t.jump(0,5); // 2
 */
#pragma once

using ull = unsigned long long;

struct JumpTable {
	vector<vi> jmp;
	JumpTable(const vi& next, int lg)
		: jmp(lg,next) {
		assert(1 <= lg && lg <= 64);
		for (int j = 1; j < lg; ++j)
			for (int v = 0; v < sz(next); ++v) {
				int p = jmp[j-1][v];
				jmp[j][v] = p < 0 ? -1 : jmp[j-1][p];
			}
	}
	int jump(int v, ull k) const {
		assert(sz(jmp) == 64 || (k >> sz(jmp)) == 0);
		for (int j = 0; k && v >= 0; ++j, k >>= 1)
			if (k & 1) v = jmp[j][v];
		return v;
	}
};
