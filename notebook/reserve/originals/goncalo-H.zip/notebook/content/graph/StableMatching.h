/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Assign partners with no pair that would both
 *   prefer each other over their assigned partners.
 *   a[u] and b[v] list opposite-side IDs, best first.
 *   \item S proposers, T receivers, $S\le T$. Each row is
 *   a complete permutation (no ties); free receivers accept
 *   any proposer. Returns each proposer's partner, best
 *   possible for proposers among all stable assignments.
 *   \item rank[v][u] is u's preference position for v;
 *   next[u] is the next proposal; queue holds free proposers.
 *   All S are matched; $O(ST+S+T)$ time and space.
 *   \end{itemize}
 * Usage: auto partner = stableMatching(a,b);
 */
#pragma once

vi stableMatching(const vector<vi>& a,
		const vector<vi>& b) {
	int s = sz(a), t = sz(b);
	assert(s <= t);
	vector<vi> rank(t,vi(s));
	for (int v = 0; v < t; ++v) {
		assert(sz(b[v]) == s);
		for (int i = 0; i < s; ++i)
			rank[v][b[v][i]] = i;
	}
	vi l(s,-1), r(t,-1), next(s);
	queue<int> free;
	for (int u = 0; u < s; ++u) {
		assert(sz(a[u]) == t); free.push(u);
	}
	while (!free.empty()) {
		int u = free.front(); free.pop();
		int v = a[u][next[u]++];
		int w = r[v];
		if (w < 0 || rank[v][u] < rank[v][w]) {
			l[u] = v; r[v] = u;
			if (w >= 0) {
				l[w] = -1; free.push(w);
			}
		} else free.push(u);
	}
	return l;
}
