/**
 * Author: jet notebook
 * Summary: Representar cada subárvore por um intervalo
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: 0 chefia 1, que chefia 2 e 3.
 *   Colocar a equipa inteira de 1 num intervalo.
 *   \item g[u] contém vizinhos de uma árvore não dirigida;
 *   root escolhe a raiz. Entrada vazia permitida;
 *   caso contrário, root deve ser válido.
 *   \item ord[i] é o vértice na posição i. A subárvore de v é
 *   ord[tin[v]..tout[v]), incluindo v. par[v] é o pai
 *   (-1 na raiz); dep[v] conta arestas desde a raiz.
 *   \item Stack visita pais antes dos filhos;
 *   a ordem inversa acumula tamanhos. Tempo/espaço $O(n)$.
 *   \end{itemize}
 * Usage: vector<vi> g{{1},{0,2,3},{1},{1}};
 *   TreeTour t(g,0);
 *   int first=t.tin[1], past=t.tout[1]; // [1,4)
 *   vi team(t.ord.begin()+first,t.ord.begin()+past);
 *   // team={1,3,2}; ordem interna pode variar
 */
#pragma once

struct TreeTour {
	vi par, dep, tin, tout, ord;
	TreeTour(const vector<vi>& g, int root = 0)
		: par(sz(g),-1), dep(sz(g)),
		  tin(sz(g)), tout(sz(g)) {
		if (g.empty()) return;
		vi st{root}, size(sz(g),1);
		while (!st.empty()) {
			int v = st.back(); st.pop_back();
			tin[v] = sz(ord); ord.push_back(v);
			for (int u : g[v]) if (u != par[v]) {
				par[u] = v; dep[u] = dep[v]+1;
				st.push_back(u);
			}
		}
		for (int i = sz(ord); i--;) {
			int v = ord[i];
			tout[v] = tin[v]+size[v];
			if (par[v] >= 0)
				size[par[v]] += size[v];
		}
	}
};
