/**
 * Author: Simon Lindholm
 * Date: 2016-12-15
 * License: CC0
 * Source: http://en.wikipedia.org/wiki/Floyd–Warshall_algorithm
 * Summary: Caminhos mínimos entre todos os pares
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Exemplo: 0 para 1 custa 4, 1 para 2 custa -2.
 *   Calcular os menores custos entre todos os pares.
 *   \item Matriz quadrada de ll: m[u][v]=custo da aresta,
 *   FW::inf se ausente. Guardar a menor aresta paralela; V pequeno.
 *   \item Substitui m pelos custos mínimos: inf é inalcançável,
 *   -inf é custo sem limite inferior por ciclo negativo.
 *   A diagonal fica no máximo 0.
 *   \item $V\max|w|<inf=2^{62}$; tempo $O(V^3)$,
 *   espaço extra $O(1)$.
 *   \end{itemize}
 * Usage: vector<vector<ll>> m(3,vector<ll>(3,FW::inf));
 *   m[0][1]=4; m[1][2]=-2;
 *   FW::floydWarshall(m);
 *   ll cost = m[0][2]; // 2; m[2][0] é FW::inf
 * Status: Pouco testado
 */
#pragma once

namespace FW {
const ll inf = 1LL << 62;
void floydWarshall(vector<vector<ll>>& m) {
	int n = sz(m);
	for (int i = 0; i < n; i++)
		m[i][i] = min(m[i][i], 0LL);
	for (int k = 0; k < n; k++)
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if (m[i][k] != inf &&
						m[k][j] != inf) {
					auto newDist = max(
						m[i][k] + m[k][j], -inf);
					m[i][j] = min(m[i][j], newDist);
				}
	for (int k = 0; k < n; k++) if (m[k][k] < 0)
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if (m[i][k] != inf &&
						m[k][j] != inf)
					m[i][j] = -inf;
}
} // namespace FW
