/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *   \item Query/update values along a tree path using a
 *   segment tree. Give undirected tree g and root; store
 *   vertex v at array index tin[v].
 *   \item path(u,v) returns disjoint [l,r) array ranges;
 *   loop over them and query/update each. edges=true skips
 *   the LCA: store each edge at its deeper endpoint's tin.
 *   Ranges are unordered (sum/min/max OK, string order not).
 *   \item TreeTour fields stay available; head[v] starts its
 *   heavy chain. Empty build OK. Build/space $O(n)$;
 *   path $O(\log n)$ time and returned ranges.
 *   \end{itemize}
 * Usage: HeavyLight h(g,root);
 *   for (auto [l,r] : h.path(u,v)) sum += seg.query(l,r);
 */
#pragma once
#include "TreeTour.h"

struct HeavyLight : TreeTour {
	vi head;
	HeavyLight(const vector<vi>& g, int root = 0)
		: TreeTour(g,root), head(sz(g)) {
		if (g.empty()) return;
		vi heavy(sz(g),-1);
		for (int v = 0; v < sz(g); ++v)
			for (int u : g[v]) if (par[u] == v) {
				int w = heavy[v];
				if (w < 0 ||
						tout[u]-tin[u] > tout[w]-tin[w])
					heavy[v] = u;
			}
		vi st{root}; ord.clear();
		while (!st.empty()) {
			int v = st.back(); st.pop_back();
			for (int u = v; u >= 0; u = heavy[u]) {
				head[u] = v;
				tin[u] = sz(ord); ord.push_back(u);
				tout[u] = tin[u]+1;
				for (int w : g[u])
					if (par[w] == u && w != heavy[u])
						st.push_back(w);
			}
		}
		for (int i = sz(ord); i--;) {
			int v = ord[i];
			if (par[v] >= 0)
				tout[par[v]] = max(tout[par[v]],tout[v]);
		}
	}
	vector<pair<int,int>> path(int u, int v,
			bool edges = false) const {
		vector<pair<int,int>> ranges;
		while (head[u] != head[v]) {
			if (dep[head[u]] < dep[head[v]]) swap(u,v);
			ranges.push_back({tin[head[u]],tin[u]+1});
			u = par[head[u]];
		}
		if (dep[u] > dep[v]) swap(u,v);
		int l = tin[u]+int(edges), r = tin[v]+1;
		if (l < r) ranges.push_back({l,r});
		return ranges;
	}
};
