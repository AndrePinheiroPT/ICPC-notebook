/**
 * Author: jet notebook
 * Summary: Encontrar todas as ocorrências de um padrão
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Encontrar todos os aba em ababa, incluindo sobreposições.}
 *  Recebe texto s e padrão p: strings ou vetores de inteiros.
 *  Devolve os índices iniciais das ocorrências. O padrão vazio
 *  ocorre nas n+1 fronteiras; dispensa um separador especial.
 *  \item prefixFunction calcula pi: pi[i] é o comprimento do maior
 *  prefixo que também termina em i, menor que [0,i+1).
 *  Não é preciso procurar um padrão.
 *  \item Prefixos: $O(m)$; procura: $O(n+m)$ tempo,
 *  $O(m)$ espaço mais o resultado.
 *  \end{itemize}
 * Usage: string text = "ababa", pattern = "aba";
 *  auto pos = kmpMatches(text,pattern); // {0,2}
 *  auto pi = prefixFunction(pattern); // {0,0,1}
 */
#pragma once

template<class S>
vi prefixFunction(const S& s) {
	vi p(sz(s));
	for (int i = 1; i < sz(s); ++i) {
		int j = p[i-1];
		while (j && s[i] != s[j]) j = p[j-1];
		if (s[i] == s[j]) ++j;
		p[i] = j;
	}
	return p;
}
template<class S, class P>
vi kmpMatches(const S& s, const P& p) {
	vi ans;
	int n = sz(s), m = sz(p), j = 0;
	if (!m) {
		ans.resize(n+1);
		iota(ans.begin(),ans.end(),0);
		return ans;
	}
	vi pi = prefixFunction(p);
	for (int i = 0; i < n; ++i) {
		while (j && s[i] != p[j]) j = pi[j-1];
		if (s[i] == p[j]) ++j;
		if (j == m) {
			ans.push_back(i-m+1); j = pi[j-1];
		}
	}
	return ans;
}
