/**
 * Author: supplied by user, adapted
 * Summary: Chaves rápidas de substrings; podem colidir
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Comparar partes sem as copiar.}
 *  Constrói a partir de string ou vector<int>. get(l,r) devolve
 *  \{hash1,hash2,length\} para $[l,r)$; comparar chaves com ==.
 *  Chaves diferentes indicam sequências diferentes; iguais podem colidir.
 *  \item h[i] representa os primeiros i símbolos; p[i] guarda
 *  as potências i das duas bases fixas. Ambos têm n+1 entradas.
 *  Construção/espaço $O(n)$; get e concat $O(1)$.
 *  \item h.concat(x,y) representa x seguido de y. Usa as potências de h:
 *  o comprimento de y não pode exceder o input de h (verificado).
 *  Para mais potências, construir h com um input maior.
 *  \item Strings usam bytes sem sinal. IDs inteiros em
 *  $[0,10^9+7)$; comprimir TODAS as sequências comparadas em conjunto.
 *  Bases fixas dão resultados reproduzíveis, mas permitem colisões
 *  construídas: hashing não garante igualdade exata.
 *  \end{itemize}
 * Usage: DoubleHash h("abc"), target("ac");
 *  auto erased = h.concat(h.get(0,1),h.get(2,3));
 *  bool same = erased == target.get(0,2); // true
 */
#pragma once

struct DoubleHash {
	using Key = array<ll,3>; // hash1, hash2, comprimento
	static constexpr array<ll,2> mod{1000000007,1000000009};
	static constexpr array<ll,2> base{911382323,972663749};
	vector<array<ll,2>> h, p;
	explicit DoubleHash(const vector<int>& s)
		: h(sz(s)+1), p(sz(s)+1, {1,1}) {
		for (int i = 0; i < sz(s); ++i) {
			assert(0 <= s[i] && s[i] < mod[0]);
			for (int k = 0; k < 2; ++k) {
				h[i+1][k] = (h[i][k]*base[k]+s[i])%mod[k];
				p[i+1][k] = p[i][k]*base[k]%mod[k];
			}
		}
	}
	explicit DoubleHash(const vector<unsigned char>& s)
		: DoubleHash(vector<int>(s.begin(),s.end())) {}
	explicit DoubleHash(string_view s)
		: DoubleHash(vector<unsigned char>(s.begin(),s.end())) {}
	Key get(int l, int r) const {
		assert(0 <= l && l <= r && r < sz(h));
		Key ans{0,0,r-l};
		for (int k = 0; k < 2; ++k)
			ans[k] = (h[r][k]-h[l][k]*p[r-l][k]%mod[k]+mod[k])%mod[k];
		return ans;
	}
	Key concat(Key x, Key y) const {
		assert(0 <= y[2] && y[2] < sz(p));
		assert(0 <= x[2] && x[2] <= INT_MAX-y[2]);
		for (int k = 0; k < 2; ++k)
			x[k] = (x[k]*p[y[2]][k]+y[k])%mod[k];
		x[2] += y[2]; return x;
	}
};
