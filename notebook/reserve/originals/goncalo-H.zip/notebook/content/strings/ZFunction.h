/**
 * Author: jet notebook
 * Summary: Comprimento do prefixo coincidente em cada posição
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Em aabcaab, quanto do início se repete
 *  na posição 4? As três letras aab.}
 *  Recebe string/vetor s. Devolve z[i], o número de símbolos
 *  iniciais iguais em s e s[i,n). z[0]=0.
 *  \item Para aaaa: \{0,3,2,1\}; vazio dá vazio.
 *  [l,r) guarda um intervalo já comparado para reutilizar trabalho.
 *  \end{itemize}
 * Usage: string s = "aabcaab";
 *  auto z = zFunction(s); // {0,1,0,0,3,1,0}
 *  int repeated = z[4]; // 3 símbolos coincidentes
 * Time: O(n) tempo e espaço.
 */
#pragma once

template<class S> vi zFunction(const S& s) {
	int n = sz(s), l = 0, r = 0;
	vi z(n);
	for (int i = 1; i < n; ++i) {
		if (i < r) z[i] = min(r-i,z[i-l]);
		while (z[i] < n-i && s[z[i]] == s[i+z[i]])
			++z[i];
		if (i+z[i] > r) l = i, r = i+z[i];
	}
	return z;
}
