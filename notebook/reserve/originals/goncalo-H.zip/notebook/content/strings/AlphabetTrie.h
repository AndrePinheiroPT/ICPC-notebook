/**
 * Author: supplied by user, adapted
 * Summary: Guardar palavras; contar palavras e prefixos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Inserir cat, car, cat. Quantas começam por
 *  ca? Quantas são cat?}
 *  Recebe palavras a-z; aceita vazias. insert acrescenta uma cópia;
 *  count/countPrefix contam palavras exatas/com o prefixo.
 *  \item contains testa pertença. walk devolve o ID do nó,
 *  ou -1 se ausente. Raiz 0; next guarda arestas (-1 se ausentes).
 *  terminal conta fins de palavra, pass conta palavras que passam.
 *  countPrefix("") conta todas as inserções, incluindo duplicados.
 *  \item DP de segmentação percorre node[v].next. Crescer o vetor
 *  invalida referências a nós. Inserções/nós $<INT\_MAX$.
 *  Chamadas $O(|s|+1)$, amortizado para insert; espaço $O(26L)$
 *  para L prefixos distintos mais a raiz.
 *  \end{itemize}
 * Usage: Trie t;
 *  t.insert("cat"); t.insert("car"); t.insert("cat");
 *  int copies = t.count("cat"); // 2
 *  int pref = t.countPrefix("ca"); // 3
 *  bool exact = t.contains("ca"); // false
 */
#pragma once

struct Trie {
	struct Node {
		array<int,26> next;
		int terminal = 0, pass = 0;
		Node() { next.fill(-1); }
	};
	vector<Node> node = vector<Node>(1);
	void insert(const string& s) {
		assert(node[0].pass < INT_MAX);
		int v = 0; ++node[v].pass;
		for (char c : s) {
			int x = c-'a'; assert(0 <= x && x < 26);
			if (node[v].next[x] == -1) {
				assert(node.size() < INT_MAX);
				int id = sz(node); node.emplace_back();
				node[v].next[x] = id;
			}
			v = node[v].next[x]; ++node[v].pass;
		}
		++node[v].terminal;
	}
	int walk(const string& s) const {
		int v = 0;
		for (char c : s) {
			int x = c-'a'; assert(0 <= x && x < 26);
			v = node[v].next[x];
			if (v == -1) break;
		}
		return v;
	}
	int count(const string& s) const {
		int v = walk(s); return v == -1 ? 0 : node[v].terminal;
	}
	bool contains(const string& s) const { return count(s) != 0; }
	int countPrefix(const string& s) const {
		int v = walk(s); return v == -1 ? 0 : node[v].pass;
	}
};
