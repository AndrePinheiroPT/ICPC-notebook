/**
 * Author: jet notebook
 * Summary: Adições em retângulos; valores finais da grelha
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Somar 5 de água às últimas duas colunas, depois 2
 *  às primeiras duas células da última linha. Ler cada total.}
 *  Difference2D d(n,m) começa a zero. add(r1,c1,r2,c2,x) soma x
 *  às linhas $[r_1,r_2)$, colunas $[c_1,c_2)$.
 *  values() devolve a grelha final, mantendo d utilizável.
 *  Usa quando só precisas da grelha após todas as atualizações.
 *  \item d guarda alterações nos cantos; values acumula-as.
 *  Adição $O(1)$; values/espaço $O(n(m+1))$.
 *  Valores intermédios têm de caber em T.
 *  \end{itemize}
 * Usage: Difference2D d(2,3);
 *  d.add(0,1,2,3,5);
 *  d.add(1,0,2,2,2);
 *  auto a = d.values(); // {{0,5,5},{2,7,5}}
 */
#pragma once

template<class T = ll> struct Difference2D {
	int n, m;
	vector<vector<T>> d;
	Difference2D(int rows, int cols)
		: n(rows), m(cols), d(n) {
		assert(n >= 0 && m >= 0);
		for (auto& row : d) row.resize(m);
	}
	void add(int r1, int c1, int r2, int c2,
			T delta) {
		assert(0 <= r1 && r1 <= r2 && r2 <= n);
		assert(0 <= c1 && c1 <= c2 && c2 <= m);
		if (r1 == r2 || c1 == c2) return;
		d[r1][c1] += delta;
		if (r2 < n) d[r2][c1] -= delta;
		if (c2 < m) d[r1][c2] -= delta;
		if (r2 < n && c2 < m) d[r2][c2] += delta;
	}
	vector<vector<T>> values() const {
		auto a = d;
		for (int r = 0; r < n; ++r)
			for (int c = 0; c < m; ++c) {
				if (r) a[r][c] += a[r-1][c];
				if (c) a[r][c] += a[r][c-1];
				if (r && c) a[r][c] -= a[r-1][c-1];
			}
		return a;
	}
};
