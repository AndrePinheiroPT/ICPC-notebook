/**
 * Author: jet notebook
 * Source: CPH, capítulo 28 (lazy propagation).
 * Summary: Adições e somas em intervalos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Salários 10,20,30,40: somar 5 aos dois do meio;
 *  obter o total dos últimos três.}
 *  Constrói a partir de a. add(l,r,x) soma x a cada a[i] em $[l,r)$;
 *  query(l,r) devolve a soma, zero se vazio. Toda a aritmética tem de caber em T.
 *  \item sum[p] guarda o total do nó; lazy[p] a adição pendente.
 *  apply altera um nó inteiro; push passa a adição aos filhos.
 *  Usa as versões curtas de add/query; as longas tratam da recursão.
 *  \item Construção/espaço $O(n)$; adição/consulta $O(\log n)$.
 *  \end{itemize}
 * Usage: vector<ll> salary{10,20,30,40};
 *  LazySegTree s(salary);
 *  s.add(1,3,5); // agora {10,25,35,40}
 *  ll payroll = s.query(1,4); // 100
 */
#pragma once

template<class T = ll> struct LazySegTree {
	int n;
	vector<T> sum, lazy;
	LazySegTree(const vector<T>& a) : n(sz(a)),
		sum(4*n), lazy(4*n) {
		if (n) build(1, 0, n, a);
	}
	void build(int p, int l, int r,
			const vector<T>& a) {
		if (r-l == 1) { sum[p] = a[l]; return; }
		int m = l + (r-l)/2;
		build(2*p,l,m,a); build(2*p+1,m,r,a);
		sum[p] = sum[2*p] + sum[2*p+1];
	}
	void apply(int p, int len, T x) {
		sum[p] += x*len; lazy[p] += x;
	}
	void push(int p, int l, int r) {
		if (lazy[p] == 0) return;
		int m = l + (r-l)/2;
		apply(2*p, m-l, lazy[p]);
		apply(2*p+1, r-m, lazy[p]);
		lazy[p] = 0;
	}
	void add(int l, int r, T x,
			int p, int a, int b) {
		if (r <= a || b <= l || l == r) return;
		if (l <= a && b <= r) {
			apply(p,b-a,x); return;
		}
		push(p,a,b);
		int m = a + (b-a)/2;
		add(l,r,x,2*p,a,m); add(l,r,x,2*p+1,m,b);
		sum[p] = sum[2*p] + sum[2*p+1];
	}
	void add(int l, int r, T x) {
		assert(0 <= l && l <= r && r <= n);
		add(l,r,x,1,0,n);
	}
	T query(int l, int r, int p, int a, int b) {
		if (r <= a || b <= l || l == r) return 0;
		if (l <= a && b <= r) return sum[p];
		push(p,a,b);
		int m = a + (b-a)/2;
		return query(l,r,2*p,a,m)
			+ query(l,r,2*p+1,m,b);
	}
	T query(int l, int r) {
		assert(0 <= l && l <= r && r <= n);
		return query(l,r,1,0,n);
	}
};
