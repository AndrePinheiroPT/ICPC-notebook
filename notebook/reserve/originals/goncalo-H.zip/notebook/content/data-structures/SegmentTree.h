/**
 * Author: Lucian Bicsi
 * Date: 2017-10-31
 * License: CC0
 * Source: folklore
 * Summary: Atribuições pontuais e máximos em intervalos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Pontuações 4,6,3,8: pôr 9 na posição 2;
 *  obter o máximo das posições 1 a 3.}
 *  SegTree(n) começa com INT\_MIN. update(i,x) atribui a[i]=x.
 *  query(l,r) devolve o máximo em $[l,r)$, INT\_MIN se vazio.
 *  s guarda esses máximos.
 *  \item Valores int. Para ll, altera T e unit em conjunto.
 *  Construção/espaço $O(n)$; atualização/consulta $O(\log n)$.
 *  \end{itemize}
 * Usage: vi scores{4,6,3,8}; SegTree s(4);
 *  for (int i = 0; i < 4; ++i) s.update(i,scores[i]);
 *  s.update(2,9);
 *  int best = s.query(1,4); // 9
 */
#pragma once

struct SegTree {
	typedef int T;
	static constexpr T unit = INT_MIN;
	vector<T> s; int n;
	SegTree(int m = 0, T def = unit) : s(2*m, def), n(m) {}
	void update(int pos, T val) {
		assert(0 <= pos && pos < n);
		pos += n; s[pos] = val;
		for (pos /= 2; pos >= 1; pos /= 2)
			s[pos] = max(s[pos * 2], s[pos * 2 + 1]);
	}
	T query(int l, int r) const {
		assert(0 <= l && l <= r && r <= n);
		T ans = unit;
		for (l += n, r += n; l < r; l /= 2, r /= 2) {
			if (l & 1) ans = max(ans, s[l++]);
			if (r & 1) ans = max(ans, s[--r]);
		}
		return ans;
	}
};
