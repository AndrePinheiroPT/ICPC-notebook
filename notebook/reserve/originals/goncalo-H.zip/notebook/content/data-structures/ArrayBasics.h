/**
 * Author: team notebook
 * Summary: Somas em intervalos e adições offline
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Ganhos diários \{4,-2,7\}: total em [1,3)?}
 *  prefixSums(a) devolve n+1 somas prefixo, começando em zero.
 *  rangeSum(p,l,r) devolve o total em [l,r). Inteiros podem ser negativos.
 *  Valores, prefixos e respostas têm de caber em ll.
 *  Construção/espaço $O(n)$; consulta $O(1)$.
 *  \item \textbf{Somar bónus a intervalos; ler valores finais.}
 *  Começa com vector<ll> d(n+1,0). addRange(d,l,r,x) soma x a [l,r);
 *  intervalo vazio não altera nada. finishDiff(d) devolve os n valores
 *  finais sem alterar d. Soma depois o array inicial, se existir.
 *  Intermédios têm de caber em ll. Adição $O(1)$, finalização $O(n)$;
 *  sem consultas entre atualizações.
 *  \end{itemize}
 * Usage: auto p = prefixSums(vi{4,-2,7});
 *  ll total = rangeSum(p,1,3); // 5
 *  vector<ll> d(4); addRange(d,1,3,5);
 *  auto a = finishDiff(d); // {0,5,5}
 */
#pragma once

template<class T> vector<ll> prefixSums(const vector<T>& a) {
	vector<ll> p(sz(a)+1);
	for (int i = 0; i < sz(a); ++i) p[i+1] = p[i]+ll(a[i]);
	return p;
}
ll rangeSum(const vector<ll>& p, int l, int r) {
	assert(0 <= l && l <= r && r < sz(p));
	return p[r]-p[l];
}
void addRange(vector<ll>& d, int l, int r, ll x) {
	assert(0 <= l && l <= r && r < sz(d));
	if (l == r) return;
	d[l] += x; d[r] -= x;
}
vector<ll> finishDiff(const vector<ll>& d) {
	assert(!d.empty());
	vector<ll> a(sz(d)-1);
	ll value = 0;
	for (int i = 0; i < sz(a); ++i) a[i] = value += d[i];
	return a;
}
