/**
 * Author: jet, zyndek; adaptado ao notebook
 * Summary: Adições pontuais e somas em intervalos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Salários 10,20,30: somar 5 ao funcionário 1;
 *  obter o total dos funcionários 1 e 2.}
 *  Fenwick f(n) começa com n zeros, tipo ll. add(i,x) soma x;
 *  query(r) soma $[0,r)$; query(l,r) soma $[l,r)$.
 *  t guarda somas parciais.
 *  \item lowerBound(s) encontra o primeiro i com query(i+1)>=s;
 *  devolve n se não existir, -1 se s<=0. Só esta pesquisa exige
 *  valores não negativos no array.
 *  \item Construção/espaço $O(n)$; operações $O(\log n)$.
 *  Somas têm de caber em T. Fenwick<int> usa int em vez de ll.
 *  \end{itemize}
 * Usage: vector<ll> salary{10,20,30}; Fenwick f(3);
 *  for (int i = 0; i < 3; ++i) f.add(i,salary[i]);
 *  f.add(1,5);
 *  ll payroll = f.query(1,3); // 55
 *  int at = f.lowerBound(35); // 1: primeiro prefixo >=35
 */
#pragma once

template<class T = ll> struct Fenwick {
	int n;
	vector<T> t;
	Fenwick(int m = 0) : n(m), t(size_t(m)+1) {
		assert(n >= 0);
	}
	void add(int i, T delta) {
		assert(0 <= i && i < n);
		for (ll k = ll(i)+1; k <= n; k += k & -k)
			t[k] += delta;
	}
	T query(int r) const {
		assert(0 <= r && r <= n);
		T ans{};
		for (; r > 0; r -= r & -r) ans += t[r];
		return ans;
	}
	T query(int l, int r) const {
		assert(0 <= l && l <= r && r <= n);
		return query(r) - query(l);
	}
	int lowerBound(T sum) const {
		if (sum <= T(0)) return -1;
		int pos = 0, step = 1;
		while (step <= n/2) step *= 2;
		for (; step; step /= 2)
			if (step <= n-pos && t[pos+step] < sum) {
				pos += step;
				sum -= t[pos];
			}
		return pos;
	}
};
