/**
 * Author: Johan Sannemo, pajenegod
 * License: CC0
 * Source: KACTL; consultas de mínimo.
 * Summary: Consultar mínimos num array fixo
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Alturas fixas 5,1,1,3: mínimo das primeiras três;
 *  em empate, escolher a primeira posição.}
 *  Constrói a partir de a. query(l,r) devolve o mínimo no intervalo
 *  não vazio $[l,r)$. Guarda pares (valor,índice) para obter posições.
 *  jmp[k][i] cobre $2^k$ valores a partir de i.
 *  \item Troca ambas as chamadas min por max para máximos.
 *  Construção/espaço $O(n\log n)$, consulta $O(1)$; $n<2^{30}$.
 *  \end{itemize}
 * Usage: vector<pair<int,int>> a{{5,0},{1,1},{1,2},{3,3}};
 *  RMQ rmq(a);
 *  auto [height,index] = rmq.query(0,3); // 1,1
 */
#pragma once

template<class T = ll> struct RMQ {
	vector<vector<T>> jmp;
	RMQ(const vector<T>& a) : jmp(1,a) {
		for (int k = 1; (1 << k) <= sz(a); ++k) {
			jmp.emplace_back(sz(a) - (1 << k) + 1);
			for (int i = 0; i < sz(jmp[k]); ++i)
				jmp[k][i] = min(jmp[k-1][i],
					jmp[k-1][i + (1 << (k-1))]);
		}
	}
	T query(int l, int r) const {
		assert(0 <= l && l < r && r <= sz(jmp[0]));
		int k = __lg(r-l);
		return min(jmp[k][l], jmp[k][r - (1 << k)]);
	}
};
