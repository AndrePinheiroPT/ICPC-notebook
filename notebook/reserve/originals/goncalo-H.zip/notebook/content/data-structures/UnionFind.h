/**
 * Author: Lukas Polacek
 * Date: 2009-10-26
 * License: CC0
 * Source: folklore
 * Summary: Juntar grupos e testar conectividade
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Adicionar estradas 0--1, 1--2: 0 chega a 2?
 *  Quantas cidades estão ligadas a 1?}
 *  UF(n) começa com n vértices separados $[0,n)$.
 *  join(a,b) junta os grupos; devolve true apenas se os unir.
 *  Usado pelo Kruskal.
 *  \item find(v) devolve a raiz do grupo; sameSet(a,b) verifica se partilham
 *  o grupo; size(v) dá o tamanho. e[root] guarda o tamanho negativo;
 *  nos restantes vértices, e[v] guarda o pai.
 *  \item Construção/espaço $O(n)$; operações amortizadas $O(\alpha(n))$.
 *  \end{itemize}
 * Usage: UF roads(4);
 *  roads.join(0,1); roads.join(1,2);
 *  bool connected = roads.sameSet(0,2); // true
 *  int groupSize = roads.size(1); // 3
 *  bool separate = roads.sameSet(0,3); // false
 */
#pragma once

struct UF {
	vector<int> e;
	UF(int n) : e(n, -1) {}
	bool sameSet(int a, int b) { return find(a) == find(b); }
	int size(int x) { return -e[find(x)]; }
	int find(int x) {
		if (e[x] < 0) return x;
		return e[x] = find(e[x]); // comprime o caminho
	}
	bool join(int a, int b) {
		a = find(a); b = find(b);
		if (a == b) return false;
		if (e[a] > e[b]) swap(a, b);
		e[a] += e[b]; e[b] = a;
		return true;
	}
};
