/**
 * Author: jet notebook
 * Summary: Somas de retângulos numa grelha fixa
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Culturas numa grelha: total nas últimas duas colunas,
 *  em ambas as linhas.}
 *  Passa (rows,cols,a); a tem de ter essas dimensões.
 *  query(r1,c1,r2,c2) soma linhas $[r_1,r_2)$ e colunas $[c_1,c_2)$.
 *  Retângulos vazios dão zero. p tem uma linha e coluna extra a zero.
 *  \item Construção/espaço $O((n+1)(m+1))$, consulta $O(1)$.
 *  Somas intermédias têm de caber em T.
 *  \end{itemize}
 * Usage: vector<vector<ll>> crops{{1,2,3},{4,5,6}};
 *  PrefixSum2D p(2,3,crops);
 *  ll total = p.query(0,1,2,3); // 2+3+5+6 = 16
 */
#pragma once

template<class T = ll> struct PrefixSum2D {
	int n, m;
	vector<vector<T>> p;
	PrefixSum2D(int rows, int cols,
		const vector<vector<T>>& a)
		: n(rows), m(cols), p(n+1, vector<T>(m+1)) {
		assert(n >= 0 && m >= 0 && sz(a) == n);
		for (int r = 0; r < n; ++r) {
			assert(sz(a[r]) == m);
			for (int c = 0; c < m; ++c)
				p[r+1][c+1] = a[r][c] + p[r][c+1]
					+ p[r+1][c] - p[r][c];
		}
	}
	T query(int r1, int c1, int r2, int c2) const {
		assert(0 <= r1 && r1 <= r2 && r2 <= n);
		assert(0 <= c1 && c1 <= c2 && c2 <= m);
		return p[r2][c2] - p[r1][c2]
			- p[r2][c1] + p[r1][c1];
	}
};
