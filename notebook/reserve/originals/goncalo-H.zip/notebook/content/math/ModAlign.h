/**
 * Author: jet notebook
 * Summary: Encontrar o próximo múltiplo ou evento.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Autocarros partem às 3,8,13,\ldots; chegando às 17, parte às 18.
 *  \item nextMultiple(x,k) devolve o primeiro múltiplo de k não inferior a x.
 *  nextTerm(x,t0,k) devolve o primeiro evento não anterior a x, começando
 *  em t0 e repetindo a cada k. Chegar antes de t0 devolve t0.
 *  \item Entradas inteiras, k>0; o resultado deve caber no tipo. Tempo/espaço O(1).
 *  \end{itemize}
 * Usage: ll arrival = 17;
 *  ll departure = nextTerm(arrival,3LL,5LL);
 *  assert(departure == 18);
 *  assert(nextMultiple(arrival,5LL) == 20);
 * Status: Testado com aritmética de precisão arbitrária.
 */
#pragma once

template<class T> T nextMultiple(T x, T k) {
	T r = x % k;
	if (r > 0) return x + (k - r);
	return x - r;
}

template<class T> T nextTerm(T x, T t0, T k) {
	if (x <= t0) return t0;
	T a = x % k, b = t0 % k;
	if (a < 0) a += k;
	if (b < 0) b += k;
	if (a <= b) return x + (b - a);
	return x + (k - (a - b));
}
