/**
 * Author: jet notebook
 * Summary: Arredondar divisão inteira por defeito ou excesso.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item 17 objetos precisam de 4 caixas de capacidade 5. floorDiv arredonda
 *  por defeito; ceilDiv por excesso. O / de C++ arredonda para zero.
 *  Ambas aceitam negativos.
 *  \item Passa a,b do mesmo tipo inteiro, b!=0. Devolve a/b arredondado;
 *  o resultado deve caber no tipo (excluir MIN/-1). Tempo/espaço O(1).
 *  \end{itemize}
 * Usage: ll items = 17, capacity = 5;
 *  assert(ceilDiv(items,capacity) == 4);
 *  assert(floorDiv(-7LL,3LL) == -3);
 * Status: Testado com desigualdades de precisão arbitrária.
 */
#pragma once

template<class T> T floorDiv(T a, T b) {
	T q = a / b, r = a % b;
	if (r != 0 && ((r < 0) != (b < 0))) --q;
	return q;
}

template<class T> T ceilDiv(T a, T b) {
	T q = a / b, r = a % b;
	if (r != 0 && ((r < 0) == (b < 0))) ++q;
	return q;
}
