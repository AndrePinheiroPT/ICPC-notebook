/**
 * Author: jet notebook
 * Summary: Ler e imprimir inteiros muito grandes.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Multiplicar dois valores $10^{12}$ e imprimir $10^{24}$
 *  exatamente. Faz cast ANTES: i128(a)*b, não i128(a*b).
 *  Todo o produto usa o tipo maior.
 *  \item toString(x) devolve texto decimal. read128(in,x) lê um inteiro
 *  com sinal para x; devolve false perante entrada inválida, overflow ou EOF,
 *  sem alterar x.
 *  \item Streams normais não leem/imprimem i128 diretamente.
 *  Tempo/espaço O(d) para d algarismos.
 *  \end{itemize}
 * Usage: i128 big = i128(1000000000000LL)*1000000000000LL;
 *  string text = toString(big);
 *  assert(text == "1000000000000000000000000");
 *  istringstream in(text); i128 value;
 *  assert(read128(in,value) && value == big);
 * Status: Testado contra cpp_int, incluindo entrada inválida.
 */
#pragma once

using i128 = __int128_t;
using u128 = __uint128_t;

string toString(i128 x) {
	u128 v = x < 0 ? -u128(x) : u128(x);
	string s;
	do {
		s += char('0' + v % 10);
		v /= 10;
	} while (v);
	if (x < 0) s += '-';
	reverse(s.begin(), s.end());
	return s;
}

bool read128(istream& in, i128& x) {
	string s;
	if (!(in >> s)) return false;
	bool neg = s[0] == '-';
	int i = neg || s[0] == '+';
	if (i == sz(s)) return false;
	u128 v = 0, lim = (u128(1) << 127) - !neg;
	for (; i < sz(s); ++i) {
		int d = s[i] - '0';
		if (d < 0 || d > 9) return false;
		if (v > (lim - d) / 10) return false;
		v = v * 10 + d;
	}
	x = neg && v ? -i128(v - 1) - 1 : i128(v);
	return true;
}
