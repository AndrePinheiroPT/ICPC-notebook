/**
 * Author: Team reference
 * Summary: Probabilidades em tentativas independentes repetidas.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Cada um de n tiros acerta independentemente com probabilidade p.
 *  binomialProb(n,p) devolve n+1 entradas: a entrada k é a probabilidade
 *  de exatamente k acertos, $0\le k\le n$. Soma entradas para um intervalo.
 *  Tempo $O(n^2)$, espaço $O(n)$: usar n moderado.
 *  \item atLeastOne(n,p) devolve a probabilidade de pelo menos um acerto
 *  em n tiros, sem subtrair um valor próximo de 1. geometricProb(k,p)
 *  devolve a probabilidade de o primeiro acerto ser no tiro k (começa em 1).
 *  Estes dois auxiliares usam tempo/espaço $O(1)$.
 *  \item Exige $n\ge0$ e $0\le p\le1$; geometricProb exige $k\ge1$.
 *  Zero tentativas dá zero acertos; p=0 nunca acerta, p=1 acerta sempre.
 *  Resultados aproximados em long double; probabilidades ínfimas
 *  podem arredondar para zero por underflow.
 *  \end{itemize}
 * Usage: int n = 4, k = 2; long double p = 0.5L;
 *  auto prob = binomialProb(n,p);
 *  long double exact = prob[k]; // exatamente k sucessos
 *  long double atMost = accumulate(prob.begin(),prob.begin()+k+1,0.0L);
 *  long double atLeast = accumulate(prob.begin()+k,prob.end(),0.0L);
 *  assert(exact == 0.375L && atMost == 0.6875L && atLeast == 0.6875L);
 *  assert(fabsl(atLeastOne(n,p)-0.9375L) < 1e-15L);
 *  assert(fabsl(geometricProb(3,p)-0.125L) < 1e-15L);
 *  long double expectedHits = n*p, expectedFirstHit = 1/p; // exige p>0
 *  assert(expectedHits == 2 && expectedFirstHit == 2);
 * Status: Testado com casos exaustivos e probabilidades de 100 dígitos.
 */
#pragma once

vector<long double> binomialProb(int n, long double p) {
	assert(n >= 0 && 0 <= p && p <= 1);
	vector<long double> prob((size_t)n + 1);
	prob[0] = 1;
	for (int i = 0; i < n; ++i) {
		// Descer: prob[k-1] ainda tem de descrever os i tiros anteriores.
		for (int k = i+1; k >= 1; --k)
			prob[k] = prob[k]*(1-p) + prob[k-1]*p;
		prob[0] *= 1-p;
	}
	return prob;
}

long double atLeastOne(long long n, long double p) {
	assert(n >= 0 && 0 <= p && p <= 1);
	if (n == 0 || p == 0) return 0;
	if (p == 1) return 1;
	// Forma estável de 1-(1-p)^n; condições evitam log(0).
	return -expm1l(n*log1pl(-p));
}

long double geometricProb(long long k, long double p) {
	assert(k >= 1 && 0 <= p && p <= 1);
	if (k == 1) return p;
	if (p == 0 || p == 1) return 0;
	return p*expl((k-1)*log1pl(-p));
}
