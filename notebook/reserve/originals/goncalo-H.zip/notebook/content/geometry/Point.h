/**
 * Author: Ulf Lundstrom
 * Date: 2009-02-26
 * License: CC0
 * Source: Original KACTL Point.h
 * Summary: Pontos, vetores e distâncias em 2D
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{De (1,2) a (4,6): calcular deslocamento
 *  e distância em linha reta.}
 *  Point<ll>(x,y) para inteiros, Point<long double>(x,y)
 *  para coordenadas reais. Diferenças, produtos e somas
 *  devem caber em T.
 *  \item dot dá o produto escalar. a.cross(b,c) dá o dobro
 *  da área orientada do triângulo: positivo numa viragem à esquerda.
 *  dist2 dá o quadrado da distância à origem;
 *  (a-b).dist() dá a distância de a a b.
 *  \item unit/normal exigem vetores reais não nulos;
 *  rotate usa radianos. dist/angle devolvem double.
 *  Chamadas $O(1)$. Ordenação exata por (x,y), sem epsilon.
 *  \end{itemize}
 * Usage: Point<ll> a(1,2), b(4,6);
 *  auto step = b-a; // (3,4)
 *  ll squared = step.dist2(); // 25
 *  double length = step.dist(); // 5
 */
#pragma once

template <class T> int sgn(T x) { return (x > 0) - (x < 0); }
template<class T>
struct Point {
	typedef Point P;
	T x, y;
	explicit Point(T x=0, T y=0) : x(x), y(y) {}
	bool operator<(P p) const { return tie(x,y) < tie(p.x,p.y); }
	bool operator==(P p) const { return tie(x,y)==tie(p.x,p.y); }
	P operator+(P p) const { return P(x+p.x, y+p.y); }
	P operator-(P p) const { return P(x-p.x, y-p.y); }
	P operator*(T d) const { return P(x*d, y*d); }
	P operator/(T d) const { return P(x/d, y/d); }
	T dot(P p) const { return x*p.x + y*p.y; }
	T cross(P p) const { return x*p.y - y*p.x; }
	T cross(P a, P b) const { return (a-*this).cross(b-*this); }
	T dist2() const { return x*x + y*y; }
	double dist() const { return sqrt((double)dist2()); }
	// ângulo com o eixo x no intervalo [-pi, pi]
	double angle() const { return atan2(y, x); }
	P unit() const { return *this/dist(); } // torna dist()=1
	P perp() const { return P(-y, x); } // roda +90 graus
	P normal() const { return perp().unit(); }
	// roda 'a' radianos no sentido anti-horário em torno da origem
	P rotate(double a) const {
		return P(x*cos(a)-y*sin(a),x*sin(a)+y*cos(a)); }
	friend ostream& operator<<(ostream& os, P p) {
		return os << "(" << p.x << "," << p.y << ")"; }
};
