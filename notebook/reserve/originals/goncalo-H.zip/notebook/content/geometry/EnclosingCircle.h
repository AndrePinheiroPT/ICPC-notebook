/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use to cover all given points with the smallest circle.
 *  \textbf{Input:} vector<P2>. Returns Circle\{center,radius\}; empty
 *  gives radius -1. Duplicates/collinear points work.
 *  \item out tests if a point needs covering; diameter makes the
 *  circle with a,b as opposite ends. Tolerance is eps$\ge0$
 *  plus machine roundoff by scale; final radius covers
 *  every point, minimality approximate at that scale.
 *  \item Expected $O(n)$, worst $O(n^3)$ time; $O(n)$ space.
 *  Finite data/conditioning must suit long double.
 *  \end{itemize}
 * Usage: Circle c = enclosingCircle(p); // c.c centre; c.r radius
 */
#pragma once
#include "Circle2.h"

Circle enclosingCircle(vector<P2> p,
		ld eps = 1e-12L) {
	static mt19937 rng(random_device{}());
	shuffle(p.begin(),p.end(),rng);
	Circle c{P2(0,0),-1};
	auto out = [&](P2 a) {
		ld s = max({abs(a.x),abs(a.y),
			abs(c.c.x),abs(c.c.y),c.r});
		ld e = eps+
			16*numeric_limits<ld>::epsilon()*s;
		ld d = sqrtl((a-c.c).dist2());
		return c.r < 0 || d > c.r+e;
	};
	auto diameter = [](P2 a, P2 b) {
		return Circle{a+(b-a)/2,
			sqrtl((b-a).dist2())/2};
	};
	for (int i=0; i<sz(p); ++i) if (out(p[i])) {
		c = {p[i],0};
		for (int j = 0; j < i; ++j) if (out(p[j])) {
			c = diameter(p[i],p[j]);
			for (int k = 0; k < j; ++k)
				if (out(p[k])) {
					auto q = circumcircle(p[i],p[j],p[k]);
					if (q) c = *q;
					else {
						c = diameter(p[i],p[j]);
						for (int v : {i,j}) {
							auto d = diameter(p[v],p[k]);
							if (d.r > c.r) c = d;
						}
					}
				}
		}
	}
	for (P2 a : p)
		c.r = max(c.r,sqrtl((a-c.c).dist2()));
	return c;
}
