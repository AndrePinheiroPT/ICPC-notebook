/**
 * Author: jet notebook
 * Summary: Projeções, reflexões e distâncias
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Margem (0,0)--(4,0), casa (6,3): distância
 *  à margem e à reta prolongada, e reflexo nessa reta?}
 *  Passar pontos reais a,b da reta/segmento e consulta p.
 *  project devolve o ponto mais próximo na reta;
 *  reflect devolve o ponto refletido nessa reta.
 *  \item lineDist/segDist devolvem distâncias não negativas.
 *  Retas exigem a!=b; segmentos aceitam a=b.
 *  Todos os valores reais intermédios devem ser finitos.
 *  Tempo/espaço $O(1)$.
 *  \end{itemize}
 * Usage: P2 a(0,0), b(4,0), p(6,3);
 *  P2 foot = project(a,b,p); // (6,0)
 *  P2 mirror = reflect(a,b,p); // (6,-3)
 *  ld toLine = lineDist(a,b,p); // 3
 *  ld toBank = segDist(a,b,p); // sqrt(13)
 */
#pragma once
#include "Predicates.h"

P2 project(P2 a, P2 b, P2 p) {
	P2 u = b-a;
	assert(u.dist2() > 0);
	return a+u*((p-a).dot(u)/u.dist2());
}
P2 reflect(P2 a, P2 b, P2 p) {
	return project(a,b,p)*2-p;
}
ld lineDist(P2 a, P2 b, P2 p) {
	assert(!(a == b));
	return abs((b-a).cross(p-a))/
		sqrtl((b-a).dist2());
}
ld segDist(P2 a, P2 b, P2 p) {
	if (a == b) return sqrtl((p-a).dist2());
	P2 u = b-a;
	ld t = clamp((p-a).dot(u)/u.dist2(),
		ld(0),ld(1));
	return sqrtl((p-(a+u*t)).dist2());
}
