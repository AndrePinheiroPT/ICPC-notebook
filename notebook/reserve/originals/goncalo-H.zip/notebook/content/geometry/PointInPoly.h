/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use to test a point inside any simple polygon. Pass
 *  boundary-order vertices p and query point q. Returns
 *  -1 outside, 0 on boundary, 1 inside; either orientation.
 *  \item Empty/point/segment allowed. $O(n)$ time, $O(1)$ space.
 *  Exact signs within Point bounds; reals may round.
 *  \end{itemize}
 * Usage: int where = pointInPoly(p,q);
 */
#pragma once
#include "Predicates.h"

template<class T> int pointInPoly(
		const vector<Point<T>>& p, Point<T> q) {
	bool in = false;
	for (int i = 0; i < sz(p); ++i) {
		auto a = p[i], b = p[(i+1)%sz(p)];
		if (onSeg(a,b,q)) return 0;
		if ((a.y > q.y) != (b.y > q.y))
			if ((a.cross(b,q) > 0) == (b.y > a.y))
				in = !in;
	}
	return in ? 1 : -1;
}
