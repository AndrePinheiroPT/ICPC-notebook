/**
 * Author: jet notebook
 * Summary: Orientação e pertença a segmentos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Estrada (0,0)--(4,0): casa (2,3) à esquerda?
 *  Portão (2,0) sobre a estrada?}
 *  Passar extremos a,b e ponto p. side devolve -1 à direita,
 *  0 na reta, 1 à esquerda, olhando de a para b.
 *  onSeg devolve bool; inclui extremos e aceita a=b.
 *  \item toReal(p) converte para P2 (Point<long double>).
 *  geoSgn compara com zero; eps opcional é a tolerância
 *  em unidades de comprimento ao quadrado, por omissão 0.
 *  Aritmética deve caber em T; reais podem arredondar.
 *  Tempo/espaço $O(1)$.
 *  \end{itemize}
 * Usage: Point<ll> a(0,0), b(4,0), p(2,3);
 *  int turn = side(a,b,p); // 1: esquerda
 *  bool gate = onSeg(a,b,Point<ll>(2,0)); // true
 *  bool beyond = onSeg(a,b,Point<ll>(5,0)); // false
 */
#pragma once
#include "Point.h"

using ld = long double;
using P2 = Point<ld>;

template<class T> P2 toReal(Point<T> p) {
	return P2(ld(p.x),ld(p.y));
}
template<class T> int geoSgn(T x, T eps=T{}) {
	return (x > eps)-(x < -eps);
}
template<class T>
int side(Point<T> a, Point<T> b, Point<T> p,
		T eps=0) {
	return geoSgn(a.cross(b,p),eps);
}
template<class T>
bool onSeg(Point<T> a, Point<T> b, Point<T> p,
		T eps=0) {
	return !side(a,b,p,eps) &&
		(p-a).dot(p-b) <= eps;
}
