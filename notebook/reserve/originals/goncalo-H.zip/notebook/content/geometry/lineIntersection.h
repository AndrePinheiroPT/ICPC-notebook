/**
 * Author: Victor Lecomte, chilli
 * Date: 2019-05-05
 * License: CC0
 * Source: Original KACTL lineIntersection.h
 * Summary: Interseção de duas retas infinitas
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Onde se cruzam as estradas (0,0)--(3,3)
 *  e (0,3)--(3,0)?}
 *  Passar s1,e1 e s2,e2; exigir s1!=e1 e s2!=e2.
 *  Devolve \{1,point\}, \{0,(0,0)\} se paralelas,
 *  \{-1,(0,0)\} se coincidentes. Só ler point se kind=1.
 *  \item Usar pontos reais para respostas fracionárias:
 *  a divisão inteira trunca. Produtos triplos devem caber no tipo.
 *  Coordenadas grandes ou retas quase paralelas podem perder precisão.
 *  \end{itemize}
 * Usage: using P = Point<long double>;
 *  P a(0,0), b(3,3), c(0,3), d(3,0);
 *  auto [kind,p] = lineInter(a,b,c,d);
 *  // kind=1, p=(1.5,1.5)
 * Time: O(1).
 */
#pragma once

#include "Point.h"

template<class P>
pair<int, P> lineInter(P s1, P e1, P s2, P e2) {
	auto d = (e1 - s1).cross(e2 - s2);
	if (d == 0) { // paralelas ou coincidentes
		int kind = s1.cross(e1,s2) == 0 ? -1 : 0;
		return {kind,P(0,0)};
	}
	auto p = s2.cross(e1, e2), q = s2.cross(e2, s1);
	return {1, (s1 * p + e1 * q) / d};
}
