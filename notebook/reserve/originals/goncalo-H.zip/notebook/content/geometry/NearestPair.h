/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use for the closest pair in an unordered point set p.
 *  Returns \{squared distance,\{input index1,index2\}\};
 *  fewer than 2 points gives \{0,\{-1,-1\}\}. Ties arbitrary,
 *  duplicates valid, input unchanged.
 *  \item solve(l,r) splits by x, merges by y, checks the narrow
 *  strip; test updates the best pair. Arithmetic must fit T;
 *  real values stay finite. No epsilon/sqrt. $O(n\log n)$
 *  time, $O(n)$ space; recursion depth $O(\log n)$.
 *  \end{itemize}
 * Usage: auto [d2,ids] = nearestPair(p);
 */
#pragma once
#include "Predicates.h"

template<class T>
auto nearestPair(const vector<Point<T>>& p) {
	if (sz(p) < 2) return pair{T(0),pair{-1,-1}};
	using Item = pair<Point<T>,int>;
	vector<Item> a, tmp(sz(p));
	for (int i = 0; i < sz(p); ++i)
		a.push_back({p[i],i});
	sort(a.begin(),a.end());
	T best = (p[0]-p[1]).dist2();
	pair<int,int> ids{0,1};
	auto test = [&](const Item& u, const Item& v) {
		T d = (u.first-v.first).dist2();
		if (d < best)
			best = d, ids = {u.second,v.second};
	};
	auto byY = [](const Item& u, const Item& v) {
		return u.first.y < v.first.y;
	};
	function<void(int,int)> solve = [&](int l, int r) {
		if (r-l <= 3) {
			for (int i = l; i < r; ++i)
				for (int j = i+1; j < r; ++j)
					test(a[i],a[j]);
			sort(a.begin()+l,a.begin()+r,byY);
			return;
		}
		int m = l+(r-l)/2;
		T x = a[m].first.x;
		solve(l,m); solve(m,r);
		merge(a.begin()+l,a.begin()+m,
			a.begin()+m,a.begin()+r,tmp.begin()+l,byY);
		copy_n(tmp.begin()+l,r-l,a.begin()+l);
		int k = 0;
		for (int i = l; i < r; ++i) {
			T dx = a[i].first.x-x;
			if (dx*dx >= best) continue;
			for (int j = k; j--;) {
				T dy = a[i].first.y-tmp[j].first.y;
				if (dy*dy >= best) break;
				test(a[i],tmp[j]);
			}
			tmp[k++] = a[i];
		}
	};
	solve(0,sz(a));
	return pair{best,ids};
}
