/**
 * Author: jet notebook
 * Summary: Interseção de dois segmentos finitos
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Vedações x=0..4 e x=2..6 sobre y=0.
 *  Encontrar os extremos da parte comum.}
 *  Passar extremos a,b e c,d como Point<ll> ou P2.
 *  Devolve zero pontos, um ponto ou dois extremos da sobreposição,
 *  ordenados por (x,y). Permite contacto e segmentos de comprimento zero.
 *  \item Testes inteiros exatos dentro dos limites de Point;
 *  pontos P2 devolvidos são aproximados.
 *  Testes reais comparam com zero. Tempo/espaço $O(1)$.
 *  \end{itemize}
 * Usage: using P = Point<ll>;
 *  auto points = segInter(P(0,0),P(4,0),
 *      P(2,0),P(6,0)); // {(2,0),(4,0)}
 */
#pragma once
#include "Predicates.h"
#include "lineIntersection.h"

template<class T>
vector<P2> segInter(Point<T> a, Point<T> b,
		Point<T> c, Point<T> d) {
	if (side(a,b,c)*side(a,b,d) < 0 &&
			side(c,d,a)*side(c,d,b) < 0) {
		P2 A=toReal(a), B=toReal(b);
		P2 C=toReal(c), D=toReal(d);
		if ((B-A).dist2() > (D-C).dist2()) {
			swap(A,C); swap(B,D);
		}
		auto hit = lineInter(P2(),B-A,C-A,D-A);
		return {A+hit.second};
	}
	vector<Point<T>> q;
	for (auto p : {a,b})
		if (onSeg(c,d,p)) q.push_back(p);
	for (auto p : {c,d})
		if (onSeg(a,b,p)) q.push_back(p);
	sort(q.begin(),q.end());
	q.erase(unique(q.begin(),q.end()),q.end());
	vector<P2> ans;
	for (auto p : q) ans.push_back(toReal(p));
	return ans;
}
