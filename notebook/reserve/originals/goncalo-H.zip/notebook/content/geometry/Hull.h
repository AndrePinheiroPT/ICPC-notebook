/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use to wrap a point set with its smallest convex polygon.
 *  \textbf{Input:} unordered points p. Returns unique hull vertices
 *  in CCW order, without a repeated closing vertex or
 *  points lying between two others on a straight edge.
 *  \item Collinear input returns endpoints; empty/one point valid.
 *  $O(n\log n)$ time, $O(n)$ space. Point bounds apply;
 *  real signs may round near a straight line.
 *  \end{itemize}
 * Usage: auto h = hull(p);
 */
#pragma once
#include "Predicates.h"

template<class T>
vector<Point<T>> hull(vector<Point<T>> p) {
	sort(p.begin(), p.end());
	p.erase(unique(p.begin(),p.end()),p.end());
	int n = sz(p), k = 0;
	if (n < 2) return p;
	vector<Point<T>> h(2*n);
	for (auto q : p) {
		while (k >= 2 &&
			h[k-2].cross(h[k-1],q) <= 0) --k;
		h[k++] = q;
	}
	for (int i = n-2, t = k+1; i >= 0; --i) {
		while (k >= t &&
			h[k-2].cross(h[k-1],p[i]) <= 0) --k;
		h[k++] = p[i];
	}
	h.resize(k-1);
	return h;
}
