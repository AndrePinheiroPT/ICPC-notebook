/**
 * Author: jet notebook
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Use to clip a convex polygon by a straight boundary.
 *  \textbf{Input:} real vertices p in order, distinct points a,b.
 *  Returns the part LEFT of a to b, including the line;
 *  vertex order is preserved, no repeated closing vertex.
 *  \item Empty/point/segment allowed; add avoids duplicate
 *  vertices. Exact sign tests (eps=0), real rounding applies.
 *  $O(n)$ time/extra space.
 *  \end{itemize}
 * Usage: auto kept = convexCut(p,a,b);
 */
#pragma once
#include "Predicates.h"

vector<P2> convexCut(const vector<P2>& p,
		P2 a, P2 b) {
	assert(!(a == b));
	vector<P2> out;
	auto add = [&](P2 q) {
		if (out.empty() || !(out.back() == q))
			out.push_back(q);
	};
	int n = sz(p);
	for (int i = 0; i < n; ++i) {
		P2 u = p[i], v = p[(i+1)%n];
		ld s = a.cross(b,u), t = a.cross(b,v);
		if (s >= 0) add(u);
		if (n == 2 && i == 1) continue;
		if ((s < 0 && t > 0) || (s > 0 && t < 0))
			add(u+(v-u)*(s/(s-t)));
	}
	if (sz(out) > 1 && out[0] == out.back())
		out.pop_back();
	return out;
}
