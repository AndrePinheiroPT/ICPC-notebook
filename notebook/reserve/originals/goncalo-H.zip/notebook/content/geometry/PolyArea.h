/**
 * Author: jet notebook
 * Summary: Área a partir do contorno de um polígono
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Terreno com cantos (0,0),(3,0),(3,2),(0,2):
 *  calcular a área.}
 *  Passar vértices de um polígono simples pela ordem do contorno;
 *  não repetir o primeiro no fim. Devolve o dobro da área orientada,
 *  positiva no sentido anti-horário (CCW).
 *  \item Área = abs(result)/2.0. Vazio/ponto/segmento dá 0.
 *  Produtos e soma devem caber em T. Tempo $O(n)$, espaço $O(1)$.
 *  \end{itemize}
 * Usage: using P = Point<ll>;
 *  vector<P> plot{P(0,0),P(3,0),P(3,2),P(0,2)};
 *  ll twice = polyArea2(plot); // 12, CCW
 *  ld area = abs(twice)/2.0L; // 6
 */
#pragma once
#include "Predicates.h"

template<class T>
T polyArea2(
		const vector<Point<T>>& p) {
	T ans = 0;
	for (int i = 0; i < sz(p); ++i)
		ans += p[i].cross(p[(i+1)%sz(p)]);
	return ans;
}
