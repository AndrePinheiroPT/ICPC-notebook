/**
 * Author: jet notebook
 * Summary: Listar todos os divisores positivos de um número.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Equipas iguais que dividem 12 alunos podem ter 1,2,3,4,6,12 elementos.
 *  \item Passa fatores primos ORDENADOS com repetições, não n.
 *  O produto tem de caber em T. Devolve divisores positivos sem ordem garantida;
 *  fatores vazios (n=1) dão \{1\}. Ordena se necessário.
 *  \item Para cada primo, acrescenta divisores antigos vezes as suas potências.
 *  Tempo/resultado $O(\tau(n))$; tau é o número de divisores.
 *  \end{itemize}
 * Usage: vector<ll> factors{2,2,3}; // fatorização de 12
 *  auto d = divisors(factors);
 *  sort(d.begin(),d.end());
 *  assert((d == vector<ll>{1,2,3,4,6,12}));
 */
#pragma once

template<class T>
vector<T> divisors(const vector<T>& f) {
	vector<T> d{1};
	for (int i = 0; i < sz(f);) {
		int k = sz(d), j = i;
		T power = 1;
		while (j < sz(f) && f[j] == f[i]) {
			power *= f[i];
			for (int q = 0; q < k; ++q)
				d.push_back(d[q]*power);
			++j;
		}
		i = j;
	}
	return d;
}
