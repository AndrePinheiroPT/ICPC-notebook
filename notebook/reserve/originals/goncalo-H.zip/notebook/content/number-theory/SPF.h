/**
 * Author: jet notebook
 * Summary: Fatorizar rapidamente muitos inteiros positivos pequenos.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Para muitas consultas até 100, pré-calcula uma vez;
 *  fatoriza 60 e verifica se 97 é primo.
 *  \item SPF(lim) cobre [0,lim), lim>=0. p[x] é o menor fator primo;
 *  para x>=2, p[x]==x indica primo. p[0]=0, p[1]=1 quando existem.
 *  \item factor(x), 1<=x<lim, devolve fatores primos ordenados com repetições;
 *  factor(1) é vazio. Construção $O(lim\log\log lim)$, espaço O(lim);
 *  fatorização O(log x).
 *  \end{itemize}
 * Usage: SPF s(101); // limite superior excluído
 *  auto f = s.factor(60);
 *  assert((f == vi{2,2,3,5}));
 *  assert(s.p[97] == 97);
 *  assert(s.factor(1).empty());
 */
#pragma once

struct SPF {
	vi p;
	SPF(int lim) : p(lim) {
		iota(p.begin(), p.end(), 0);
		for (int i = 2; i <= (lim-1)/i; ++i)
			if (p[i] == i)
				for (ll j = ll(i)*i; j < lim; j += i)
					if (p[j] == j) p[j] = i;
	}
	vi factor(int x) const {
		assert(1 <= x && x < sz(p));
		vi f;
		while (x > 1) {
			f.push_back(p[x]);
			x /= p[x];
		}
		return f;
	}
};
