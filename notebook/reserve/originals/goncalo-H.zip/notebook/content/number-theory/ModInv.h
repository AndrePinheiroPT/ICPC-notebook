/**
 * Author: jet notebook
 * Summary: Dividir módulo um número através do inverso.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Resolver $3x=4$ módulo 7: o inverso de 3 é 5, logo x=6.
 *  Multiplica pelo inverso em vez de usar divisão inteira.
 *  \item modInv(a,m) recebe a com sinal, m>1. Devolve optional v em
 *  [0,m) com a*v=1 módulo m, ou nullopt se gcd(a,m)!=1.
 *  Verifica antes de ler *inv.
 *  \item Acompanha o coeficiente de a no algoritmo de Euclides,
 *  com intermédios num tipo maior. Tempo O(log m), espaço extra O(1).
 *  \end{itemize}
 * Usage: auto inv = modInv(3,7);
 *  assert(inv && *inv == 5);
 *  ll x = 4*(*inv)%7;
 *  assert(x == 6);
 *  assert(!modInv(2,6)); // sem inverso quando gcd != 1
 */
#pragma once

optional<ll> modInv(ll a, ll m) {
	assert(m > 1);
	a %= m;
	if (a < 0) a += m;
	ll r = m, next = a;
	__int128 x = 0, y = 1;
	while (next) {
		ll q = r / next;
		ll rem = r % next;
		r = next; next = rem;
		__int128 z = x - (__int128)q*y;
		x = y; y = z;
	}
	if (r != 1) return nullopt;
	x %= m;
	if (x < 0) x += m;
	return ll(x);
}
