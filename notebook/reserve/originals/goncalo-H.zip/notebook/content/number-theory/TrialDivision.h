/**
 * Author: jet notebook
 * Summary: Fatorizar alguns inteiros sem pré-processamento.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Fatorizar 84 sem crivo: \{2,2,3,7\}. Passa inteiro n>=1;
 *  devolve fatores primos ordenados com repetições. n=1 devolve vazio.
 *  \item Testa divisores até sqrt(n), removendo cada fator por completo.
 *  Tempo $O(\sqrt n)$, resultado O(log n). Primos grandes são lentos:
 *  estima primeiro sqrt(n) iterações. Prefere SPF para muitas consultas
 *  com um limite comum.
 *  \end{itemize}
 * Usage: auto f = trialDivision(84LL);
 *  assert((f == vector<ll>{2,2,3,7}));
 *  assert((trialDivision(13LL) == vector<ll>{13}));
 *  assert(trialDivision(1LL).empty());
 */
#pragma once

template<class T> vector<T> trialDivision(T n) {
	assert(n >= 1);
	vector<T> f;
	for (T p = 2; p <= n/p; ++p) {
		while (n % p == 0) {
			f.push_back(p);
			n /= p;
		}
	}
	if (n > 1) f.push_back(n);
	return f;
}
