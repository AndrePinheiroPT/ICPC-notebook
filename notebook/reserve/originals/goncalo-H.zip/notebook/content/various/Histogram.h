/**
 * Author: jet notebook
 * Summary: Maior retângulo sob um histograma.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Encaixar o maior cartaz retangular sob colunas adjacentes.
 *  Recebe vetores inteiros de igual tamanho: alturas h>=0, larguras w>0.
 *  Larguras unitárias: w=vector<int>(n,1). A solução pode abranger
 *  várias barras adjacentes.
 *  \item Devolve (area,l,r) para barras [l,r); vazio/tudo zero dá
 *  (0,0,0), desempate arbitrário. x guarda prefixos de larguras;
 *  st contém barras à espera de um vizinho menor à direita.
 *  \item O(n) tempo/espaço. Somas de larguras e áreas têm de caber em ll.
 *  \end{itemize}
 * Usage: vi height{2,1,4,4,1}, width(5,1);
 *  auto [area,l,r] = largestRectangle(height,width);
 *  // area=8, barras [2,4); não é a altura de uma só barra
 */
#pragma once

template<class H, class W>
tuple<ll,int,int> largestRectangle(
		const vector<H>& h, const vector<W>& w) {
	int n = sz(h), left = 0, right = 0;
	vector<ll> x(n+1);
	for (int i = 0; i < n; ++i)
		x[i+1] = x[i]+ll(w[i]);
	vi st;
	ll best = 0;
	for (int r = 0; r <= n; ++r) {
		while (!st.empty() &&
				(r == n || h[st.back()] >= h[r])) {
			int j = st.back(); st.pop_back();
			int l = st.empty() ? 0 : st.back()+1;
			ll area = ll(h[j])*(x[r]-x[l]);
			if (area > best) {
				best = area; left = l; right = r;
			}
		}
		if (r < n) st.push_back(r);
	}
	return {best,left,right};
}
