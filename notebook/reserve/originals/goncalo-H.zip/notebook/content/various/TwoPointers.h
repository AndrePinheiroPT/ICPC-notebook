/**
 * Author: team notebook
 * Summary: Encontrar subarrays longos que respeitam um limite.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Até k categorias:} \{1,2,1,3\}, k=2 dá
 *  [0,3). longestKDistinct(a,k) exige k>=0 e valores comparáveis;
 *  devolve o primeiro intervalo máximo [l,r); vazio dá [0,0).
 *  Frequências descrevem a janela; apagar contagens zero. Com map:
 *  $O(n\log(D+1))$ tempo, $O(D)$ espaço; D é o máximo de valores
 *  distintos guardados.
 *  \item \textbf{Custos dentro do orçamento:} longestSumAtMost(a,limit)
 *  exige valores NÃO NEGATIVOS, limit>=0 e soma total em ll.
 *  Devolve o primeiro intervalo máximo [l,r); $O(n)$ tempo, $O(1)$ espaço.
 *  Valores negativos invalidam a regra de encolher.
 *  \item Avançar r, depois l até a janela ser válida. Retirar à esquerda
 *  não piora estas condições; cada extremo avança no máximo n vezes.
 *  A janela é [l,r). O par devolve posições; a diferença é o comprimento.
 *  \end{itemize}
 * Usage: auto [l,r] = longestKDistinct(vi{1,2,1,3},2);
 *  // l=0, r=3; comprimento r-l
 *  auto w = longestSumAtMost(vector<ll>{2,1,3},3);
 *  // {0,2}
 */
#pragma once

template<class T>
pair<int,int> longestKDistinct(const vector<T>& a, int k) {
	assert(k >= 0);
	map<T,int> freq;
	pair<int,int> best{0,0};
	for (int l = 0, r = 0; r < sz(a); ) {
		++freq[a[r++]];
		while (sz(freq) > k) {
			auto it = freq.find(a[l++]);
			if (--it->second == 0) freq.erase(it);
		}
		if (r-l > best.second-best.first) best = {l,r};
	}
	return best;
}
pair<int,int> longestSumAtMost(const vector<ll>& a, ll limit) {
	assert(limit >= 0);
	ll sum = 0;
	pair<int,int> best{0,0};
	for (int l = 0, r = 0; r < sz(a); ) {
		assert(a[r] >= 0);
		sum += a[r++];
		while (sum > limit) sum -= a[l++];
		if (r-l > best.second-best.first) best = {l,r};
	}
	return best;
}
