/**
 * Author: team notebook
 * Summary: Trocar coordenadas grandes por índices ordenados pequenos.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Coordenadas grandes precisam de índices pequenos: \{50,10,50\}
 *  dá ranks \{1,0,1\}, values \{10,50\}.
 *  \item compressCoordinates(a) devolve (values,rank). values é
 *  ordenado e sem repetições; values[rank[i]]=a[i]. Valores iguais
 *  têm o mesmo rank, preservando a ordem. Comprimir TODOS os valores
 *  comparados em conjunto.
 *  \item Distâncias/larguras usam diferenças ORIGINAIS
 *  values[j]-values[i], não j-i; verificar overflow. Exige
 *  < e == consistentes (sem NaN); $n<\mathrm{INT\_MAX}$ para índices int.
 *  \item Não altera o input; vazio dá dois vetores vazios.
 *  $O(n\log n)$ tempo, $O(n)$ espaço extra.
 *  \end{itemize}
 * Usage: auto [values,rank] = compressCoordinates(vi{50,10,50});
 */
#pragma once

template<class T>
pair<vector<T>,vi> compressCoordinates(const vector<T>& a) {
	vector<T> values = a;
	sort(values.begin(),values.end());
	values.erase(unique(values.begin(),values.end()),
		values.end());
	vi rank;
	for (const T& x : a) {
		auto it = lower_bound(values.begin(),values.end(),x);
		rank.push_back(int(it-values.begin()));
	}
	return {values,rank};
}
