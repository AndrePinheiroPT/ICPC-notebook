/**
 * Author: jet notebook
 * Summary: Agregar valores de todos os subconjuntos ou superconjuntos.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Contar receitas com os ingredientes disponíveis: bit i indica
 *  ingrediente i, e cada conjunto necessário é uma máscara.
 *  \item Recebe a de tamanho $2^k$: a[mask] é o valor desse conjunto.
 *  sos(a) substitui cada entrada pela soma das submáscaras;
 *  sos(a,true) usa supermáscaras. Sem retorno: altera o vetor recebido.
 *  \item small/big diferem num bit; op é adição por defeito.
 *  Outras operações têm de ser associativas e comutativas.
 *  Os valores intermédios têm de caber em T.
 *  \item $O(k2^k)$ operações, O(1) espaço extra.
 *  \end{itemize}
 * Usage: vi recipe(1<<3);
 *  recipe[1] = recipe[3] = 1; // requisitos 001 e 011
 *  sos(recipe);
 *  int count = recipe[3]; // 011 disponível satisfaz 2
 *  // recipe[2]=0: apenas 010 não satisfaz nenhuma
 */
#pragma once

template<class T, class F = plus<T>>
void sos(vector<T>& a, bool supersets = false,
		F op = {}) {
	int n = sz(a);
	assert(n > 0 && !(n & (n-1)));
	for (int bit = 1; bit < n; bit <<= 1) {
		for (int mask = 0; mask < n; ++mask) {
			if (mask & bit) continue;
			int small = mask, big = mask | bit;
			if (supersets) a[small] = op(a[small],a[big]);
			else a[big] = op(a[big],a[small]);
		}
	}
}
