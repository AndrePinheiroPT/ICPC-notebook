/**
 * Author: team notebook
 * Summary: Mínimo de cada janela deslizante.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Dar a menor temperatura de cada período de três dias.
 *  \item Recebe a,k com k>0. Devolve índices: ans[l] localiza o
 *  mínimo em [l,l+k); o valor é a[ans[l]]. Vazio se k>n;
 *  empates escolhem o mais à direita.
 *  \item q guarda candidatos: retirar expirados da frente e dominados
 *  de trás. Para máximos trocar >= por <=. Numa janela [l,r),
 *  inserir r-1 e expirar índices <l; ambos os extremos só avançam.
 *  Processar janelas da esquerda para a direita.
 *  \item O(n) tempo, O(min(n,k)) espaço extra mais o resultado.
 *  \end{itemize}
 * Usage: vi temperature{4,2,5,1,3};
 *  auto at = slidingMin(temperature,3); // {1,3,3}
 *  vi minimum;
 *  for (int i : at) minimum.push_back(temperature[i]);
 *  // minimum={2,1,1}
 */
#pragma once

template<class T>
vi slidingMin(const vector<T>& a, int k) {
	assert(k > 0);
	deque<int> q;
	vi ans;
	for (int r = 0; r < sz(a); ++r) {
		while (!q.empty() && q.front() <= r-k)
			q.pop_front();
		while (!q.empty() && a[q.back()] >= a[r])
			q.pop_back();
		q.push_back(r);
		if (r >= k-1) ans.push_back(q.front());
	}
	return ans;
}
