/**
 * Author: jet notebook
 * Summary: Obter a maior subsequência crescente.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Remover o mínimo de alturas para as restantes crescerem
 *  estritamente. As posições mantêm a ordem, mas não precisam
 *  de ser adjacentes. Pode saltar valores, nunca reordená-los.
 *  \item lis(a) devolve ÍNDICES escolhidos; os valores são a[id].
 *  lis(a,true) permite valores iguais. Input vazio dá vazio;
 *  desempate arbitrário.
 *  \item tail[k] termina uma subsequência de comprimento k+1 com
 *  o menor valor final; par permite reconstruí-la. Só exige <;
 *  tipo inferido de a. O(n log n) tempo, O(n) espaço.
 *  \end{itemize}
 * Usage: vi height{3,1,2,2,4};
 *  auto ids = lis(height); // índices das 3 alturas mantidas
 *  int removed = sz(height)-sz(ids); // 2
 *  auto weak = lis(height,true); // permite iguais: mantém 4
 */
#pragma once

template<class T> vi lis(const vector<T>& a,
		bool nondecreasing = false) {
	vi tail, par(sz(a),-1);
	for (int i = 0; i < sz(a); ++i) {
		int l = 0, r = sz(tail);
		while (l < r) {
			int m = l + (r-l)/2;
			bool extend = nondecreasing
				? !(a[i] < a[tail[m]]) : a[tail[m]] < a[i];
			if (extend) l = m+1;
			else r = m;
		}
		if (l > 0) par[i] = tail[l-1];
		if (l == sz(tail)) tail.push_back(i);
		else tail[l] = i;
	}
	vi ans;
	int v = tail.empty() ? -1 : tail.back();
	for (; v >= 0; v = par[v]) ans.push_back(v);
	reverse(ans.begin(),ans.end());
	return ans;
}
