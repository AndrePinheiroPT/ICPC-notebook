/**
 * Author: team notebook
 * Summary: Vizinho menor mais próximo de cada elemento.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Para cada prédio, encontrar o anterior mais próximo
 *  estritamente mais baixo. Altura igual não conta; útil para
 *  extensões e fronteiras de subarrays.
 *  \item Recebe vetor a; devolve índices. Por defeito: ESTRITAMENTE
 *  menor à esquerda, ausente=-1. right=true procura à direita,
 *  ausente=n. Usar as posições como fronteiras, não como valores.
 *  \item Candidatos na stack têm valores crescentes; pop >= remove
 *  empates. Para vizinhos <=, usar pop >; inverter comparações para maior.
 *  Contribuições de subarrays com empates exigem uma fronteira estrita
 *  e outra não estrita.
 *  \item O(n) tempo/espaço.
 *  \end{itemize}
 * Usage: vi height{3,1,2,2};
 *  auto left = nearestSmaller(height); // {-1,-1,1,1}
 *  auto right = nearestSmaller(height,true); // {1,4,4,4}
 */
#pragma once

template<class T>
vi nearestSmaller(const vector<T>& a, bool right = false) {
	int n = sz(a);
	vi ans(n,right ? n : -1), st;
	for (int t = 0; t < n; ++t) {
		int i = right ? n-1-t : t;
		while (!st.empty() && a[st.back()] >= a[i])
			st.pop_back();
		if (!st.empty()) ans[i] = st.back();
		st.push_back(i);
	}
	return ans;
}
