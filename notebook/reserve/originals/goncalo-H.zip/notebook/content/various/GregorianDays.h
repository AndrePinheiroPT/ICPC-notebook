/**
 * Author: jet notebook
 * Summary: Converter datas em números de dias.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Contar dias entre datas, incluindo anos bissextos. Subtrair
 *  resultados para dias decorridos; somar um para contagem inclusiva.
 *  \item Recebe data gregoriana válida y,m,d; mês/dia começam em 1.
 *  Devolve dias com sinal desde 1970-01-01 (devolve 0).
 *  Funciona antes de 1970 e com ano 0 (antes de 1 d.C.).
 *  Datas anteriores à referência dão valores negativos.
 *  \item $-10^{12}\le y\le10^{12}$; sem lacunas de mudanças
 *  históricas de calendário. O(1) tempo/espaço; resultado cabe em ll.
 *  \end{itemize}
 * Usage: ll first = gregorianDays(2024,2,28);
 *  ll last = gregorianDays(2024,3,1);
 *  ll elapsed = last-first; // 2
 *  ll inclusive = elapsed+1; // 3 datas
 */
#pragma once
#include "../math/IntDivision.h"

ll gregorianDays(ll y, int m, int d) {
	y -= m <= 2;
	ll era = floorDiv(y,400LL), z = y-era*400;
	int day = (153*(m+(m>2 ? -3 : 9))+2)/5+d-1;
	ll off = z*365+z/4-z/100+day;
	return era*146097+off-719468;
}
