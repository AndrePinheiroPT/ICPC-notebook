/**
 * Author: jet notebook
 * Summary: Cobrir um intervalo com o mínimo de intervalos.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Cobrir todas as horas em [0,10) com o mínimo de turnos.
 *  Pode haver sobreposição; uma lacuna torna a cobertura impossível.
 *  \item Recebe seg=\{(l,r),...\},L,R; intervalos/alvo são [l,r).
 *  Coordenadas inteiras ou reais, l<=r, L<=R, sem NaN.
 *  \item Devolve IDs originais na ordem da cobertura; nullopt se
 *  impossível, vazio se L=R. Escolhe sempre quem alcança mais longe.
 *  Input inalterado. O(n log n) tempo, O(n) espaço extra.
 *  seg[id] recupera cada turno escolhido.
 *  \end{itemize}
 * Usage: vector<pair<ll,ll>> shift{{0,3},{0,5},{4,10}};
 *  auto chosen = coverIntervals(shift,0LL,10LL);
 *  int count = chosen ? sz(*chosen) : -1; // 2
 *  // chosen contém os IDs originais {1,2}
 */
#pragma once

template<class T> optional<vi> coverIntervals(
		const vector<pair<T,T>>& seg, T L, T R) {
	if (L == R) return vi{};
	vi ord(sz(seg)), ans;
	iota(ord.begin(),ord.end(),0);
	sort(ord.begin(),ord.end(),[&](int a,int b) {
		return seg[a] < seg[b];
	});
	int i = 0;
	while (L < R) {
		T reach = L;
		int id = -1;
		while (i < sz(ord) &&
				seg[ord[i]].first <= L) {
			int j = ord[i++];
			if (reach < seg[j].second) {
				reach = seg[j].second; id = j;
			}
		}
		if (id < 0) return nullopt;
		ans.push_back(id); L = reach;
	}
	return ans;
}
