/**
 * Author: notebook contributors
 * Summary: Soluções curtas de problemas comuns de programação dinâmica.
 * Description: Implementa os exemplos acima. ll é long long; índices começam
 *  em 0. Módulo int positivo (por defeito $10^9+7$);
 *  tamanhos/capacidades abaixo de INT\_MAX. Devolve valores/contagens,
 *  sem reconstrução.
 * Usage: auto [linear,circular] = maxSubarray({5,-8,6}); // 6,11
 *  ll best = knapsack01({2,3,4},{4,5,7},5); // 9
 *  int few = minCoins({1,2},3); // 2 moedas
 *  int ways = coinWays({1,2},3); // 2 escolhas sem ordem
 *  int common = lcsLength("abc","ac"); // 2
 *  int paths = gridPaths({"...","..."}); // 3
 */
#pragma once

// Array não vazio -> {melhor soma linear, melhor soma circular}.
pair<ll,ll> maxSubarray(const vector<ll>& a) {
	assert(!a.empty());
	ll endMax = a[0], best = a[0], total = a[0];
	ll endMin = a[0], worst = a[0];
	for (int i = 1; i < sz(a); ++i) {
		endMax = max(a[i],endMax+a[i]);
		endMin = min(a[i],endMin+a[i]);
		best = max(best,endMax);
		worst = min(worst,endMin);
		total += a[i];
	}
	return {best,best < 0 ? best : max(best,total-worst)};
}

// Cada item uma vez; capacidade até W; pode não escolher nada.
ll knapsack01(const vi& w, const vector<ll>& v, int W) {
	assert(sz(w) == sz(v) && 0 <= W && W < INT_MAX);
	vector<ll> dp(W+1);
	for (int i = 0; i < sz(w); ++i) {
		assert(w[i] >= 0);
		for (int x = W; x >= w[i]; --x)
			dp[x] = max(dp[x],dp[x-w[i]]+v[i]);
	}
	return dp[W];
}

// Moedas positivas ilimitadas -> mínimo, ou -1 se impossível.
int minCoins(const vi& coins, int S) {
	assert(0 <= S && S < INT_MAX);
	for (int c : coins) assert(c > 0);
	vi dp(S+1,S+1); dp[0] = 0;
	for (int s = 1; s <= S; ++s)
		for (int c : coins) if (c <= s && dp[s-c] < S+1)
			dp[s] = min(dp[s],dp[s-c]+1);
	return dp[S] == S+1 ? -1 : dp[S];
}

// Moedas positivas DISTINTAS ilimitadas -> combinações sem ordem.
int coinWays(const vi& coins, int S, int mod = 1000000007) {
	assert(0 <= S && S < INT_MAX && mod > 0);
	vi dp(S+1); dp[0] = 1%mod;
	for (int c : coins) {
		assert(c > 0);
		for (int s = c; s <= S; ++s)
			dp[s] = int((dp[s]+ll(dp[s-c]))%mod);
	}
	return dp[S];
}

// Pode saltar caracteres; devolve apenas o comprimento da LCS.
int lcsLength(const string& a, const string& b) {
	int n = sz(a), m = sz(b);
	vi prev(m+1), cur(m+1);
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j)
			cur[j] = a[i-1] == b[j-1] ? prev[j-1]+1
				: max(prev[j],cur[j-1]);
		swap(prev,cur);
	}
	return prev[m];
}

// Só baixo/direita; '.' livre, '#' bloqueado; devolve caminhos.
int gridPaths(const vector<string>& g, int mod = 1000000007) {
	assert(mod > 0);
	int n = sz(g), m = n ? sz(g[0]) : 0;
	for (const auto& row : g) assert(sz(row) == m);
	if (!n || !m) return 0;
	vi dp(m); dp[0] = 1%mod;
	for (int r = 0; r < n; ++r)
		for (int c = 0; c < m; ++c)
			if (g[r][c] == '#') dp[c] = 0;
			else if (c) dp[c] = int((dp[c]+ll(dp[c-1]))%mod);
	return dp[m-1];
}
