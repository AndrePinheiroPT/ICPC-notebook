/**
 * Author: zyndek; adapted for the notebook
 * Summary: Somas possíveis usando cada item uma vez.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item Pacotes de pesos 3 e 7 permitem somar 10, mas não 5;
 *  cada um pode ser usado no máximo uma vez.
 *  \item Recebe pesos não negativos w e constante N>0.
 *  subsetBits<N>(w) devolve bits das somas possíveis [0,N),
 *  incluindo 0; ignora pesos >=N.
 *  \item dp[s] indica se s é possível. dp<<x soma x às somas antigas;
 *  OR permite não escolher o item. Não devolve os itens escolhidos.
 *  Um bit ligado indica possibilidade, não o número de maneiras.
 *  \item $O(n\lceil N/B\rceil)$ tempo, $O(\lceil N/B\rceil)$ palavras;
 *  B é o número de bits por palavra da máquina.
 *  \end{itemize}
 * Usage: vi weight{3,7};
 *  auto possible = subsetBits<11>(weight); // somas 0..10
 *  bool ten = possible[10], five = possible[5]; // true,false
 */
#pragma once

template<size_t N, class T>
bitset<N> subsetBits(const vector<T>& w) {
	static_assert(N > 0);
	bitset<N> dp;
	dp[0] = 1;
	for (T x : w) {
		assert(x >= 0);
		if (uintmax_t(x) < N) dp |= dp << size_t(x);
	}
	return dp;
}
