/**
 * Author: Team reference
 * Summary: Converter padrões comuns de problemas em código funcional.
 * Description: \begin{itemize}[nosep,leftmargin=*]
 *  \item \textbf{Pares iguais:} agrupar produtos por uma chave
 *  (ex.: price/d). equalKeyPairs(keys) conta pares de índices de
 *  chave igual, sem ordem. Ordenar; cada novo item emparelha com os
 *  anteriores do grupo. Aceita negativos. $O(n\log n)$ tempo, $O(n)$ cópia.
 *  \item \textbf{Janelas circulares:}
 *  countCircularWindows(s,k,wanted,need) conta inícios cujos k símbolos
 *  seguintes contêm pelo menos need cópias de wanted. $1\le k\le n$,
 *  need>=0. Retirar o símbolo que sai/somar o que entra; exatamente n inícios.
 *  $O(n)$ tempo, $O(1)$ espaço.
 *  \item \textbf{Tempo ocupado:} coveredTime(intervals) recebe
 *  intervalos não negativos [l,r), l<=r, extremos em ll. Ordena e funde
 *  sobreposições, fechando o intervalo numa lacuna. Devolve comprimento
 *  da união, não cobertura mínima. $O(n\log n)$ tempo, $O(n)$ cópia.
 *  \item \textbf{Dividir mensagem em palavras do dicionário:} construir
 *  Trie e chamar splitIntoWords(s,t). Símbolos a-z; palavras reutilizáveis.
 *  ready[i] indica se o prefixo [0,i) admite divisão; ready[0]=true.
 *  A partir de inícios válidos, seguir arestas do trie; terminações marcam
 *  novos extremos válidos. Devolve ready[n]. Palavras a,ab,bc permitem
 *  abc=a+bc; o greedy ab falha. Mensagem vazia é válida; palavras vazias
 *  não têm efeito. $O(n(L+1))$ tempo no pior caso, L palavra mais longa;
 *  $O(n)$ espaço extra. A divisão explora alternativas em vez de aceitar
 *  logo a primeira correspondência.
 *  \item Comprimentos abaixo de INT\_MAX. Devolve respostas, sem os
 *  pares, janelas, intervalos ou fronteiras de palavras escolhidos.
 *  \end{itemize}
 * Usage: ll pairs = equalKeyPairs({4,4,7,4}); // 3
 *  int starts = countCircularWindows("##..",2,'#',1); // 3
 *  ll hours = coveredTime({{1,4},{3,7},{9,10}}); // 7
 *  Trie t; for (string w : {"a","ab","bc"}) t.insert(w);
 *  bool possible = splitIntoWords("abc",t); // true
 */
#pragma once
#include "../strings/AlphabetTrie.h"

ll equalKeyPairs(vector<ll> key) {
	sort(key.begin(),key.end());
	ll pairs = 0, run = 0;
	for (int i = 0; i < sz(key); ++i) {
		if (i == 0 || key[i] != key[i-1]) run = 0;
		pairs += run; ++run;
	}
	return pairs;
}
int countCircularWindows(const string& s, int k,
		char wanted, int need) {
	int n = sz(s);
	assert(1 <= k && k <= n && need >= 0);
	int count = 0, answer = 0;
	for (int i = 0; i < k; ++i) count += s[i] == wanted;
	for (int start = 0; start < n; ++start) {
		answer += count >= need;
		count -= s[start] == wanted;
		int next = int((ll(start)+k)%n);
		count += s[next] == wanted;
	}
	return answer;
}
ll coveredTime(vector<pair<ll,ll>> intervals) {
	if (intervals.empty()) return 0;
	for (auto [l,r] : intervals) assert(0 <= l && l <= r);
	sort(intervals.begin(),intervals.end());
	auto [left,right] = intervals[0];
	ll total = 0;
	for (auto [l,r] : intervals) {
		if (l > right) {
			total += right-left; left = l;
		}
		right = max(right,r);
	}
	return total+(right-left);
}
bool splitIntoWords(const string& s, const Trie& t) {
	vi ready(sz(s)+1); ready[0] = 1;
	for (int i = 0; i < sz(s); ++i) if (ready[i]) {
		int v = 0;
		for (int j = i; j < sz(s); ++j) {
			int c = s[j]-'a'; assert(0 <= c && c < 26);
			v = t.node[v].next[c];
			if (v == -1) break;
			if (t.node[v].terminal) ready[j+1] = 1;
		}
	}
	return ready.back();
}
